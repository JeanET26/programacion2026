package ar.edu.inspt.mundomarino.integracion;

import static org.assertj.core.api.Assertions.assertThat;

import ar.edu.inspt.mundomarino.soporte.ClienteHttp;
import ar.edu.inspt.mundomarino.soporte.ClienteHttp.Respuesta;
import ar.edu.inspt.mundomarino.soporte.Fabrica;
import ar.edu.inspt.mundomarino.soporte.PruebaHttp;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;

/** Autenticación, autorización, CSRF, CORS y sesiones, con el servidor HTTP real. */
class SeguridadApiIT extends PruebaHttp {

    @Test
    void sinSesionSeResponde401EnJson() {
        Respuesta r = cliente().get("/api/zonas");
        assertThat(r.estado()).isEqualTo(401);
        assertThat(r.json().get("mensaje").asText()).contains("iniciar sesión");
    }

    @Test
    void loginIncorrectoNoRevelaSiElUsuarioExiste() {
        fabrica.guia("guia.existe");
        assertThat(cliente().login("guia.existe", "Equivocada1").json().get("mensaje").asText())
                .isEqualTo(cliente().login("no.existe", "Equivocada1").json().get("mensaje").asText());
        assertThat(cliente().login("guia.existe", "Equivocada1").estado()).isEqualTo(401);
    }

    @Test
    void elLoginExigeTokenCsrf() {
        fabrica.guia("guia.a");
        Respuesta r = cliente().postSinCsrf("/api/auth/login", Map.of("nombreUsuario", "guia.a", "contrasena", Fabrica.CLAVE));
        assertThat(r.estado()).isEqualTo(403);
    }

    @Test
    void laCookieDeSesionEsHttpOnlyYSameSite() {
        fabrica.guia("guia.a");
        Respuesta r = cliente().login("guia.a", Fabrica.CLAVE);
        assertThat(r.estado()).isEqualTo(200);
        String cookie = String.join(";", r.encabezados().getOrDefault("set-cookie", List.of()));
        assertThat(cookie).contains("MMSESION=").containsIgnoringCase("HttpOnly").containsIgnoringCase("SameSite=Lax");
        assertThat(r.json().get("rol").asText()).isEqualTo("GUIA");
        assertThat(r.cuerpo()).doesNotContain("hash").doesNotContain("bcrypt");
    }

    @Test
    void unGuiaNoPuedeUsarRutasDeAdministracionNiDeCuidador() {
        fabrica.guia("guia.a");
        ClienteHttp guia = cliente();
        guia.login("guia.a", Fabrica.CLAVE);
        assertThat(guia.get("/api/empleados").estado()).isEqualTo(403);
        assertThat(guia.post("/api/zonas", Map.of("nombre", "X", "extensionM2", 10)).estado()).isEqualTo(403);
        assertThat(guia.get("/api/mi/especies").estado()).isEqualTo(403);
        assertThat(guia.get("/api/mi/recorridos").estado()).isEqualTo(200);
    }

    @Test
    void cadaGuiaRecibeSoloSusRecorridosSegunLaSesion() {
        UUID it = fabrica.itinerario(1, 45, fabrica.especie("Pez", fabrica.zona("Arrecife")));
        UUID lucia = fabrica.guia("guia.lucia");
        UUID martin = fabrica.guia("guia.martin");
        fabrica.horario(lucia, it, LocalTime.of(10, 0));
        fabrica.horario(martin, it, LocalTime.of(14, 0));
        ClienteHttp c = cliente();
        c.login("guia.martin", Fabrica.CLAVE);
        Respuesta r = c.get("/api/mi/recorridos?guiaId=" + lucia); // un parámetro de otro guía se ignora
        assertThat(r.json()).hasSize(1);
        assertThat(r.json().get(0).get("hora").asText()).isEqualTo("14:00");
    }

    @Test
    void lasModificacionesSinTokenCsrfSeRechazan() {
        ClienteHttp admin = comoAdministrador();
        assertThat(admin.postSinCsrf("/api/zonas", Map.of("nombre", "X", "extensionM2", 10)).estado()).isEqualTo(403);
        assertThat(admin.post("/api/zonas", Map.of("nombre", "X", "extensionM2", 10)).estado()).isEqualTo(201);
    }

    @Test
    void cerrarSesionInvalidaLaSesionEnElServidor() {
        fabrica.guia("guia.a");
        ClienteHttp c = cliente();
        c.login("guia.a", Fabrica.CLAVE);
        assertThat(c.get("/api/auth/yo").estado()).isEqualTo(200);
        assertThat(c.post("/api/auth/logout", null).estado()).isEqualTo(204);
        assertThat(c.get("/api/auth/yo").estado()).isEqualTo(401);
        assertThat(contar("SPRING_SESSION where PRINCIPAL_NAME = 'guia.a'")).isZero();
    }

    @Test
    void cambiarLaContrasenaCierraLasOtrasSesionesYMantieneLaActual() {
        fabrica.guia("guia.a");
        ClienteHttp pc = cliente();
        ClienteHttp celular = cliente();
        pc.login("guia.a", Fabrica.CLAVE);
        celular.login("guia.a", Fabrica.CLAVE);

        Respuesta r = pc.put("/api/auth/contrasena", Map.of("actual", Fabrica.CLAVE, "nueva", "NuevaClave2026"));
        assertThat(r.estado()).isEqualTo(204);
        pc.renovarCsrf();
        assertThat(pc.get("/api/auth/yo").estado()).isEqualTo(200);
        assertThat(celular.get("/api/auth/yo").estado()).isEqualTo(401);
        assertThat(cliente().login("guia.a", Fabrica.CLAVE).estado()).isEqualTo(401);
        assertThat(cliente().login("guia.a", "NuevaClave2026").estado()).isEqualTo(200);
    }

    @Test
    void siElAdministradorRestableceLaContrasenaSeCierranLasSesionesDelEmpleado() {
        UUID guia = fabrica.guia("guia.a");
        ClienteHttp empleado = cliente();
        empleado.login("guia.a", Fabrica.CLAVE);
        ClienteHttp admin = comoAdministrador();
        Respuesta r = admin.put("/api/empleados/" + guia, Map.of("contrasena", "Restablecida2026", "nombre", "Guía A",
                "direccion", "Calle 1", "telefono", "11 5555-0000", "fechaIngreso", "2024-01-01", "version", 0));
        assertThat(r.estado()).isEqualTo(200);
        assertThat(empleado.get("/api/mi/recorridos").estado()).isEqualTo(401);
    }

    @Test
    void demasiadosIntentosFallidosBloqueanTemporalmenteAlUsuario() {
        // Usuario exclusivo de esta prueba: el contador de intentos vive en memoria durante toda la ejecución.
        fabrica.guia("guia.bloqueo");
        for (int i = 0; i < 5; i++) {
            assertThat(cliente().login("guia.bloqueo", "Mala12345").estado()).isEqualTo(401);
        }
        assertThat(cliente().login("guia.bloqueo", Fabrica.CLAVE).estado()).isEqualTo(429);
    }

    @Test
    void corsSoloAceptaOrigenesConfigurados() {
        Respuesta permitido = cliente().preflight("/api/zonas", "http://localhost:5173");
        assertThat(permitido.estado()).isEqualTo(200);
        assertThat(permitido.encabezados().get("access-control-allow-origin")).containsExactly("http://localhost:5173");
        assertThat(permitido.encabezados().get("access-control-allow-credentials")).containsExactly("true");
        assertThat(cliente().preflight("/api/zonas", "http://sitio-malicioso.com").estado()).isEqualTo(403);
    }

    @Test
    void unaContrasenaImportadaDeLaV2FuncionaYSeActualizaABcrypt() {
        UUID id = UUID.randomUUID();
        jdbc.update("""
                insert into usuario (id, rol, nombre_usuario, hash_contrasena, nombre, direccion, telefono, fecha_ingreso)
                values (?, 'GUIA', 'guia.v2', ?, 'Guía v2', 'Calle', '11 5555-0000', '2024-01-01')""",
                id.toString(), "{pbkdf2-v2}" + ar.edu.inspt.mundomarino.unitarias.Pbkdf2LegadoPasswordEncoderTest.HASH_V2);
        assertThat(cliente().login("guia.v2", "Marino2026!").estado()).isEqualTo(200);
        assertThat(jdbc.queryForObject("select hash_contrasena from usuario where id = ?", String.class, id.toString()))
                .startsWith("{bcrypt}");
    }
}
