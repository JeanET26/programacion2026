# Cambios de la v2 (Ant + archivos) a la v3 (Maven + Spring Boot + MySQL + React)

El original se conserva sin modificar en `respaldo/`:
- `respaldo/v2-ant/GrupoCTema12/` — proyecto NetBeans/Ant de la v2 (sin `dist/` ni `javadoc/` generados).
- `respaldo/v1-original/` — archivo de datos `datos_mundo_marino.dat` y el `.jar` de la v1.

Las reglas de negocio de la v2 se mantienen todas; lo que cambia es dónde y cómo se aplican.

---

## 1. Construcción y estructura

| Antes (v2) | Ahora (v3) | Por qué |
|---|---|---|
| Proyecto NetBeans con Ant (`build.xml`, `nbproject/`) | `backend/` con **Maven** y **Maven Wrapper** (`./mvnw`, Maven 3.9.9) | Dependencias declaradas y reproducibles; se compila igual en cualquier máquina o en CI sin NetBeans |
| Un solo proyecto con todo | `backend/`, `frontend/`, `docs/` separados | El frontend y el backend se construyen, prueban y despliegan por separado |
| Sin perfiles | Perfiles `dev`, `prod`, `test`, `importacion` + variables de entorno | Ninguna contraseña en el código; cada entorno con su configuración |
| — | `docker-compose.yml` con MySQL 8 | Base reproducible para desarrollo |
| — | `.github/workflows/ci.yml` | Corre `./mvnw verify`, `npm test` y `npm run build` en cada push |

## 2. Persistencia

| Antes | Ahora | Por qué |
|---|---|---|
| Serialización de objetos en archivos (`.dat`/JSON) | **MySQL 8** con **Spring Data JPA + Hibernate** | Integridad (PK, FK, únicos, CHECK), transacciones y acceso concurrente real |
| El programa creaba los datos al iniciar | **Flyway**: `V1__esquema_inicial.sql`, `V2__sesiones_http.sql` | Esquema versionado; Hibernate solo valida (`ddl-auto: validate`) |
| DAO genérico sobre archivos | `Dao<T,ID>` (contrato) + `DaoJpa<T,ID>` (adaptador) que delega en un `JpaRepository` **privado del paquete** | Los servicios dependen del contrato, no de Spring Data. Ver `docs/ARQUITECTURA.md` |
| UUID en memoria | UUID guardado como `CHAR(36)` | Se conservan los IDs de la v1/v2 al importar. Ver `docs/RESPUESTAS_PROFESOR.md` |
| Sin control de concurrencia | `@Version` (bloqueo optimista) + versión enviada por el cliente; bloqueo pesimista ordenado para horarios | Dos administradores no se pisan; no pueden quedar horarios superpuestos. Ver `docs/CONCURRENCIA.md` |
| Datos de ejemplo siempre | Datos de demostración **solo en `dev` y con la base vacía** | Nunca reemplazan datos reales |

## 3. Backend: capas y diseño

- **Controladores REST** (`*Controller`) solo traducen HTTP ↔ DTO; no tienen reglas ni acceden a repositorios
  (lo controla una prueba de ArchUnit).
- **DTO** (`*Dtos`, records) con validación (`@NotBlank`, `@Size`, …). Nunca se devuelven entidades ni hashes.
- **Servicios** (`*Service`) con las reglas y los límites de transacción (`@Transactional`).
- **Entidades** validan sus propios invariantes (por ejemplo, un itinerario sin especies no puede existir).
- **Errores centralizados** en `ManejadorErrores` con un formato JSON único (`ApiError`) y códigos coherentes
  (400, 401, 403, 404, 405, 409, 500). Los nombres de restricciones de MySQL se traducen a mensajes claros.
- **Inyección por constructor** en todas las clases.
- **Puertos entre módulos** para no crear ciclos: `ValidadorCambioDuracion` (itinerario ← asignación) y
  `CierreSesiones` (personal ← seguridad).
- `Empleado` sigue abstracta. `Administrador` **ya no es `final`**: JPA/Hibernate necesitan poder crear
  subclases proxy de las entidades. Se explica en `docs/RESPUESTAS_PROFESOR.md`; `final` nunca fue un
  mecanismo de seguridad.
- **Consola eliminada** (decisión del grupo): la interfaz es la web.

## 4. Seguridad

| Antes | Ahora |
|---|---|
| Token propio en memoria; el logout no lo invalidaba | **Spring Security** con **sesión de servidor** (cookie `MMSESION`, `HttpOnly`, `SameSite=Lax`, `Secure` en prod), guardada en MySQL con Spring Session JDBC |
| PBKDF2 propio | `DelegatingPasswordEncoder` con **bcrypt** (sal incluida). Los hashes PBKDF2 de la v2 siguen funcionando y se **migran a bcrypt** en el siguiente login |
| La identidad venía del cliente | La identidad sale **siempre** de la sesión del servidor (`@AuthenticationPrincipal`) |
| — | **CSRF** con token por sesión; **CORS** con lista explícita de orígenes (`*` prohibido) |
| — | Cambio de contraseña propio o reseteo por el admin → se **cierran todas las sesiones** de ese usuario (la propia se renueva) |
| — | Límite de intentos fallidos de login en una ventana de 10 minutos: 5 por usuario y 30 por IP |
| — | Permisos por rol (`Permiso`) en lugar de comparar strings |

## 5. API REST (nueva)

Autenticación, perfil, cambio de contraseña; CRUD paginado de zonas, hábitats, especies, itinerarios y
personal; alta, cambio y baja de asignaciones; "mis recorridos" del guía y "mis especies" del cuidador.
Documentada con OpenAPI (Swagger UI en `dev`) y en `docs/API.md`.

## 6. Frontend (nuevo)

`frontend/` con **React 18 + Vite 5**, separado del backend. Panel del administrador (CRUD y asignaciones),
vista del guía, vista del cuidador y cuenta. Estados de carga y error, confirmaciones antes de borrar,
manejo de conflictos de versión (409) y de sesión vencida (401).

## 7. Importación de datos anteriores

- La v1 (`.dat`) se convirtió **una sola vez** a JSON (`herramientas/convertir-v1/`), leyendo el original sin modificarlo.
- Importador controlado (`importacion/`): conserva IDs, valida todo, detecta duplicados y referencias
  faltantes, **todo o nada** en una transacción, no toca los archivos de origen y escribe un informe.

## 8. Pruebas (nuevas)

- Unitarias: reglas de horarios, entidades, codificador PBKDF2 heredado.
- Arquitectura: ArchUnit (sin ciclos entre módulos, controladores sin repositorios).
- Integración con **MySQL real (Testcontainers)**: reglas de negocio, restricciones y rollback,
  concurrencia, contrato de cada DAO, seguridad HTTP, API REST, volumen (sin N+1), importación.
- Frontend: Vitest + Testing Library + MSW.

Qué se pudo ejecutar al preparar la entrega y qué no: **`docs/VERIFICACION.md`**.

## 9. Documentación (nueva)

`README.md`, `GUIA_PASO_A_PASO.md`, y en `docs/`: respuestas al profesor, arquitectura, API, base de datos,
seguridad, concurrencia, importación y respaldo, escalabilidad, verificación y diagramas (dominio,
arquitectura, módulos, base de datos, casos de uso, secuencia de asignación).
