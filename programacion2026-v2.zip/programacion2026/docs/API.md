# API REST

La documentación interactiva se genera sola a partir del código (OpenAPI):

- **Swagger UI:** http://localhost:8080/swagger-ui.html (perfil dev)
- **OpenAPI JSON:** http://localhost:8080/v3/api-docs

En producción ambas están desactivadas (`application-prod.yml`).

## Convenciones

- JSON en el cuerpo, UTF-8. Fechas `AAAA-MM-DD`, horas `HH:mm`, ids UUID.
- Las modificaciones (POST/PUT/DELETE) requieren la cookie de sesión **y** el encabezado `X-CSRF-TOKEN`.
- Los listados son paginados en el servidor: `?pagina=0&tamanio=20&orden=nombre&dir=asc&q=texto`
  (máximo 100 por página; solo se aceptan campos de orden permitidos).
- Al modificar se envía la `version` leída; si cambió, la respuesta es **409**.

Respuesta paginada:

```json
{ "contenido": [ ... ], "numero": 0, "tamanio": 20, "totalElementos": 57, "totalPaginas": 3 }
```

Error (siempre el mismo formato):

```json
{ "estado": 400, "mensaje": "Revisá los datos ingresados.", "errores": { "nombre": "El nombre es obligatorio." },
  "ruta": "/api/zonas", "fecha": "2026-10-19T23:59:00Z" }
```

| Código | Cuándo |
|---|---|
| 200 / 201 / 204 | Correcto / creado (con `Location`) / eliminado o sin contenido |
| 400 | Formato o dato inválido (validación, referencia inexistente, UUID mal formado) |
| 401 | Sin sesión o credenciales incorrectas |
| 403 | Sin permiso, o falta el token CSRF |
| 404 | No existe |
| 409 | Regla de negocio: duplicado, en uso, horario superpuesto, versión vieja o bloqueo |
| 429 | Demasiados intentos de login |
| 500 | Error inesperado (se registra con un código que también recibe el cliente) |

## Endpoints

### Autenticación
| Método | Ruta | Cuerpo / respuesta |
|---|---|---|
| GET | `/api/auth/csrf` | → `{ "encabezado": "X-CSRF-TOKEN", "token": "…" }` |
| POST | `/api/auth/login` | `{ nombreUsuario, contrasena }` → perfil + cookie |
| POST | `/api/auth/logout` | → 204 |
| GET | `/api/auth/yo` | → perfil `{ id, nombreUsuario, nombre, rol, permisos, direccion?, telefono?, fechaIngreso? }` |
| PUT | `/api/auth/contrasena` | `{ actual, nueva }` → 204 (cierra las otras sesiones) |

### Administración (permiso `ADMINISTRAR_PARQUE`)
| Recurso | Rutas | Cuerpo de alta / modificación |
|---|---|---|
| Zonas | `GET/POST /api/zonas`, `GET/PUT/DELETE /api/zonas/{id}`, `GET /api/zonas/opciones` | `{ nombre, extensionM2, version? }` |
| Hábitats | `/api/habitats` (ídem) | `{ nombre, clima, vegetacion, continentes[], version? }` |
| Especies | `/api/especies` (ídem; filtro `zonaId`) | `{ nombreEspanol, nombreCientifico, descripcion, zonaId?, habitatIds[], version? }` |
| Itinerarios | `/api/itinerarios` (ídem) | `{ numero (solo alta), duracionMinutos, longitudKm, maximoVisitantes, especieIds[], version? }` |
| Personal | `/api/empleados` (filtro `rol`), `GET /api/empleados/opciones?rol=GUIA` | alta: `{ rol, nombreUsuario, contrasena, nombre, direccion, telefono, fechaIngreso }`; modificación: lo mismo sin rol ni usuario, `contrasena` opcional (restablece) + `version` |
| Horarios | `GET/POST /api/asignaciones-guia` (filtros `guiaId`, `itinerarioId`), `PUT/DELETE /api/asignaciones-guia/{id}` | alta `{ guiaId, itinerarioId, hora }`; cambio `{ hora, version }` |
| Cuidados | `GET/POST /api/asignaciones-cuidado` (filtros `cuidadorId`, `especieId`), `PUT/DELETE …/{id}` | alta `{ cuidadorId, especieId, fechaAsignacion }`; cambio `{ fechaAsignacion, version }` |

### Consultas propias
| Método | Ruta | Permiso | Respuesta |
|---|---|---|---|
| GET | `/api/mi/recorridos` | `VER_RECORRIDOS_PROPIOS` | `[{ asignacionId, hora, horaFin, codigo, duracionMinutos, longitudKm, maximoVisitantes, zonas[], especies[{nombreEspanol, nombreCientifico}] }]` |
| GET | `/api/mi/especies` | `VER_ESPECIES_PROPIAS` | `[{ asignacionId, desde, nombreEspanol, nombreCientifico, descripcion, zona, habitats[{nombre, clima}], otrosCuidadores[] }]` |

### Operación
| GET | `/actuator/health` | Salud de la aplicación y de la base (público, sin detalles) |
|---|---|---|

## Ejemplo con curl (perfil dev)

```bash
C=cookies.txt
T=$(curl -s -c $C -b $C localhost:8080/api/auth/csrf | sed 's/.*"token":"\([^"]*\)".*/\1/')
curl -s -c $C -b $C -H "X-CSRF-TOKEN: $T" -H 'Content-Type: application/json' \
     -d '{"nombreUsuario":"admin.ana","contrasena":"Admin2026!"}' localhost:8080/api/auth/login
T=$(curl -s -c $C -b $C localhost:8080/api/auth/csrf | sed 's/.*"token":"\([^"]*\)".*/\1/')
curl -s -b $C "localhost:8080/api/zonas?tamanio=5"
curl -s -c $C -b $C -H "X-CSRF-TOKEN: $T" -H 'Content-Type: application/json' \
     -d '{"nombre":"Pingüinera","extensionM2":600}' localhost:8080/api/zonas
```
