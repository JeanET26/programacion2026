# Consistencia y concurrencia

Qué pasa si dos administradores hacen algo **al mismo tiempo**, o si una
operación falla a la mitad. Para cada riesgo: qué mecanismo lo protege, dónde
está y qué prueba lo verifica.

## 1. Operaciones fallidas: nada a medias

| Mecanismo | Dónde | Qué protege |
|---|---|---|
| `@Transactional` en cada servicio | `*Service.java` | Si algo falla, **rollback**: la base vuelve al estado anterior |
| `flush` al guardar y eliminar | `DaoJpa.guardar/eliminar` | Las violaciones de claves aparecen **dentro** de la transacción, no después |
| Entidades que validan todo **antes** de asignar | `Zona.asignar`, `Itinerario.asignar`... | Un dato inválido no deja el objeto modificado a medias |
| `open-in-view: false` + DTO | `application.yml`, `*Dtos.java` | Las entidades no salen del servicio; nadie las modifica fuera de una transacción |
| Éxito solo después del commit | El controlador responde al volver el servicio | Si el commit falla, el cliente recibe error, no "guardado" |
| Cierre de sesiones `afterCommit` | `CierreSesionesSpringSession` | Si el cambio de contraseña se deshace, no se cierra ninguna sesión |
| Importación en una transacción | `ImportadorDatos` | Todo o nada |

Pruebas: `RestriccionesYTransaccionesIT` (`siFallaUnaParte…`, `unaEdicionRechazadaNoCambiaNada`,
`unRestablecimientoDeContrasenaInvalido…`), `ImportacionIT`, `EntidadesTest.unaEdicionInvalidaNoDejaLaEntidadAMedias`.

## 2. Operaciones simultáneas

| Riesgo | Mecanismo | ¿Por qué alcanza? |
|---|---|---|
| Dos altas con el mismo nombre de zona / hábitat / científico / código / usuario | **Restricción `UNIQUE` en MySQL** (+ consulta previa para el mensaje) | La consulta previa sola NO alcanza (los dos ven "libre"). La base rechaza el segundo INSERT y `TraductorRestricciones` lo convierte en 409 con mensaje claro |
| Borrar algo mientras otro lo referencia | **Claves foráneas `ON DELETE RESTRICT`** | La base verifica la referencia en el momento del DELETE/INSERT, con sus propios bloqueos |
| Dos ediciones del mismo registro (una pisa a la otra) | **`@Version`** + versión enviada por el formulario | El UPDATE lleva `WHERE version = ?`: si otro guardó antes, no actualiza nada → 409 |
| Dos horarios superpuestos para el mismo guía | **Bloqueo pesimista de la fila del guía** (`SELECT … FOR UPDATE`) + `READ_COMMITTED` + única `(guia_id, hora)` | Ver sección 3 |
| Alargar un itinerario mientras se asigna a uno de sus guías | **`FOR UPDATE` del itinerario** al cambiar la duración y **`FOR SHARE`** al asignar; luego bloqueo de guías en orden | Ver sección 3 |
| Quitarle la zona a una especie mientras se arma un itinerario con ella | `FOR UPDATE` de la especie al editarla y `FOR SHARE` de las especies al armar el itinerario | Una espera a la otra; la segunda ve el resultado de la primera |

### Por qué no alcanzan los mecanismos "simples" para los horarios

- **Consulta previa sola:** dos transacciones consultan a la vez, ambas ven
  "libre" y ambas insertan.
- **Transacción sin coordinación:** en `REPEATABLE READ` cada una ve su foto
  inicial y no ve el INSERT de la otra; no hay ninguna fila en común que choque.
- **`@Version`:** solo detecta cambios sobre la MISMA fila. Dos INSERT de
  asignaciones distintas no modifican ninguna fila compartida.
- **`UNIQUE (guia_id, hora)`:** solo atrapa la misma hora exacta, no 10:00 contra 10:20.

## 3. La estrategia para horarios

1. **Bloqueo por guía.** Toda operación que agrega o mueve horarios de un guía
   empieza con `SELECT … FROM usuario WHERE id = ? FOR UPDATE`. Las operaciones
   sobre **el mismo guía** se hacen de a una; las de **otros guías** siguen en
   paralelo (no se bloquea toda la tabla ni la aplicación).
2. **El itinerario también se bloquea:** `FOR SHARE` al asignar (muchas
   asignaciones pueden leerlo a la vez) y `FOR UPDATE` al cambiar su duración.
3. **Orden fijo de bloqueos** en todo el sistema: itinerario → especies → guías
   (ordenados por id). Siempre en el mismo orden, para que no haya interbloqueos.
4. **`READ_COMMITTED`** en esos métodos: después de esperar un bloqueo, la
   consulta de horarios ve lo que la otra transacción confirmó.
5. **Tiempo máximo de espera:** `innodb_lock_wait_timeout = 5` s (configurable
   con `DB_ESPERA_BLOQUEO_S`). Si se supera, o MySQL detecta un interbloqueo,
   se responde 409 "Intentá de nuevo" en lugar de quedar colgado.
6. **Transacciones breves:** el bloqueo dura solo lo que tarda el servicio (milisegundos).

## 4. Evidencia

**Verificado en este entorno contra MySQL 8.0.46 real**, con los scripts de
`herramientas/verificacion-concurrencia/`, que replican el protocolo SQL del servicio:

```text
SIN bloqueo (solo consulta previa): aceptadas=9 filas en la base=9
CON bloqueo FOR UPDATE del guía:    aceptadas=1 filas en la base=1

30 rondas alargar(IT-01 a 90 min) vs asignar(11:00):
  {'alargar rechazado + asignar ok': 28, 'alargar ok + asignar rechazado': 2}
Rondas que terminaron con horarios superpuestos en la base: 0
```

**Escrito para ejecutar con `./mvnw verify`** (Java + Testcontainers): `ConcurrenciaIT`
(9 hilos sobre el mismo guía → 1 aceptada; 8 guías distintos en paralelo → 8
aceptadas; 8 altas del mismo nombre → 1; ediciones con la misma versión → 1;
5 rondas de duración contra asignación → nunca superposición).

## 5. Objetos modificables

- Los servicios devuelven **DTO**, nunca entidades.
- Los `record` con listas hacen **copia defensiva** (`List.copyOf`) en su
  constructor compacto: un `record` no vuelve inmutables sus colecciones por sí solo.
- Las entidades exponen colecciones de solo lectura (`Collections.unmodifiableSet`).
- `Pagina<T>` copia su contenido.
- Pruebas: `EntidadesTest.lasColeccionesExpuestasSonDeSoloLectura`, `DaoContratoIT.laPaginaDevueltaNoSePuedeModificar`.
