# Verificación: qué se comprobó y qué no

Este documento separa lo que **se ejecutó y funcionó** al preparar la entrega de lo que
**no se pudo ejecutar**. No hay resultados inventados: si algo dice "no verificado", es porque
no se corrió.

## Limitación del entorno

El entorno donde se preparó el trabajo **no tenía acceso a Maven Central ni a Docker Hub**
(la red los rechazaba por política). Por eso:

- **No se pudo correr `./mvnw verify`**: Maven no puede descargar Spring Boot ni sus dependencias.
- **No se pudieron correr las pruebas con Testcontainers**: necesitan Docker y la imagen de MySQL.

Para compensar se hicieron las verificaciones parciales de abajo. **La verificación definitiva es
correr `./mvnw verify`** en una máquina con internet y Docker (o hacer push a GitHub: el workflow
`.github/workflows/ci.yml` lo corre automáticamente).

---

## ✅ Verificado (ejecutado)

### Base de datos (MySQL 8.0.46 real, instalado localmente)
- `V1__esquema_inicial.sql` y `V2__sesiones_http.sql` se aplican sobre una base vacía sin errores.
- Las restricciones rechazan datos inválidos: nombre de usuario duplicado (sin distinguir mayúsculas),
  `CHECK` de rol, de datos de empleado, de código `IT-nn`, de duración, longitud y máximo de visitantes;
  claves foráneas `RESTRICT` (no se puede borrar una zona con especies, ni un guía con horarios, etc.);
  único `guía + hora`.
- Respaldo y recuperación con `mysqldump` → base nueva: se restauran las tablas y las 38 restricciones.

### Concurrencia (contra MySQL real, scripts en `herramientas/verificacion-concurrencia/`)
- 10 asignaciones simultáneas superpuestas para el mismo guía:
  **sin** el protocolo de bloqueo se aceptaron 9 (error esperado, demuestra el problema);
  **con** el protocolo (`FOR SHARE` itinerario → `FOR UPDATE` guía) se aceptó **1**.
- 30 rondas de "cambiar duración del itinerario" vs. "asignar horario" en paralelo:
  28 / 2 según quién llegó primero, **0 superposiciones** al final.

### Backend Java (compilación con `javac` de JDK 21)
- **77 de los 93 archivos** de `backend/src/main/java` compilaron **completos, sin errores ni
  advertencias** (`-Xlint:all`): entidades, DAO genérico y DAO por módulo, repositorios, servicios,
  DTO, controladores, reglas de horarios, demo y administrador inicial.
  Para esto se usaron stubs (versiones mínimas) de las anotaciones y tipos de Spring, Spring Data,
  Jakarta Persistence/Validation, Jackson y SLF4J que esos archivos usan.
  **Límite:** un stub comprueba que el código usa bien los nombres y tipos, pero si una firma de
  un stub difiere de la real, esa diferencia no se detecta.
- Lógica de dominio ejecutada (24 comprobaciones): un itinerario exige al menos una especie y que todas
  tengan zona, el código `IT-01..IT-99`, las zonas se derivan de las especies, la regla de
  superposición de horarios y el rechazo de recorridos que terminan después de las 23:59.
- `Pbkdf2LegadoPasswordEncoder` ejecutado: valida el hash de la v2 de `Marino2026!` y rechaza una
  contraseña incorrecta.

### Datos de la v1
- El `.dat` original no se modificó (SHA-256 `f10484418ca8f33472f45225b2c01d059272fc0c66ab9f89a62627be614b2a22`).
- Los JSON convertidos cumplen las reglas nuevas (las zonas de los itinerarios se derivan bien:
  `[Arrecife azul]`, `[Bosque de kelp]`).

### Frontend
- `npm ci` + `npm test`: **11 de 11 pruebas pasan** (Vitest + Testing Library + MSW).
- `npm run build`: construcción de producción sin errores.

### Configuración
- `application*.yml` y `docker-compose.yml` son YAML válidos.

---

## ❌ No verificado

| Qué | Por qué | Cómo verificarlo |
|---|---|---|
| Compilación completa del backend con Maven | Sin acceso a Maven Central | `cd backend && ./mvnw verify` |
| 16 archivos Java no compilados con stubs: `SeguridadConfig`, `CodificacionConfig`, `AuthController`, `DetallesUsuarioService`, `UsuarioAutenticado`, `LimitadorIntentosLogin`, `PropiedadesSeguridad`, `RespuestasJsonSeguridad`, `CierreSesionesSpringSession`, `CierreSesionesSinWeb`, `ManejadorErrores`, los 4 de `importacion/` y `MundoMarinoApplication` | Usan mucha API de Spring Security, Spring Session y Spring MVC; escribir stubs a mano de esa API habría sido inventar firmas | `./mvnw compile` |
| Todas las pruebas JUnit (`*Test`, `*IT`): reglas de negocio, transacciones, concurrencia, contrato de DAO, seguridad HTTP, API REST, volumen (sin N+1), importación, arquitectura (ArchUnit) | Sin Maven ni Docker | `./mvnw verify` (necesita Docker en marcha) |
| Arranque real de Spring Boot (beans, Flyway desde la aplicación, validación de Hibernate contra el esquema) | Ídem | `./mvnw spring-boot:run` con `docker compose up -d` |
| Frontend contra el backend real | Las pruebas del frontend usan un backend simulado (MSW) | Levantar los tres procesos y probar en el navegador |

Si `./mvnw verify` falla, lo más probable son detalles de compilación o de configuración de
Spring en los 16 archivos no compilados; el error de Maven dice el archivo y la línea.

---

## Limitaciones conocidas (por diseño, no son errores)

- El **limitador de intentos de login** guarda los intentos en memoria: con varias instancias del
  backend, cada una cuenta por separado (ver `docs/ESCALABILIDAD.md`).
- La **búsqueda por texto** usa `LIKE '%texto%'`, que no aprovecha índices. Con los volúmenes del
  trabajo es suficiente; no se midió con volúmenes grandes.
- **No se midió** cuántos usuarios simultáneos soporta el sistema; no se afirma ninguna cifra.
- El informe PDF de la entrega anterior describe la v2 y quedó desactualizado.
