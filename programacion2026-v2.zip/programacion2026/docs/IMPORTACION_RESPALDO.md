# Importación de datos anteriores, respaldo y recuperación

## 1. Qué datos existían

| Origen | Formato | Contenido real | Qué se hizo |
|---|---|---|---|
| v1 (`respaldo/v1-original/datos_mundo_marino.dat`) | Serialización Java | 2 zonas, 2 hábitats, 4 especies, 2 itinerarios, 2 guías (Mario López, Sofía Martínez), 2 cuidadores (Elena Torres, Rafael Díaz), 2 horarios, 4 cuidados. **Sin contraseñas** (la v1 no las tenía) | Se convirtió **una vez**, solo leyendo el original, a `datos-importacion/v1-convertido/*.json` con `herramientas/convertir-v1/ConvertirV1.java`. El `.dat` queda intacto (SHA-256 `f10484418ca8f334…`) |
| v2 (`GrupoCTema12/datos/*.json`) | JSON | Lo que hayan cargado al usar la v2 (la carpeta no estaba en el ZIP; se genera al ejecutar) | Se importa directamente; las contraseñas PBKDF2 se conservan |

## 2. Cómo importar

La importación se ejecuta **sin servidor web**, contra una base sin esos datos:

```bash
# 1) Base vacía (si ya había datos de demostración, empezar de cero):
docker compose down -v && docker compose up -d

# 2) Importar (desde backend/):
./mvnw spring-boot:run \
  -Dspring-boot.run.profiles=dev,importacion \
  -Dspring-boot.run.arguments="--app.importacion.directorio=../datos-importacion/v1-convertido"
#    Para la v2: --app.importacion.directorio=/ruta/a/GrupoCTema12/datos

# 3) Levantar el backend creando un administrador (los datos de la v1 no tienen ninguno):
MM_ADMIN_USUARIO=admin MM_ADMIN_CONTRASENA='CambiarEsto2026' ./mvnw spring-boot:run
```

Al terminar se escribe `backend/informes-importacion/informe-importacion-<fecha>.md`
y el proceso sale con código **0** (importada) o **2** (no se importó nada).
Si la base ya tiene usuarios (por ejemplo, después de importar), los datos de
demostración **no** se cargan.

### Garantías

| Garantía | Cómo |
|---|---|
| Todo o nada | Validación y escritura en **una sola transacción**; ante cualquier error, rollback |
| Valida antes de confirmar | Formato JSON, UUID, valores (con los mismos constructores de las entidades), referencias, roles, horarios superpuestos (con `ReglaHorarios`) |
| Duplicados | Ids repetidos en el archivo, nombres/códigos/usuarios repetidos y conflictos con la base (por id o por dato único) son **errores** |
| No pisa información | Si el id ya existe en la base, no se sobrescribe: es un error |
| Conserva ids y relaciones | Se usan los mismos UUID |
| Archivos originales intactos | Solo lectura; el informe registra el SHA-256 de cada archivo |
| Archivos dañados | Se informa archivo, línea y causa; no se importa nada |
| Usuarios sin contraseña (v1) | Se les asigna una contraseña aleatoria que nadie conoce y se avisa en el informe; el administrador les da una nueva desde "Personal → Editar" |

Pruebas: `ImportacionIT` (importa la v1 real, reimportación rechazada, archivo
dañado, referencia inexistente, horarios superpuestos, contraseñas de la v2,
informe, archivos sin modificar).

## 3. Respaldo y recuperación

**Respaldo** (consistente, sin detener la aplicación, gracias a `--single-transaction`):

```bash
docker exec mundo-marino-mysql sh -c \
  'mysqldump -u root -p"$MYSQL_ROOT_PASSWORD" --single-transaction --routines --triggers --set-gtid-purged=OFF mundo_marino' \
  > respaldo-$(date +%Y%m%d-%H%M).sql
```

**Recuperación** (en una base vacía; detener antes el backend):

```bash
docker exec -i mundo-marino-mysql sh -c 'mysql -u root -p"$MYSQL_ROOT_PASSWORD" mundo_marino' < respaldo-AAAAMMDD-HHMM.sql
```

El respaldo incluye la tabla `flyway_schema_history`, así que al arrancar el
backend Flyway reconoce las migraciones ya aplicadas.

Verificado en este entorno: respaldo con `mysqldump` → restauración en una base
nueva → datos y las 38 restricciones presentes.

**Recomendaciones:** respaldar antes de cada importación y de cada
actualización con migraciones nuevas, y guardar los respaldos fuera de la
máquina de la base. Las sesiones (`SPRING_SESSION*`) también quedan en el
respaldo; al restaurar en otro momento conviene vaciarlas para obligar a
iniciar sesión de nuevo.
