# Arquitectura

**Monolito modular**: un solo backend desplegable, organizado en **módulos por
área del dominio**, y un frontend separado. Diagramas: `diagramas/arquitectura.png`
y `diagramas/modulos.png`.

## Módulos del backend (`ar.edu.inspt.mundomarino`)

| Módulo | Contenido |
|---|---|
| `comun` | `Dao<T,ID>`, `DaoJpa`, `EntidadConId`, paginación, validaciones, manejo de errores |
| `zona`, `habitat`, `especie`, `itinerario` | El parque |
| `personal` | Usuario, Administrador, Empleado, Guía, Cuidador, permisos, alta y baja de personal |
| `asignacion` | Horarios de guías, cuidados, regla de horarios y consultas propias ("mi panel") |
| `seguridad` | Spring Security, login, sesiones, contraseñas |
| `importacion` | Importación controlada de datos v1/v2 |
| `demo` | Datos de demostración (solo perfil dev) |

Cada módulo de dominio tiene la misma forma:

```text
zona/
├── Zona.java              entidad JPA (con sus invariantes)
├── ZonaDao.java           contrato DAO (público)
├── ZonaDaoJpa.java        implementación (package-private)
├── ZonaRepositorio.java   repositorio Spring Data (package-private)
├── ZonaService.java       reglas + transacciones
├── ZonaDtos.java          DTO de entrada y salida
└── ZonaController.java    API REST
```

### Dependencias entre módulos (sin ciclos)

```text
zona, habitat, personal ─▶ comun
especie ─▶ zona, habitat
itinerario ─▶ especie, zona
asignacion ─▶ itinerario, especie, personal
seguridad ─▶ personal
```

Dos dependencias que irían "al revés" se invirtieron con interfaces (puertos):

- `itinerario.ValidadorCambioDuracion`, implementado por `asignacion.VerificadorHorarios`.
- `personal.CierreSesiones`, implementado por `seguridad.CierreSesionesSpringSession`.

`ArquitecturaTest` lo verifica automáticamente: no hay ciclos, los controladores
y servicios no usan repositorios JPA, los controladores no devuelven entidades,
las entidades no son `final` y los repositorios no son públicos.

### Por qué no microservicios ni caché

Para este proyecto no hay una necesidad demostrada: agregarían red, despliegues
y fallas parciales sin beneficio medible. El monolito modular permite separar
un módulo más adelante si hiciera falta, porque las dependencias ya están
ordenadas.

## Frontend (`frontend/src`)

| Carpeta | Contenido |
|---|---|
| `api/` | `cliente.js` (fetch, cookie, CSRF, errores) y `autenticacion.js` |
| `sesion/` | contexto con el usuario que inició sesión |
| `componentes/` | `SeccionCrud` (tabla paginada + búsqueda + formulario), `Formulario`, `Modal`, `Avisos`, estados de carga y error |
| `paginas/` | `Login`, `Panel` (elige la vista por rol), `admin/`, `guia/`, `cuidador/`, `comun/` (perfil y contraseña) |
| `config.js` | URL del backend (`VITE_API_URL`) |
