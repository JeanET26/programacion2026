# Base de datos

MySQL 8, motor InnoDB, `utf8mb4` con colación `utf8mb4_0900_ai_ci` (las
comparaciones no distinguen mayúsculas ni acentos: "ARRECIFE" choca con "Arrecife").

Diagrama entidad-relación: `diagramas/base_de_datos.png`.

## Migraciones (Flyway)

| Versión | Archivo | Contenido |
|---|---|---|
| V1 | `backend/src/main/resources/db/migration/V1__esquema_inicial.sql` | Tablas del dominio, claves, restricciones e índices |
| V2 | `V2__sesiones_http.sql` | Tablas de Spring Session (sesiones HTTP) |

- Flyway las aplica en orden al arrancar y registra cuáles aplicó en `flyway_schema_history`.
- **Nunca se modifica una migración ya aplicada**: los cambios van en una V3 nueva.
- Hibernate usa `ddl-auto: validate`: no crea ni altera tablas, solo verifica que coincidan con las entidades.

## Tablas

| Tabla | Entidad | Notas |
|---|---|---|
| `zona` | `Zona` | `UNIQUE nombre`, `CHECK extension_m2 > 0` |
| `habitat` | `Habitat` | `UNIQUE nombre` |
| `habitat_continente` | `Habitat.continentes` | PK (habitat_id, continente) |
| `especie` | `Especie` | `UNIQUE nombre_cientifico`; `zona_id` FK nullable, RESTRICT |
| `especie_habitat` | `Especie.habitats` | PK compuesta; FK al hábitat RESTRICT |
| `itinerario` | `Itinerario` | `UNIQUE codigo`; CHECK de formato IT-NN, duración 5–480, longitud > 0, cupo 1–500 |
| `itinerario_especie` | `Itinerario.especies` | PK compuesta; FK a especie RESTRICT. **Las zonas no se guardan**: se derivan |
| `usuario` | `Usuario` y subclases | Herencia SINGLE_TABLE; `rol` discriminador con CHECK; `UNIQUE nombre_usuario`; CHECK de datos completos para empleados |
| `asignacion_guia` | `AsignacionGuia` | `UNIQUE (guia_id, hora)`; FK RESTRICT a guía e itinerario |
| `asignacion_cuidado` | `AsignacionCuidado` | `UNIQUE (cuidador_id, especie_id)`; FK RESTRICT |
| `SPRING_SESSION`, `SPRING_SESSION_ATTRIBUTES` | — | Sesiones HTTP (esquema oficial de Spring Session) |

Todas las tablas del dominio tienen `version BIGINT` (bloqueo optimista).

**Integridad que garantiza la base aunque se escriba sin pasar por Java:**
claves primarias, foráneas, unicidad y CHECK. Verificado contra MySQL 8.0.46
(ver `VERIFICACION.md`).

**Lo que la base NO puede garantizar sola** (y por eso lo hace el servicio con
bloqueos): que los horarios de un guía no se superpongan (depende de la
duración de otro registro), que `guia_id` apunte a un usuario de rol GUIA y que
toda especie de un itinerario tenga zona.

## UUID

- Generados en Java (`UUID.randomUUID()`), guardados como `CHAR(36)` en
  formato texto estándar. Configuración: `hibernate.type.preferred_uuid_jdbc_type: CHAR`.
- Al leer, Hibernate reconstruye el `UUID` con `UUID.fromString`.
- Se conservan al importar datos anteriores.

## Índices y por qué

| Índice | Consulta que acelera |
|---|---|
| PK de cada tabla | buscar por id |
| `UNIQUE` (nombres, código, usuario) | además de garantizar unicidad, búsqueda por esos campos (login por usuario) |
| FK (InnoDB las indexa automáticamente) | "especies de esta zona", horarios de un itinerario, etc. |
| `ix_especie_nombre_espanol` | listado de especies ordenado por nombre (el más usado) |
| `ix_usuario_rol_nombre` | listado de personal filtrado por rol y ordenado por nombre |
| `uk_asignacion_guia_guia_hora` | horarios de un guía ordenados por hora (regla de superposición y "mis recorridos") |
| `ix_asignacion_cuidado_especie` | "¿quién más cuida esta especie?" |
| `ix_itinerario_especie_especie` | "¿esta especie está en algún itinerario?" |

La búsqueda por texto usa `LIKE '%texto%'`, que **no** aprovecha índices. Para
el volumen esperado es suficiente; con decenas de miles de filas convendría un
índice `FULLTEXT`.

## Datos de demostración

Solo en el perfil `dev` y solo si la tabla `usuario` está vacía
(`demo/CargadorDatosDemo.java`). Se cargan con los servicios, cumpliendo las
mismas reglas. Nunca reemplazan datos existentes.
