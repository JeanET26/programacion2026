# Seguridad

## Mecanismo elegido: sesión con cookie (sin JWT)

- Al iniciar sesión (`POST /api/auth/login`), Spring Security verifica la
  contraseña y guarda la autenticación en una **sesión del servidor**.
- Las sesiones se guardan en **MySQL** (Spring Session JDBC, tablas
  `SPRING_SESSION*` de la migración V2), no en la memoria del proceso.
- El navegador recibe solo un identificador en la cookie `MMSESION`.
- **Por qué no JWT:** separar frontend y backend no lo exige. Con sesión en el
  servidor es simple **cerrar** sesiones (al salir, al cambiar o restablecer la
  contraseña, al dar de baja a alguien); con JWT habría que mantener una lista
  de tokens revocados.

### Atributos de la cookie

| Atributo | Valor | Para qué |
|---|---|---|
| `HttpOnly` | sí | JavaScript no la puede leer (un XSS no la roba) |
| `SameSite` | `Lax` (configurable con `COOKIE_SAME_SITE`) | El navegador no la envía en pedidos POST iniciados desde otros sitios |
| `Secure` | `false` en dev, **`true` en prod** | Solo viaja por HTTPS |
| Vencimiento | 30 min sin uso (`SESION_MINUTOS`) | Sesiones abandonadas expiran |

## CSRF

Activado (la cookie viaja sola, por eso hace falta). Cada POST/PUT/DELETE debe
llevar `X-CSRF-TOKEN`, obtenido de `GET /api/auth/csrf`. El token se guarda en la
sesión y se **renueva** al iniciar sesión y al cambiar la contraseña.
`frontend/src/api/cliente.js` lo maneja solo y reintenta una vez si venció.

## CORS

- **Desarrollo:** el proxy de Vite hace que el navegador vea un solo origen
  (`localhost:5173`), así que CORS no interviene.
- **Si el frontend se publica en otro origen:** el backend acepta solo los
  orígenes de `ORIGENES_PERMITIDOS` (lista exacta; **`*` está prohibido** y la
  aplicación no arranca si se configura), con `allowCredentials=true`, y solo
  los métodos y encabezados necesarios.
- Si frontend y backend quedan en **sitios distintos** (dominios diferentes),
  hay que usar `COOKIE_SAME_SITE=none` y `COOKIE_SEGURA=true` (HTTPS
  obligatorio). La opción más simple es publicarlos bajo el mismo dominio con
  un proxy inverso: `/` para el frontend y `/api` para el backend.

## Contraseñas

- `DelegatingPasswordEncoder` con **BCrypt** (cada hash incluye su propia sal
  aleatoria; costo configurable con `BCRYPT_FUERZA`, 12 en prod).
- Se guardan como `{bcrypt}$2a$...`; el prefijo indica el algoritmo.
- Las contraseñas importadas de la v2 (`{pbkdf2-v2}...`) se verifican con
  `Pbkdf2LegadoPasswordEncoder` y se **convierten a BCrypt** en el primer
  login correcto.
- Los usuarios de la v1 no tenían contraseña: quedan **bloqueados** con una
  aleatoria que nadie conoce hasta que el administrador les asigne una.
- Política: 8 a 64 caracteres, con letras y números (`PoliticaContrasena`).
- Login: mismo mensaje exista o no el usuario; bloqueo temporal tras 5
  intentos fallidos por usuario o 30 por IP en 10 minutos (`LimitadorIntentosLogin`).

## Autorización

Permisos (`personal/Permiso.java`) que cada tipo de usuario declara en `getPermisos()`:

| Rutas | Permiso |
|---|---|
| `/api/zonas`, `/api/habitats`, `/api/especies`, `/api/itinerarios`, `/api/empleados`, `/api/asignaciones-*` | `ADMINISTRAR_PARQUE` |
| `GET /api/mi/recorridos` | `VER_RECORRIDOS_PROPIOS` (guías) |
| `GET /api/mi/especies` | `VER_ESPECIES_PROPIAS` (cuidadores) |
| `/api/auth/**` (salvo login y csrf) | sesión iniciada |
| cualquier otra | **denegada** (`denyAll`) |

**Identidad del servidor:** las consultas propias usan
`@AuthenticationPrincipal(expression = "id")`; el id nunca viene del cliente.

## Comportamiento definido

| Evento | Qué pasa |
|---|---|
| Logout | Se borra la sesión en MySQL y la cookie; los pedidos siguientes → 401 |
| Cambio de la propia contraseña | Se cierran **las demás** sesiones del usuario; la actual sigue con un id nuevo y otro token CSRF |
| Restablecimiento por el administrador | Se cierran **todas** las sesiones de ese empleado |
| Baja de un empleado | Se cierran todas sus sesiones |
| Login | Id de sesión nuevo (contra la fijación de sesión) y token CSRF nuevo |

Pruebas: `SeguridadApiIT` (13 casos con el servidor HTTP real y cookies).
