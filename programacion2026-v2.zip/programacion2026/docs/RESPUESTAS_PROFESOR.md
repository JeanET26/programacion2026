# Respuestas a las observaciones del profesor

Cada respuesta se apoya en clases reales del proyecto. Las rutas son relativas a
`backend/src/main/java/ar/edu/inspt/mundomarino/`.

> **Sobre el uso de IA.** Este proyecto se desarrolló con ayuda de IA. Antes de
> la defensa, cada integrante debería poder explicar sin leer las secciones 1 a 6
> de este documento y recorrer la `GUIA_PASO_A_PASO.md`. Si algo no queda
> claro, conviene investigarlo: son las preguntas más probables.

---

## 1. Principios SOLID con ejemplos del proyecto

### S: Responsabilidad única

Cada clase tiene **un solo motivo para cambiar**.

| Clase | Su única responsabilidad | Lo que NO hace |
|---|---|---|
| `zona/ZonaController` | Traducir HTTP ⇄ llamadas al servicio | Reglas de negocio ni SQL |
| `zona/ZonaService` | Reglas de las zonas (nombre único, versión) en una transacción | Saber si hay MySQL o JSON |
| `zona/ZonaDaoJpa` | Guardar y buscar zonas | Validar reglas |
| `asignacion/ReglaHorarios` | Decidir si dos recorridos se superponen | Leer la base |
| `comun/error/ManejadorErrores` | Convertir excepciones en respuestas HTTP | Lógica de negocio |
| `seguridad/LimitadorIntentosLogin` | Contar intentos fallidos | Autenticar |

**Contraste con la v2:** `SistemaMundoMarino` guardaba colecciones, validaba
permisos, aplicaba reglas y buscaba usuarios. Ahora eso está en
DAO + servicios + seguridad.

### O: Abierto/cerrado

Se puede **agregar** comportamiento sin **modificar** el código que ya funciona.

- **`itinerario/ValidadorCambioDuracion`.** `ItinerarioService` recibe
  `List<ValidadorCambioDuracion>`. Si mañana hay otra regla al cambiar la
  duración (por ejemplo, que no supere el horario del parque), se agrega una
  clase que implemente la interfaz y Spring la inyecta sola. `ItinerarioService`
  no cambia.
- **`comun/dao/DaoJpa<T, ID>`.** Para persistir una entidad nueva se escribe
  `XDaoJpa extends DaoJpa<X, UUID>`. El CRUD genérico no se toca.
- **`frontend/src/paginas/admin/secciones.jsx`.** Una pestaña nueva del
  administrador es un objeto más en la lista. `SeccionCrud.jsx` no cambia.

**Lo que NO es abierto/cerrado (y hay que decirlo):** agregar un **rol** nuevo
(por ejemplo, Veterinario) **sí requiere modificar** varios lugares:

1. Crear la entidad `Veterinario extends Empleado` con su `@DiscriminatorValue`.
2. Agregar el valor a la enumeración `Rol` (y quizás un `Permiso` nuevo).
3. Una migración Flyway que amplíe `ck_usuario_rol` en la tabla `usuario`.
4. Reglas en `SeguridadConfig` para sus rutas.
5. El `switch` de `PersonalService.crear` y del importador.
6. Una vista nueva en `frontend/src/paginas/Panel.jsx`.

Lo que sí se evita es **reescribir** la lógica de permisos: `Usuario.getPermisos()`
es polimórfico y la autorización no usa `instanceof`.

### L: Sustitución de Liskov

Donde se espera un tipo, se puede usar cualquier subtipo **sin que el programa se comporte mal**.

- `UsuarioDao` lo usa `PersonalService` sin saber que la implementación es
  `UsuarioDaoJpa`. La prueba `DaoContratoIT` ejecuta **las mismas pruebas**
  contra los DAO de zonas, hábitats, especies y usuarios: si una implementación
  no cumple el contrato `Dao<T, ID>`, falla.
- `CierreSesiones` tiene dos implementaciones: `CierreSesionesSpringSession` (con
  servidor web) y `CierreSesionesSinWeb` (al importar). `PersonalService`
  funciona igual con cualquiera.
- `Usuario` → `Administrador`, `Guia`, `Cuidador`: Spring Security trabaja con
  cualquier `Usuario` a través de `getPermisos()`.

### I: Segregación de interfaces

Ningún cliente depende de métodos que no usa.

- `Dao<T, ID>` tiene solo 5 operaciones genéricas. Cada módulo agrega **solo** lo
  suyo: `AsignacionGuiaDao.buscarPorGuia`, `UsuarioDao.buscarGuiaParaModificar`,
  `EspecieDao.estaEnAlgunItinerario`.
- `ValidadorCambioDuracion` y `CierreSesiones` tienen **un** método cada una:
  justo lo que necesita quien las usa.

### D: Inversión de dependencias

Los módulos de alto nivel (servicios) dependen de **abstracciones** (interfaces),
no de detalles (JPA, MySQL, Spring Session).

```java
// asignacion/AsignacionGuiaService.java
public AsignacionGuiaService(AsignacionGuiaDao asignaciones, ItinerarioDao itinerarios,
                             UsuarioDao usuarios, VerificadorHorarios verificador)
```

Las tres primeras son **interfaces**. Además, la dirección de la dependencia se
invierte **entre módulos**:

- `itinerario` define `ValidadorCambioDuracion` y `asignacion` lo implementa. Si
  fuera al revés, `itinerario` dependería de `asignacion` y habría un ciclo.
- `personal` define `CierreSesiones` y `seguridad` lo implementa.

La prueba `ArquitecturaTest` verifica que **no haya ciclos** entre módulos y que
los servicios **no** dependan de los repositorios de Spring Data.

---

## 2. Diferencia entre interfaz e implementación

- **Interfaz:** *qué* se puede hacer (un contrato). Ejemplo: `ZonaDao` dice
  que se puede `guardar`, `buscarPorId`, `existeNombre`...
- **Implementación:** *cómo* se hace. `ZonaDaoJpa` lo hace con Spring Data JPA
  y MySQL. En la v2, `ZonaDaoJson` lo hacía con un archivo.

El servicio declara `private final ZonaDao zonas;` (la interfaz). Por eso el
cambio de archivos JSON a MySQL **no tocó ninguna regla de negocio**.

---

## 3. Diferencia entre delegación e inyección de dependencias

- **Delegación:** un objeto le **pide a otro** que haga parte del trabajo.
  `DaoJpa.guardar()` **delega** en `repositorio.saveAndFlush()`, y
  `ItinerarioService.actualizar()` delega en el validador la revisión de horarios.
- **Inyección de dependencias:** **quién crea** a ese otro objeto. El servicio
  **no hace `new`** de su DAO: lo **recibe** por el constructor y Spring decide
  qué implementación pasarle.

Son complementarias: con inyección, el objeto *recibe* a quién delegar. Sin
inyección (`this.zonas = new ZonaDaoJpa(...)` dentro del servicio) seguiría
habiendo delegación, pero el servicio quedaría atado a JPA y no se podría
probar ni reemplazar.

En la v2 había inyección **manual** (la clase `Servicios` armaba todo a mano).
Ahora la hace **Spring**: detecta los `@Service` y `@Repository`, mira sus
constructores y les pasa los objetos que piden.

---

## 4. Propósito del DAO genérico

`comun/dao/Dao.java` define **una vez** el contrato de persistencia:

```java
public interface Dao<T, ID> {
    Optional<T> buscarPorId(ID id);
    boolean existePorId(ID id);
    Pagina<T> listar(SolicitudPagina solicitud);
    T guardar(T entidad);
    void eliminar(T entidad);
}
```

1. **No repetir:** las 7 entidades comparten el CRUD; `DaoJpa<T, ID>` lo
   implementa una sola vez.
2. **Uniformidad:** todos los DAO se comportan igual (por ejemplo, `guardar` y
   `eliminar` hacen `flush` para que un error de clave foránea aparezca dentro
   de la transacción del servicio). Lo verifica `DaoContratoIT`.
3. **Independencia:** los servicios no dependen de Spring Data. `Pagina` y
   `SolicitudPagina` son clases nuestras, no `Page`/`Pageable` de Spring.
4. **Contratos específicos donde hace falta:** `ZonaDao extends Dao<Zona, UUID>`
   agrega `existeNombre`, `buscar` y `contarEspecies`.

---

## 5. DAO, repositorio JPA y servicio: qué es cada uno

Tomando las zonas como ejemplo:

```text
ZonaService ──usa──▶ ZonaDao (interfaz nuestra)       ← CONTRATO DAO
                         ▲ implementa
                    ZonaDaoJpa extends DaoJpa         ← ADAPTADOR (DAO concreto)
                         │ delega en
                    ZonaRepositorio extends JpaRepository ← REPOSITORIO de Spring Data
                         │ usa
                    Hibernate ──SQL──▶ MySQL
```

| | Qué es | Quién lo escribe | Quién lo conoce |
|---|---|---|---|
| **Servicio** (`ZonaService`) | Reglas de negocio y transacción | Nosotros | Controladores |
| **Contrato DAO** (`ZonaDao`) | Qué operaciones de datos existen | Nosotros | Servicios |
| **DAO concreto** (`ZonaDaoJpa`) | Cómo se hacen con JPA | Nosotros | Spring (lo inyecta) |
| **Repositorio JPA** (`ZonaRepositorio`) | Interfaz de la que **Spring genera** la implementación (SQL incluido) | Nosotros declaramos la interfaz; Spring escribe el código | Solo su DAO |

**¿Por qué no usar directamente `ZonaRepositorio` en el servicio?** Declarar un
`JpaRepository` no cumple por sí solo el pedido de DAO: expone decenas de métodos
de Spring Data (`findAll`, `saveAll`, `flush`, `deleteAllInBatch`...) y ataría
los servicios a Spring Data. El DAO publica solo lo que el dominio necesita.
Los repositorios son **package-private** (no se ven fuera de su módulo) y
`ArquitecturaTest` verifica que ningún servicio ni controlador los use.

---

## 6. UUID: por qué y cómo se guarda

**Por qué:**
- El objeto tiene identidad **desde que se crea en Java** (`UUID.randomUUID()`),
  antes de guardarse: no hace falta ir a la base a pedir un número.
- Se **conservan los ids** al importar los datos de la v1 y la v2: las
  relaciones (especie → zona, horario → guía) siguen siendo válidas.
- No son correlativos: en la API no se puede adivinar `/api/empleados/2` a
  partir de `/api/empleados/1`. Eso no reemplaza la autorización, que la sigue
  haciendo el servidor.
- `UUID.randomUUID()` (versión 4) tiene 122 bits aleatorios; que se repitan es
  despreciable en la práctica.

**Cómo se almacena y reconstruye:**
- Columna `CHAR(36)` (texto `3589334b-8533-47fc-b64c-a7e16f6d3e92`), configurada
  con `hibernate.type.preferred_uuid_jdbc_type: CHAR` en `application.yml`.
- Al leer, Hibernate hace `UUID.fromString(...)` y la entidad recupera el
  **mismo** id. Lo prueba `RestriccionesYTransaccionesIT.elUuidSeGuardaComoTextoYSeReconstruyeIgual`.
- Las entidades tienen dos constructores: el protegido sin argumentos (lo usa
  Hibernate) y el que recibe el `UUID`. Los servicios generan uno nuevo; el
  importador pasa el existente.
- **Alternativa no elegida:** `BINARY(16)` ocupa menos y los índices son más
  chicos, pero es ilegible al consultar la base a mano. Para el volumen del
  proyecto priorizamos claridad.

---

## 7. ¿Por qué `Empleado` sigue siendo abstracta si hereda de `Usuario` abstracta?

Heredar de una clase abstracta **no** vuelve abstracta a la subclase: es
abstracta solo si se declara así. Lo analizamos y **conviene mantenerla abstracta**:

1. **Dominio:** no existe "un empleado" a secas; siempre es Guía o Cuidador.
   Si fuera concreta se podría hacer `new Empleado(...)` y guardar un usuario
   sin rol ni permisos coherentes.
2. **Compilador:** `Empleado` no implementa `getRol()` ni `getPermisos()`
   (abstractos en `Usuario`). Una clase que no implementa todos los métodos
   abstractos que hereda **tiene** que ser abstracta para compilar.
3. **Base de datos (SINGLE_TABLE):** al ser abstracta no necesita valor
   propio en la columna `rol`. Allí solo aparecen `GUIA` o `CUIDADOR`, y la
   restricción `ck_usuario_rol` lo garantiza.

Su función es **no repetir** dirección, teléfono, fecha de ingreso y su
validación en `Guia` y `Cuidador`, y permitir que `PersonalService` trate a
ambos como `Empleado` (polimorfismo).

---

## 8. ¿`Administrador` debe ser `final`?

**En la v2 lo era; en la v3 dejó de serlo, y lo explicamos así:**

- En la v2, `final` expresaba una **decisión de diseño**: no estaban previstas
  subclases de `Administrador`, y el compilador impedía crearlas.
- **`final` nunca fue un mecanismo de autenticación ni de autorización.**
  Quién puede hacer qué lo decide el servidor: Spring Security verifica en cada
  pedido que la sesión exista y que el usuario tenga el permiso
  `ADMINISTRAR_PARQUE`. Una subclase no podría "colarse": los usuarios se
  reconstruyen desde la base según la columna `rol`, y el código cliente no
  puede inyectar clases propias.
- En la v3, `Administrador` es una **entidad JPA**, y la especificación de JPA
  exige que las entidades **no sean `final`** (tampoco sus métodos
  persistentes): Hibernate crea subclases *proxy* en tiempo de ejecución para la
  carga diferida (LAZY). Por eso se quitó `final`, de manera **justificada**
  (no automática), y la intención queda documentada en el Javadoc de la clase.
  `ArquitecturaTest.lasEntidadesNoSonFinalParaQueHibernatePuedaCrearProxies`
  lo verifica.

---

## 9. Dónde están los DAO y su contrato genérico

| Archivo | Rol |
|---|---|
| `comun/dao/Dao.java` | Contrato genérico |
| `comun/dao/DaoJpa.java` | Implementación genérica (adaptador sobre Spring Data) |
| `*/ZonaDao.java`, `HabitatDao`, `EspecieDao`, `ItinerarioDao`, `UsuarioDao`, `AsignacionGuiaDao`, `AsignacionCuidadoDao` | Contratos específicos |
| `*/ZonaDaoJpa.java` (y uno por entidad) | Implementaciones |
| `*/ZonaRepositorio.java` (y uno por entidad) | Repositorios Spring Data (internos del módulo) |
| `backend/src/test/.../DaoContratoIT.java` | Prueba de contrato aplicada a varias implementaciones |
