# Escalabilidad y mantenimiento

**No afirmamos que soporte una cantidad determinada de usuarios: no se midió
con pruebas de carga.** Este documento separa lo implementado de lo que haría
falta ante un crecimiento mayor.

## Implementado

| Aspecto | Qué hay |
|---|---|
| Módulos | Monolito modular por áreas del dominio, sin ciclos (verificado por `ArquitecturaTest`) |
| Despliegue independiente | Backend (JAR de Spring Boot) y frontend (archivos estáticos de `npm run build`) se construyen y publican por separado; la URL del backend es configurable |
| Listados | Paginación, filtro y orden **en la base** (`LIMIT/OFFSET` + `COUNT`); máximo 100 por página; campos de orden en lista blanca |
| Consultas | `@EntityGraph` / `join fetch` para relaciones a uno y `default_batch_fetch_size=50` para colecciones (sin N+1: `VolumenIT` verifica ≤ 4 consultas para una página de 50 especies entre 3000) |
| Conteos | La cantidad de especies por zona sale de una sola consulta agrupada |
| Índices | Justificados en `BASE_DE_DATOS.md` |
| Pool de conexiones | HikariCP configurable (`DB_POOL_MAXIMO`, `DB_POOL_MINIMO`, `DB_POOL_ESPERA_MS`) |
| Concurrencia | Bloqueos **por fila** (por guía, por itinerario), no globales; transacciones breves; tiempo máximo de espera de bloqueo configurable |
| Configuración externa | Conexión, orígenes CORS, cookies, BCrypt, sesiones y límites, por variables de entorno |
| Salud | `/actuator/health` (incluye la base) para balanceadores y orquestadores |
| Logs | Altas, bajas, asignaciones, logins y errores inesperados (con un código que también recibe el usuario) |
| Errores | Formato único `ApiError` y códigos HTTP coherentes |

## Sesiones con varias instancias del backend

Las sesiones **ya** están en MySQL (Spring Session JDBC), no en la memoria de
cada instancia. Con dos o más instancias detrás de un balanceador:

- cualquier instancia reconoce la cookie de cualquier otra (no hace falta "afinidad de sesión");
- cerrar las sesiones al cambiar la contraseña funciona en todas.

**Lo que habría que cambiar para escalar horizontalmente:**

1. `LimitadorIntentosLogin` cuenta en **memoria de cada instancia**: con N
   instancias, un atacante tendría N veces más intentos. Habría que moverlo a
   la base, a Redis o al balanceador.
2. El balanceador debe terminar HTTPS (`COOKIE_SEGURA=true`) y reenviar la IP
   real (`server.forward-headers-strategy=framework`), para que el limitador y
   los logs vean al cliente y no al balanceador.
3. Con mucho tráfico de sesiones, la tabla `SPRING_SESSION` puede volverse un
   cuello de botella; ahí sí se justificaría Redis (Spring Session Data Redis),
   cambiando solo una dependencia.
4. Cada instancia tiene su propio pool: el total de conexiones
   (instancias × `DB_POOL_MAXIMO`) debe quedar por debajo de `max_connections` de MySQL.

## Ante un crecimiento mayor (no implementado, sin necesidad demostrada)

- Pruebas de carga reales (por ejemplo, con k6 o Gatling) para medir antes de decidir.
- Búsqueda por texto con índices `FULLTEXT` si las tablas llegan a decenas de miles de filas.
- Paginación por cursor (keyset) en lugar de `OFFSET` para páginas muy profundas.
- Réplicas de lectura de MySQL si las consultas superan a las escrituras.
- Métricas (Micrometer + Prometheus) y trazas distribuidas.
- Cachés o colas: solo si una medición muestra la necesidad.
