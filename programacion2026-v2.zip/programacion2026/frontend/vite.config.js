import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

// En desarrollo, Vite reenvía /api al backend: el navegador ve un único origen
// (http://localhost:5173) y la cookie de sesión funciona sin configurar nada más.
// Para apuntar a otro backend: VITE_PROXY_BACKEND=http://otro-host:8080 npm run dev
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  return {
    plugins: [react()],
    server: {
      port: 5173,
      proxy: {
        '/api': { target: env.VITE_PROXY_BACKEND || 'http://localhost:8080', changeOrigin: false },
      },
    },
    test: {
      environment: 'jsdom',
      setupFiles: ['./src/test/preparacion.js'],
      globals: true,
      env: { VITE_API_URL: 'http://api.prueba' },
    },
  };
});
