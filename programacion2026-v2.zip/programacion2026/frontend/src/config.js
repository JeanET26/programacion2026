// Configuración del frontend. Vite reemplaza import.meta.env.* al compilar.
// VITE_API_URL vacío = mismo origen (proxy de Vite en desarrollo).
export const API_URL = (import.meta.env.VITE_API_URL ?? '').replace(/\/$/, '');
export const TAMANIO_PAGINA = 10;
