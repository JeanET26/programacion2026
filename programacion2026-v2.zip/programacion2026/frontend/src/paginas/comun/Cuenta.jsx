import { cambiarContrasena } from '../../api/autenticacion.js';
import Formulario from '../../componentes/Formulario.jsx';
import Modal from '../../componentes/Modal.jsx';
import { fecha, NOMBRE_ROL } from '../../formato.js';

export function Perfil({ usuario, alCerrar }) {
  const filas = [
    ['Nombre', usuario.nombre], ['Usuario', usuario.nombreUsuario], ['Rol', NOMBRE_ROL[usuario.rol]],
    ['Teléfono', usuario.telefono], ['Dirección', usuario.direccion], ['Ingreso', usuario.fechaIngreso && fecha(usuario.fechaIngreso)],
  ].filter(([, v]) => v);
  return (
    <Modal titulo="Mi perfil" alCerrar={alCerrar}>
      <dl className="row mb-2">
        {filas.map(([k, v]) => [<dt key={`${k}t`} className="col-4 text-suave">{k}</dt>, <dd key={`${k}d`} className="col-8">{v}</dd>])}
      </dl>
      <p className="small text-suave mb-0">Si algún dato es incorrecto, pedile al administrador que lo actualice.</p>
    </Modal>
  );
}

const CAMPOS_CONTRASENA = [
  { nombre: 'actual', etiqueta: 'Contraseña actual', tipo: 'password', requerido: true },
  { nombre: 'nueva', etiqueta: 'Nueva contraseña', tipo: 'password', requerido: true, ayuda: 'Mínimo 8 caracteres, con letras y números.',
    validar: (v) => (v.length < 8 || !/[A-Za-z]/.test(v) || !/\d/.test(v) ? 'Mínimo 8 caracteres, con letras y números.' : null) },
  { nombre: 'repetir', etiqueta: 'Repetí la nueva contraseña', tipo: 'password', requerido: true,
    validar: (v, todos) => (v !== todos.nueva ? 'No coincide con la nueva contraseña.' : null) },
];

export function CambioContrasena({ alCerrar, alTerminar }) {
  return (
    <Formulario titulo="Cambiar contraseña" textoBoton="Cambiar" campos={CAMPOS_CONTRASENA} alCerrar={alCerrar}
      alEnviar={async ({ actual, nueva }) => {
        await cambiarContrasena(actual, nueva);
        alTerminar();
      }} />
  );
}
