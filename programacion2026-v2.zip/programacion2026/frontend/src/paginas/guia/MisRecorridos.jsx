import { useCallback, useEffect, useState } from 'react';
import { api } from '../../api/cliente.js';
import { Cargando, MensajeError } from '../../componentes/Estados.jsx';
import { duracion, minutosDelDia } from '../../formato.js';

/** Agenda del guía. El servidor devuelve SOLO sus recorridos (identidad tomada de la sesión). */
export default function MisRecorridos() {
  const [recorridos, setRecorridos] = useState(null);
  const [error, setError] = useState(null);

  const cargar = useCallback(async () => {
    setError(null);
    try {
      setRecorridos(await api.get('/api/mi/recorridos'));
    } catch (e) {
      setError(e);
    }
  }, []);
  useEffect(() => { cargar(); }, [cargar]);

  if (error) return <MensajeError error={error} alReintentar={cargar} />;
  if (!recorridos) return <Cargando texto="Cargando tus recorridos…" />;
  if (recorridos.length === 0) {
    return (
      <div className="tarjeta vacio">
        <p className="fw-semibold mb-1">Todavía no tenés recorridos asignados.</p>
        <p className="mb-0">Cuando el administrador te asigne un horario, lo vas a ver acá.</p>
      </div>
    );
  }

  const ahora = new Date().getHours() * 60 + new Date().getMinutes();
  const estado = (r) => (ahora >= minutosDelDia(r.horaFin) ? 'terminado' : ahora >= minutosDelDia(r.hora) ? 'en-curso' : 'pendiente');
  const hayEnCurso = recorridos.some((r) => estado(r) === 'en-curso');
  const siguiente = recorridos.find((r) => estado(r) === 'pendiente');
  const total = recorridos.reduce((t, r) => t + r.duracionMinutos, 0);

  return (
    <div className="row g-4">
      <div className="col-lg-8">
        <section className="tarjeta agenda" aria-labelledby="t-agenda">
          <div className="p-3 border-bottom">
            <h2 className="h5 mb-0" id="t-agenda">Mi agenda de hoy</h2>
            <p className="small text-suave mb-0">Los horarios se repiten todos los días hasta que el administrador los cambie.</p>
          </div>
          {recorridos.map((r) => {
            let e = estado(r);
            if (r === siguiente && !hayEnCurso) e = 'siguiente';
            const etiqueta = { 'en-curso': 'En curso', siguiente: 'Próximo' }[e];
            return (
              <article key={r.asignacionId} className={`turno ${e}`} aria-label={`Recorrido ${r.codigo} a las ${r.hora}`}>
                <div className="horario">
                  <div className="inicio">{r.hora}</div>
                  <div className="fin">hasta {r.horaFin}</div>
                </div>
                <div>
                  <div className="d-flex align-items-center gap-2 flex-wrap">
                    <span className="codigo fs-5">{r.codigo}</span>
                    {etiqueta && <span className={`estado-turno ${e}`}>{etiqueta}</span>}
                  </div>
                  <div className="metricas-mini">
                    <span><strong>{duracion(r.duracionMinutos)}</strong> de recorrido</span>
                    <span><strong>{Number(r.longitudKm).toLocaleString('es-AR')} km</strong></span>
                    <span>hasta <strong>{r.maximoVisitantes} visitantes</strong></span>
                  </div>
                  <p className="small fw-semibold mb-1">Zonas</p>
                  <div className="mb-2">{r.zonas.map((z) => <span key={z} className="chip">{z}</span>)}</div>
                  <p className="small fw-semibold mb-1">Especies que vas a presentar</p>
                  <ul className="mb-0 ps-3">
                    {r.especies.map((s) => (
                      <li key={s.nombreCientifico}>{s.nombreEspanol} <span className="fst-italic text-suave small">{s.nombreCientifico}</span></li>
                    ))}
                  </ul>
                </div>
              </article>
            );
          })}
        </section>
      </div>
      <div className="col-lg-4">
        <div className="row g-3">
          <div className="col-6 col-lg-12"><div className="tarjeta metrica"><div className="numero">{recorridos.length}</div><div className="etiqueta">Recorridos por día</div></div></div>
          <div className="col-6 col-lg-12"><div className="tarjeta metrica"><div className="numero">{duracion(total)}</div><div className="etiqueta">Tiempo guiando</div></div></div>
          {siguiente && (
            <div className="col-12"><div className="tarjeta metrica">
              <div className="etiqueta">Tu próximo recorrido</div><div className="numero">{siguiente.hora}</div><div className="codigo">{siguiente.codigo}</div>
            </div></div>
          )}
        </div>
      </div>
    </div>
  );
}
