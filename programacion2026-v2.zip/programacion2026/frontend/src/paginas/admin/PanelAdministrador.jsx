import { useCallback, useEffect, useState } from 'react';
import { api } from '../../api/cliente.js';
import SeccionCrud from '../../componentes/SeccionCrud.jsx';
import { SECCIONES } from './secciones.jsx';

/** Resumen + pestañas. Los totales se piden al servidor (tamanio=1), sin traer todos los registros. */
export default function PanelAdministrador() {
  const [activa, setActiva] = useState(SECCIONES[0].clave);
  const [totales, setTotales] = useState({});

  const contar = useCallback(async () => {
    const consultas = {
      guias: '/api/empleados?rol=GUIA&tamanio=1',
      cuidadores: '/api/empleados?rol=CUIDADOR&tamanio=1',
      itinerarios: '/api/itinerarios?tamanio=1',
      especies: '/api/especies?tamanio=1',
    };
    const resultado = {};
    await Promise.all(Object.entries(consultas).map(async ([k, ruta]) => {
      try {
        resultado[k] = (await api.get(ruta)).totalElementos;
      } catch {
        resultado[k] = '–';
      }
    }));
    setTotales(resultado);
  }, []);

  useEffect(() => { contar(); }, [contar]);

  const seccion = SECCIONES.find((s) => s.clave === activa);
  const tarjeta = (clave, etiqueta) => (
    <div className="col-6 col-md-3" key={clave}>
      <div className="tarjeta metrica"><div className="numero">{totales[clave] ?? '–'}</div><div className="etiqueta">{etiqueta}</div></div>
    </div>
  );

  return (
    <>
      <div className="row g-3 mb-4">
        {tarjeta('guias', 'Guías')}
        {tarjeta('cuidadores', 'Cuidadores')}
        {tarjeta('itinerarios', 'Itinerarios')}
        {tarjeta('especies', 'Especies')}
      </div>
      <ul className="nav pestanas mb-3" role="tablist">
        {SECCIONES.map((s) => (
          <li className="nav-item" role="presentation" key={s.clave}>
            <button type="button" role="tab" aria-selected={s.clave === activa}
              className={`nav-link${s.clave === activa ? ' active' : ''}`} onClick={() => setActiva(s.clave)}>
              {s.pestana}
            </button>
          </li>
        ))}
      </ul>
      <div role="tabpanel" aria-label={seccion.pestana}>
        <SeccionCrud key={seccion.clave} config={seccion} alCambiarDatos={contar} />
      </div>
    </>
  );
}
