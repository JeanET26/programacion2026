import { useState } from 'react';
import { useSesion } from '../sesion/SesionContext.jsx';

export default function Login() {
  const { iniciar } = useSesion();
  const [usuario, setUsuario] = useState('');
  const [contrasena, setContrasena] = useState('');
  const [error, setError] = useState(null);
  const [enviando, setEnviando] = useState(false);

  async function enviar(ev) {
    ev.preventDefault();
    if (!usuario.trim() || !contrasena) {
      setError('Completá usuario y contraseña.');
      return;
    }
    setEnviando(true);
    setError(null);
    try {
      await iniciar(usuario.trim().toLowerCase(), contrasena);
    } catch (e) {
      setError(e.message);
      setContrasena('');
    } finally {
      setEnviando(false);
    }
  }

  return (
    <main className="pantalla-login">
      <div className="caja-login">
        <div className="marca mb-1"><img src="/logo.svg" alt="" />Mundo Marino</div>
        <p className="text-suave mb-4">Sistema del personal: administración, guías y cuidadores.</p>
        <form onSubmit={enviar} noValidate>
          <div className="mb-3">
            <label htmlFor="usuario" className="form-label fw-semibold">Usuario</label>
            <input id="usuario" className="form-control form-control-lg" autoComplete="username" autoCapitalize="none"
              spellCheck="false" maxLength={30} value={usuario} onChange={(e) => setUsuario(e.target.value)} />
          </div>
          <div className="mb-3">
            <label htmlFor="contrasena" className="form-label fw-semibold">Contraseña</label>
            <input id="contrasena" type="password" className="form-control form-control-lg" autoComplete="current-password"
              maxLength={64} value={contrasena} onChange={(e) => setContrasena(e.target.value)} />
          </div>
          {error && <div className="alert alert-danger py-2" role="alert">{error}</div>}
          <button type="submit" className="btn btn-oceano btn-lg w-100" disabled={enviando}>{enviando ? 'Ingresando…' : 'Ingresar'}</button>
        </form>
        <p className="small text-suave mt-4 mb-0">¿Olvidaste tu contraseña? Pedile al administrador que te asigne una nueva.</p>
      </div>
    </main>
  );
}
