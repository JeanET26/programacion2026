import { useCallback, useEffect, useState } from 'react';
import { api } from '../../api/cliente.js';
import { Cargando, MensajeError } from '../../componentes/Estados.jsx';
import { diasDesde, fecha } from '../../formato.js';

/** Especies a cargo del cuidador. De los compañeros solo llega el nombre. */
export default function MisEspecies() {
  const [especies, setEspecies] = useState(null);
  const [error, setError] = useState(null);

  const cargar = useCallback(async () => {
    setError(null);
    try {
      setEspecies(await api.get('/api/mi/especies'));
    } catch (e) {
      setError(e);
    }
  }, []);
  useEffect(() => { cargar(); }, [cargar]);

  if (error) return <MensajeError error={error} alReintentar={cargar} />;
  if (!especies) return <Cargando texto="Cargando tus especies…" />;
  if (especies.length === 0) {
    return (
      <div className="tarjeta vacio">
        <p className="fw-semibold mb-1">Todavía no tenés especies a cargo.</p>
        <p className="mb-0">Cuando el administrador te asigne una especie, la vas a ver acá.</p>
      </div>
    );
  }
  return (
    <>
      <div className="tarjeta metrica mb-4 d-inline-block">
        <div className="numero">{especies.length}</div>
        <div className="etiqueta">{especies.length === 1 ? 'Especie a tu cargo' : 'Especies a tu cargo'}</div>
      </div>
      <div className="row g-4">
        {especies.map((e) => (
          <div className="col-md-6 col-xl-4" key={e.asignacionId}>
            <article className="tarjeta ficha-especie">
              <div className="franja"><span className="inicial" aria-hidden="true">{e.nombreEspanol.charAt(0)}</span></div>
              <div className="cuerpo">
                <h2 className="h5 mb-0">{e.nombreEspanol}</h2>
                <p className="cientifico small mb-2">{e.nombreCientifico}</p>
                <p className="mb-0">{e.descripcion}</p>
                <dl>
                  <dt>Zona</dt><dd>{e.zona ?? 'Sin zona asignada'}</dd>
                  <dt>Hábitat</dt><dd>{e.habitats.length ? e.habitats.map((h) => `${h.nombre} (${h.clima})`).join(', ') : '—'}</dd>
                  <dt>A cargo</dt><dd>desde {fecha(e.desde)} · {diasDesde(e.desde)} días</dd>
                  <dt>Equipo</dt><dd>{e.otrosCuidadores.length ? `También la cuida: ${e.otrosCuidadores.join(', ')}` : 'Sos la única persona a cargo'}</dd>
                </dl>
              </div>
            </article>
          </div>
        ))}
      </div>
    </>
  );
}
