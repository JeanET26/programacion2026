import { useState } from 'react';
import { useAvisos } from '../componentes/Avisos.jsx';
import { NOMBRE_ROL } from '../formato.js';
import { useSesion } from '../sesion/SesionContext.jsx';
import PanelAdministrador from './admin/PanelAdministrador.jsx';
import MisEspecies from './cuidador/MisEspecies.jsx';
import MisRecorridos from './guia/MisRecorridos.jsx';
import { CambioContrasena, Perfil } from './comun/Cuenta.jsx';

// Vista según el rol. El servidor igual controla cada permiso: ocultar algo acá no es seguridad.
const VISTAS = {
  ADMINISTRADOR: { Vista: PanelAdministrador, subtitulo: 'Gestioná especies, itinerarios, personal y asignaciones.' },
  GUIA: { Vista: MisRecorridos, subtitulo: 'Estos son tus recorridos y horarios.' },
  CUIDADOR: { Vista: MisEspecies, subtitulo: 'Estas son las especies que tenés a cargo.' },
};

export default function Panel() {
  const { usuario, cerrar } = useSesion();
  const avisar = useAvisos();
  const [menu, setMenu] = useState(false);
  const [modal, setModal] = useState(null);
  const config = VISTAS[usuario.rol];

  return (
    <>
      <a className="visually-hidden-focusable btn btn-light position-absolute m-2" href="#contenido">Saltar al contenido</a>
      <header className="barra">
        <div className="container d-flex align-items-center gap-3 py-2">
          <span className="marca"><img src="/logo.svg" alt="" />Mundo Marino</span>
          <span className="chip-rol">{NOMBRE_ROL[usuario.rol]}</span>
          <div className="ms-auto dropdown">
            <button type="button" className="btn btn-sm btn-outline-light dropdown-toggle" aria-expanded={menu}
              onClick={() => setMenu((m) => !m)}>{usuario.nombre}</button>
            {menu && (
              <ul className="dropdown-menu dropdown-menu-end show" style={{ right: 0 }}>
                <li><button type="button" className="dropdown-item" onClick={() => { setMenu(false); setModal('perfil'); }}>Mi perfil</button></li>
                <li><button type="button" className="dropdown-item" onClick={() => { setMenu(false); setModal('contrasena'); }}>Cambiar contraseña</button></li>
                <li><hr className="dropdown-divider" /></li>
                <li><button type="button" className="dropdown-item text-danger" onClick={cerrar}>Cerrar sesión</button></li>
              </ul>
            )}
          </div>
        </div>
      </header>
      <section className="encabezado">
        <div className="container">
          <h1>Hola, {usuario.nombre.split(' ')[0]}</h1>
          <p>{config?.subtitulo}</p>
        </div>
      </section>
      <main id="contenido" className="container contenido pb-5" tabIndex={-1}>
        {config ? <config.Vista /> : <div className="alert alert-warning">Tu rol no tiene una vista asignada.</div>}
      </main>
      {modal === 'perfil' && <Perfil usuario={usuario} alCerrar={() => setModal(null)} />}
      {modal === 'contrasena' && (
        <CambioContrasena alCerrar={() => setModal(null)}
          alTerminar={() => avisar('Contraseña actualizada. Se cerraron tus sesiones en otros dispositivos.')} />
      )}
    </>
  );
}
