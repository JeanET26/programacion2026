/** Indicador de carga accesible. */
export function Cargando({ texto = 'Cargando…' }) {
  return (
    <div className="estado-carga" role="status">
      <span className="spinner-border spinner-border-sm" aria-hidden="true" /> {texto}
    </div>
  );
}

/** Error con opción de reintentar. Nunca muestra detalles técnicos. */
export function MensajeError({ error, alReintentar }) {
  return (
    <div className="alert alert-danger d-flex align-items-center gap-2" role="alert">
      <span>{error?.message || 'Ocurrió un error.'}</span>
      {alReintentar && (
        <button type="button" className="btn btn-sm btn-outline-danger ms-auto" onClick={alReintentar}>Reintentar</button>
      )}
    </div>
  );
}
