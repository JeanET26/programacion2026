import { useEffect, useRef } from 'react';

/** Ventana modal con estilos de Bootstrap (sin su JavaScript). Escape la cierra. */
export default function Modal({ titulo, alCerrar, children, pie }) {
  const caja = useRef(null);
  useEffect(() => {
    const anterior = document.activeElement;
    caja.current?.querySelector('input:not([disabled]), select:not([disabled]), textarea, button')?.focus();
    const tecla = (e) => e.key === 'Escape' && alCerrar();
    document.addEventListener('keydown', tecla);
    return () => {
      document.removeEventListener('keydown', tecla);
      anterior?.focus?.();
    };
  }, [alCerrar]);
  return (
    <div className="modal modal-mm" role="dialog" aria-modal="true" aria-labelledby="titulo-modal">
      <div className="modal-dialog modal-dialog-scrollable" ref={caja}>
        <div className="modal-content">
          <div className="modal-header">
            <h2 className="modal-title h5" id="titulo-modal">{titulo}</h2>
            <button type="button" className="btn-close" aria-label="Cerrar" onClick={alCerrar} />
          </div>
          <div className="modal-body">{children}</div>
          {pie && <div className="modal-footer">{pie}</div>}
        </div>
      </div>
    </div>
  );
}

export function Confirmar({ titulo, mensaje, textoBoton = 'Eliminar', alConfirmar, alCerrar }) {
  return (
    <Modal titulo={titulo} alCerrar={alCerrar} pie={<>
      <button type="button" className="btn btn-link" onClick={alCerrar}>Cancelar</button>
      <button type="button" className="btn btn-danger" onClick={alConfirmar}>{textoBoton}</button>
    </>}>
      <p className="mb-0">{mensaje}</p>
    </Modal>
  );
}
