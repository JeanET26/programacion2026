import { useEffect, useState } from 'react';
import Modal from './Modal.jsx';

/**
 * Formulario en modal a partir de una lista de campos:
 * { nombre, etiqueta, tipo: texto|password|numero|fecha|hora|area|seleccion|casillas|lista,
 *   requerido, valor, opciones: () => Promise<[{id, texto}]>, ayuda, min, max, paso, deshabilitado, validar }
 * Muestra el estado de envío y los errores que devuelve el servidor junto al campo.
 */
export default function Formulario({ titulo, campos, textoBoton = 'Guardar', alEnviar, alCerrar }) {
  const [valores, setValores] = useState(() => Object.fromEntries(campos.map((c) => [c.nombre, inicial(c)])));
  const [opciones, setOpciones] = useState({});
  const [errores, setErrores] = useState({});
  const [errorGeneral, setErrorGeneral] = useState(null);
  const [enviando, setEnviando] = useState(false);

  useEffect(() => {
    let vivo = true;
    campos.filter((c) => c.opciones).forEach(async (c) => {
      try {
        const lista = await c.opciones();
        if (vivo) setOpciones((o) => ({ ...o, [c.nombre]: lista }));
      } catch (e) {
        if (vivo) setErrorGeneral(e.message);
      }
    });
    return () => { vivo = false; };
  }, [campos]);

  const cambiar = (nombre, valor) => setValores((v) => ({ ...v, [nombre]: valor }));

  async function enviar(ev) {
    ev.preventDefault();
    const encontrados = {};
    for (const c of campos) {
      const v = valores[c.nombre];
      const vacio = v === '' || v === null || v === undefined || (Array.isArray(v) && v.length === 0);
      if (c.requerido && !c.deshabilitado && vacio) encontrados[c.nombre] = 'Este campo es obligatorio.';
      else if (c.validar && !vacio) {
        const e = c.validar(v, valores);
        if (e) encontrados[c.nombre] = e;
      }
    }
    setErrores(encontrados);
    if (Object.keys(encontrados).length) return;
    const datos = {};
    campos.filter((c) => !c.deshabilitado).forEach((c) => { datos[c.nombre] = convertir(c, valores[c.nombre]); });
    setEnviando(true);
    setErrorGeneral(null);
    try {
      await alEnviar(datos);
      alCerrar();
    } catch (e) {
      setErrorGeneral(e.message);
      setErrores(e.errores || {});
    } finally {
      setEnviando(false);
    }
  }

  return (
    <Modal titulo={titulo} alCerrar={alCerrar}>
      <form onSubmit={enviar} noValidate>
        {errorGeneral && <div className="alert alert-danger" role="alert">{errorGeneral}</div>}
        {campos.map((c) => (
          <Campo key={c.nombre} campo={c} valor={valores[c.nombre]} opciones={opciones[c.nombre]}
            error={errores[c.nombre]} alCambiar={(v) => cambiar(c.nombre, v)} />
        ))}
        <div className="d-flex justify-content-end gap-2">
          <button type="button" className="btn btn-link" onClick={alCerrar}>Cancelar</button>
          <button type="submit" className="btn btn-oceano" disabled={enviando}>
            {enviando ? 'Guardando…' : textoBoton}
          </button>
        </div>
      </form>
    </Modal>
  );
}

function inicial(c) {
  if (c.tipo === 'casillas') return c.valor ?? [];
  if (c.tipo === 'lista') return (c.valor ?? []).join(', ');
  return c.valor ?? '';
}

function convertir(c, v) {
  if (c.tipo === 'numero') return v === '' ? null : Number(v);
  if (c.tipo === 'lista') return String(v).split(',').map((x) => x.trim()).filter(Boolean);
  if (c.tipo === 'casillas' || c.tipo === 'password') return v;
  return v === '' ? null : String(v).trim();
}

function Campo({ campo: c, valor, opciones, error, alCambiar }) {
  const id = `campo-${c.nombre}`;
  const clase = `form-control${error ? ' is-invalid' : ''}`;
  let control;
  if (c.tipo === 'area') {
    control = <textarea id={id} className={clase} rows={3} value={valor} disabled={c.deshabilitado} onChange={(e) => alCambiar(e.target.value)} />;
  } else if (c.tipo === 'seleccion') {
    const lista = c.lista ?? opciones;
    control = (
      <select id={id} className={`form-select${error ? ' is-invalid' : ''}`} value={valor} disabled={c.deshabilitado || !lista}
        onChange={(e) => alCambiar(e.target.value)}>
        <option value="">{lista ? (c.requerido ? 'Elegí una opción…' : '— Ninguna —') : 'Cargando…'}</option>
        {(lista ?? []).map((o) => <option key={o.id} value={o.id}>{o.texto}</option>)}
      </select>
    );
  } else if (c.tipo === 'casillas') {
    control = (
      <div className="lista-opciones" role="group" aria-labelledby={`${id}-etiqueta`}>
        {!opciones && <span className="text-suave small">Cargando…</span>}
        {opciones?.length === 0 && <span className="text-suave small">No hay opciones disponibles.</span>}
        {opciones?.map((o) => (
          <div className="form-check" key={o.id}>
            <input className="form-check-input" type="checkbox" id={`${id}-${o.id}`} checked={valor.includes(o.id)}
              disabled={c.deshabilitado}
              onChange={(e) => alCambiar(e.target.checked ? [...valor, o.id] : valor.filter((x) => x !== o.id))} />
            <label className="form-check-label" htmlFor={`${id}-${o.id}`}>{o.texto}</label>
          </div>
        ))}
      </div>
    );
  } else {
    const tipos = { texto: 'text', password: 'password', numero: 'number', fecha: 'date', hora: 'time', lista: 'text' };
    control = (
      <input id={id} className={clase} type={tipos[c.tipo] ?? 'text'} value={valor} disabled={c.deshabilitado}
        min={c.min} max={c.max} step={c.paso} maxLength={c.maxLength} autoComplete={c.tipo === 'password' ? 'new-password' : 'off'}
        onChange={(e) => alCambiar(e.target.value)} />
    );
  }
  return (
    <div className="mb-3">
      <label className="form-label fw-semibold" htmlFor={id} id={`${id}-etiqueta`}>
        {c.etiqueta}{c.requerido && !c.deshabilitado && <span className="text-danger" aria-hidden="true"> *</span>}
      </label>
      {control}
      {c.ayuda && <div className="form-text">{c.ayuda}</div>}
      {error && <div className="invalid-feedback d-block">{error}</div>}
    </div>
  );
}
