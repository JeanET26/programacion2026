import { useCallback, useEffect, useState } from 'react';
import { api, consulta } from '../api/cliente.js';
import { TAMANIO_PAGINA } from '../config.js';
import { useAvisos } from './Avisos.jsx';
import { Cargando, MensajeError } from './Estados.jsx';
import Formulario from './Formulario.jsx';
import { Confirmar } from './Modal.jsx';

/**
 * Sección de administración genérica: tabla paginada EN EL SERVIDOR, búsqueda,
 * alta, edición y baja. Cada pestaña es solo una configuración (ver secciones.js).
 */
export default function SeccionCrud({ config, alCambiarDatos }) {
  const [pagina, setPagina] = useState(0);
  const [busqueda, setBusqueda] = useState('');
  const [texto, setTexto] = useState('');
  const [datos, setDatos] = useState(null);
  const [error, setError] = useState(null);
  const [cargando, setCargando] = useState(false);
  const [formulario, setFormulario] = useState(null);
  const [aEliminar, setAEliminar] = useState(null);
  const avisar = useAvisos();

  const cargar = useCallback(async () => {
    setCargando(true);
    setError(null);
    try {
      setDatos(await api.get(config.endpoint + consulta({ pagina, tamanio: TAMANIO_PAGINA, q: busqueda, orden: config.orden })));
    } catch (e) {
      setError(e);
    } finally {
      setCargando(false);
    }
  }, [config, pagina, busqueda]);

  useEffect(() => { cargar(); }, [cargar]);

  // La búsqueda se envía al servidor medio segundo después de dejar de escribir.
  useEffect(() => {
    const t = setTimeout(() => { setPagina(0); setBusqueda(texto.trim()); }, 400);
    return () => clearTimeout(t);
  }, [texto]);

  async function despuesDeCambiar(mensaje) {
    avisar(mensaje);
    await cargar();
    alCambiarDatos?.();
  }

  function abrir(item) {
    setFormulario({
      titulo: item ? `Editar ${config.singular}` : config.textoNuevo,
      campos: config.campos(item),
      alEnviar: async (valores) => {
        const cuerpo = config.aCuerpo ? config.aCuerpo(valores, item) : valores;
        if (item) await api.put(`${config.endpoint}/${item.id}`, { ...cuerpo, version: item.version });
        else await api.post(config.endpoint, cuerpo);
        await despuesDeCambiar(item ? 'Cambios guardados.' : 'Registro creado.');
      },
    });
  }

  async function eliminar() {
    const item = aEliminar;
    setAEliminar(null);
    try {
      await api.delete(`${config.endpoint}/${item.id}`);
      await despuesDeCambiar('Eliminado.');
    } catch (e) {
      avisar(e.message, 'error');
    }
  }

  return (
    <section className="tarjeta" aria-labelledby={`titulo-${config.clave}`}>
      <div className="d-flex flex-wrap align-items-center gap-2 p-3 border-bottom">
        <div className="me-auto">
          <h2 className="h5 mb-0" id={`titulo-${config.clave}`}>{config.titulo}</h2>
          {config.descripcion && <p className="small text-suave mb-0">{config.descripcion}</p>}
        </div>
        {config.buscable !== false && (
          <input type="search" className="form-control w-auto" placeholder="Buscar…" aria-label={`Buscar en ${config.titulo}`}
            maxLength={40} value={texto} onChange={(e) => setTexto(e.target.value)} />
        )}
        <button type="button" className="btn btn-coral" onClick={() => abrir(null)}>+ {config.textoNuevo}</button>
      </div>

      {error && <div className="p-3"><MensajeError error={error} alReintentar={cargar} /></div>}
      {!datos && !error && <Cargando />}
      {datos && (
        <>
          <div className="table-responsive">
            <table className="table table-hover tabla-mm" aria-busy={cargando}>
              <thead>
                <tr>
                  {config.columnas.map((c) => <th key={c.titulo} scope="col">{c.titulo}</th>)}
                  <th scope="col" className="text-end">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {datos.contenido.map((item) => (
                  <tr key={item.id}>
                    {config.columnas.map((c) => <td key={c.titulo}>{c.valor(item) ?? '—'}</td>)}
                    <td className="acciones">
                      <button type="button" className="btn btn-outline-secondary btn-icono me-1" onClick={() => abrir(item)}>Editar</button>
                      <button type="button" className="btn btn-outline-danger btn-icono" onClick={() => setAEliminar(item)}>Eliminar</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {datos.contenido.length === 0 && (
            <div className="vacio">{busqueda ? 'No hay resultados para esa búsqueda.' : `Todavía no hay ${config.titulo.toLowerCase()} cargados.`}</div>
          )}
          <div className="paginador">
            <span className="small text-suave me-auto">{datos.totalElementos} en total</span>
            <button type="button" className="btn btn-sm btn-outline-secondary" disabled={pagina === 0 || cargando}
              onClick={() => setPagina((p) => p - 1)}>← Anterior</button>
            <span className="small">Página {datos.totalPaginas === 0 ? 0 : pagina + 1} de {datos.totalPaginas}</span>
            <button type="button" className="btn btn-sm btn-outline-secondary" disabled={pagina + 1 >= datos.totalPaginas || cargando}
              onClick={() => setPagina((p) => p + 1)}>Siguiente →</button>
          </div>
        </>
      )}

      {formulario && <Formulario {...formulario} alCerrar={() => setFormulario(null)} />}
      {aEliminar && (
        <Confirmar titulo={`Eliminar ${config.singular}`} mensaje={config.textoBorrar(aEliminar)}
          alConfirmar={eliminar} alCerrar={() => setAEliminar(null)} />
      )}
    </section>
  );
}
