import { createContext, useCallback, useContext, useState } from 'react';

/** Mensajes breves de confirmación ("Guardado.") o error, en la esquina inferior. */
const AvisosContext = createContext(() => {});

export function ProveedorAvisos({ children }) {
  const [avisos, setAvisos] = useState([]);
  const avisar = useCallback((mensaje, tipo = 'ok') => {
    const id = Math.random().toString(36).slice(2);
    setAvisos((a) => [...a, { id, mensaje, tipo }]);
    setTimeout(() => setAvisos((a) => a.filter((x) => x.id !== id)), 4000);
  }, []);
  return (
    <AvisosContext.Provider value={avisar}>
      {children}
      <div className="avisos" aria-live="polite">
        {avisos.map((a) => (
          <div key={a.id} className={`aviso ${a.tipo === 'error' ? 'error' : ''}`} role={a.tipo === 'error' ? 'alert' : 'status'}>
            {a.mensaje}
          </div>
        ))}
      </div>
    </AvisosContext.Provider>
  );
}

export const useAvisos = () => useContext(AvisosContext);
