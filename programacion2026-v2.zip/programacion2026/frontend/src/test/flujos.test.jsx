import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import { describe, expect, it } from 'vitest';
import { olvidarCsrf } from '../api/cliente.js';
import App from '../App.jsx';
import { ProveedorAvisos } from '../componentes/Avisos.jsx';
import { ProveedorSesion } from '../sesion/SesionContext.jsx';
import { expirarSesion, registro } from './servidorSimulado.js';

function iniciarApp() {
  olvidarCsrf();
  return render(
    <MemoryRouter initialEntries={['/']}>
      <ProveedorAvisos><ProveedorSesion><App /></ProveedorSesion></ProveedorAvisos>
    </MemoryRouter>,
  );
}

async function ingresar(usuario, clave) {
  const u = userEvent.setup();
  await u.type(await screen.findByLabelText('Usuario'), usuario);
  await u.type(screen.getByLabelText('Contraseña'), clave);
  await u.click(screen.getByRole('button', { name: 'Ingresar' }));
  return u;
}

describe('Inicio de sesión', () => {
  it('sin sesión muestra el formulario de ingreso', async () => {
    iniciarApp();
    expect(await screen.findByRole('button', { name: 'Ingresar' })).toBeInTheDocument();
  });

  it('muestra el mensaje del servidor si la contraseña es incorrecta', async () => {
    iniciarApp();
    await ingresar('guia.lucia', 'equivocada');
    expect(await screen.findByRole('alert')).toHaveTextContent('Usuario o contraseña incorrectos.');
  });

  it('valida campos vacíos sin llamar al servidor', async () => {
    iniciarApp();
    const u = userEvent.setup();
    await u.click(await screen.findByRole('button', { name: 'Ingresar' }));
    expect(screen.getByRole('alert')).toHaveTextContent('Completá usuario y contraseña.');
  });
});

describe('Vistas por rol', () => {
  it('el guía ve solo su agenda', async () => {
    iniciarApp();
    await ingresar('guia.lucia', 'Marino2026!');
    expect(await screen.findByText('Mi agenda de hoy')).toBeInTheDocument();
    expect(screen.getByText('IT-01')).toBeInTheDocument();
    expect(screen.getByText('Pez payaso')).toBeInTheDocument();
    expect(screen.queryByText('Horarios de guías')).not.toBeInTheDocument();
  });

  it('el cuidador ve sus especies y quién más las cuida', async () => {
    iniciarApp();
    await ingresar('cuidador.diego', 'Marino2026!');
    expect(await screen.findByText('Tortuga verde')).toBeInTheDocument();
    expect(screen.getByText(/También la cuida: Sofía Ibarra/)).toBeInTheDocument();
  });

  it('si la sesión vence, vuelve al ingreso', async () => {
    iniciarApp();
    const u = await ingresar('admin.ana', 'Admin2026!');
    await screen.findByText('Lucía Gómez', { selector: 'strong' });
    expirarSesion();
    await u.click(screen.getByRole('tab', { name: 'Zonas' }));
    expect(await screen.findByRole('button', { name: 'Ingresar' })).toBeInTheDocument();
  });
});

describe('Administración', () => {
  it('crea una zona enviando el token CSRF y confirma la operación', async () => {
    iniciarApp();
    const u = await ingresar('admin.ana', 'Admin2026!');
    await u.click(await screen.findByRole('tab', { name: 'Zonas' }));
    await screen.findByText('Zona 01');
    await u.click(screen.getByRole('button', { name: '+ Nueva zona' }));
    const modal = await screen.findByRole('dialog');
    await u.type(within(modal).getByLabelText(/Nombre/), 'Pingüinera');
    await u.type(within(modal).getByLabelText(/Extensión/), '600');
    await u.click(within(modal).getByRole('button', { name: 'Guardar' }));
    expect(await screen.findByText('Registro creado.')).toBeInTheDocument();
    expect(await screen.findByText('Pingüinera')).toBeInTheDocument();
    const post = registro.pedidos.find((p) => p.metodo === 'POST' && p.url.endsWith('/api/zonas'));
    expect(post.csrf).toBe('token-csrf-prueba');
  });

  it('muestra el error del servidor dentro del formulario y no lo cierra', async () => {
    iniciarApp();
    const u = await ingresar('admin.ana', 'Admin2026!');
    await u.click(await screen.findByRole('button', { name: '+ Asignar horario' }));
    const modal = await screen.findByRole('dialog');
    await waitFor(() => expect(within(modal).getByRole('option', { name: 'Lucía Gómez' })).toBeInTheDocument());
    await u.selectOptions(within(modal).getByLabelText(/Guía/), 'g1');
    await u.selectOptions(within(modal).getByLabelText(/Itinerario/), 'i2');
    const hora = within(modal).getByLabelText(/Hora de salida/);
    await u.clear(hora);
    await u.type(hora, '10:30');
    await u.click(within(modal).getByRole('button', { name: 'Guardar' }));
    expect(await within(modal).findByRole('alert')).toHaveTextContent('se superpone');
    expect(screen.getByRole('dialog')).toBeInTheDocument();
  });

  it('al editar envía la versión leída (control de cambios concurrentes)', async () => {
    iniciarApp();
    const u = await ingresar('admin.ana', 'Admin2026!');
    await u.click(await screen.findByRole('tab', { name: 'Zonas' }));
    await screen.findByText('Zona 01');
    await u.click(screen.getAllByRole('button', { name: 'Editar' })[0]);
    const modal = await screen.findByRole('dialog');
    const nombre = within(modal).getByLabelText(/Nombre/);
    await u.clear(nombre);
    await u.type(nombre, 'Zona renombrada');
    await u.click(within(modal).getByRole('button', { name: 'Guardar' }));
    expect(await screen.findByText('Cambios guardados.')).toBeInTheDocument();
    expect(registro.ultimoCuerpo).toMatchObject({ nombre: 'Zona renombrada', version: 0 });
  });

  it('la paginación pide la página siguiente al servidor', async () => {
    iniciarApp();
    const u = await ingresar('admin.ana', 'Admin2026!');
    await u.click(await screen.findByRole('tab', { name: 'Zonas' }));
    await screen.findByText('Zona 01');
    expect(screen.getByText('Página 1 de 2')).toBeInTheDocument();
    await u.click(screen.getByRole('button', { name: 'Siguiente →' }));
    expect(await screen.findByText('Zona 11')).toBeInTheDocument();
    expect(registro.pedidos.some((p) => p.url.includes('/api/zonas') && p.url.includes('pagina=1'))).toBe(true);
  });

  it('valida localmente que las contraseñas coincidan', async () => {
    iniciarApp();
    const u = await ingresar('guia.lucia', 'Marino2026!');
    await u.click(await screen.findByRole('button', { name: 'Lucía Gómez' }));
    await u.click(screen.getByRole('button', { name: 'Cambiar contraseña' }));
    const modal = await screen.findByRole('dialog');
    await u.type(within(modal).getByLabelText(/Contraseña actual/), 'Marino2026!');
    await u.type(within(modal).getByLabelText(/^Nueva contraseña/), 'NuevaClave2026');
    await u.type(within(modal).getByLabelText(/Repetí/), 'OtraClave2026');
    await u.click(within(modal).getByRole('button', { name: 'Cambiar' }));
    expect(within(modal).getByText('No coincide con la nueva contraseña.')).toBeInTheDocument();
  });
});
