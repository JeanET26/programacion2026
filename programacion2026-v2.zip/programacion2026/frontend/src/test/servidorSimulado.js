import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';

/**
 * Backend SIMULADO para probar el frontend sin Java: responde como la API real
 * (mismos códigos y formatos). Registra los pedidos para verificar qué envió
 * el frontend (por ejemplo, el token CSRF y la versión al editar).
 */
const B = 'http://api.prueba';
const TOKEN = 'token-csrf-prueba';

export const registro = { pedidos: [] };
let estado;

export function reiniciarDatos() {
  estado = {
    sesion: null,
    usuarios: {
      'admin.ana': { clave: 'Admin2026!', perfil: { id: 'a1', nombreUsuario: 'admin.ana', nombre: 'Ana Ruiz', rol: 'ADMINISTRADOR', permisos: ['ADMINISTRAR_PARQUE'] } },
      'guia.lucia': { clave: 'Marino2026!', perfil: { id: 'g1', nombreUsuario: 'guia.lucia', nombre: 'Lucía Gómez', rol: 'GUIA', permisos: ['VER_RECORRIDOS_PROPIOS'] } },
      'cuidador.diego': { clave: 'Marino2026!', perfil: { id: 'c1', nombreUsuario: 'cuidador.diego', nombre: 'Diego Pérez', rol: 'CUIDADOR', permisos: ['VER_ESPECIES_PROPIAS'] } },
    },
    zonas: Array.from({ length: 12 }, (_, i) => ({ id: `z${i + 1}`, nombre: `Zona ${String(i + 1).padStart(2, '0')}`, extensionM2: 100, cantidadEspecies: 0, version: 0 })),
    horarios: [{ id: 'h1', guiaId: 'g1', guiaNombre: 'Lucía Gómez', itinerarioId: 'i1', itinerarioCodigo: 'IT-01', hora: '10:00', horaFin: '10:45', zonas: ['Arrecife'], version: 0 }],
  };
  registro.pedidos = [];
}
reiniciarDatos();

const error = (status, mensaje, errores = {}) => HttpResponse.json({ estado: status, mensaje, errores }, { status });
const pagina = (lista, url) => {
  const p = Number(url.searchParams.get('pagina') ?? 0);
  const t = Number(url.searchParams.get('tamanio') ?? 10);
  const q = (url.searchParams.get('q') ?? '').toLowerCase();
  const filtrada = lista.filter((x) => !q || JSON.stringify(x).toLowerCase().includes(q));
  return { contenido: filtrada.slice(p * t, p * t + t), numero: p, tamanio: t, totalElementos: filtrada.length, totalPaginas: Math.ceil(filtrada.length / t) };
};

/** Simula Spring Security: sesión obligatoria, permiso por rol y CSRF en las modificaciones. */
function proteger(request, rol) {
  registro.pedidos.push({ metodo: request.method, url: request.url, csrf: request.headers.get('X-CSRF-TOKEN') });
  if (!estado.sesion) return error(401, 'Tenés que iniciar sesión.');
  if (request.method !== 'GET' && request.headers.get('X-CSRF-TOKEN') !== TOKEN) return error(403, 'Falta o venció el token de seguridad (CSRF).');
  if (rol && estado.sesion.rol !== rol) return error(403, 'No tenés permiso para realizar esta operación.');
  return null;
}

export const servidor = setupServer(
  http.get(`${B}/api/auth/csrf`, () => HttpResponse.json({ encabezado: 'X-CSRF-TOKEN', token: TOKEN })),
  http.get(`${B}/api/auth/yo`, () => (estado.sesion ? HttpResponse.json(estado.sesion) : error(401, 'Tenés que iniciar sesión.'))),
  http.post(`${B}/api/auth/login`, async ({ request }) => {
    if (request.headers.get('X-CSRF-TOKEN') !== TOKEN) return error(403, 'Falta o venció el token de seguridad (CSRF).');
    const { nombreUsuario, contrasena } = await request.json();
    const u = estado.usuarios[nombreUsuario];
    if (!u || u.clave !== contrasena) return error(401, 'Usuario o contraseña incorrectos.');
    estado.sesion = u.perfil;
    return HttpResponse.json(u.perfil);
  }),
  http.post(`${B}/api/auth/logout`, () => { estado.sesion = null; return new HttpResponse(null, { status: 204 }); }),
  http.put(`${B}/api/auth/contrasena`, ({ request }) => proteger(request) ?? new HttpResponse(null, { status: 204 })),

  http.get(`${B}/api/mi/recorridos`, ({ request }) => proteger(request, 'GUIA') ?? HttpResponse.json([
    { asignacionId: 'h1', hora: '10:00', horaFin: '10:45', codigo: 'IT-01', duracionMinutos: 45, longitudKm: 1.8, maximoVisitantes: 25,
      zonas: ['Arrecife central', 'Túnel oceánico'], especies: [{ nombreEspanol: 'Pez payaso', nombreCientifico: 'Amphiprion ocellaris' }] },
  ])),
  http.get(`${B}/api/mi/especies`, ({ request }) => proteger(request, 'CUIDADOR') ?? HttpResponse.json([
    { asignacionId: 'c1', desde: '2025-02-01', nombreEspanol: 'Tortuga verde', nombreCientifico: 'Chelonia mydas', descripcion: 'Herbívora',
      zona: 'Túnel oceánico', habitats: [{ nombre: 'Arrecife coralino', clima: 'Tropical' }], otrosCuidadores: ['Sofía Ibarra'] },
  ])),

  http.get(`${B}/api/zonas`, ({ request }) => proteger(request, 'ADMINISTRADOR') ?? HttpResponse.json(pagina(estado.zonas, new URL(request.url)))),
  http.post(`${B}/api/zonas`, async ({ request }) => {
    const bloqueo = proteger(request, 'ADMINISTRADOR');
    if (bloqueo) return bloqueo;
    const datos = await request.json();
    if (!datos.nombre) return error(400, 'Revisá los datos ingresados.', { nombre: 'El nombre es obligatorio.' });
    if (estado.zonas.some((z) => z.nombre.toLowerCase() === datos.nombre.toLowerCase())) return error(409, 'Ya existe una zona con ese nombre.');
    const nueva = { id: `z${estado.zonas.length + 1}`, cantidadEspecies: 0, version: 0, ...datos };
    estado.zonas.unshift(nueva);
    return HttpResponse.json(nueva, { status: 201 });
  }),
  http.put(`${B}/api/zonas/:id`, async ({ request, params }) => {
    const bloqueo = proteger(request, 'ADMINISTRADOR');
    if (bloqueo) return bloqueo;
    const datos = await request.json();
    registro.ultimoCuerpo = datos;
    const z = estado.zonas.find((x) => x.id === params.id);
    if (datos.version !== z.version) return error(409, 'Otra persona modificó este registro mientras lo editabas.');
    Object.assign(z, datos, { version: z.version + 1 });
    return HttpResponse.json(z);
  }),
  http.get(`${B}/api/asignaciones-guia`, ({ request }) => proteger(request, 'ADMINISTRADOR') ?? HttpResponse.json(pagina(estado.horarios, new URL(request.url)))),
  http.post(`${B}/api/asignaciones-guia`, async ({ request }) => {
    const bloqueo = proteger(request, 'ADMINISTRADOR');
    if (bloqueo) return bloqueo;
    const datos = await request.json();
    if (datos.hora < '10:45' && datos.hora > '09:15') return error(409, 'El guía ya tiene el IT-01 de 10:00 a 10:45, que se superpone.');
    return HttpResponse.json({ id: 'h2', ...datos, guiaNombre: 'Lucía Gómez', itinerarioCodigo: 'IT-02', horaFin: '11:30', zonas: [], version: 0 }, { status: 201 });
  }),
  http.get(`${B}/api/empleados/opciones`, () => HttpResponse.json([{ id: 'g1', texto: 'Lucía Gómez' }])),
  http.get(`${B}/api/itinerarios/opciones`, () => HttpResponse.json([{ id: 'i1', texto: 'IT-01 · 45 min' }, { id: 'i2', texto: 'IT-02 · 45 min' }])),
  http.get(`${B}/api/empleados`, ({ request }) => proteger(request, 'ADMINISTRADOR') ?? HttpResponse.json(pagina([], new URL(request.url)))),
  http.get(`${B}/api/itinerarios`, ({ request }) => proteger(request, 'ADMINISTRADOR') ?? HttpResponse.json(pagina([], new URL(request.url)))),
  http.get(`${B}/api/especies`, ({ request }) => proteger(request, 'ADMINISTRADOR') ?? HttpResponse.json(pagina([], new URL(request.url)))),
);

export function expirarSesion() {
  estado.sesion = null;
}
