import { api, olvidarCsrf } from './cliente.js';

export async function iniciarSesion(nombreUsuario, contrasena) {
  olvidarCsrf();
  const perfil = await api.post('/api/auth/login', { nombreUsuario, contrasena });
  olvidarCsrf(); // el servidor renueva el token al iniciar sesión
  return perfil;
}

export async function cerrarSesion() {
  try {
    await api.post('/api/auth/logout');
  } finally {
    olvidarCsrf();
  }
}

export const perfilActual = () => api.get('/api/auth/yo');

export async function cambiarContrasena(actual, nueva) {
  await api.put('/api/auth/contrasena', { actual, nueva });
  olvidarCsrf();
}
