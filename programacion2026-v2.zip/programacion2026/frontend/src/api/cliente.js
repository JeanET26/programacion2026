import { API_URL } from '../config.js';

/**
 * Único lugar que habla con el backend.
 * - credentials: 'include' → el navegador envía la cookie de sesión (HttpOnly; JavaScript no la ve).
 * - CSRF: en POST/PUT/DELETE se envía el token que da GET /api/auth/csrf.
 * - Errores: el backend responde { estado, mensaje, errores }; se lanzan como ErrorApi.
 */
export class ErrorApi extends Error {
  constructor(mensaje, estado, errores = {}) {
    super(mensaje);
    this.estado = estado;
    this.errores = errores;
  }
}

let csrf = null; // { encabezado, token } en memoria (nunca en localStorage)
let alExpirarSesion = () => {};

export function configurarExpiracionSesion(funcion) {
  alExpirarSesion = funcion;
}

export function olvidarCsrf() {
  csrf = null;
}

async function obtenerCsrf() {
  if (!csrf) {
    const r = await fetch(`${API_URL}/api/auth/csrf`, { credentials: 'include', headers: { Accept: 'application/json' } });
    if (!r.ok) throw new ErrorApi('No se pudo obtener el token de seguridad.', r.status);
    csrf = await r.json();
  }
  return csrf;
}

async function pedir(metodo, ruta, cuerpo, reintento = true) {
  const encabezados = { Accept: 'application/json' };
  if (metodo !== 'GET') {
    const t = await obtenerCsrf();
    encabezados['Content-Type'] = 'application/json';
    encabezados[t.encabezado] = t.token;
  }
  let respuesta;
  try {
    respuesta = await fetch(`${API_URL}${ruta}`, {
      method: metodo,
      credentials: 'include',
      headers: encabezados,
      body: cuerpo === undefined ? undefined : JSON.stringify(cuerpo),
    });
  } catch {
    throw new ErrorApi('No se pudo conectar con el servidor. ¿Está corriendo el backend?', 0);
  }
  const datos = (respuesta.headers.get('Content-Type') || '').includes('application/json') ? await respuesta.json() : null;
  if (respuesta.ok) return datos;

  // Token CSRF vencido (por ejemplo, después de iniciar sesión): se pide otro y se reintenta una vez.
  if (respuesta.status === 403 && metodo !== 'GET' && reintento && datos?.mensaje?.includes('CSRF')) {
    csrf = null;
    return pedir(metodo, ruta, cuerpo, false);
  }
  if (respuesta.status === 401 && !ruta.startsWith('/api/auth/')) alExpirarSesion();
  throw new ErrorApi(datos?.mensaje || `Error ${respuesta.status}`, respuesta.status, datos?.errores || {});
}

export const api = {
  get: (ruta) => pedir('GET', ruta),
  post: (ruta, cuerpo) => pedir('POST', ruta, cuerpo ?? {}),
  put: (ruta, cuerpo) => pedir('PUT', ruta, cuerpo ?? {}),
  delete: (ruta) => pedir('DELETE', ruta),
};

/** Arma "?pagina=0&tamanio=10&..." omitiendo vacíos. */
export function consulta(parametros) {
  const p = new URLSearchParams();
  Object.entries(parametros).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') p.set(k, v);
  });
  const texto = p.toString();
  return texto ? `?${texto}` : '';
}
