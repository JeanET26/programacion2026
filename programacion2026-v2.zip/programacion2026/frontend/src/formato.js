/** Formatos para mostrar (es-AR). */
export function fecha(iso) {
  if (!iso) return '—';
  const [a, m, d] = iso.split('-').map(Number);
  return new Date(a, m - 1, d).toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

export function duracion(min) {
  const h = Math.floor(min / 60);
  const m = min % 60;
  return h ? `${h} h${m ? ` ${m} min` : ''}` : `${m} min`;
}

export const hoyIso = () => new Date().toISOString().slice(0, 10);

export function minutosDelDia(hhmm) {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
}

export function diasDesde(iso) {
  const [a, m, d] = iso.split('-').map(Number);
  return Math.max(0, Math.floor((Date.now() - new Date(a, m - 1, d)) / 86400000));
}

export const NOMBRE_ROL = { ADMINISTRADOR: 'Administración', GUIA: 'Guía', CUIDADOR: 'Cuidador/a' };
