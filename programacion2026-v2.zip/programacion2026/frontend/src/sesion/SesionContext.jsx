import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { configurarExpiracionSesion } from '../api/cliente.js';
import * as auth from '../api/autenticacion.js';

/**
 * Estado de la sesión en el frontend: quién inició sesión. La sesión real
 * vive en el servidor; acá solo se guarda el perfil para mostrar el nombre
 * y elegir la vista. Al recargar la página se vuelve a pedir al servidor.
 */
const SesionContext = createContext(null);

export function ProveedorSesion({ children }) {
  const [usuario, setUsuario] = useState(null);
  const [cargando, setCargando] = useState(true);

  const recargar = useCallback(async () => {
    try {
      setUsuario(await auth.perfilActual());
    } catch {
      setUsuario(null);
    } finally {
      setCargando(false);
    }
  }, []);

  useEffect(() => {
    configurarExpiracionSesion(() => setUsuario(null));
    recargar();
  }, [recargar]);

  const valor = useMemo(() => ({
    usuario,
    cargando,
    iniciar: async (u, c) => setUsuario(await auth.iniciarSesion(u, c)),
    cerrar: async () => {
      try {
        await auth.cerrarSesion();
      } finally {
        setUsuario(null);
      }
    },
  }), [usuario, cargando]);

  return <SesionContext.Provider value={valor}>{children}</SesionContext.Provider>;
}

export function useSesion() {
  return useContext(SesionContext);
}
