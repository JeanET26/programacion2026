import { Navigate, Route, Routes } from 'react-router-dom';
import { Cargando } from './componentes/Estados.jsx';
import Login from './paginas/Login.jsx';
import Panel from './paginas/Panel.jsx';
import { useSesion } from './sesion/SesionContext.jsx';

/** Rutas: /ingresar (público) y / (requiere sesión). */
export default function App() {
  const { usuario, cargando } = useSesion();
  if (cargando) return <div className="container py-5"><Cargando /></div>;
  return (
    <Routes>
      <Route path="/ingresar" element={usuario ? <Navigate to="/" replace /> : <Login />} />
      <Route path="/" element={usuario ? <Panel /> : <Navigate to="/ingresar" replace />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
