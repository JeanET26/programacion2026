-- =====================================================================
-- V1: esquema inicial de Mundo Marino (MySQL 8, InnoDB, utf8mb4).
--
-- Reglas que garantiza la BASE (aunque haya dos pedidos simultáneos):
--   * Claves primarias UUID (CHAR(36), texto "8-4-4-4-12").
--   * Unicidad: nombre de zona/hábitat, nombre científico, código de
--     itinerario, nombre de usuario, cuidador+especie, guía+hora de salida.
--   * Claves foráneas con RESTRICT: no se puede borrar algo que esté en uso.
--   * CHECK de valores numéricos y de datos obligatorios por rol.
--   * Columna "version" para el bloqueo optimista (@Version de JPA).
-- Las reglas que dependen de varias filas (horarios superpuestos) las
-- controla el servicio con bloqueo pesimista; ver docs/CONCURRENCIA.md.
-- =====================================================================

CREATE TABLE zona (
    id            CHAR(36)      NOT NULL,
    nombre        VARCHAR(80)   NOT NULL,
    extension_m2  DECIMAL(10,2) NOT NULL,
    version       BIGINT        NOT NULL DEFAULT 0,
    CONSTRAINT pk_zona PRIMARY KEY (id),
    CONSTRAINT uk_zona_nombre UNIQUE (nombre),
    CONSTRAINT ck_zona_extension CHECK (extension_m2 > 0)
) ENGINE = InnoDB;

CREATE TABLE habitat (
    id          CHAR(36)     NOT NULL,
    nombre      VARCHAR(80)  NOT NULL,
    clima       VARCHAR(80)  NOT NULL,
    vegetacion  VARCHAR(120) NOT NULL,
    version     BIGINT       NOT NULL DEFAULT 0,
    CONSTRAINT pk_habitat PRIMARY KEY (id),
    CONSTRAINT uk_habitat_nombre UNIQUE (nombre)
) ENGINE = InnoDB;

-- Set<String> continentes de Habitat (@ElementCollection)
CREATE TABLE habitat_continente (
    habitat_id  CHAR(36)    NOT NULL,
    continente  VARCHAR(30) NOT NULL,
    CONSTRAINT pk_habitat_continente PRIMARY KEY (habitat_id, continente),
    CONSTRAINT fk_habitat_continente_habitat FOREIGN KEY (habitat_id)
        REFERENCES habitat (id) ON DELETE CASCADE
) ENGINE = InnoDB;

CREATE TABLE especie (
    id                 CHAR(36)     NOT NULL,
    nombre_espanol     VARCHAR(80)  NOT NULL,
    nombre_cientifico  VARCHAR(120) NOT NULL,
    descripcion        VARCHAR(500) NOT NULL,
    zona_id            CHAR(36)     NULL,
    version            BIGINT       NOT NULL DEFAULT 0,
    CONSTRAINT pk_especie PRIMARY KEY (id),
    CONSTRAINT uk_especie_nombre_cientifico UNIQUE (nombre_cientifico),
    -- RESTRICT: no se puede borrar una zona con especies ubicadas.
    CONSTRAINT fk_especie_zona FOREIGN KEY (zona_id) REFERENCES zona (id) ON DELETE RESTRICT
) ENGINE = InnoDB;
-- Índice para ordenar y buscar el listado por nombre (el más usado en pantalla).
CREATE INDEX ix_especie_nombre_espanol ON especie (nombre_espanol);

CREATE TABLE especie_habitat (
    especie_id  CHAR(36) NOT NULL,
    habitat_id  CHAR(36) NOT NULL,
    CONSTRAINT pk_especie_habitat PRIMARY KEY (especie_id, habitat_id),
    CONSTRAINT fk_especie_habitat_especie FOREIGN KEY (especie_id) REFERENCES especie (id) ON DELETE CASCADE,
    -- RESTRICT: no se puede borrar un hábitat asociado a especies.
    CONSTRAINT fk_especie_habitat_habitat FOREIGN KEY (habitat_id) REFERENCES habitat (id) ON DELETE RESTRICT
) ENGINE = InnoDB;

CREATE TABLE itinerario (
    id                 CHAR(36)     NOT NULL,
    codigo             VARCHAR(5)   NOT NULL,
    duracion_minutos   INT          NOT NULL,
    longitud_km        DECIMAL(5,2) NOT NULL,
    maximo_visitantes  INT          NOT NULL,
    version            BIGINT       NOT NULL DEFAULT 0,
    CONSTRAINT pk_itinerario PRIMARY KEY (id),
    CONSTRAINT uk_itinerario_codigo UNIQUE (codigo),
    CONSTRAINT ck_itinerario_codigo CHECK (codigo REGEXP '^IT-[0-9]{2}$'),
    CONSTRAINT ck_itinerario_duracion CHECK (duracion_minutos BETWEEN 5 AND 480),
    CONSTRAINT ck_itinerario_longitud CHECK (longitud_km > 0),
    CONSTRAINT ck_itinerario_maximo CHECK (maximo_visitantes BETWEEN 1 AND 500)
) ENGINE = InnoDB;

-- Las zonas del itinerario NO se guardan: se derivan de estas especies.
CREATE TABLE itinerario_especie (
    itinerario_id  CHAR(36) NOT NULL,
    especie_id     CHAR(36) NOT NULL,
    CONSTRAINT pk_itinerario_especie PRIMARY KEY (itinerario_id, especie_id),
    CONSTRAINT fk_itinerario_especie_itinerario FOREIGN KEY (itinerario_id) REFERENCES itinerario (id) ON DELETE CASCADE,
    -- RESTRICT: no se puede borrar una especie que forma parte de un itinerario.
    CONSTRAINT fk_itinerario_especie_especie FOREIGN KEY (especie_id) REFERENCES especie (id) ON DELETE RESTRICT
) ENGINE = InnoDB;
-- "¿En qué itinerarios está esta especie?" (regla al quitarle la zona).
CREATE INDEX ix_itinerario_especie_especie ON itinerario_especie (especie_id);

-- Administrador, Guía y Cuidador en una sola tabla (herencia SINGLE_TABLE).
CREATE TABLE usuario (
    id               CHAR(36)     NOT NULL,
    rol              VARCHAR(20)  NOT NULL,
    nombre_usuario   VARCHAR(30)  NOT NULL,
    hash_contrasena  VARCHAR(255) NOT NULL,
    nombre           VARCHAR(80)  NOT NULL,
    direccion        VARCHAR(120) NULL,
    telefono         VARCHAR(20)  NULL,
    fecha_ingreso    DATE         NULL,
    version          BIGINT       NOT NULL DEFAULT 0,
    CONSTRAINT pk_usuario PRIMARY KEY (id),
    CONSTRAINT uk_usuario_nombre_usuario UNIQUE (nombre_usuario),
    CONSTRAINT ck_usuario_rol CHECK (rol IN ('ADMINISTRADOR', 'GUIA', 'CUIDADOR')),
    -- Los empleados deben tener sus datos laborales completos.
    CONSTRAINT ck_usuario_datos_empleado CHECK (
        rol = 'ADMINISTRADOR'
        OR (direccion IS NOT NULL AND telefono IS NOT NULL AND fecha_ingreso IS NOT NULL))
) ENGINE = InnoDB;
-- Listado de personal filtrado por rol y ordenado por nombre.
CREATE INDEX ix_usuario_rol_nombre ON usuario (rol, nombre);

CREATE TABLE asignacion_guia (
    id             CHAR(36) NOT NULL,
    guia_id        CHAR(36) NOT NULL,
    itinerario_id  CHAR(36) NOT NULL,
    hora           TIME     NOT NULL,
    version        BIGINT   NOT NULL DEFAULT 0,
    CONSTRAINT pk_asignacion_guia PRIMARY KEY (id),
    -- Red de seguridad en la base: un guía no puede salir dos veces a la misma hora.
    -- La superposición parcial (10:00-10:45 vs 10:30) la controla el servicio con bloqueo.
    -- Este índice único también sirve para buscar los horarios de un guía ordenados.
    CONSTRAINT uk_asignacion_guia_guia_hora UNIQUE (guia_id, hora),
    CONSTRAINT fk_asignacion_guia_guia FOREIGN KEY (guia_id) REFERENCES usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_asignacion_guia_itinerario FOREIGN KEY (itinerario_id) REFERENCES itinerario (id) ON DELETE RESTRICT
) ENGINE = InnoDB;

CREATE TABLE asignacion_cuidado (
    id                CHAR(36) NOT NULL,
    cuidador_id       CHAR(36) NOT NULL,
    especie_id        CHAR(36) NOT NULL,
    fecha_asignacion  DATE     NOT NULL,
    version           BIGINT   NOT NULL DEFAULT 0,
    CONSTRAINT pk_asignacion_cuidado PRIMARY KEY (id),
    CONSTRAINT uk_asignacion_cuidado_cuidador_especie UNIQUE (cuidador_id, especie_id),
    CONSTRAINT fk_asignacion_cuidado_cuidador FOREIGN KEY (cuidador_id) REFERENCES usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_asignacion_cuidado_especie FOREIGN KEY (especie_id) REFERENCES especie (id) ON DELETE RESTRICT
) ENGINE = InnoDB;
-- "¿Quién más cuida esta especie?" (vista del cuidador).
CREATE INDEX ix_asignacion_cuidado_especie ON asignacion_cuidado (especie_id);
