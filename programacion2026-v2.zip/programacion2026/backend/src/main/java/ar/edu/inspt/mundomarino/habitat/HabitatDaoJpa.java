package ar.edu.inspt.mundomarino.habitat;

import ar.edu.inspt.mundomarino.comun.dao.DaoJpa;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Repository;

@Repository
class HabitatDaoJpa extends DaoJpa<Habitat, UUID> implements HabitatDao {

    private final HabitatRepositorio repositorio;

    HabitatDaoJpa(HabitatRepositorio repositorio) {
        super(repositorio);
        this.repositorio = repositorio;
    }

    @Override
    public boolean existeNombre(String nombre, UUID excluirId) {
        String n = nombre == null ? "" : nombre.strip();
        return excluirId == null ? repositorio.existsByNombreIgnoreCase(n)
                : repositorio.existsByNombreIgnoreCaseAndIdNot(n, excluirId);
    }

    @Override
    public Pagina<Habitat> buscar(String texto, SolicitudPagina solicitud) {
        return aPagina(repositorio.buscar(patronBusqueda(texto), aPageable(solicitud)));
    }

    @Override
    public List<Habitat> opciones() {
        return repositorio.findTop500ByOrderByNombreAsc();
    }

    @Override
    public List<Habitat> buscarPorIds(Collection<UUID> ids) {
        return ids.isEmpty() ? List.of() : repositorio.findAllById(ids);
    }
}
