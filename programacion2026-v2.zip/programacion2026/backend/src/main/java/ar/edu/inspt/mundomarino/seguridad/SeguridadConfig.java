package ar.edu.inspt.mundomarino.seguridad;

import ar.edu.inspt.mundomarino.personal.Permiso;
import java.util.List;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.logout.HttpStatusReturningLogoutSuccessHandler;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.security.web.context.SecurityContextRepository;
import org.springframework.security.web.csrf.HttpSessionCsrfTokenRepository;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

/**
 * Configuración web de Spring Security (solo cuando hay servidor web). Decisiones (explicadas en docs/SEGURIDAD.md):
 * <ul>
 *   <li><b>Sesión con cookie</b> (no JWT): el servidor guarda la sesión en
 *   MySQL (Spring Session JDBC) y el navegador solo tiene un identificador en
 *   una cookie HttpOnly. Es simple y permite cerrar sesiones desde el servidor.</li>
 *   <li><b>CSRF activado</b>: como el navegador envía la cookie solo, cada
 *   POST/PUT/DELETE debe llevar además un token que solo nuestro frontend conoce.</li>
 *   <li><b>CORS explícito</b>: solo los orígenes configurados, con credenciales.</li>
 *   <li><b>Autorización por permisos</b>: cada ruta exige un {@link Permiso}.</li>
 * </ul>
 */
@Configuration
@EnableWebSecurity
@ConditionalOnWebApplication
public class SeguridadConfig {

    private static final String[] RUTAS_ADMIN = {
        "/api/zonas/**", "/api/habitats/**", "/api/especies/**", "/api/itinerarios/**",
        "/api/empleados/**", "/api/asignaciones-guia/**", "/api/asignaciones-cuidado/**"
    };

    @Bean
    SecurityFilterChain cadenaDeFiltros(HttpSecurity http, RespuestasJsonSeguridad respuestas,
            SecurityContextRepository repositorioContexto, HttpSessionCsrfTokenRepository repositorioCsrf) throws Exception {
        http
            .cors(Customizer.withDefaults())
            .csrf(csrf -> csrf.csrfTokenRepository(repositorioCsrf))
            .securityContext(ctx -> ctx.securityContextRepository(repositorioContexto))
            .requestCache(AbstractHttpConfigurer::disable)
            .formLogin(AbstractHttpConfigurer::disable)
            .httpBasic(AbstractHttpConfigurer::disable)
            .authorizeHttpRequests(a -> a
                .requestMatchers("/error").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/auth/csrf").permitAll()
                .requestMatchers(HttpMethod.POST, "/api/auth/login").permitAll()
                .requestMatchers("/actuator/health", "/actuator/health/**").permitAll()
                .requestMatchers("/v3/api-docs/**", "/swagger-ui/**", "/swagger-ui.html").permitAll()
                .requestMatchers("/api/auth/**").authenticated()
                .requestMatchers(HttpMethod.GET, "/api/mi/recorridos").hasAuthority(Permiso.VER_RECORRIDOS_PROPIOS.name())
                .requestMatchers(HttpMethod.GET, "/api/mi/especies").hasAuthority(Permiso.VER_ESPECIES_PROPIAS.name())
                .requestMatchers(RUTAS_ADMIN).hasAuthority(Permiso.ADMINISTRAR_PARQUE.name())
                .anyRequest().denyAll())
            .exceptionHandling(e -> e.authenticationEntryPoint(respuestas).accessDeniedHandler(respuestas))
            .logout(l -> l
                .logoutUrl("/api/auth/logout")
                .logoutSuccessHandler(new HttpStatusReturningLogoutSuccessHandler(HttpStatus.NO_CONTENT))
                .invalidateHttpSession(true)
                .clearAuthentication(true)
                .deleteCookies("MMSESION"))
            .headers(h -> h.frameOptions(f -> f.deny()));
        return http.build();
    }

    /** Dónde se guarda la autenticación entre pedidos: en la sesión HTTP (que Spring Session guarda en MySQL). */
    @Bean
    SecurityContextRepository repositorioContexto() {
        return new HttpSessionSecurityContextRepository();
    }

    /** El token CSRF vive en la sesión; el frontend lo pide a GET /api/auth/csrf y lo envía en un encabezado. */
    @Bean
    HttpSessionCsrfTokenRepository repositorioCsrf() {
        return new HttpSessionCsrfTokenRepository();
    }

    /** Solo los orígenes configurados pueden llamar a la API desde el navegador con la cookie de sesión. */
    @Bean
    CorsConfigurationSource configuracionCors(PropiedadesSeguridad propiedades) {
        UrlBasedCorsConfigurationSource fuente = new UrlBasedCorsConfigurationSource();
        if (propiedades.origenesPermitidos().isEmpty()) {
            return fuente; // sin orígenes: el navegador bloquea cualquier llamada desde otro origen
        }
        CorsConfiguration cfg = new CorsConfiguration();
        cfg.setAllowedOrigins(propiedades.origenesPermitidos());
        cfg.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        cfg.setAllowedHeaders(List.of("Content-Type", "Accept", "X-CSRF-TOKEN"));
        cfg.setAllowCredentials(true);
        cfg.setMaxAge(3600L);
        fuente.registerCorsConfiguration("/api/**", cfg);
        return fuente;
    }
}
