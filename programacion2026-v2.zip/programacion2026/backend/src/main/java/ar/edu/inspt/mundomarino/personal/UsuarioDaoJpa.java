package ar.edu.inspt.mundomarino.personal;

import ar.edu.inspt.mundomarino.comun.dao.DaoJpa;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

@Repository
class UsuarioDaoJpa extends DaoJpa<Usuario, UUID> implements UsuarioDao {

    private static final Pageable LIMITE_OPCIONES = PageRequest.of(0, 500);

    private final UsuarioRepositorio repositorio;

    UsuarioDaoJpa(UsuarioRepositorio repositorio) {
        super(repositorio);
        this.repositorio = repositorio;
    }

    @Override
    public Optional<Usuario> buscarPorNombreUsuario(String nombreUsuario) {
        return nombreUsuario == null ? Optional.empty()
                : repositorio.findByNombreUsuario(nombreUsuario.strip().toLowerCase());
    }

    @Override
    public boolean existeNombreUsuario(String nombreUsuario) {
        return nombreUsuario != null && repositorio.existsByNombreUsuario(nombreUsuario.strip().toLowerCase());
    }

    @Override
    public boolean existeAdministrador() {
        return repositorio.contarAdministradores() > 0;
    }

    @Override
    public long contar() {
        return repositorio.count();
    }

    @Override
    public Pagina<Empleado> buscarEmpleados(String texto, Rol rol, SolicitudPagina solicitud) {
        String patron = patronBusqueda(texto);
        Pageable p = aPageable(solicitud);
        if (rol == Rol.GUIA) {
            return aPagina(repositorio.buscarGuias(patron, p));
        }
        if (rol == Rol.CUIDADOR) {
            return aPagina(repositorio.buscarCuidadores(patron, p));
        }
        return aPagina(repositorio.buscarEmpleados(patron, p));
    }

    @Override
    public Optional<Empleado> buscarEmpleado(UUID id) {
        return repositorio.buscarEmpleado(id);
    }

    @Override
    public List<Empleado> opciones(Rol rol) {
        return rol == Rol.CUIDADOR ? repositorio.opcionesCuidadores(LIMITE_OPCIONES)
                : repositorio.opcionesGuias(LIMITE_OPCIONES);
    }

    @Override
    public Optional<Guia> buscarGuia(UUID id) {
        return repositorio.buscarGuia(id);
    }

    @Override
    public Optional<Cuidador> buscarCuidador(UUID id) {
        return repositorio.buscarCuidador(id);
    }

    @Override
    public Optional<Guia> buscarGuiaParaModificar(UUID id) {
        return repositorio.buscarGuiaConBloqueo(id);
    }

    @Override
    public List<Guia> bloquearGuias(Collection<UUID> ids) {
        return ids.isEmpty() ? List.of() : repositorio.bloquearGuias(ids);
    }
}
