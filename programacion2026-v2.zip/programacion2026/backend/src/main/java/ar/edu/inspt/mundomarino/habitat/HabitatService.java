package ar.edu.inspt.mundomarino.habitat;

import ar.edu.inspt.mundomarino.comun.dao.ControlVersion;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import ar.edu.inspt.mundomarino.comun.error.RecursoNoEncontradoException;
import ar.edu.inspt.mundomarino.comun.error.ReglaNegocioException;
import ar.edu.inspt.mundomarino.comun.web.Opcion;
import ar.edu.inspt.mundomarino.habitat.HabitatDtos.HabitatRespuesta;
import ar.edu.inspt.mundomarino.habitat.HabitatDtos.HabitatSolicitud;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Reglas de negocio de los hábitats. */
@Service
@Transactional
public class HabitatService {

    private static final Set<String> ORDENES = Set.of("nombre", "clima");

    private final HabitatDao habitats;

    public HabitatService(HabitatDao habitats) {
        this.habitats = habitats;
    }

    @Transactional(readOnly = true)
    public Pagina<HabitatRespuesta> listar(String texto, SolicitudPagina solicitud) {
        return habitats.buscar(texto, solicitud.conOrdenPermitido(ORDENES, "nombre")).map(HabitatService::aRespuesta);
    }

    @Transactional(readOnly = true)
    public HabitatRespuesta obtener(UUID id) {
        return aRespuesta(buscar(id));
    }

    @Transactional(readOnly = true)
    public List<Opcion> opciones() {
        return habitats.opciones().stream().map(h -> new Opcion(h.getId(), h.getNombre())).toList();
    }

    public HabitatRespuesta crear(HabitatSolicitud s) {
        if (habitats.existeNombre(s.nombre(), null)) {
            throw new ReglaNegocioException("Ya existe un hábitat con ese nombre.");
        }
        Habitat h = new Habitat(UUID.randomUUID(), s.nombre(), s.clima(), s.vegetacion(), new LinkedHashSet<>(s.continentes()));
        return aRespuesta(habitats.guardar(h));
    }

    public HabitatRespuesta actualizar(UUID id, HabitatSolicitud s) {
        Habitat h = buscar(id);
        ControlVersion.verificar(h.getVersion(), s.version());
        if (habitats.existeNombre(s.nombre(), id)) {
            throw new ReglaNegocioException("Ya existe un hábitat con ese nombre.");
        }
        h.actualizar(s.nombre(), s.clima(), s.vegetacion(), new LinkedHashSet<>(s.continentes()));
        return aRespuesta(habitats.guardar(h));
    }

    /** Si hay especies asociadas, la clave foránea lo impide (409). */
    public void eliminar(UUID id) {
        habitats.eliminar(buscar(id));
    }

    private Habitat buscar(UUID id) {
        return habitats.buscarPorId(id).orElseThrow(() -> new RecursoNoEncontradoException("El hábitat no existe."));
    }

    private static HabitatRespuesta aRespuesta(Habitat h) {
        return new HabitatRespuesta(h.getId(), h.getNombre(), h.getClima(), h.getVegetacion(),
                List.copyOf(h.getContinentes()), h.getVersion());
    }
}
