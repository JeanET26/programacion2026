package ar.edu.inspt.mundomarino.personal;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import java.time.LocalDate;
import java.util.EnumSet;
import java.util.Set;
import java.util.UUID;

/** Empleado que conduce itinerarios. No es final por el mismo motivo que Administrador (proxies de JPA). */
@Entity
@DiscriminatorValue("GUIA")
public class Guia extends Empleado {

    protected Guia() {
    }

    public Guia(UUID id, String nombreUsuario, String hashContrasena, String nombre, String direccion,
            String telefono, LocalDate fechaIngreso) {
        super(id, nombreUsuario, hashContrasena, nombre, direccion, telefono, fechaIngreso);
    }

    @Override
    public Rol getRol() {
        return Rol.GUIA;
    }

    @Override
    public Set<Permiso> getPermisos() {
        return Set.copyOf(EnumSet.of(Permiso.VER_PERFIL_PROPIO, Permiso.VER_RECORRIDOS_PROPIOS));
    }
}
