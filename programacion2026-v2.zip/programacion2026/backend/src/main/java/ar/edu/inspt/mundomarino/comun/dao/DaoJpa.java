package ar.edu.inspt.mundomarino.comun.dao;

import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * <b>Adaptador genérico</b> que implementa {@link Dao} delegando en un
 * repositorio de Spring Data JPA. El CRUD se escribe una sola vez acá y lo
 * heredan todos los DAO concretos ({@code ZonaDaoJpa}, {@code EspecieDaoJpa}...).
 *
 * <p>Además centraliza dos decisiones: hacer {@code flush} al guardar y al
 * eliminar (para que las violaciones de claves aparezcan dentro del servicio)
 * y convertir nuestra {@link SolicitudPagina} en el {@code Pageable} de Spring.</p>
 */
public abstract class DaoJpa<T, ID> implements Dao<T, ID> {

    private final JpaRepository<T, ID> repositorio;

    protected DaoJpa(JpaRepository<T, ID> repositorio) {
        this.repositorio = repositorio;
    }

    @Override
    public Optional<T> buscarPorId(ID id) {
        return repositorio.findById(id);
    }

    @Override
    public boolean existePorId(ID id) {
        return repositorio.existsById(id);
    }

    @Override
    public Pagina<T> listar(SolicitudPagina solicitud) {
        return aPagina(repositorio.findAll(aPageable(solicitud)));
    }

    @Override
    public T guardar(T entidad) {
        return repositorio.saveAndFlush(entidad);
    }

    @Override
    public void eliminar(T entidad) {
        repositorio.delete(entidad);
        repositorio.flush();
    }

    protected static Pageable aPageable(SolicitudPagina s) {
        Sort orden = s.ordenarPor() == null ? Sort.unsorted()
                : Sort.by(s.ascendente() ? Sort.Direction.ASC : Sort.Direction.DESC, s.ordenarPor());
        return PageRequest.of(s.numero(), s.tamanio(), orden);
    }

    protected static <E> Pagina<E> aPagina(Page<E> page) {
        return new Pagina<>(page.getContent(), page.getNumber(), page.getSize(), page.getTotalElements(),
                page.getTotalPages());
    }

    /** Texto de búsqueda para LIKE: null si viene vacío; escapa % y _. */
    protected static String patronBusqueda(String texto) {
        if (texto == null || texto.isBlank()) {
            return null;
        }
        String limpio = texto.strip().toLowerCase().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_");
        return "%" + limpio + "%";
    }
}
