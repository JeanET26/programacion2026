package ar.edu.inspt.mundomarino.demo;

import ar.edu.inspt.mundomarino.asignacion.AsignacionCuidadoService;
import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.CuidadoAlta;
import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.HorarioAlta;
import ar.edu.inspt.mundomarino.asignacion.AsignacionGuiaService;
import ar.edu.inspt.mundomarino.especie.EspecieDtos.EspecieSolicitud;
import ar.edu.inspt.mundomarino.especie.EspecieService;
import ar.edu.inspt.mundomarino.habitat.HabitatDtos.HabitatSolicitud;
import ar.edu.inspt.mundomarino.habitat.HabitatService;
import ar.edu.inspt.mundomarino.itinerario.ItinerarioDtos.ItinerarioSolicitud;
import ar.edu.inspt.mundomarino.itinerario.ItinerarioService;
import ar.edu.inspt.mundomarino.personal.Administrador;
import ar.edu.inspt.mundomarino.personal.PersonalDtos.EmpleadoAlta;
import ar.edu.inspt.mundomarino.personal.PersonalService;
import ar.edu.inspt.mundomarino.personal.Rol;
import ar.edu.inspt.mundomarino.personal.UsuarioDao;
import ar.edu.inspt.mundomarino.zona.ZonaDtos.ZonaSolicitud;
import ar.edu.inspt.mundomarino.zona.ZonaService;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * Datos de demostración EXCLUSIVOS del perfil "dev" y solo si la base no tiene
 * ningún usuario: nunca reemplazan información existente. Se cargan a través
 * de los servicios, así cumplen exactamente las mismas reglas que el uso normal.
 */
@Component
@Profile("dev")
@ConditionalOnProperty(prefix = "app.demo", name = "habilitado", havingValue = "true")
@Order(2)
class CargadorDatosDemo implements ApplicationRunner {

    static final String CLAVE_ADMIN = "Admin2026!";
    static final String CLAVE_EMPLEADOS = "Marino2026!";
    private static final Logger LOG = LoggerFactory.getLogger(CargadorDatosDemo.class);

    private final UsuarioDao usuarios;
    private final PasswordEncoder codificador;
    private final ZonaService zonas;
    private final HabitatService habitats;
    private final EspecieService especies;
    private final ItinerarioService itinerarios;
    private final PersonalService personal;
    private final AsignacionGuiaService horarios;
    private final AsignacionCuidadoService cuidados;

    CargadorDatosDemo(UsuarioDao usuarios, PasswordEncoder codificador, ZonaService zonas, HabitatService habitats,
            EspecieService especies, ItinerarioService itinerarios, PersonalService personal,
            AsignacionGuiaService horarios, AsignacionCuidadoService cuidados) {
        this.usuarios = usuarios;
        this.codificador = codificador;
        this.zonas = zonas;
        this.habitats = habitats;
        this.especies = especies;
        this.itinerarios = itinerarios;
        this.personal = personal;
        this.horarios = horarios;
        this.cuidados = cuidados;
    }

    @Override
    public void run(ApplicationArguments args) {
        if (usuarios.contar() > 0) {
            LOG.info("La base ya tiene usuarios: no se cargan datos de demostración.");
            return;
        }
        usuarios.guardar(new Administrador(UUID.randomUUID(), "admin.ana", codificador.encode(CLAVE_ADMIN), "Ana Ruiz"));

        UUID arrecife = zonas.crear(new ZonaSolicitud("Arrecife central", new BigDecimal("850"), null)).id();
        UUID tunel = zonas.crear(new ZonaSolicitud("Túnel oceánico", new BigDecimal("1100"), null)).id();
        UUID costa = zonas.crear(new ZonaSolicitud("Costa austral", new BigDecimal("1400"), null)).id();
        UUID bahia = zonas.crear(new ZonaSolicitud("Bahía de los delfines", new BigDecimal("2600"), null)).id();

        UUID coral = habitats.crear(new HabitatSolicitud("Arrecife coralino", "Tropical cálido", "Corales y algas",
                List.of("Oceanía", "América", "Asia"), null)).id();
        UUID rocosa = habitats.crear(new HabitatSolicitud("Costa rocosa", "Templado frío", "Algas pardas",
                List.of("América"), null)).id();
        UUID abierto = habitats.crear(new HabitatSolicitud("Mar abierto", "Variable", "Fitoplancton",
                List.of("América", "África", "Europa", "Asia", "Oceanía"), null)).id();

        UUID payaso = especie("Pez payaso", "Amphiprion ocellaris", "Pez marino que vive asociado a las anémonas.", arrecife, coral);
        UUID tiburon = especie("Tiburón de punta negra", "Carcharhinus melanopterus", "Tiburón costero de arrecifes tropicales.", tunel, coral);
        UUID tortuga = especie("Tortuga verde", "Chelonia mydas", "Tortuga marina herbívora que migra miles de kilómetros.", tunel, coral, abierto);
        UUID lobo = especie("Lobo marino sudamericano", "Otaria flavescens", "Mamífero marino de las costas de Sudamérica.", costa, rocosa);
        UUID pinguino = especie("Pingüino de Magallanes", "Spheniscus magellanicus", "Ave marina que anida en la costa patagónica.", costa, rocosa, abierto);
        UUID delfin = especie("Delfín nariz de botella", "Tursiops truncatus", "Cetáceo muy sociable que se comunica con silbidos.", bahia, abierto);

        UUID it1 = itinerarios.crear(new ItinerarioSolicitud(1, 45, new BigDecimal("1.8"), 25, List.of(payaso, tiburon, tortuga), null)).id();
        UUID it2 = itinerarios.crear(new ItinerarioSolicitud(2, 60, new BigDecimal("2.4"), 30, List.of(lobo, pinguino, delfin), null)).id();

        UUID lucia = empleado(Rol.GUIA, "guia.lucia", "Lucía Gómez", "Av. del Mar 120", "11 5555-1000", LocalDate.of(2024, 3, 4));
        UUID martin = empleado(Rol.GUIA, "guia.martin", "Martín Sosa", "Calle Ostra 9", "11 5555-1001", LocalDate.of(2025, 1, 10));
        UUID diego = empleado(Rol.CUIDADOR, "cuidador.diego", "Diego Pérez", "Calle Coral 45", "11 5555-2000", LocalDate.of(2023, 8, 15));
        UUID sofia = empleado(Rol.CUIDADOR, "cuidador.sofia", "Sofía Ibarra", "Pasaje Ancla 3", "11 5555-2001", LocalDate.of(2024, 6, 1));

        horarios.asignar(new HorarioAlta(lucia, it1, LocalTime.of(10, 0)));
        horarios.asignar(new HorarioAlta(lucia, it2, LocalTime.of(15, 0)));
        horarios.asignar(new HorarioAlta(martin, it2, LocalTime.of(11, 0)));
        cuidados.asignar(new CuidadoAlta(diego, payaso, LocalDate.of(2025, 2, 1)));
        cuidados.asignar(new CuidadoAlta(diego, tortuga, LocalDate.of(2025, 5, 12)));
        cuidados.asignar(new CuidadoAlta(sofia, tortuga, LocalDate.of(2025, 7, 1)));
        cuidados.asignar(new CuidadoAlta(sofia, lobo, LocalDate.of(2024, 9, 20)));
        LOG.info("Datos de demostración cargados. admin.ana / {} · empleados / {}", CLAVE_ADMIN, CLAVE_EMPLEADOS);
    }

    private UUID especie(String nombre, String cientifico, String descripcion, UUID zona, UUID... habitatIds) {
        return especies.crear(new EspecieSolicitud(nombre, cientifico, descripcion, zona, List.of(habitatIds), null)).id();
    }

    private UUID empleado(Rol rol, String usuario, String nombre, String direccion, String telefono, LocalDate ingreso) {
        return personal.crear(new EmpleadoAlta(rol, usuario, CLAVE_EMPLEADOS, nombre, direccion, telefono, ingreso)).id();
    }
}
