package ar.edu.inspt.mundomarino.especie;

import ar.edu.inspt.mundomarino.comun.dao.EntidadConId;
import ar.edu.inspt.mundomarino.comun.dao.Validaciones;
import ar.edu.inspt.mundomarino.habitat.Habitat;
import ar.edu.inspt.mundomarino.zona.Zona;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * Especie del parque (tabla {@code especie}).
 * <ul>
 *   <li>{@code @ManyToOne zona}: columna {@code zona_id} (clave foránea, puede ser nula).</li>
 *   <li>{@code @ManyToMany habitats}: tabla intermedia {@code especie_habitat}.</li>
 * </ul>
 * Ambas son LAZY: se cargan solo si se usan, y en lotes
 * ({@code hibernate.default_batch_fetch_size}) para evitar el problema N+1.
 */
@Entity
@Table(name = "especie")
public class Especie extends EntidadConId {

    @Column(name = "nombre_espanol", nullable = false, length = 80)
    private String nombreEspanol;

    @Column(name = "nombre_cientifico", nullable = false, length = 120)
    private String nombreCientifico;

    @Column(name = "descripcion", nullable = false, length = 500)
    private String descripcion;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "zona_id")
    private Zona zona;

    @ManyToMany
    @JoinTable(name = "especie_habitat",
            joinColumns = @JoinColumn(name = "especie_id"),
            inverseJoinColumns = @JoinColumn(name = "habitat_id"))
    private Set<Habitat> habitats = new LinkedHashSet<>();

    protected Especie() {
    }

    public Especie(UUID id, String nombreEspanol, String nombreCientifico, String descripcion, Zona zona,
            Collection<Habitat> habitats) {
        super(id);
        asignar(nombreEspanol, nombreCientifico, descripcion, zona, habitats);
    }

    public void actualizar(String nombreEspanol, String nombreCientifico, String descripcion, Zona zona,
            Collection<Habitat> habitats) {
        asignar(nombreEspanol, nombreCientifico, descripcion, zona, habitats);
    }

    private void asignar(String nombreEspanol, String nombreCientifico, String descripcion, Zona zona,
            Collection<Habitat> habitats) {
        String ne = Validaciones.texto(nombreEspanol, "nombreEspanol", 80);
        String nc = Validaciones.texto(nombreCientifico, "nombreCientifico", 120);
        String d = Validaciones.texto(descripcion, "descripcion", 500);
        this.nombreEspanol = ne;
        this.nombreCientifico = nc;
        this.descripcion = d;
        this.zona = zona;
        this.habitats.clear();
        if (habitats != null) {
            this.habitats.addAll(habitats);
        }
    }

    public String getNombreEspanol() {
        return nombreEspanol;
    }

    public String getNombreCientifico() {
        return nombreCientifico;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public Optional<Zona> getZona() {
        return Optional.ofNullable(zona);
    }

    public Set<Habitat> getHabitats() {
        return Collections.unmodifiableSet(habitats);
    }
}
