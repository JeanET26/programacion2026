package ar.edu.inspt.mundomarino.asignacion;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.UUID;

public final class AsignacionDtos {

    private AsignacionDtos() {
    }

    public record HorarioAlta(
            @NotNull(message = "Elegí el guía.") UUID guiaId,
            @NotNull(message = "Elegí el itinerario.") UUID itinerarioId,
            @NotNull(message = "Indicá la hora.") @JsonFormat(pattern = "HH:mm") LocalTime hora) {
    }

    public record HorarioCambio(
            @NotNull(message = "Indicá la hora.") @JsonFormat(pattern = "HH:mm") LocalTime hora,
            Long version) {
    }

    public record HorarioRespuesta(UUID id, UUID guiaId, String guiaNombre, UUID itinerarioId, String itinerarioCodigo,
            @JsonFormat(pattern = "HH:mm") LocalTime hora, @JsonFormat(pattern = "HH:mm") LocalTime horaFin,
            List<String> zonas, Long version) {

        public HorarioRespuesta {
            zonas = List.copyOf(zonas);
        }
    }

    public record CuidadoAlta(
            @NotNull(message = "Elegí el cuidador.") UUID cuidadorId,
            @NotNull(message = "Elegí la especie.") UUID especieId,
            @NotNull(message = "Indicá la fecha.") LocalDate fechaAsignacion) {
    }

    public record CuidadoCambio(@NotNull(message = "Indicá la fecha.") LocalDate fechaAsignacion, Long version) {
    }

    public record CuidadoRespuesta(UUID id, UUID cuidadorId, String cuidadorNombre, UUID especieId,
            String especieNombre, String zonaNombre, LocalDate fechaAsignacion, Long version) {
    }

    /* -------- Vistas propias de cada empleado (solo lo que necesitan ver) -------- */

    public record EspecieBreve(String nombreEspanol, String nombreCientifico) {
    }

    public record RecorridoPropio(UUID asignacionId, @JsonFormat(pattern = "HH:mm") LocalTime hora,
            @JsonFormat(pattern = "HH:mm") LocalTime horaFin, String codigo, int duracionMinutos,
            BigDecimal longitudKm, int maximoVisitantes, List<String> zonas, List<EspecieBreve> especies) {

        public RecorridoPropio {
            zonas = List.copyOf(zonas);
            especies = List.copyOf(especies);
        }
    }

    public record HabitatBreve(String nombre, String clima) {
    }

    /** De los compañeros solo se muestra el nombre (ni teléfono ni dirección). */
    public record EspecieACargo(UUID asignacionId, LocalDate desde, String nombreEspanol, String nombreCientifico,
            String descripcion, String zona, List<HabitatBreve> habitats, List<String> otrosCuidadores) {

        public EspecieACargo {
            habitats = List.copyOf(habitats);
            otrosCuidadores = List.copyOf(otrosCuidadores);
        }
    }
}
