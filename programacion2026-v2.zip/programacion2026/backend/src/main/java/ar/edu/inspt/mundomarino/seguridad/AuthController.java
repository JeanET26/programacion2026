package ar.edu.inspt.mundomarino.seguridad;

import ar.edu.inspt.mundomarino.comun.error.ApiError;
import ar.edu.inspt.mundomarino.personal.PersonalDtos.CambioContrasena;
import ar.edu.inspt.mundomarino.personal.PersonalDtos.Perfil;
import ar.edu.inspt.mundomarino.personal.PersonalService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.time.Instant;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextHolderStrategy;
import org.springframework.security.web.context.SecurityContextRepository;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.security.web.csrf.HttpSessionCsrfTokenRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Autenticación. El cierre de sesión ({@code POST /api/auth/logout}) lo
 * resuelve el filtro de logout de Spring Security (ver SeguridadConfig).
 */
@RestController
@ConditionalOnWebApplication
@RequestMapping("/api/auth")
@Tag(name = "Autenticación")
public class AuthController {

    private static final Logger LOG = LoggerFactory.getLogger(AuthController.class);

    private final AuthenticationManager autenticador;
    private final SecurityContextRepository repositorioContexto;
    private final HttpSessionCsrfTokenRepository repositorioCsrf;
    private final LimitadorIntentosLogin limitador;
    private final PersonalService personal;
    private final SecurityContextHolderStrategy contexto = SecurityContextHolder.getContextHolderStrategy();

    public AuthController(AuthenticationManager autenticador, SecurityContextRepository repositorioContexto,
            HttpSessionCsrfTokenRepository repositorioCsrf, LimitadorIntentosLogin limitador, PersonalService personal) {
        this.autenticador = autenticador;
        this.repositorioContexto = repositorioContexto;
        this.repositorioCsrf = repositorioCsrf;
        this.limitador = limitador;
        this.personal = personal;
    }

    public record Credenciales(@NotBlank @Size(max = 30) String nombreUsuario, @NotBlank @Size(max = 64) String contrasena) {
    }

    public record TokenCsrf(String encabezado, String token) {
    }

    @GetMapping("/csrf")
    @Operation(summary = "Token CSRF que el frontend debe enviar en POST/PUT/DELETE")
    public TokenCsrf csrf(CsrfToken token) {
        return new TokenCsrf(token.getHeaderName(), token.getToken());
    }

    @PostMapping("/login")
    @Operation(summary = "Inicia sesión; responde con el perfil y la cookie de sesión HttpOnly")
    public ResponseEntity<?> login(@Valid @RequestBody Credenciales c, HttpServletRequest req, HttpServletResponse res) {
        String usuario = c.nombreUsuario().strip().toLowerCase();
        String ip = req.getRemoteAddr();
        if (limitador.bloqueado(usuario, ip)) {
            return error(HttpStatus.TOO_MANY_REQUESTS, "Demasiados intentos fallidos. Esperá unos minutos.", req);
        }
        Authentication autenticacion;
        try {
            autenticacion = autenticador.authenticate(UsernamePasswordAuthenticationToken.unauthenticated(usuario, c.contrasena()));
        } catch (AuthenticationException ex) {
            limitador.registrarFallo(usuario, ip);
            LOG.info("Login fallido para '{}' desde {}", usuario, ip);
            // Mismo mensaje exista o no el usuario: no se revela qué usuarios existen.
            return error(HttpStatus.UNAUTHORIZED, "Usuario o contraseña incorrectos.", req);
        }
        limitador.registrarExito(usuario);

        // Protección contra fijación de sesión: el identificador cambia al autenticarse.
        if (req.getSession(false) != null) {
            req.changeSessionId();
        } else {
            req.getSession(true);
        }
        SecurityContext ctx = contexto.createEmptyContext();
        ctx.setAuthentication(autenticacion);
        contexto.setContext(ctx);
        repositorioContexto.saveContext(ctx, req, res);
        repositorioCsrf.saveToken(null, req, res); // token CSRF nuevo después de iniciar sesión

        UsuarioAutenticado yo = (UsuarioAutenticado) autenticacion.getPrincipal();
        LOG.info("Login correcto de '{}' ({})", yo.getUsername(), yo.getRol());
        return ResponseEntity.ok(personal.perfil(yo.getId()));
    }

    @GetMapping("/yo")
    @Operation(summary = "Perfil del usuario autenticado (datos actuales de la base)")
    public Perfil yo(@AuthenticationPrincipal UsuarioAutenticado yo) {
        return personal.perfil(yo.getId());
    }

    @PutMapping("/contrasena")
    @Operation(summary = "Cambia la propia contraseña y cierra las demás sesiones del usuario")
    public ResponseEntity<Void> cambiarContrasena(@AuthenticationPrincipal UsuarioAutenticado yo,
            @Valid @RequestBody CambioContrasena cambio, HttpServletRequest req, HttpServletResponse res) {
        personal.cambiarContrasenaPropia(yo.getId(), cambio.actual(), cambio.nueva(), req.getSession().getId());
        req.changeSessionId();
        repositorioCsrf.saveToken(null, req, res);
        return ResponseEntity.noContent().build();
    }

    private static ResponseEntity<ApiError> error(HttpStatus estado, String mensaje, HttpServletRequest req) {
        return ResponseEntity.status(estado).body(new ApiError(estado.value(), mensaje, Map.of(), req.getRequestURI(), Instant.now()));
    }
}
