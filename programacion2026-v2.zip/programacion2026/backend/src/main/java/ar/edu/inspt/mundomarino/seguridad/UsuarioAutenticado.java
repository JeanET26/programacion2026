package ar.edu.inspt.mundomarino.seguridad;

import ar.edu.inspt.mundomarino.personal.Usuario;
import java.io.Serial;
import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import org.springframework.security.core.CredentialsContainer;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * Lo que Spring Security guarda en la sesión sobre quien inició sesión.
 * Es una COPIA mínima (id, usuario, nombre, rol y permisos), no la entidad
 * JPA: así la sesión no retiene objetos de la base. Se serializa porque
 * Spring Session la guarda en la tabla SPRING_SESSION_ATTRIBUTES.
 * El hash de la contraseña se borra después de autenticar.
 */
public final class UsuarioAutenticado implements UserDetails, CredentialsContainer, Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private final UUID id;
    private final String nombreUsuario;
    private final String nombre;
    private final String rol;
    private final List<SimpleGrantedAuthority> permisos;
    private String hashContrasena;

    UsuarioAutenticado(Usuario u) {
        this.id = u.getId();
        this.nombreUsuario = u.getNombreUsuario();
        this.nombre = u.getNombre();
        this.rol = u.getRol().name();
        this.permisos = u.getPermisos().stream().map(p -> new SimpleGrantedAuthority(p.name())).toList();
        this.hashContrasena = u.getHashContrasena();
    }

    public UUID getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getRol() {
        return rol;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return permisos;
    }

    @Override
    public String getPassword() {
        return hashContrasena;
    }

    /** Spring Session indexa las sesiones por este nombre (para cerrarlas todas). */
    @Override
    public String getUsername() {
        return nombreUsuario;
    }

    @Override
    public void eraseCredentials() {
        this.hashContrasena = null;
    }
}
