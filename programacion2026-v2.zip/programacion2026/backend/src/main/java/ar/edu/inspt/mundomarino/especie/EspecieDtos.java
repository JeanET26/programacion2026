package ar.edu.inspt.mundomarino.especie;

import ar.edu.inspt.mundomarino.comun.web.Opcion;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;
import java.util.UUID;

public final class EspecieDtos {

    private EspecieDtos() {
    }

    public record EspecieSolicitud(
            @NotBlank(message = "El nombre es obligatorio.") @Size(max = 80) String nombreEspanol,
            @NotBlank(message = "El nombre científico es obligatorio.") @Size(max = 120) String nombreCientifico,
            @NotBlank(message = "La descripción es obligatoria.") @Size(max = 500) String descripcion,
            UUID zonaId,
            @Size(max = 20) List<@NotNull UUID> habitatIds,
            Long version) {

        public EspecieSolicitud {
            habitatIds = habitatIds == null ? List.of() : List.copyOf(habitatIds);
        }
    }

    public record EspecieRespuesta(UUID id, String nombreEspanol, String nombreCientifico, String descripcion,
            UUID zonaId, String zonaNombre, List<Opcion> habitats, Long version) {

        public EspecieRespuesta {
            habitats = List.copyOf(habitats);
        }
    }
}
