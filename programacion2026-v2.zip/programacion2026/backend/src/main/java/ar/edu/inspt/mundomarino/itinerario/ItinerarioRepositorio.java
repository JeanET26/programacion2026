package ar.edu.inspt.mundomarino.itinerario;

import jakarta.persistence.LockModeType;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

interface ItinerarioRepositorio extends JpaRepository<Itinerario, UUID> {

    boolean existsByCodigo(String codigo);

    @Query("select i from Itinerario i where :patron is null or lower(i.codigo) like :patron")
    Page<Itinerario> buscar(@Param("patron") String patron, Pageable pageable);

    List<Itinerario> findTop500ByOrderByCodigoAsc();

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select i from Itinerario i where i.id = :id")
    Optional<Itinerario> buscarConBloqueoEscritura(@Param("id") UUID id);

    @Lock(LockModeType.PESSIMISTIC_READ)
    @Query("select i from Itinerario i where i.id = :id")
    Optional<Itinerario> buscarConBloqueoLectura(@Param("id") UUID id);
}
