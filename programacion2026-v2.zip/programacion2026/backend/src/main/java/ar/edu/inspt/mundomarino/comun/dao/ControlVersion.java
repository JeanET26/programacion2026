package ar.edu.inspt.mundomarino.comun.dao;

import ar.edu.inspt.mundomarino.comun.error.ReglaNegocioException;
import java.util.Objects;

/**
 * Evita que una edición pise cambios ajenos. El formulario envía la versión
 * que leyó; si en la base ya hay otra, alguien guardó antes y se rechaza.
 * Entre esta comprobación y el UPDATE, {@code @Version} cubre la carrera.
 */
public final class ControlVersion {

    private ControlVersion() {
    }

    public static void verificar(Long versionActual, Long versionEnviada) {
        if (versionEnviada == null) {
            throw new ReglaNegocioException("Falta la versión del registro: recargá los datos y volvé a intentar.");
        }
        if (!Objects.equals(versionActual, versionEnviada)) {
            throw new ReglaNegocioException(
                    "Otra persona modificó este registro mientras lo editabas. Recargá los datos y volvé a intentar.");
        }
    }
}
