package ar.edu.inspt.mundomarino.seguridad;

import ar.edu.inspt.mundomarino.personal.CierreSesiones;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.session.Session;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

/**
 * Implementa el puerto {@link CierreSesiones} con Spring Session JDBC: busca
 * las sesiones guardadas en MySQL por nombre de usuario y las borra.
 * Se ejecuta DESPUÉS del commit de la transacción de negocio: si el cambio de
 * contraseña se deshace, no se cierra ninguna sesión.
 */
@Component
@ConditionalOnWebApplication
class CierreSesionesSpringSession implements CierreSesiones {

    private static final Logger LOG = LoggerFactory.getLogger(CierreSesionesSpringSession.class);

    private final FindByIndexNameSessionRepository<? extends Session> sesiones;

    CierreSesionesSpringSession(FindByIndexNameSessionRepository<? extends Session> sesiones) {
        this.sesiones = sesiones;
    }

    @Override
    public void cerrarSesionesDe(String nombreUsuario, String excepto) {
        if (TransactionSynchronizationManager.isSynchronizationActive()) {
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void afterCommit() {
                    cerrar(nombreUsuario, excepto);
                }
            });
        } else {
            cerrar(nombreUsuario, excepto);
        }
    }

    private void cerrar(String nombreUsuario, String excepto) {
        Map<String, ? extends Session> abiertas = sesiones.findByPrincipalName(nombreUsuario);
        abiertas.keySet().stream().filter(id -> !id.equals(excepto)).forEach(sesiones::deleteById);
        LOG.info("Se cerraron {} sesión(es) de {}", abiertas.keySet().stream().filter(id -> !id.equals(excepto)).count(),
                nombreUsuario);
    }
}
