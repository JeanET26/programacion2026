package ar.edu.inspt.mundomarino.personal;

import ar.edu.inspt.mundomarino.comun.dao.Validaciones;
import ar.edu.inspt.mundomarino.comun.error.DatoInvalidoException;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import java.time.LocalDate;
import java.util.Optional;
import java.util.UUID;

/**
 * Datos comunes de guías y cuidadores.
 *
 * <p><b>¿Por qué sigue siendo abstracta?</b> Heredar de una clase abstracta
 * no la vuelve abstracta; lo es porque se declara así. Tiene sentido porque:</p>
 * <ol>
 *   <li>En el dominio no existe "un empleado" a secas: siempre es Guía o
 *   Cuidador. Si fuera concreta se podría guardar un empleado sin rol.</li>
 *   <li>No implementa {@code getRol()} ni {@code getPermisos()}; una clase
 *   que no implementa todos los métodos abstractos heredados tiene que ser
 *   abstracta para compilar.</li>
 *   <li>Con SINGLE_TABLE, al ser abstracta no necesita valor de discriminador
 *   propio: en la columna {@code rol} solo aparecen GUIA o CUIDADOR.</li>
 * </ol>
 */
@Entity
public abstract class Empleado extends Usuario {

    @Column(name = "direccion", length = 120)
    private String direccion;

    @Column(name = "telefono", length = 20)
    private String telefono;

    @Column(name = "fecha_ingreso")
    private LocalDate fechaIngreso;

    protected Empleado() {
    }

    protected Empleado(UUID id, String nombreUsuario, String hashContrasena, String nombre, String direccion,
            String telefono, LocalDate fechaIngreso) {
        super(id, nombreUsuario, hashContrasena, nombre);
        asignarDatosLaborales(direccion, telefono, fechaIngreso);
    }

    public void actualizarDatosLaborales(String direccion, String telefono, LocalDate fechaIngreso) {
        asignarDatosLaborales(direccion, telefono, fechaIngreso);
    }

    private void asignarDatosLaborales(String direccion, String telefono, LocalDate fechaIngreso) {
        String d = Validaciones.texto(direccion, "direccion", 120);
        String t = Validaciones.texto(telefono, "telefono", 20);
        if (!t.matches("^\\+?[0-9 -]{8,20}$")) {
            throw new DatoInvalidoException("telefono", "El teléfono debe tener entre 8 y 20 dígitos (se admiten espacios y guiones).");
        }
        LocalDate f = Validaciones.obligatorio(fechaIngreso, "fechaIngreso");
        if (f.isAfter(LocalDate.now()) || f.isBefore(LocalDate.of(1950, 1, 1))) {
            throw new DatoInvalidoException("fechaIngreso", "La fecha de ingreso no puede ser futura ni anterior a 1950.");
        }
        this.direccion = d;
        this.telefono = t;
        this.fechaIngreso = f;
    }

    @Override
    public Optional<Empleado> comoEmpleado() {
        return Optional.of(this);
    }

    public String getDireccion() {
        return direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public LocalDate getFechaIngreso() {
        return fechaIngreso;
    }
}
