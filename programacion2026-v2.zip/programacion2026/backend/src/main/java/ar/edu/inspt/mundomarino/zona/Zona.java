package ar.edu.inspt.mundomarino.zona;

import ar.edu.inspt.mundomarino.comun.dao.EntidadConId;
import ar.edu.inspt.mundomarino.comun.dao.Validaciones;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.util.UUID;

/** Zona física del parque (tabla {@code zona}). */
@Entity
@Table(name = "zona")
public class Zona extends EntidadConId {

    private static final BigDecimal MAXIMO_M2 = new BigDecimal("99999999.99");

    @Column(name = "nombre", nullable = false, length = 80)
    private String nombre;

    @Column(name = "extension_m2", nullable = false, precision = 10, scale = 2)
    private BigDecimal extensionM2;

    protected Zona() {
    }

    public Zona(UUID id, String nombre, BigDecimal extensionM2) {
        super(id);
        asignar(nombre, extensionM2);
    }

    public void actualizar(String nombre, BigDecimal extensionM2) {
        asignar(nombre, extensionM2);
    }

    /**
     * Valida todo ANTES de asignar: si algo falla, la entidad no queda a medias.
     * Es privado (y no final) porque JPA no admite métodos final en entidades:
     * Hibernate crea subclases "proxy" que necesitan poder redefinirlos.
     */
    private void asignar(String nombre, BigDecimal extensionM2) {
        String n = Validaciones.texto(nombre, "nombre", 80);
        BigDecimal e = Validaciones.positivo(extensionM2, "extensionM2", MAXIMO_M2);
        this.nombre = n;
        this.extensionM2 = e;
    }

    public String getNombre() {
        return nombre;
    }

    public BigDecimal getExtensionM2() {
        return extensionM2;
    }
}
