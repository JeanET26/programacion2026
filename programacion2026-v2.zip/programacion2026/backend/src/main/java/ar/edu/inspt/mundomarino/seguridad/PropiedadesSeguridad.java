package ar.edu.inspt.mundomarino.seguridad;

import java.util.List;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * Configuración externa de seguridad (application.yml / variables de entorno).
 *
 * @param origenesPermitidos orígenes del frontend autorizados por CORS (nunca "*")
 * @param fuerzaBcrypt       costo de BCrypt (10 = ~100 ms por hash)
 * @param intentosPorUsuario intentos fallidos de login permitidos por usuario en la ventana
 * @param intentosPorIp      intentos fallidos permitidos por IP en la ventana
 * @param minutosVentana     duración de la ventana de intentos
 */
@ConfigurationProperties(prefix = "app.seguridad")
public record PropiedadesSeguridad(
        @DefaultValue List<String> origenesPermitidos,
        @DefaultValue("10") int fuerzaBcrypt,
        @DefaultValue("5") int intentosPorUsuario,
        @DefaultValue("30") int intentosPorIp,
        @DefaultValue("10") int minutosVentana) {

    public PropiedadesSeguridad {
        origenesPermitidos = List.copyOf(origenesPermitidos);
        if (origenesPermitidos.stream().anyMatch(o -> o.contains("*"))) {
            throw new IllegalArgumentException(
                    "app.seguridad.origenes-permitidos no admite '*': con cookies de sesión hay que listar los orígenes exactos.");
        }
    }
}
