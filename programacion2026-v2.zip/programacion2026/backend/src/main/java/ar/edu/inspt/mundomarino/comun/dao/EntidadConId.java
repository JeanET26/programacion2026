package ar.edu.inspt.mundomarino.comun.dao;

import jakarta.persistence.Column;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.Version;
import java.util.Objects;
import java.util.UUID;

/**
 * Base de todas las entidades: identificador UUID y versión.
 *
 * <ul>
 *   <li><b>UUID asignado en Java</b> (no autoincremental): el objeto tiene
 *   identidad desde que se crea, se conserva al importar datos de versiones
 *   anteriores y no revela cuántos registros hay. Se guarda como texto
 *   CHAR(36) (propiedad {@code hibernate.type.preferred_uuid_jdbc_type=CHAR})
 *   y Hibernate lo reconstruye con {@code UUID.fromString}.</li>
 *   <li><b>{@code @Version}</b>: bloqueo optimista. Cada UPDATE incluye
 *   {@code WHERE version = ?}; si otro usuario guardó antes, no se actualiza
 *   ninguna fila y Hibernate lanza un error en lugar de pisar los cambios.
 *   Mientras vale {@code null}, Spring Data sabe que la entidad es nueva
 *   y hace INSERT sin consultar antes.</li>
 * </ul>
 */
@MappedSuperclass
public abstract class EntidadConId {

    @Id
    @Column(name = "id", nullable = false, updatable = false, length = 36)
    private UUID id;

    @Version
    @Column(name = "version", nullable = false)
    private Long version;

    /** Requerido por JPA. */
    protected EntidadConId() {
    }

    protected EntidadConId(UUID id) {
        this.id = Objects.requireNonNull(id, "El id es obligatorio.");
    }

    public UUID getId() {
        return id;
    }

    public Long getVersion() {
        return version;
    }

    /** Dos entidades son iguales si tienen el mismo id (funciona con proxies de Hibernate). */
    @Override
    public boolean equals(Object otro) {
        if (this == otro) {
            return true;
        }
        if (!(otro instanceof EntidadConId e) || id == null) {
            return false;
        }
        return id.equals(e.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }
}
