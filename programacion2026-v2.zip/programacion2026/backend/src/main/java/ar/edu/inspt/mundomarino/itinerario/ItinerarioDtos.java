package ar.edu.inspt.mundomarino.itinerario;

import ar.edu.inspt.mundomarino.comun.web.Opcion;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

public final class ItinerarioDtos {

    private ItinerarioDtos() {
    }

    /** {@code numero} se usa solo al crear (genera IT-XX); el código no cambia después. */
    public record ItinerarioSolicitud(
            @Min(value = 1, message = "Entre 1 y 99.") @Max(value = 99, message = "Entre 1 y 99.") Integer numero,
            @NotNull(message = "La duración es obligatoria.")
            @Min(value = Itinerario.DURACION_MINIMA, message = "Mínimo 5 minutos.")
            @Max(value = Itinerario.DURACION_MAXIMA, message = "Máximo 480 minutos.") Integer duracionMinutos,
            @NotNull(message = "La longitud es obligatoria.") @DecimalMin(value = "0.01", message = "Debe ser mayor que 0.")
            @DecimalMax(value = "999.99") @Digits(integer = 3, fraction = 2) BigDecimal longitudKm,
            @NotNull(message = "El máximo de visitantes es obligatorio.") @Min(1) @Max(500) Integer maximoVisitantes,
            @NotEmpty(message = "Elegí al menos una especie.") @Size(max = 50) List<@NotNull UUID> especieIds,
            Long version) {

        public ItinerarioSolicitud {
            especieIds = especieIds == null ? null : List.copyOf(especieIds);
        }
    }

    public record ItinerarioRespuesta(UUID id, String codigo, int numero, int duracionMinutos, BigDecimal longitudKm,
            int maximoVisitantes, List<Opcion> especies, List<String> zonas, Long version) {

        public ItinerarioRespuesta {
            especies = List.copyOf(especies);
            zonas = List.copyOf(zonas);
        }
    }
}
