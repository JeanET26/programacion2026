package ar.edu.inspt.mundomarino.asignacion;

import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.HorarioAlta;
import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.HorarioCambio;
import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.HorarioRespuesta;
import ar.edu.inspt.mundomarino.comun.dao.ControlVersion;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import ar.edu.inspt.mundomarino.comun.error.DatoInvalidoException;
import ar.edu.inspt.mundomarino.comun.error.RecursoNoEncontradoException;
import ar.edu.inspt.mundomarino.itinerario.Itinerario;
import ar.edu.inspt.mundomarino.itinerario.ItinerarioDao;
import ar.edu.inspt.mundomarino.personal.Guia;
import ar.edu.inspt.mundomarino.personal.UsuarioDao;
import ar.edu.inspt.mundomarino.zona.Zona;
import java.util.Set;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Horarios de guías. <b>Estrategia de concurrencia</b> (detalle en docs/CONCURRENCIA.md):
 * <ol>
 *   <li>Bloqueo COMPARTIDO del itinerario: nadie puede cambiar su duración mientras tanto.</li>
 *   <li>Bloqueo de ESCRITURA del guía: las operaciones sobre el MISMO guía se
 *   ejecutan de a una; las de otros guías no esperan.</li>
 *   <li>Recién entonces se consultan sus horarios y se aplica la regla.</li>
 *   <li>READ_COMMITTED: después de esperar un bloqueo, la consulta ve lo que la
 *   otra transacción confirmó.</li>
 *   <li>Red de seguridad en la base: única (guia_id, hora).</li>
 * </ol>
 * Una consulta previa sin bloqueo NO alcanza: dos transacciones podrían ver
 * "libre" a la vez y ambas insertar.
 */
@Service
@Transactional
public class AsignacionGuiaService {

    private static final Logger LOG = LoggerFactory.getLogger(AsignacionGuiaService.class);
    private static final Set<String> ORDENES = Set.of("hora", "guia.nombre", "itinerario.codigo");

    private final AsignacionGuiaDao asignaciones;
    private final ItinerarioDao itinerarios;
    private final UsuarioDao usuarios;
    private final VerificadorHorarios verificador;

    public AsignacionGuiaService(AsignacionGuiaDao asignaciones, ItinerarioDao itinerarios, UsuarioDao usuarios,
            VerificadorHorarios verificador) {
        this.asignaciones = asignaciones;
        this.itinerarios = itinerarios;
        this.usuarios = usuarios;
        this.verificador = verificador;
    }

    @Transactional(readOnly = true)
    public Pagina<HorarioRespuesta> listar(UUID guiaId, UUID itinerarioId, SolicitudPagina solicitud) {
        return asignaciones.buscar(guiaId, itinerarioId, solicitud.conOrdenPermitido(ORDENES, "hora"))
                .map(AsignacionGuiaService::aRespuesta);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public HorarioRespuesta asignar(HorarioAlta alta) {
        Itinerario itinerario = itinerarios.buscarConBloqueoCompartido(alta.itinerarioId())
                .orElseThrow(() -> new DatoInvalidoException("itinerarioId", "El itinerario elegido no existe."));
        Guia guia = usuarios.buscarGuiaParaModificar(alta.guiaId())
                .orElseThrow(() -> new DatoInvalidoException("guiaId", "El guía elegido no existe."));
        AsignacionGuia nueva = new AsignacionGuia(UUID.randomUUID(), guia, itinerario, alta.hora());
        verificador.verificarDisponible(guia.getId(), nueva.getHora(), itinerario.getDuracionMinutos(), null);
        AsignacionGuia guardada = asignaciones.guardar(nueva);
        LOG.info("Horario asignado: {} {} {}", guia.getNombreUsuario(), itinerario.getCodigo(), guardada.getHora());
        return aRespuesta(guardada);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public HorarioRespuesta cambiarHora(UUID id, HorarioCambio cambio) {
        AsignacionGuia actual = buscar(id);
        // Mismo orden de bloqueos que al asignar: itinerario y después guía.
        Itinerario itinerario = itinerarios.buscarConBloqueoCompartido(actual.getItinerario().getId())
                .orElseThrow(() -> new RecursoNoEncontradoException("El itinerario ya no existe."));
        usuarios.buscarGuiaParaModificar(actual.getGuia().getId())
                .orElseThrow(() -> new RecursoNoEncontradoException("El guía ya no existe."));
        ControlVersion.verificar(actual.getVersion(), cambio.version());
        verificador.verificarDisponible(actual.getGuia().getId(), cambio.hora(), itinerario.getDuracionMinutos(), id);
        actual.cambiarHora(cambio.hora());
        return aRespuesta(asignaciones.guardar(actual));
    }

    public void eliminar(UUID id) {
        asignaciones.eliminar(buscar(id));
    }

    private AsignacionGuia buscar(UUID id) {
        return asignaciones.buscarPorId(id).orElseThrow(() -> new RecursoNoEncontradoException("El horario no existe."));
    }

    static HorarioRespuesta aRespuesta(AsignacionGuia a) {
        Itinerario it = a.getItinerario();
        return new HorarioRespuesta(a.getId(), a.getGuia().getId(), a.getGuia().getNombre(), it.getId(), it.getCodigo(),
                a.getHora(), a.getHoraFin(), it.getZonas().stream().map(Zona::getNombre).toList(), a.getVersion());
    }
}
