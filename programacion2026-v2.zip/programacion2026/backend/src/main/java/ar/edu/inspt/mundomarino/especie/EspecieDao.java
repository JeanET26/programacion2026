package ar.edu.inspt.mundomarino.especie;

import ar.edu.inspt.mundomarino.comun.dao.Dao;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/** Contrato DAO de especies. */
public interface EspecieDao extends Dao<Especie, UUID> {

    boolean existeNombreCientifico(String nombreCientifico, UUID excluirId);

    Pagina<Especie> buscar(String texto, UUID zonaId, SolicitudPagina solicitud);

    List<Especie> opciones();

    /**
     * Lee la especie con bloqueo de ESCRITURA (SELECT ... FOR UPDATE): nadie
     * más puede usarla en un itinerario hasta que termine esta transacción.
     */
    Optional<Especie> buscarParaModificar(UUID id);

    /**
     * Lee varias especies con bloqueo COMPARTIDO (SELECT ... FOR SHARE): otros
     * pueden leerlas, pero nadie puede quitarles la zona mientras se arma un itinerario.
     */
    List<Especie> buscarConBloqueoCompartido(Collection<UUID> ids);

    /** ¿La especie forma parte de algún itinerario? */
    boolean estaEnAlgunItinerario(UUID especieId);
}
