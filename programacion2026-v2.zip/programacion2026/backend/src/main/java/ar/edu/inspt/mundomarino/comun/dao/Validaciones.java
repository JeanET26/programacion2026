package ar.edu.inspt.mundomarino.comun.dao;

import ar.edu.inspt.mundomarino.comun.error.DatoInvalidoException;
import java.math.BigDecimal;
import java.util.Collection;

/**
 * Validaciones que usan las ENTIDADES para protegerse a sí mismas (invariantes).
 * Los DTO ya validan el formato con anotaciones; estas comprobaciones existen
 * porque una entidad también se crea desde otros caminos (importación, datos
 * de demostración) y nunca debe quedar en un estado inválido.
 */
public final class Validaciones {

    private Validaciones() {
    }

    public static String texto(String valor, String campo, int largoMaximo) {
        if (valor == null || valor.isBlank()) {
            throw new DatoInvalidoException(campo, "El campo " + campo + " es obligatorio.");
        }
        String limpio = valor.strip().replaceAll("\\s+", " ");
        if (limpio.length() > largoMaximo) {
            throw new DatoInvalidoException(campo, "El campo " + campo + " admite hasta " + largoMaximo + " caracteres.");
        }
        return limpio;
    }

    public static BigDecimal positivo(BigDecimal valor, String campo, BigDecimal maximo) {
        if (valor == null || valor.signum() <= 0 || valor.compareTo(maximo) > 0) {
            throw new DatoInvalidoException(campo, "El campo " + campo + " debe ser mayor que 0 y como máximo " + maximo + ".");
        }
        return valor;
    }

    public static int entre(Integer valor, String campo, int minimo, int maximo) {
        if (valor == null || valor < minimo || valor > maximo) {
            throw new DatoInvalidoException(campo, "El campo " + campo + " debe estar entre " + minimo + " y " + maximo + ".");
        }
        return valor;
    }

    public static <T> T obligatorio(T valor, String campo) {
        if (valor == null) {
            throw new DatoInvalidoException(campo, "El campo " + campo + " es obligatorio.");
        }
        return valor;
    }

    public static <C extends Collection<?>> C noVacia(C valores, String campo) {
        if (valores == null || valores.isEmpty()) {
            throw new DatoInvalidoException(campo, "Debe indicar al menos un elemento en " + campo + ".");
        }
        return valores;
    }
}
