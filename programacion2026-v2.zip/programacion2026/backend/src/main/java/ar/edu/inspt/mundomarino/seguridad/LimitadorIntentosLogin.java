package ar.edu.inspt.mundomarino.seguridad;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Component;

/**
 * Frena los intentos de adivinar contraseñas: por usuario (estricto) y por IP
 * (más amplio). <b>Limitación documentada:</b> los contadores están en la
 * memoria de cada instancia; con varias instancias detrás de un balanceador,
 * cada una cuenta por separado. Para compartirlos habría que moverlos a la
 * base o al proxy (ver docs/ESCALABILIDAD.md).
 */
@Component
class LimitadorIntentosLogin {

    private final Map<String, Deque<Instant>> fallos = new ConcurrentHashMap<>();
    private final PropiedadesSeguridad propiedades;

    LimitadorIntentosLogin(PropiedadesSeguridad propiedades) {
        this.propiedades = propiedades;
    }

    boolean bloqueado(String usuario, String ip) {
        return superaLimite("u:" + usuario, propiedades.intentosPorUsuario())
                || superaLimite("ip:" + ip, propiedades.intentosPorIp());
    }

    void registrarFallo(String usuario, String ip) {
        agregar("u:" + usuario);
        agregar("ip:" + ip);
    }

    void registrarExito(String usuario) {
        fallos.remove("u:" + usuario);
    }

    private boolean superaLimite(String clave, int maximo) {
        Deque<Instant> lista = fallos.get(clave);
        if (lista == null) {
            return false;
        }
        Instant limite = Instant.now().minus(Duration.ofMinutes(propiedades.minutosVentana()));
        synchronized (lista) {
            lista.removeIf(i -> i.isBefore(limite));
            return lista.size() >= maximo;
        }
    }

    private void agregar(String clave) {
        Deque<Instant> lista = fallos.computeIfAbsent(clave, k -> new ArrayDeque<>());
        synchronized (lista) {
            lista.add(Instant.now());
            while (lista.size() > 200) {
                lista.removeFirst();
            }
        }
    }
}
