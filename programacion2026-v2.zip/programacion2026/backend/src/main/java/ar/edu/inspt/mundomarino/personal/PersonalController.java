package ar.edu.inspt.mundomarino.personal;

import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.web.Opcion;
import ar.edu.inspt.mundomarino.comun.web.ParametrosPagina;
import ar.edu.inspt.mundomarino.personal.PersonalDtos.EmpleadoAlta;
import ar.edu.inspt.mundomarino.personal.PersonalDtos.EmpleadoCambios;
import ar.edu.inspt.mundomarino.personal.PersonalDtos.EmpleadoRespuesta;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.UUID;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/empleados")
@Tag(name = "Personal", description = "Guías y cuidadores. Solo administrador")
public class PersonalController {

    private final PersonalService servicio;

    public PersonalController(PersonalService servicio) {
        this.servicio = servicio;
    }

    @GetMapping
    public Pagina<EmpleadoRespuesta> listar(ParametrosPagina p, @RequestParam(required = false) Rol rol) {
        return servicio.listar(p.texto(), rol, p.aSolicitud());
    }

    @GetMapping("/opciones")
    public List<Opcion> opciones(@RequestParam Rol rol) {
        return servicio.opciones(rol);
    }

    @GetMapping("/{id}")
    public EmpleadoRespuesta obtener(@PathVariable UUID id) {
        return servicio.obtener(id);
    }

    @PostMapping
    public ResponseEntity<EmpleadoRespuesta> crear(@Valid @RequestBody EmpleadoAlta alta) {
        EmpleadoRespuesta creado = servicio.crear(alta);
        return ResponseEntity.created(URI.create("/api/empleados/" + creado.id())).body(creado);
    }

    @PutMapping("/{id}")
    public EmpleadoRespuesta actualizar(@PathVariable UUID id, @Valid @RequestBody EmpleadoCambios cambios) {
        return servicio.actualizar(id, cambios);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable UUID id) {
        servicio.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
