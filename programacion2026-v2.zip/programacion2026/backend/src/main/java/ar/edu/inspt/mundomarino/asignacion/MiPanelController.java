package ar.edu.inspt.mundomarino.asignacion;

import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.EspecieACargo;
import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.RecorridoPropio;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import java.util.UUID;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Lo que cada empleado consulta sobre sí mismo. No recibe ningún id: el
 * {@code @AuthenticationPrincipal(expression = "id")} toma el id del usuario
 * de la sesión que guardó Spring Security en el servidor.
 */
@RestController
@Tag(name = "Mi panel", description = "Consultas propias de guías y cuidadores")
public class MiPanelController {

    private final MiPanelService servicio;

    public MiPanelController(MiPanelService servicio) {
        this.servicio = servicio;
    }

    @GetMapping("/api/mi/recorridos")
    @Operation(summary = "Recorridos y horarios del guía autenticado")
    public List<RecorridoPropio> misRecorridos(@AuthenticationPrincipal(expression = "id") UUID usuarioId) {
        return servicio.misRecorridos(usuarioId);
    }

    @GetMapping("/api/mi/especies")
    @Operation(summary = "Especies a cargo del cuidador autenticado")
    public List<EspecieACargo> misEspecies(@AuthenticationPrincipal(expression = "id") UUID usuarioId) {
        return servicio.misEspecies(usuarioId);
    }
}
