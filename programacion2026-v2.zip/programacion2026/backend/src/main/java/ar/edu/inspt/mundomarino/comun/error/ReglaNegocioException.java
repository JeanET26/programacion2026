package ar.edu.inspt.mundomarino.comun.error;

/**
 * La operación rompe una regla del negocio (duplicado, elemento en uso,
 * horario superpuesto, cambio concurrente) → HTTP 409 Conflict.
 */
public class ReglaNegocioException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public ReglaNegocioException(String mensaje) {
        super(mensaje);
    }
}
