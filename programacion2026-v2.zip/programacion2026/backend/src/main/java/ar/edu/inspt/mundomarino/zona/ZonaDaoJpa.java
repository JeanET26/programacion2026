package ar.edu.inspt.mundomarino.zona;

import ar.edu.inspt.mundomarino.comun.dao.DaoJpa;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.stereotype.Repository;

/** Adaptador: implementa {@link ZonaDao} usando el repositorio JPA. */
@Repository
class ZonaDaoJpa extends DaoJpa<Zona, UUID> implements ZonaDao {

    private final ZonaRepositorio repositorio;

    ZonaDaoJpa(ZonaRepositorio repositorio) {
        super(repositorio);
        this.repositorio = repositorio;
    }

    @Override
    public boolean existeNombre(String nombre, UUID excluirId) {
        String n = nombre == null ? "" : nombre.strip();
        return excluirId == null ? repositorio.existsByNombreIgnoreCase(n)
                : repositorio.existsByNombreIgnoreCaseAndIdNot(n, excluirId);
    }

    @Override
    public Pagina<Zona> buscar(String texto, SolicitudPagina solicitud) {
        return aPagina(repositorio.buscar(patronBusqueda(texto), aPageable(solicitud)));
    }

    @Override
    public List<Zona> opciones() {
        return repositorio.findTop500ByOrderByNombreAsc();
    }

    @Override
    public Map<UUID, Long> contarEspecies(Collection<UUID> zonaIds) {
        Map<UUID, Long> resultado = new HashMap<>();
        if (zonaIds.isEmpty()) {
            return resultado;
        }
        List<String> ids = zonaIds.stream().map(UUID::toString).toList();
        for (Object[] fila : repositorio.contarEspecies(ids)) {
            resultado.put(UUID.fromString(String.valueOf(fila[0])), ((Number) fila[1]).longValue());
        }
        return resultado;
    }
}
