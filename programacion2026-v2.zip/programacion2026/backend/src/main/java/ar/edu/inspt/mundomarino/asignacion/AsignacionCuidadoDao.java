package ar.edu.inspt.mundomarino.asignacion;

import ar.edu.inspt.mundomarino.comun.dao.Dao;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

/** Contrato DAO de cuidados. */
public interface AsignacionCuidadoDao extends Dao<AsignacionCuidado, UUID> {

    boolean existe(UUID cuidadorId, UUID especieId);

    /** Especies a cargo de un cuidador, con especie y zona cargadas. */
    List<AsignacionCuidado> buscarPorCuidador(UUID cuidadorId);

    /** Todos los cuidados de un conjunto de especies, con su cuidador (una consulta). */
    List<AsignacionCuidado> buscarPorEspecies(Collection<UUID> especieIds);

    Pagina<AsignacionCuidado> buscar(UUID cuidadorId, UUID especieId, SolicitudPagina solicitud);
}
