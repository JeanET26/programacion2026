package ar.edu.inspt.mundomarino.zona;

import java.util.Collection;
import java.util.List;
import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * Repositorio de Spring Data JPA: Spring genera la implementación en tiempo
 * de ejecución. Solo lo usa {@link ZonaDaoJpa}; ningún servicio ni
 * controlador lo conoce (lo verifica la prueba de arquitectura).
 */
interface ZonaRepositorio extends JpaRepository<Zona, UUID> {

    boolean existsByNombreIgnoreCase(String nombre);

    boolean existsByNombreIgnoreCaseAndIdNot(String nombre, UUID id);

    @Query("select z from Zona z where :patron is null or lower(z.nombre) like :patron")
    Page<Zona> buscar(@Param("patron") String patron, Pageable pageable);

    List<Zona> findTop500ByOrderByNombreAsc();

    /** SQL nativo: cuenta en la tabla especie sin que este módulo dependa del módulo especie. */
    @Query(value = "select zona_id, count(*) from especie where zona_id in (:ids) group by zona_id", nativeQuery = true)
    List<Object[]> contarEspecies(@Param("ids") Collection<String> ids);
}
