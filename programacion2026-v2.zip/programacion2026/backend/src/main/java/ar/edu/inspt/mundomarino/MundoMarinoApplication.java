package ar.edu.inspt.mundomarino;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/**
 * Punto de entrada. {@code @SpringBootApplication} activa la configuración
 * automática y busca componentes ({@code @Service}, {@code @RestController},
 * {@code @Repository}...) en este paquete y sus subpaquetes. Spring crea esos
 * objetos y les inyecta sus dependencias por constructor.
 */
@SpringBootApplication
@ConfigurationPropertiesScan
public class MundoMarinoApplication {

    public static void main(String[] args) {
        SpringApplication.run(MundoMarinoApplication.class, args);
    }
}
