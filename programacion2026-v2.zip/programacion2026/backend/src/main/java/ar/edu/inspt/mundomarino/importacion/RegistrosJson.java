package ar.edu.inspt.mundomarino.importacion;

import java.math.BigDecimal;
import java.util.List;

/**
 * Formato de los archivos JSON de la versión 2 (y de la conversión del .dat
 * de la versión 1). Todo se lee como texto y se valida después, para poder
 * informar exactamente qué registro está mal.
 */
final class RegistrosJson {

    private RegistrosJson() {
    }

    record ZonaJson(String id, String nombre, BigDecimal extensionM2) {
    }

    record HabitatJson(String id, String nombre, String clima, String vegetacion, List<String> continentes) {
    }

    record EspecieJson(String id, String nombreEspanol, String nombreCientifico, String descripcion, String zonaId,
            List<String> habitatIds) {
    }

    record ItinerarioJson(String id, String codigo, Integer duracionMinutos, BigDecimal longitudKm,
            Integer maximoVisitantes, List<String> especieIds) {
    }

    record UsuarioJson(String id, String rol, String nombreUsuario, String hashContrasena, String nombre,
            String direccion, String telefono, String fechaIngreso) {
    }

    record AsignacionGuiaJson(String id, String guiaId, String itinerarioId, String hora) {
    }

    record AsignacionCuidadoJson(String id, String cuidadorId, String especieId, String fechaAsignacion) {
    }
}
