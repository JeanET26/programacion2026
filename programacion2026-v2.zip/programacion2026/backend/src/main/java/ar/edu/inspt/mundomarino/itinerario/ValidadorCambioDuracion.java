package ar.edu.inspt.mundomarino.itinerario;

import java.util.UUID;

/**
 * <b>Puerto</b> (interfaz) que el módulo itinerario necesita y que implementa
 * el módulo asignacion. Al cambiar la duración de un itinerario hay que
 * revisar que ningún guía quede con recorridos superpuestos, pero el módulo
 * itinerario no puede depender de asignacion (asignacion ya depende de
 * itinerario y se formaría un ciclo). Inversión de dependencias: el módulo
 * de alto nivel define la interfaz y el otro la implementa.
 */
public interface ValidadorCambioDuracion {

    /**
     * Lanza una excepción si con la nueva duración algún guía asignado a este
     * itinerario quedaría con recorridos superpuestos. Debe llamarse con el
     * itinerario ya bloqueado para escritura.
     */
    void verificarNuevaDuracion(UUID itinerarioId, int nuevaDuracionMinutos);
}
