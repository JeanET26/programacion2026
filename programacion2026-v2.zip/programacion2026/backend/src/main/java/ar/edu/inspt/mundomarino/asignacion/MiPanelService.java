package ar.edu.inspt.mundomarino.asignacion;

import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.EspecieACargo;
import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.EspecieBreve;
import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.HabitatBreve;
import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.RecorridoPropio;
import ar.edu.inspt.mundomarino.especie.Especie;
import ar.edu.inspt.mundomarino.habitat.Habitat;
import ar.edu.inspt.mundomarino.itinerario.Itinerario;
import ar.edu.inspt.mundomarino.zona.Zona;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Consultas propias de cada empleado. Reciben el id del usuario AUTENTICADO
 * (lo toma el controlador del contexto de seguridad, nunca de la URL ni del
 * cuerpo): un guía no puede pedir los recorridos de otro.
 */
@Service
@Transactional(readOnly = true)
public class MiPanelService {

    private final AsignacionGuiaDao horarios;
    private final AsignacionCuidadoDao cuidados;

    public MiPanelService(AsignacionGuiaDao horarios, AsignacionCuidadoDao cuidados) {
        this.horarios = horarios;
        this.cuidados = cuidados;
    }

    public List<RecorridoPropio> misRecorridos(UUID guiaId) {
        return horarios.buscarPorGuia(guiaId).stream().map(a -> {
            Itinerario it = a.getItinerario();
            List<EspecieBreve> esp = it.getEspecies().stream()
                    .sorted(Comparator.comparing(Especie::getNombreEspanol))
                    .map(e -> new EspecieBreve(e.getNombreEspanol(), e.getNombreCientifico())).toList();
            return new RecorridoPropio(a.getId(), a.getHora(), a.getHoraFin(), it.getCodigo(), it.getDuracionMinutos(),
                    it.getLongitudKm(), it.getMaximoVisitantes(), it.getZonas().stream().map(Zona::getNombre).toList(), esp);
        }).toList();
    }

    public List<EspecieACargo> misEspecies(UUID cuidadorId) {
        List<AsignacionCuidado> propias = cuidados.buscarPorCuidador(cuidadorId);
        // "¿Quién más la cuida?" para todas las especies en UNA consulta (sin N+1).
        Map<UUID, List<String>> otros = cuidados.buscarPorEspecies(propias.stream().map(a -> a.getEspecie().getId()).toList())
                .stream()
                .filter(a -> !a.getCuidador().getId().equals(cuidadorId))
                .collect(Collectors.groupingBy(a -> a.getEspecie().getId(),
                        Collectors.mapping(a -> a.getCuidador().getNombre(), Collectors.toList())));
        return propias.stream().map(a -> {
            Especie e = a.getEspecie();
            List<HabitatBreve> hs = e.getHabitats().stream().sorted(Comparator.comparing(Habitat::getNombre))
                    .map(h -> new HabitatBreve(h.getNombre(), h.getClima())).toList();
            return new EspecieACargo(a.getId(), a.getFechaAsignacion(), e.getNombreEspanol(), e.getNombreCientifico(),
                    e.getDescripcion(), e.getZona().map(Zona::getNombre).orElse(null), hs,
                    otros.getOrDefault(e.getId(), List.of()));
        }).toList();
    }
}
