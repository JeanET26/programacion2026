package ar.edu.inspt.mundomarino.itinerario;

import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.web.Opcion;
import ar.edu.inspt.mundomarino.comun.web.ParametrosPagina;
import ar.edu.inspt.mundomarino.itinerario.ItinerarioDtos.ItinerarioRespuesta;
import ar.edu.inspt.mundomarino.itinerario.ItinerarioDtos.ItinerarioSolicitud;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.UUID;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/itinerarios")
@Tag(name = "Itinerarios", description = "Solo administrador")
public class ItinerarioController {

    private final ItinerarioService servicio;

    public ItinerarioController(ItinerarioService servicio) {
        this.servicio = servicio;
    }

    @GetMapping
    public Pagina<ItinerarioRespuesta> listar(ParametrosPagina p) {
        return servicio.listar(p.texto(), p.aSolicitud());
    }

    @GetMapping("/opciones")
    public List<Opcion> opciones() {
        return servicio.opciones();
    }

    @GetMapping("/{id}")
    public ItinerarioRespuesta obtener(@PathVariable UUID id) {
        return servicio.obtener(id);
    }

    @PostMapping
    public ResponseEntity<ItinerarioRespuesta> crear(@Valid @RequestBody ItinerarioSolicitud solicitud) {
        ItinerarioRespuesta creado = servicio.crear(solicitud);
        return ResponseEntity.created(URI.create("/api/itinerarios/" + creado.id())).body(creado);
    }

    @PutMapping("/{id}")
    public ItinerarioRespuesta actualizar(@PathVariable UUID id, @Valid @RequestBody ItinerarioSolicitud solicitud) {
        return servicio.actualizar(id, solicitud);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable UUID id) {
        servicio.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
