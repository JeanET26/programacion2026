package ar.edu.inspt.mundomarino.personal;

import ar.edu.inspt.mundomarino.comun.dao.EntidadConId;
import ar.edu.inspt.mundomarino.comun.dao.Validaciones;
import ar.edu.inspt.mundomarino.comun.error.DatoInvalidoException;
import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorColumn;
import jakarta.persistence.DiscriminatorType;
import jakarta.persistence.Entity;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.Table;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * Base abstracta de toda persona que inicia sesión.
 *
 * <p><b>Herencia en la base:</b> {@code SINGLE_TABLE} guarda Administrador,
 * Guía y Cuidador en la tabla {@code usuario}; la columna {@code rol} indica
 * la subclase. Hibernate lee esa columna y construye el objeto correcto.</p>
 *
 * <p><b>UUID:</b> se genera en Java al dar de alta (ver {@code EntidadConId})
 * y se conserva tal cual al importar datos de versiones anteriores.</p>
 */
@Entity
@Table(name = "usuario")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "rol", discriminatorType = DiscriminatorType.STRING, length = 20)
public abstract class Usuario extends EntidadConId {

    public static final String REGEX_NOMBRE_USUARIO = "^[a-z0-9._]{3,30}$";

    @Column(name = "nombre_usuario", nullable = false, length = 30, updatable = false)
    private String nombreUsuario;

    /** Hash con prefijo del algoritmo, por ejemplo {@code {bcrypt}$2a$10$...}. Nunca la contraseña. */
    @Column(name = "hash_contrasena", nullable = false, length = 255)
    private String hashContrasena;

    @Column(name = "nombre", nullable = false, length = 80)
    private String nombre;

    protected Usuario() {
    }

    protected Usuario(UUID id, String nombreUsuario, String hashContrasena, String nombre) {
        super(id);
        String u = Validaciones.texto(nombreUsuario, "nombreUsuario", 30).toLowerCase();
        if (!u.matches(REGEX_NOMBRE_USUARIO)) {
            throw new DatoInvalidoException("nombreUsuario",
                    "El usuario debe tener entre 3 y 30 caracteres: minúsculas, números, punto o guion bajo.");
        }
        this.nombreUsuario = u;
        this.hashContrasena = Validaciones.texto(hashContrasena, "contrasena", 255);
        this.nombre = Validaciones.texto(nombre, "nombre", 80);
    }

    /** Rol para guardar y mostrar; cada subclase devuelve el suyo. */
    public abstract Rol getRol();

    /** Permisos del tipo de usuario (polimorfismo en lugar de preguntar "instanceof"). */
    public abstract Set<Permiso> getPermisos();

    /** Acceso a los datos laborales sin {@code instanceof}: solo Empleado devuelve algo. */
    public Optional<Empleado> comoEmpleado() {
        return Optional.empty();
    }

    public void cambiarNombre(String nombre) {
        this.nombre = Validaciones.texto(nombre, "nombre", 80);
    }

    /** Recibe el hash YA calculado por el PasswordEncoder. */
    public void cambiarHashContrasena(String hash) {
        this.hashContrasena = Validaciones.texto(hash, "contrasena", 255);
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public String getHashContrasena() {
        return hashContrasena;
    }

    public String getNombre() {
        return nombre;
    }
}
