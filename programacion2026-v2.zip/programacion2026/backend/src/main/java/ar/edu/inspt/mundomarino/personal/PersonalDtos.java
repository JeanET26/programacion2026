package ar.edu.inspt.mundomarino.personal;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public final class PersonalDtos {

    private PersonalDtos() {
    }

    /** Alta de guía o cuidador. */
    public record EmpleadoAlta(
            @NotNull(message = "Elegí el rol.") Rol rol,
            @NotBlank(message = "El usuario es obligatorio.")
            @Pattern(regexp = Usuario.REGEX_NOMBRE_USUARIO,
                    message = "Entre 3 y 30 caracteres: minúsculas, números, punto o guion bajo.") String nombreUsuario,
            @NotBlank(message = "La contraseña inicial es obligatoria.") @Size(min = 8, max = 64) String contrasena,
            @NotBlank(message = "El nombre es obligatorio.") @Size(max = 80) String nombre,
            @NotBlank(message = "La dirección es obligatoria.") @Size(max = 120) String direccion,
            @NotBlank(message = "El teléfono es obligatorio.")
            @Pattern(regexp = "^\\+?[0-9 -]{8,20}$", message = "Entre 8 y 20 dígitos.") String telefono,
            @NotNull(message = "La fecha de ingreso es obligatoria.") @PastOrPresent LocalDate fechaIngreso) {
    }

    /** Modificación: rol y usuario no cambian. Si viene contrasena, se restablece. */
    public record EmpleadoCambios(
            @Size(min = 8, max = 64) String contrasena,
            @NotBlank(message = "El nombre es obligatorio.") @Size(max = 80) String nombre,
            @NotBlank(message = "La dirección es obligatoria.") @Size(max = 120) String direccion,
            @NotBlank(message = "El teléfono es obligatorio.")
            @Pattern(regexp = "^\\+?[0-9 -]{8,20}$", message = "Entre 8 y 20 dígitos.") String telefono,
            @NotNull(message = "La fecha de ingreso es obligatoria.") @PastOrPresent LocalDate fechaIngreso,
            Long version) {
    }

    /** Datos de un empleado para el administrador (sin hash de contraseña). */
    public record EmpleadoRespuesta(UUID id, String nombreUsuario, String nombre, Rol rol, String direccion,
            String telefono, LocalDate fechaIngreso, Long version) {
    }

    /** Perfil propio de quien inició sesión. */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record Perfil(UUID id, String nombreUsuario, String nombre, Rol rol, List<String> permisos,
            String direccion, String telefono, LocalDate fechaIngreso) {

        public Perfil {
            permisos = List.copyOf(permisos);
        }
    }

    public record CambioContrasena(
            @NotBlank(message = "Ingresá tu contraseña actual.") String actual,
            @NotBlank(message = "Ingresá la nueva contraseña.") @Size(min = 8, max = 64) String nueva) {
    }

}
