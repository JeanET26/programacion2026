package ar.edu.inspt.mundomarino.seguridad;

import java.util.HashMap;
import java.util.Map;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.DelegatingPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * Codificación de contraseñas y autenticación. Está separada de la
 * configuración web porque también la usan procesos sin servidor HTTP
 * (la importación de datos).
 */
@Configuration
public class CodificacionConfig {

    /**
     * BCrypt (cada hash incluye su propia sal aleatoria) para todas las
     * contraseñas nuevas. El prefijo {bcrypt} o {pbkdf2-v2} indica con qué
     * algoritmo verificar; los hashes viejos se actualizan solos al entrar.
     */
    @Bean
    PasswordEncoder codificadorContrasenas(PropiedadesSeguridad propiedades) {
        Map<String, PasswordEncoder> codificadores = new HashMap<>();
        codificadores.put("bcrypt", new BCryptPasswordEncoder(propiedades.fuerzaBcrypt()));
        codificadores.put(Pbkdf2LegadoPasswordEncoder.ID, new Pbkdf2LegadoPasswordEncoder());
        return new DelegatingPasswordEncoder("bcrypt", codificadores);
    }

    @Bean
    AuthenticationManager administradorAutenticacion(DetallesUsuarioService detalles, PasswordEncoder codificador) {
        DaoAuthenticationProvider proveedor = new DaoAuthenticationProvider();
        proveedor.setUserDetailsService(detalles);
        proveedor.setPasswordEncoder(codificador);
        proveedor.setUserDetailsPasswordService(detalles);
        return new ProviderManager(proveedor);
    }
}
