package ar.edu.inspt.mundomarino.zona;

import ar.edu.inspt.mundomarino.comun.dao.Dao;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Contrato DAO específico de zonas: hereda el CRUD genérico y agrega sus consultas. */
public interface ZonaDao extends Dao<Zona, UUID> {

    /** ¿Existe otra zona con ese nombre? (sin distinguir mayúsculas; excluye la propia al editar). */
    boolean existeNombre(String nombre, UUID excluirId);

    Pagina<Zona> buscar(String texto, SolicitudPagina solicitud);

    /** Todas las zonas ordenadas, para listas desplegables (cantidad acotada). */
    List<Zona> opciones();

    /** Cantidad de especies de cada zona, en UNA consulta (evita N+1). */
    Map<UUID, Long> contarEspecies(Collection<UUID> zonaIds);
}
