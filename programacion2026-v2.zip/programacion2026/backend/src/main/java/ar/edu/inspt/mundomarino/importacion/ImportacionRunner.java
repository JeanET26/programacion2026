package ar.edu.inspt.mundomarino.importacion;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Component;

/**
 * Ejecuta la importación cuando se arranca con
 * {@code --app.importacion.directorio=<carpeta>} (perfil "importacion", sin
 * servidor web). Escribe el informe y termina con código 0 (éxito) o 2 (falló).
 */
@Component
@ConditionalOnProperty(prefix = "app.importacion", name = "directorio")
class ImportacionRunner implements ApplicationRunner {

    private static final Logger LOG = LoggerFactory.getLogger(ImportacionRunner.class);

    private final ImportadorDatos importador;
    private final ConfigurableApplicationContext contexto;
    private final Path directorio;
    private final Path carpetaInformes;
    private final boolean salir;

    ImportacionRunner(ImportadorDatos importador, ConfigurableApplicationContext contexto,
            @Value("${app.importacion.directorio}") String directorio,
            @Value("${app.importacion.informes:informes-importacion}") String carpetaInformes,
            @Value("${app.importacion.salir-al-terminar:true}") boolean salir) {
        this.importador = importador;
        this.contexto = contexto;
        this.directorio = Path.of(directorio);
        this.carpetaInformes = Path.of(carpetaInformes);
        this.salir = salir;
    }

    @Override
    public void run(ApplicationArguments args) throws IOException {
        LOG.info("Importando datos desde {}", directorio.toAbsolutePath());
        InformeImportacion informe = importador.importar(directorio);
        String fecha = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
        Files.createDirectories(carpetaInformes);
        Path archivo = carpetaInformes.resolve("informe-importacion-" + fecha + ".md");
        Files.writeString(archivo, informe.comoMarkdown(fecha));
        if (informe.exitosa()) {
            LOG.info("Importación confirmada: {}. Informe: {}", informe.getImportados(), archivo.toAbsolutePath());
        } else {
            LOG.error("La importación NO se realizó ({} errores). Informe: {}", informe.getErrores().size(),
                    archivo.toAbsolutePath());
        }
        if (salir) {
            int codigo = SpringApplication.exit(contexto, () -> informe.exitosa() ? 0 : 2);
            System.exit(codigo);
        }
    }
}
