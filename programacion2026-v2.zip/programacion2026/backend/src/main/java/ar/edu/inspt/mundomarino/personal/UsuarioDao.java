package ar.edu.inspt.mundomarino.personal;

import ar.edu.inspt.mundomarino.comun.dao.Dao;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Contrato DAO de usuarios. Ejemplo de segregación de interfaces: además del
 * CRUD genérico declara solo lo que necesitan sus clientes (login, personal,
 * asignaciones) y devuelve el tipo concreto cuando hace falta (Guia, Cuidador).
 */
public interface UsuarioDao extends Dao<Usuario, UUID> {

    Optional<Usuario> buscarPorNombreUsuario(String nombreUsuario);

    boolean existeNombreUsuario(String nombreUsuario);

    boolean existeAdministrador();

    long contar();

    /** Empleados paginados; {@code rol} null = guías y cuidadores. */
    Pagina<Empleado> buscarEmpleados(String texto, Rol rol, SolicitudPagina solicitud);

    Optional<Empleado> buscarEmpleado(UUID id);

    List<Empleado> opciones(Rol rol);

    Optional<Guia> buscarGuia(UUID id);

    Optional<Cuidador> buscarCuidador(UUID id);

    /**
     * Bloquea la fila del guía (SELECT ... FOR UPDATE). Todas las operaciones
     * que agregan o cambian horarios de un guía pasan por acá: se hacen de a una
     * POR GUÍA, mientras que las de otros guías siguen en paralelo.
     */
    Optional<Guia> buscarGuiaParaModificar(UUID id);

    /** Bloquea varios guías siempre en el mismo orden (por id) para evitar interbloqueos. */
    List<Guia> bloquearGuias(Collection<UUID> ids);
}
