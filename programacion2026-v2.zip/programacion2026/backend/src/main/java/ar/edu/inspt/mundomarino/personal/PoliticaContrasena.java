package ar.edu.inspt.mundomarino.personal;

import ar.edu.inspt.mundomarino.comun.error.DatoInvalidoException;

/** Reglas mínimas de contraseña, en un solo lugar (alta, restablecimiento y cambio propio). */
public final class PoliticaContrasena {

    private PoliticaContrasena() {
    }

    public static void validar(String campo, String contrasena) {
        if (contrasena == null || contrasena.length() < 8 || contrasena.length() > 64
                || !contrasena.matches(".*[A-Za-z].*") || !contrasena.matches(".*\\d.*")) {
            throw new DatoInvalidoException(campo, "La contraseña debe tener entre 8 y 64 caracteres e incluir letras y números.");
        }
    }
}
