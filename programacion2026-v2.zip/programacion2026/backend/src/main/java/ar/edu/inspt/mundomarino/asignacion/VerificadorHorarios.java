package ar.edu.inspt.mundomarino.asignacion;

import ar.edu.inspt.mundomarino.comun.error.ReglaNegocioException;
import ar.edu.inspt.mundomarino.itinerario.ValidadorCambioDuracion;
import ar.edu.inspt.mundomarino.personal.UsuarioDao;
import java.time.LocalTime;
import java.util.List;
import java.util.TreeSet;
import java.util.UUID;
import org.springframework.stereotype.Component;

/**
 * Aplica {@link ReglaHorarios} contra los datos de la base. Se usa:
 * <ul>
 *   <li>al asignar un guía y al cambiar la hora ({@link AsignacionGuiaService});</li>
 *   <li>al cambiar la duración de un itinerario (implementa el puerto
 *   {@link ValidadorCambioDuracion} que define el módulo itinerario).</li>
 * </ul>
 * No tiene {@code @Transactional}: siempre se ejecuta DENTRO de la transacción
 * del servicio que lo llama (AsignacionGuiaService o ItinerarioService).
 * <b>Precondición:</b> el guía ya está bloqueado (FOR UPDATE) en la transacción
 * actual. Por eso la consulta de sus horarios no puede quedar desactualizada:
 * ninguna otra transacción puede agregarle horarios hasta que esta termine.
 */
@Component
class VerificadorHorarios implements ValidadorCambioDuracion {

    private final AsignacionGuiaDao asignaciones;
    private final UsuarioDao usuarios;

    VerificadorHorarios(AsignacionGuiaDao asignaciones, UsuarioDao usuarios) {
        this.asignaciones = asignaciones;
        this.usuarios = usuarios;
    }

    /** Verifica que un recorrido nuevo (o movido) no se superponga con los otros del guía. */
    void verificarDisponible(UUID guiaId, LocalTime hora, int duracionMinutos, UUID ignorarAsignacionId) {
        ReglaHorarios.finDe(hora, duracionMinutos); // rechaza recorridos que pasan la medianoche
        for (AsignacionGuia otra : asignaciones.buscarPorGuia(guiaId)) {
            if (otra.getId().equals(ignorarAsignacionId)) {
                continue;
            }
            int durOtra = otra.getItinerario().getDuracionMinutos();
            if (ReglaHorarios.seSuperponen(hora, duracionMinutos, otra.getHora(), durOtra)) {
                throw new ReglaNegocioException("El guía ya tiene el " + otra.getItinerario().getCodigo() + " de "
                        + otra.getHora() + " a " + ReglaHorarios.finDe(otra.getHora(), durOtra)
                        + ", que se superpone con " + hora + "–" + ReglaHorarios.finDe(hora, duracionMinutos) + ".");
            }
        }
    }

    /**
     * Al alargar un itinerario: bloquea a todos sus guías (siempre en el mismo
     * orden, por id) y revisa cada horario con la NUEVA duración.
     */
    @Override
    public void verificarNuevaDuracion(UUID itinerarioId, int nuevaDuracion) {
        List<AsignacionGuia> delItinerario = asignaciones.buscarPorItinerario(itinerarioId);
        TreeSet<UUID> guias = new TreeSet<>();
        delItinerario.forEach(a -> guias.add(a.getGuia().getId()));
        usuarios.bloquearGuias(guias);
        List<AsignacionGuia> todas = asignaciones.buscarPorGuias(guias);
        for (AsignacionGuia a : todas) {
            for (AsignacionGuia b : todas) {
                if (a.getId().compareTo(b.getId()) >= 0 || !a.getGuia().getId().equals(b.getGuia().getId())) {
                    continue;
                }
                int durA = a.getItinerario().getId().equals(itinerarioId) ? nuevaDuracion : a.getItinerario().getDuracionMinutos();
                int durB = b.getItinerario().getId().equals(itinerarioId) ? nuevaDuracion : b.getItinerario().getDuracionMinutos();
                if (a.getItinerario().getId().equals(itinerarioId) || b.getItinerario().getId().equals(itinerarioId)) {
                    ReglaHorarios.finDe(a.getHora(), durA);
                    ReglaHorarios.finDe(b.getHora(), durB);
                    if (ReglaHorarios.seSuperponen(a.getHora(), durA, b.getHora(), durB)) {
                        throw new ReglaNegocioException("Con " + nuevaDuracion + " minutos, el guía "
                                + a.getGuia().getNombre() + " quedaría con recorridos superpuestos ("
                                + a.getHora() + " y " + b.getHora() + ").");
                    }
                }
            }
        }
        // También se revisa que ningún horario de este itinerario pase la medianoche.
        delItinerario.forEach(a -> ReglaHorarios.finDe(a.getHora(), nuevaDuracion));
    }
}
