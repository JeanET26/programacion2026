package ar.edu.inspt.mundomarino.personal;

import ar.edu.inspt.mundomarino.comun.dao.ControlVersion;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import ar.edu.inspt.mundomarino.comun.error.DatoInvalidoException;
import ar.edu.inspt.mundomarino.comun.error.RecursoNoEncontradoException;
import ar.edu.inspt.mundomarino.comun.error.ReglaNegocioException;
import ar.edu.inspt.mundomarino.comun.web.Opcion;
import ar.edu.inspt.mundomarino.personal.PersonalDtos.EmpleadoAlta;
import ar.edu.inspt.mundomarino.personal.PersonalDtos.EmpleadoCambios;
import ar.edu.inspt.mundomarino.personal.PersonalDtos.EmpleadoRespuesta;
import ar.edu.inspt.mundomarino.personal.PersonalDtos.Perfil;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Alta, modificación y baja de guías y cuidadores; perfil propio. */
@Service
@Transactional
public class PersonalService {

    private static final Logger LOG = LoggerFactory.getLogger(PersonalService.class);
    private static final Set<String> ORDENES = Set.of("nombre", "nombreUsuario", "fechaIngreso");

    private final UsuarioDao usuarios;
    private final PasswordEncoder codificador;
    private final CierreSesiones cierreSesiones;

    public PersonalService(UsuarioDao usuarios, PasswordEncoder codificador, CierreSesiones cierreSesiones) {
        this.usuarios = usuarios;
        this.codificador = codificador;
        this.cierreSesiones = cierreSesiones;
    }

    @Transactional(readOnly = true)
    public Pagina<EmpleadoRespuesta> listar(String texto, Rol rol, SolicitudPagina solicitud) {
        return usuarios.buscarEmpleados(texto, rol, solicitud.conOrdenPermitido(ORDENES, "nombre"))
                .map(PersonalService::aRespuesta);
    }

    @Transactional(readOnly = true)
    public EmpleadoRespuesta obtener(UUID id) {
        return aRespuesta(buscar(id));
    }

    @Transactional(readOnly = true)
    public List<Opcion> opciones(Rol rol) {
        if (rol != Rol.GUIA && rol != Rol.CUIDADOR) {
            throw new DatoInvalidoException("rol", "Indicá GUIA o CUIDADOR.");
        }
        return usuarios.opciones(rol).stream().map(e -> new Opcion(e.getId(), e.getNombre())).toList();
    }

    @Transactional(readOnly = true)
    public Perfil perfil(UUID usuarioId) {
        Usuario u = usuarios.buscarPorId(usuarioId)
                .orElseThrow(() -> new RecursoNoEncontradoException("El usuario ya no existe."));
        return aPerfil(u);
    }

    public EmpleadoRespuesta crear(EmpleadoAlta a) {
        PoliticaContrasena.validar("contrasena", a.contrasena());
        if (usuarios.existeNombreUsuario(a.nombreUsuario())) {
            throw new ReglaNegocioException("El nombre de usuario " + a.nombreUsuario() + " ya está en uso.");
        }
        String hash = codificador.encode(a.contrasena());
        UUID id = UUID.randomUUID();
        Empleado nuevo = switch (a.rol()) {
            case GUIA -> new Guia(id, a.nombreUsuario(), hash, a.nombre(), a.direccion(), a.telefono(), a.fechaIngreso());
            case CUIDADOR -> new Cuidador(id, a.nombreUsuario(), hash, a.nombre(), a.direccion(), a.telefono(), a.fechaIngreso());
            case ADMINISTRADOR -> throw new DatoInvalidoException("rol", "Desde aquí solo se registran guías y cuidadores.");
        };
        Empleado guardado = (Empleado) usuarios.guardar(nuevo);
        LOG.info("Alta de {} {}", guardado.getRol(), guardado.getNombreUsuario());
        return aRespuesta(guardado);
    }

    /**
     * Si el administrador restablece la contraseña, se cierran TODAS las
     * sesiones abiertas de ese empleado (después de confirmar la transacción).
     */
    public EmpleadoRespuesta actualizar(UUID id, EmpleadoCambios c) {
        Empleado e = buscar(id);
        ControlVersion.verificar(e.getVersion(), c.version());
        boolean restablece = c.contrasena() != null && !c.contrasena().isEmpty();
        if (restablece) {
            PoliticaContrasena.validar("contrasena", c.contrasena());
        }
        e.cambiarNombre(c.nombre());
        e.actualizarDatosLaborales(c.direccion(), c.telefono(), c.fechaIngreso());
        if (restablece) {
            e.cambiarHashContrasena(codificador.encode(c.contrasena()));
            cierreSesiones.cerrarSesionesDe(e.getNombreUsuario(), null);
            LOG.info("Contraseña restablecida para {}", e.getNombreUsuario());
        }
        return aRespuesta((Empleado) usuarios.guardar(e));
    }

    /** Las claves foráneas impiden borrar a alguien con asignaciones (409). */
    public void eliminar(UUID id) {
        Empleado e = buscar(id);
        String nombreUsuario = e.getNombreUsuario();
        usuarios.eliminar(e);
        cierreSesiones.cerrarSesionesDe(nombreUsuario, null);
        LOG.info("Baja de {}", nombreUsuario);
    }

    /** Cambio de la propia contraseña: se cierran las demás sesiones del usuario. */
    public void cambiarContrasenaPropia(UUID usuarioId, String actual, String nueva, String sesionActual) {
        Usuario u = usuarios.buscarPorId(usuarioId)
                .orElseThrow(() -> new RecursoNoEncontradoException("El usuario ya no existe."));
        if (!codificador.matches(actual, u.getHashContrasena())) {
            throw new DatoInvalidoException("actual", "La contraseña actual no es correcta.");
        }
        if (nueva.equals(actual)) {
            throw new DatoInvalidoException("nueva", "La nueva contraseña debe ser distinta de la actual.");
        }
        PoliticaContrasena.validar("nueva", nueva);
        u.cambiarHashContrasena(codificador.encode(nueva));
        usuarios.guardar(u);
        cierreSesiones.cerrarSesionesDe(u.getNombreUsuario(), sesionActual);
    }

    private Empleado buscar(UUID id) {
        return usuarios.buscarEmpleado(id).orElseThrow(() -> new RecursoNoEncontradoException("El empleado no existe."));
    }

    static EmpleadoRespuesta aRespuesta(Empleado e) {
        return new EmpleadoRespuesta(e.getId(), e.getNombreUsuario(), e.getNombre(), e.getRol(), e.getDireccion(),
                e.getTelefono(), e.getFechaIngreso(), e.getVersion());
    }

    static Perfil aPerfil(Usuario u) {
        List<String> permisos = u.getPermisos().stream().map(Enum::name).sorted().toList();
        Empleado e = u.comoEmpleado().orElse(null);
        return new Perfil(u.getId(), u.getNombreUsuario(), u.getNombre(), u.getRol(), permisos,
                e == null ? null : e.getDireccion(), e == null ? null : e.getTelefono(),
                e == null ? null : e.getFechaIngreso());
    }
}
