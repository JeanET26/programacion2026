package ar.edu.inspt.mundomarino.asignacion;

import ar.edu.inspt.mundomarino.comun.dao.DaoJpa;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Repository;

@Repository
class AsignacionGuiaDaoJpa extends DaoJpa<AsignacionGuia, UUID> implements AsignacionGuiaDao {

    private final AsignacionGuiaRepositorio repositorio;

    AsignacionGuiaDaoJpa(AsignacionGuiaRepositorio repositorio) {
        super(repositorio);
        this.repositorio = repositorio;
    }

    @Override
    public List<AsignacionGuia> buscarPorGuia(UUID guiaId) {
        return repositorio.buscarPorGuia(guiaId);
    }

    @Override
    public List<AsignacionGuia> buscarPorGuias(Collection<UUID> guiaIds) {
        return guiaIds.isEmpty() ? List.of() : repositorio.buscarPorGuias(guiaIds);
    }

    @Override
    public List<AsignacionGuia> buscarPorItinerario(UUID itinerarioId) {
        return repositorio.buscarPorItinerario(itinerarioId);
    }

    @Override
    public Pagina<AsignacionGuia> buscar(UUID guiaId, UUID itinerarioId, SolicitudPagina solicitud) {
        return aPagina(repositorio.buscar(guiaId, itinerarioId, aPageable(solicitud)));
    }
}
