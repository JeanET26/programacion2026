package ar.edu.inspt.mundomarino.zona;

import ar.edu.inspt.mundomarino.comun.dao.ControlVersion;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import ar.edu.inspt.mundomarino.comun.error.RecursoNoEncontradoException;
import ar.edu.inspt.mundomarino.comun.error.ReglaNegocioException;
import ar.edu.inspt.mundomarino.comun.web.Opcion;
import ar.edu.inspt.mundomarino.zona.ZonaDtos.ZonaRespuesta;
import ar.edu.inspt.mundomarino.zona.ZonaDtos.ZonaSolicitud;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Reglas de negocio de las zonas. Cada método público es una transacción:
 * si algo falla, se deshace todo (rollback) y no queda nada a medias.
 *
 * <p>Recibe el contrato {@link ZonaDao} por constructor (inyección de
 * dependencias): no sabe que detrás hay JPA ni MySQL.</p>
 */
@Service
@Transactional
public class ZonaService {

    private static final Set<String> ORDENES = Set.of("nombre", "extensionM2");

    private final ZonaDao zonas;

    public ZonaService(ZonaDao zonas) {
        this.zonas = zonas;
    }

    @Transactional(readOnly = true)
    public Pagina<ZonaRespuesta> listar(String texto, SolicitudPagina solicitud) {
        Pagina<Zona> pagina = zonas.buscar(texto, solicitud.conOrdenPermitido(ORDENES, "nombre"));
        Map<UUID, Long> cantidades = zonas.contarEspecies(pagina.contenido().stream().map(Zona::getId).toList());
        return pagina.map(z -> aRespuesta(z, cantidades.getOrDefault(z.getId(), 0L)));
    }

    @Transactional(readOnly = true)
    public ZonaRespuesta obtener(UUID id) {
        Zona z = buscar(id);
        return aRespuesta(z, zonas.contarEspecies(List.of(id)).getOrDefault(id, 0L));
    }

    @Transactional(readOnly = true)
    public List<Opcion> opciones() {
        return zonas.opciones().stream().map(z -> new Opcion(z.getId(), z.getNombre())).toList();
    }

    public ZonaRespuesta crear(ZonaSolicitud s) {
        // Mensaje claro en el caso normal; ante dos altas simultáneas decide la restricción única de la base.
        if (zonas.existeNombre(s.nombre(), null)) {
            throw new ReglaNegocioException("Ya existe una zona con ese nombre.");
        }
        Zona zona = zonas.guardar(new Zona(UUID.randomUUID(), s.nombre(), s.extensionM2()));
        return aRespuesta(zona, 0);
    }

    public ZonaRespuesta actualizar(UUID id, ZonaSolicitud s) {
        Zona zona = buscar(id);
        ControlVersion.verificar(zona.getVersion(), s.version());
        if (zonas.existeNombre(s.nombre(), id)) {
            throw new ReglaNegocioException("Ya existe una zona con ese nombre.");
        }
        zona.actualizar(s.nombre(), s.extensionM2());
        zona = zonas.guardar(zona);
        return aRespuesta(zona, zonas.contarEspecies(List.of(id)).getOrDefault(id, 0L));
    }

    /** Si hay especies en la zona, la clave foránea lo impide y se responde 409. */
    public void eliminar(UUID id) {
        zonas.eliminar(buscar(id));
    }

    private Zona buscar(UUID id) {
        return zonas.buscarPorId(id).orElseThrow(() -> new RecursoNoEncontradoException("La zona no existe."));
    }

    private static ZonaRespuesta aRespuesta(Zona z, long cantidadEspecies) {
        return new ZonaRespuesta(z.getId(), z.getNombre(), z.getExtensionM2(), cantidadEspecies, z.getVersion());
    }
}
