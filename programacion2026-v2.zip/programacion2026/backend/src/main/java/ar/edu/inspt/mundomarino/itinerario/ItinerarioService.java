package ar.edu.inspt.mundomarino.itinerario;

import ar.edu.inspt.mundomarino.comun.dao.ControlVersion;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import ar.edu.inspt.mundomarino.comun.dao.Validaciones;
import ar.edu.inspt.mundomarino.comun.error.DatoInvalidoException;
import ar.edu.inspt.mundomarino.comun.error.RecursoNoEncontradoException;
import ar.edu.inspt.mundomarino.comun.error.ReglaNegocioException;
import ar.edu.inspt.mundomarino.comun.web.Opcion;
import ar.edu.inspt.mundomarino.especie.Especie;
import ar.edu.inspt.mundomarino.especie.EspecieDao;
import ar.edu.inspt.mundomarino.itinerario.ItinerarioDtos.ItinerarioRespuesta;
import ar.edu.inspt.mundomarino.itinerario.ItinerarioDtos.ItinerarioSolicitud;
import ar.edu.inspt.mundomarino.zona.Zona;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

/** Reglas de negocio de los itinerarios. */
@Service
@Transactional
public class ItinerarioService {

    private static final Set<String> ORDENES = Set.of("codigo", "duracionMinutos", "maximoVisitantes");

    private final ItinerarioDao itinerarios;
    private final EspecieDao especies;
    private final List<ValidadorCambioDuracion> validadoresDuracion;

    /**
     * Spring inyecta TODAS las implementaciones de {@link ValidadorCambioDuracion}
     * que existan. Hoy hay una (horarios de guías); si mañana hiciera falta otra
     * regla al cambiar la duración, se agrega una clase sin tocar este servicio.
     */
    public ItinerarioService(ItinerarioDao itinerarios, EspecieDao especies,
            List<ValidadorCambioDuracion> validadoresDuracion) {
        this.itinerarios = itinerarios;
        this.especies = especies;
        this.validadoresDuracion = List.copyOf(validadoresDuracion);
    }

    @Transactional(readOnly = true)
    public Pagina<ItinerarioRespuesta> listar(String texto, SolicitudPagina solicitud) {
        return itinerarios.buscar(texto, solicitud.conOrdenPermitido(ORDENES, "codigo")).map(ItinerarioService::aRespuesta);
    }

    @Transactional(readOnly = true)
    public ItinerarioRespuesta obtener(UUID id) {
        return aRespuesta(itinerarios.buscarPorId(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("El itinerario no existe.")));
    }

    @Transactional(readOnly = true)
    public List<Opcion> opciones() {
        return itinerarios.opciones().stream()
                .map(i -> new Opcion(i.getId(), i.getCodigo() + " · " + i.getDuracionMinutos() + " min"))
                .toList();
    }

    /** Las especies se leen con bloqueo compartido: nadie puede quitarles la zona hasta confirmar. */
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public ItinerarioRespuesta crear(ItinerarioSolicitud s) {
        String codigo = Itinerario.codigoPara(Validaciones.obligatorio(s.numero(), "numero"));
        if (itinerarios.existeCodigo(codigo)) {
            throw new ReglaNegocioException("Ya existe el itinerario " + codigo + ".");
        }
        Itinerario nuevo = new Itinerario(UUID.randomUUID(), codigo, s.duracionMinutos(), s.longitudKm(),
                s.maximoVisitantes(), especiesElegidas(s.especieIds()));
        return aRespuesta(itinerarios.guardar(nuevo));
    }

    /**
     * Orden de bloqueos (siempre el mismo en todo el sistema, para evitar
     * interbloqueos): 1) el itinerario, 2) sus especies, 3) los guías asignados
     * (dentro del validador de duración).
     */
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public ItinerarioRespuesta actualizar(UUID id, ItinerarioSolicitud s) {
        Itinerario it = itinerarios.buscarParaModificar(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("El itinerario no existe."));
        ControlVersion.verificar(it.getVersion(), s.version());
        Set<Especie> elegidas = especiesElegidas(s.especieIds());
        if (s.duracionMinutos() != null && s.duracionMinutos() != it.getDuracionMinutos()) {
            validadoresDuracion.forEach(v -> v.verificarNuevaDuracion(id, s.duracionMinutos()));
        }
        it.actualizar(s.duracionMinutos(), s.longitudKm(), s.maximoVisitantes(), elegidas);
        return aRespuesta(itinerarios.guardar(it));
    }

    /** Si tiene guías asignados, la clave foránea lo impide (409). */
    public void eliminar(UUID id) {
        itinerarios.eliminar(itinerarios.buscarPorId(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("El itinerario no existe.")));
    }

    private Set<Especie> especiesElegidas(List<UUID> ids) {
        Set<UUID> pedidas = new LinkedHashSet<>(Validaciones.noVacia(ids, "especieIds"));
        List<Especie> encontradas = especies.buscarConBloqueoCompartido(pedidas);
        if (encontradas.size() != pedidas.size()) {
            throw new DatoInvalidoException("especieIds", "Alguna de las especies elegidas no existe.");
        }
        return new LinkedHashSet<>(encontradas);
    }

    static ItinerarioRespuesta aRespuesta(Itinerario i) {
        List<Opcion> esp = i.getEspecies().stream()
                .sorted(Comparator.comparing(Especie::getNombreEspanol))
                .map(e -> new Opcion(e.getId(), e.getNombreEspanol())).toList();
        return new ItinerarioRespuesta(i.getId(), i.getCodigo(), i.getNumero(), i.getDuracionMinutos(),
                i.getLongitudKm(), i.getMaximoVisitantes(), esp, i.getZonas().stream().map(Zona::getNombre).toList(),
                i.getVersion());
    }
}
