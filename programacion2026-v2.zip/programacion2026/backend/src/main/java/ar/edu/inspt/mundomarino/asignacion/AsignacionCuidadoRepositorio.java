package ar.edu.inspt.mundomarino.asignacion;

import java.util.Collection;
import java.util.List;
import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

interface AsignacionCuidadoRepositorio extends JpaRepository<AsignacionCuidado, UUID> {

    boolean existsByCuidadorIdAndEspecieId(UUID cuidadorId, UUID especieId);

    @Query("""
            select a from AsignacionCuidado a join fetch a.especie e left join fetch e.zona
            where a.cuidador.id = :cuidadorId order by a.fechaAsignacion
            """)
    List<AsignacionCuidado> buscarPorCuidador(@Param("cuidadorId") UUID cuidadorId);

    @Query("select a from AsignacionCuidado a join fetch a.cuidador where a.especie.id in :especieIds")
    List<AsignacionCuidado> buscarPorEspecies(@Param("especieIds") Collection<UUID> especieIds);

    @EntityGraph(attributePaths = {"cuidador", "especie", "especie.zona"})
    @Query(value = """
            select a from AsignacionCuidado a
            where (:cuidadorId is null or a.cuidador.id = :cuidadorId) and (:especieId is null or a.especie.id = :especieId)
            """,
            countQuery = """
            select count(a) from AsignacionCuidado a
            where (:cuidadorId is null or a.cuidador.id = :cuidadorId) and (:especieId is null or a.especie.id = :especieId)
            """)
    Page<AsignacionCuidado> buscar(@Param("cuidadorId") UUID cuidadorId, @Param("especieId") UUID especieId,
            Pageable pageable);
}
