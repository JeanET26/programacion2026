package ar.edu.inspt.mundomarino.habitat;

import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.web.Opcion;
import ar.edu.inspt.mundomarino.comun.web.ParametrosPagina;
import ar.edu.inspt.mundomarino.habitat.HabitatDtos.HabitatRespuesta;
import ar.edu.inspt.mundomarino.habitat.HabitatDtos.HabitatSolicitud;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.UUID;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/habitats")
@Tag(name = "Hábitats", description = "Solo administrador")
public class HabitatController {

    private final HabitatService servicio;

    public HabitatController(HabitatService servicio) {
        this.servicio = servicio;
    }

    @GetMapping
    public Pagina<HabitatRespuesta> listar(ParametrosPagina p) {
        return servicio.listar(p.texto(), p.aSolicitud());
    }

    @GetMapping("/opciones")
    public List<Opcion> opciones() {
        return servicio.opciones();
    }

    @GetMapping("/{id}")
    public HabitatRespuesta obtener(@PathVariable UUID id) {
        return servicio.obtener(id);
    }

    @PostMapping
    public ResponseEntity<HabitatRespuesta> crear(@Valid @RequestBody HabitatSolicitud solicitud) {
        HabitatRespuesta creado = servicio.crear(solicitud);
        return ResponseEntity.created(URI.create("/api/habitats/" + creado.id())).body(creado);
    }

    @PutMapping("/{id}")
    public HabitatRespuesta actualizar(@PathVariable UUID id, @Valid @RequestBody HabitatSolicitud solicitud) {
        return servicio.actualizar(id, solicitud);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable UUID id) {
        servicio.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
