package ar.edu.inspt.mundomarino.asignacion;

import ar.edu.inspt.mundomarino.comun.dao.EntidadConId;
import ar.edu.inspt.mundomarino.comun.dao.Validaciones;
import ar.edu.inspt.mundomarino.itinerario.Itinerario;
import ar.edu.inspt.mundomarino.personal.Guia;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.time.LocalTime;
import java.util.UUID;

/** Un guía conduce un itinerario a una hora de salida (tabla {@code asignacion_guia}). */
@Entity
@Table(name = "asignacion_guia")
public class AsignacionGuia extends EntidadConId {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "guia_id", nullable = false, updatable = false)
    private Guia guia;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "itinerario_id", nullable = false, updatable = false)
    private Itinerario itinerario;

    @Column(name = "hora", nullable = false)
    private LocalTime hora;

    protected AsignacionGuia() {
    }

    public AsignacionGuia(UUID id, Guia guia, Itinerario itinerario, LocalTime hora) {
        super(id);
        this.guia = Validaciones.obligatorio(guia, "guiaId");
        this.itinerario = Validaciones.obligatorio(itinerario, "itinerarioId");
        this.hora = normalizar(hora);
    }

    public void cambiarHora(LocalTime nuevaHora) {
        this.hora = normalizar(nuevaHora);
    }

    private static LocalTime normalizar(LocalTime hora) {
        return Validaciones.obligatorio(hora, "hora").withSecond(0).withNano(0);
    }

    public Guia getGuia() {
        return guia;
    }

    public Itinerario getItinerario() {
        return itinerario;
    }

    public LocalTime getHora() {
        return hora;
    }

    public LocalTime getHoraFin() {
        return ReglaHorarios.finDe(hora, itinerario.getDuracionMinutos());
    }
}
