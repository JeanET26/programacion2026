package ar.edu.inspt.mundomarino.asignacion;

import java.util.Collection;
import java.util.List;
import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

interface AsignacionGuiaRepositorio extends JpaRepository<AsignacionGuia, UUID> {

    /** "join fetch": trae el itinerario en el mismo SELECT (lo necesita la regla de horarios). */
    @Query("select a from AsignacionGuia a join fetch a.itinerario where a.guia.id = :guiaId order by a.hora")
    List<AsignacionGuia> buscarPorGuia(@Param("guiaId") UUID guiaId);

    @Query("select a from AsignacionGuia a join fetch a.itinerario where a.guia.id in :guiaIds")
    List<AsignacionGuia> buscarPorGuias(@Param("guiaIds") Collection<UUID> guiaIds);

    @Query("select a from AsignacionGuia a join fetch a.guia where a.itinerario.id = :itinerarioId")
    List<AsignacionGuia> buscarPorItinerario(@Param("itinerarioId") UUID itinerarioId);

    @EntityGraph(attributePaths = {"guia", "itinerario"})
    @Query(value = """
            select a from AsignacionGuia a
            where (:guiaId is null or a.guia.id = :guiaId) and (:itinerarioId is null or a.itinerario.id = :itinerarioId)
            """,
            countQuery = """
            select count(a) from AsignacionGuia a
            where (:guiaId is null or a.guia.id = :guiaId) and (:itinerarioId is null or a.itinerario.id = :itinerarioId)
            """)
    Page<AsignacionGuia> buscar(@Param("guiaId") UUID guiaId, @Param("itinerarioId") UUID itinerarioId, Pageable pageable);
}
