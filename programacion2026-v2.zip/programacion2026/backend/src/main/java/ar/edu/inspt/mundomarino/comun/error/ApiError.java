package ar.edu.inspt.mundomarino.comun.error;

import java.time.Instant;
import java.util.Map;

/**
 * Formato único de los errores de la API:
 * <pre>{ "estado": 409, "mensaje": "...", "errores": {"campo": "detalle"}, "ruta": "/api/...", "fecha": "..." }</pre>
 */
public record ApiError(int estado, String mensaje, Map<String, String> errores, String ruta, Instant fecha) {

    public ApiError {
        errores = errores == null ? Map.of() : Map.copyOf(errores);
    }
}
