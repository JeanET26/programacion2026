package ar.edu.inspt.mundomarino.comun.web;

import java.util.UUID;

/** Elemento para listas desplegables del frontend: solo id y texto visible. */
public record Opcion(UUID id, String texto) {
}
