package ar.edu.inspt.mundomarino.seguridad;

import ar.edu.inspt.mundomarino.personal.CierreSesiones;
import org.springframework.boot.autoconfigure.condition.ConditionalOnNotWebApplication;
import org.springframework.stereotype.Component;

/**
 * Implementación del puerto cuando la aplicación corre sin servidor web
 * (importación): no hay sesiones HTTP que cerrar. Ejemplo de sustitución:
 * los servicios reciben "un CierreSesiones" y funcionan con cualquiera.
 */
@Component
@ConditionalOnNotWebApplication
class CierreSesionesSinWeb implements CierreSesiones {

    @Override
    public void cerrarSesionesDe(String nombreUsuario, String excepto) {
        // sin servidor web no existen sesiones HTTP activas en este proceso
    }
}
