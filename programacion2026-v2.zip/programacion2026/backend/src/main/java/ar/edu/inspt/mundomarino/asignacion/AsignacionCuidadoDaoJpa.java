package ar.edu.inspt.mundomarino.asignacion;

import ar.edu.inspt.mundomarino.comun.dao.DaoJpa;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Repository;

@Repository
class AsignacionCuidadoDaoJpa extends DaoJpa<AsignacionCuidado, UUID> implements AsignacionCuidadoDao {

    private final AsignacionCuidadoRepositorio repositorio;

    AsignacionCuidadoDaoJpa(AsignacionCuidadoRepositorio repositorio) {
        super(repositorio);
        this.repositorio = repositorio;
    }

    @Override
    public boolean existe(UUID cuidadorId, UUID especieId) {
        return repositorio.existsByCuidadorIdAndEspecieId(cuidadorId, especieId);
    }

    @Override
    public List<AsignacionCuidado> buscarPorCuidador(UUID cuidadorId) {
        return repositorio.buscarPorCuidador(cuidadorId);
    }

    @Override
    public List<AsignacionCuidado> buscarPorEspecies(Collection<UUID> especieIds) {
        return especieIds.isEmpty() ? List.of() : repositorio.buscarPorEspecies(especieIds);
    }

    @Override
    public Pagina<AsignacionCuidado> buscar(UUID cuidadorId, UUID especieId, SolicitudPagina solicitud) {
        return aPagina(repositorio.buscar(cuidadorId, especieId, aPageable(solicitud)));
    }
}
