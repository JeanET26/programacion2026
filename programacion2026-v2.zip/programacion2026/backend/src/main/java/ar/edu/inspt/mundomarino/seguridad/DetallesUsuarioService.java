package ar.edu.inspt.mundomarino.seguridad;

import ar.edu.inspt.mundomarino.personal.Usuario;
import ar.edu.inspt.mundomarino.personal.UsuarioDao;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsPasswordService;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Puente entre Spring Security y nuestro {@link UsuarioDao}.
 * <ul>
 *   <li>{@code loadUserByUsername}: Spring lo llama al iniciar sesión.</li>
 *   <li>{@code updatePassword}: si el hash está en un formato viejo (por
 *   ejemplo, el PBKDF2 de la versión 2 importado), Spring lo vuelve a
 *   calcular con BCrypt la primera vez que el usuario entra bien.</li>
 * </ul>
 */
@Service
class DetallesUsuarioService implements UserDetailsService, UserDetailsPasswordService {

    private final UsuarioDao usuarios;

    DetallesUsuarioService(UsuarioDao usuarios) {
        this.usuarios = usuarios;
    }

    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String nombreUsuario) {
        return usuarios.buscarPorNombreUsuario(nombreUsuario).map(UsuarioAutenticado::new)
                .orElseThrow(() -> new UsernameNotFoundException("Usuario inexistente"));
    }

    @Override
    @Transactional
    public UserDetails updatePassword(UserDetails user, String nuevoHash) {
        Usuario u = usuarios.buscarPorNombreUsuario(user.getUsername())
                .orElseThrow(() -> new UsernameNotFoundException("Usuario inexistente"));
        u.cambiarHashContrasena(nuevoHash);
        return new UsuarioAutenticado(usuarios.guardar(u));
    }
}
