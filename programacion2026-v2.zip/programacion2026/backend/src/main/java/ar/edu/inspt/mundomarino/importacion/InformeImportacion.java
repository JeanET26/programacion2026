package ar.edu.inspt.mundomarino.importacion;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Resultado de una importación: qué se leyó, qué se importó, errores y advertencias. */
public final class InformeImportacion {

    private final String directorio;
    private final Map<String, String> archivos = new LinkedHashMap<>();
    private final Map<String, Integer> leidos = new LinkedHashMap<>();
    private final Map<String, Integer> importados = new LinkedHashMap<>();
    private final List<String> errores = new ArrayList<>();
    private final List<String> advertencias = new ArrayList<>();
    private boolean confirmada;

    InformeImportacion(String directorio) {
        this.directorio = directorio;
    }

    void archivo(String nombre, String sha256, int registros) {
        archivos.put(nombre, sha256);
        leidos.put(nombre, registros);
    }

    void error(String mensaje) {
        errores.add(mensaje);
    }

    void advertencia(String mensaje) {
        advertencias.add(mensaje);
    }

    void importado(String tipo, int cantidad) {
        importados.put(tipo, cantidad);
    }

    void confirmar() {
        confirmada = true;
    }

    public boolean exitosa() {
        return confirmada && errores.isEmpty();
    }

    public List<String> getErrores() {
        return Collections.unmodifiableList(errores);
    }

    public List<String> getAdvertencias() {
        return Collections.unmodifiableList(advertencias);
    }

    public Map<String, Integer> getImportados() {
        return Collections.unmodifiableMap(importados);
    }

    /** Informe legible en Markdown. */
    public String comoMarkdown(String fecha) {
        StringBuilder sb = new StringBuilder();
        sb.append("# Informe de importación\n\n");
        sb.append("- Fecha: ").append(fecha).append('\n');
        sb.append("- Directorio de origen: `").append(directorio).append("` (los archivos no se modifican)\n");
        sb.append("- Resultado: **").append(exitosa() ? "IMPORTACIÓN CONFIRMADA" : "NO SE IMPORTÓ NADA").append("**\n\n");
        sb.append("## Archivos leídos\n\n| Archivo | Registros | SHA-256 |\n|---|---|---|\n");
        archivos.forEach((n, h) -> sb.append("| ").append(n).append(" | ").append(leidos.get(n)).append(" | `")
                .append(h).append("` |\n"));
        if (!importados.isEmpty()) {
            sb.append("\n## Registros importados\n\n");
            importados.forEach((t, c) -> sb.append("- ").append(t).append(": ").append(c).append('\n'));
        }
        sb.append("\n## Errores (").append(errores.size()).append(")\n\n");
        errores.forEach(e -> sb.append("- ").append(e).append('\n'));
        sb.append("\n## Advertencias (").append(advertencias.size()).append(")\n\n");
        advertencias.forEach(a -> sb.append("- ").append(a).append('\n'));
        return sb.toString();
    }
}
