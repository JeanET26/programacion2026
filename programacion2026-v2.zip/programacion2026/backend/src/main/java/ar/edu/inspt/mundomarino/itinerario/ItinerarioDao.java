package ar.edu.inspt.mundomarino.itinerario;

import ar.edu.inspt.mundomarino.comun.dao.Dao;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/** Contrato DAO de itinerarios. */
public interface ItinerarioDao extends Dao<Itinerario, UUID> {

    boolean existeCodigo(String codigo);

    Pagina<Itinerario> buscar(String texto, SolicitudPagina solicitud);

    List<Itinerario> opciones();

    /** SELECT ... FOR UPDATE: para cambiar la duración sin que nadie asigne guías en el medio. */
    Optional<Itinerario> buscarParaModificar(UUID id);

    /** SELECT ... FOR SHARE: para asignar un guía sin que nadie cambie la duración en el medio. */
    Optional<Itinerario> buscarConBloqueoCompartido(UUID id);
}
