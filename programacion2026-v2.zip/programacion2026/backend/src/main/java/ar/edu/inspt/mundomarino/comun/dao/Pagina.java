package ar.edu.inspt.mundomarino.comun.dao;

import java.util.List;
import java.util.function.Function;

/**
 * Una página de resultados. La lista se copia (List.copyOf): quien recibe
 * la página no puede modificar el contenido original.
 */
public record Pagina<T>(List<T> contenido, int numero, int tamanio, long totalElementos, int totalPaginas) {

    public Pagina {
        contenido = List.copyOf(contenido);
    }

    public <R> Pagina<R> map(Function<? super T, ? extends R> conversor) {
        return new Pagina<>(contenido.stream().<R>map(conversor).toList(), numero, tamanio, totalElementos, totalPaginas);
    }
}
