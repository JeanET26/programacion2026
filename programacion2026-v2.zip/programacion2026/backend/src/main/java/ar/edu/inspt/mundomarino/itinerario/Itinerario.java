package ar.edu.inspt.mundomarino.itinerario;

import ar.edu.inspt.mundomarino.comun.dao.EntidadConId;
import ar.edu.inspt.mundomarino.comun.dao.Validaciones;
import ar.edu.inspt.mundomarino.comun.error.DatoInvalidoException;
import ar.edu.inspt.mundomarino.especie.Especie;
import ar.edu.inspt.mundomarino.zona.Zona;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * Recorrido guiado (tabla {@code itinerario}).
 *
 * <p>Reglas que garantiza la propia entidad (las cumple cualquiera que la
 * cree: el servicio, el importador o los datos de demostración):</p>
 * <ul>
 *   <li>Código con formato IT-01..IT-99.</li>
 *   <li>Al menos una especie, y todas ubicadas en una zona.</li>
 *   <li>Las zonas NO se guardan: {@link #getZonas()} las deriva de las especies.</li>
 * </ul>
 */
@Entity
@Table(name = "itinerario")
public class Itinerario extends EntidadConId {

    public static final int DURACION_MINIMA = 5;
    public static final int DURACION_MAXIMA = 480;
    private static final BigDecimal LONGITUD_MAXIMA = new BigDecimal("999.99");

    @Column(name = "codigo", nullable = false, length = 5, updatable = false)
    private String codigo;

    @Column(name = "duracion_minutos", nullable = false)
    private int duracionMinutos;

    @Column(name = "longitud_km", nullable = false, precision = 5, scale = 2)
    private BigDecimal longitudKm;

    @Column(name = "maximo_visitantes", nullable = false)
    private int maximoVisitantes;

    @ManyToMany
    @JoinTable(name = "itinerario_especie",
            joinColumns = @JoinColumn(name = "itinerario_id"),
            inverseJoinColumns = @JoinColumn(name = "especie_id"))
    private Set<Especie> especies = new LinkedHashSet<>();

    protected Itinerario() {
    }

    public Itinerario(UUID id, String codigo, int duracionMinutos, BigDecimal longitudKm, int maximoVisitantes,
            Collection<Especie> especies) {
        super(id);
        if (codigo == null || !codigo.matches("^IT-\\d{2}$") || "IT-00".equals(codigo)) {
            throw new DatoInvalidoException("codigo", "El código debe tener el formato IT-01 a IT-99.");
        }
        this.codigo = codigo;
        asignar(duracionMinutos, longitudKm, maximoVisitantes, especies);
    }

    /** Convierte el número 1..99 en el código IT-01..IT-99. */
    public static String codigoPara(Integer numero) {
        return String.format("IT-%02d", Validaciones.entre(numero, "numero", 1, 99));
    }

    public void actualizar(int duracionMinutos, BigDecimal longitudKm, int maximoVisitantes, Collection<Especie> especies) {
        asignar(duracionMinutos, longitudKm, maximoVisitantes, especies);
    }

    private void asignar(int duracionMinutos, BigDecimal longitudKm, int maximoVisitantes, Collection<Especie> especies) {
        int d = Validaciones.entre(duracionMinutos, "duracionMinutos", DURACION_MINIMA, DURACION_MAXIMA);
        BigDecimal l = Validaciones.positivo(longitudKm, "longitudKm", LONGITUD_MAXIMA);
        int m = Validaciones.entre(maximoVisitantes, "maximoVisitantes", 1, 500);
        Validaciones.noVacia(especies, "especieIds");
        for (Especie e : especies) {
            if (e.getZona().isEmpty()) {
                throw new DatoInvalidoException("especieIds", "La especie " + e.getNombreEspanol()
                        + " no está ubicada en ninguna zona; ubicala antes de sumarla a un itinerario.");
            }
        }
        this.duracionMinutos = d;
        this.longitudKm = l;
        this.maximoVisitantes = m;
        this.especies.clear();
        this.especies.addAll(especies);
    }

    public String getCodigo() {
        return codigo;
    }

    public int getNumero() {
        return Integer.parseInt(codigo.substring(3));
    }

    public int getDuracionMinutos() {
        return duracionMinutos;
    }

    public BigDecimal getLongitudKm() {
        return longitudKm;
    }

    public int getMaximoVisitantes() {
        return maximoVisitantes;
    }

    public Set<Especie> getEspecies() {
        return Collections.unmodifiableSet(especies);
    }

    /** Zonas que recorre, derivadas de sus especies, sin repetir y en orden alfabético. */
    public List<Zona> getZonas() {
        return especies.stream().map(Especie::getZona).flatMap(Optional::stream).distinct()
                .sorted(Comparator.comparing(Zona::getNombre)).toList();
    }
}
