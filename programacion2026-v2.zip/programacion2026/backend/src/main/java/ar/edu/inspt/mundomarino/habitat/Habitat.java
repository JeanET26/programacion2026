package ar.edu.inspt.mundomarino.habitat;

import ar.edu.inspt.mundomarino.comun.dao.EntidadConId;
import ar.edu.inspt.mundomarino.comun.dao.Validaciones;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Table;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

/** Hábitat natural; varias especies pueden compartirlo (tabla {@code habitat}). */
@Entity
@Table(name = "habitat")
public class Habitat extends EntidadConId {

    @Column(name = "nombre", nullable = false, length = 80)
    private String nombre;

    @Column(name = "clima", nullable = false, length = 80)
    private String clima;

    @Column(name = "vegetacion", nullable = false, length = 120)
    private String vegetacion;

    @ElementCollection
    @CollectionTable(name = "habitat_continente", joinColumns = @JoinColumn(name = "habitat_id"))
    @Column(name = "continente", nullable = false, length = 30)
    private Set<String> continentes = new LinkedHashSet<>();

    protected Habitat() {
    }

    public Habitat(UUID id, String nombre, String clima, String vegetacion, Set<String> continentes) {
        super(id);
        asignar(nombre, clima, vegetacion, continentes);
    }

    public void actualizar(String nombre, String clima, String vegetacion, Set<String> continentes) {
        asignar(nombre, clima, vegetacion, continentes);
    }

    private void asignar(String nombre, String clima, String vegetacion, Set<String> continentes) {
        String n = Validaciones.texto(nombre, "nombre", 80);
        String c = Validaciones.texto(clima, "clima", 80);
        String v = Validaciones.texto(vegetacion, "vegetacion", 120);
        Set<String> conts = new LinkedHashSet<>();
        for (String cont : Validaciones.noVacia(continentes, "continentes")) {
            conts.add(Validaciones.texto(cont, "continentes", 30));
        }
        this.nombre = n;
        this.clima = c;
        this.vegetacion = v;
        // Se modifica la colección existente (no se reemplaza) para que Hibernate calcule las diferencias.
        this.continentes.clear();
        this.continentes.addAll(conts);
    }

    public String getNombre() {
        return nombre;
    }

    public String getClima() {
        return clima;
    }

    public String getVegetacion() {
        return vegetacion;
    }

    /** Vista de solo lectura: nadie puede agregar continentes sin pasar por {@link #actualizar}. */
    public Set<String> getContinentes() {
        return Collections.unmodifiableSet(continentes);
    }
}
