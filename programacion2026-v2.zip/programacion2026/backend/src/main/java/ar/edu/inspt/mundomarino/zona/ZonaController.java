package ar.edu.inspt.mundomarino.zona;

import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.web.Opcion;
import ar.edu.inspt.mundomarino.comun.web.ParametrosPagina;
import ar.edu.inspt.mundomarino.zona.ZonaDtos.ZonaRespuesta;
import ar.edu.inspt.mundomarino.zona.ZonaDtos.ZonaSolicitud;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.UUID;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controlador REST: traduce HTTP ⇄ llamadas al servicio. No tiene reglas de
 * negocio ni accede a la base. Quién puede llamarlo lo define SeguridadConfig.
 */
@RestController
@RequestMapping("/api/zonas")
@Tag(name = "Zonas", description = "Solo administrador")
public class ZonaController {

    private final ZonaService servicio;

    public ZonaController(ZonaService servicio) {
        this.servicio = servicio;
    }

    @GetMapping
    @Operation(summary = "Listado paginado (orden: nombre, extensionM2; búsqueda: q)")
    public Pagina<ZonaRespuesta> listar(ParametrosPagina p) {
        return servicio.listar(p.texto(), p.aSolicitud());
    }

    @GetMapping("/opciones")
    @Operation(summary = "Zonas para listas desplegables")
    public List<Opcion> opciones() {
        return servicio.opciones();
    }

    @GetMapping("/{id}")
    public ZonaRespuesta obtener(@PathVariable UUID id) {
        return servicio.obtener(id);
    }

    @PostMapping
    public ResponseEntity<ZonaRespuesta> crear(@Valid @RequestBody ZonaSolicitud solicitud) {
        ZonaRespuesta creada = servicio.crear(solicitud);
        return ResponseEntity.created(URI.create("/api/zonas/" + creada.id())).body(creada);
    }

    @PutMapping("/{id}")
    public ZonaRespuesta actualizar(@PathVariable UUID id, @Valid @RequestBody ZonaSolicitud solicitud) {
        return servicio.actualizar(id, solicitud);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable UUID id) {
        servicio.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
