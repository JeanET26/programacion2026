package ar.edu.inspt.mundomarino.comun.error;

import java.util.Map;

/**
 * Traduce el nombre de una restricción de MySQL (definida en las migraciones
 * Flyway) a un mensaje entendible. Así, cuando la BASE rechaza algo (por
 * ejemplo dos altas simultáneas con el mismo nombre), el usuario recibe el
 * mismo mensaje que si lo hubiera detectado el servicio.
 */
public final class TraductorRestricciones {

    private static final Map<String, String> MENSAJES = Map.ofEntries(
            Map.entry("uk_zona_nombre", "Ya existe una zona con ese nombre."),
            Map.entry("uk_habitat_nombre", "Ya existe un hábitat con ese nombre."),
            Map.entry("uk_especie_nombre_cientifico", "Ya existe una especie con ese nombre científico."),
            Map.entry("uk_itinerario_codigo", "Ya existe un itinerario con ese código."),
            Map.entry("uk_usuario_nombre_usuario", "Ese nombre de usuario ya está en uso."),
            Map.entry("uk_asignacion_guia_guia_hora", "El guía ya tiene un recorrido que sale a esa hora."),
            Map.entry("uk_asignacion_cuidado_cuidador_especie", "Ese cuidador ya está a cargo de esa especie."),
            Map.entry("fk_especie_zona", "La zona tiene especies ubicadas o no existe."),
            Map.entry("fk_especie_habitat_habitat", "El hábitat está asociado a especies o no existe."),
            Map.entry("fk_itinerario_especie_especie", "La especie forma parte de un itinerario o no existe."),
            Map.entry("fk_asignacion_guia_itinerario", "El itinerario tiene guías asignados o no existe."),
            Map.entry("fk_asignacion_guia_guia", "El guía tiene horarios asignados o no existe."),
            Map.entry("fk_asignacion_cuidado_especie", "La especie tiene cuidadores asignados o no existe."),
            Map.entry("fk_asignacion_cuidado_cuidador", "El cuidador tiene especies asignadas o no existe."));

    private TraductorRestricciones() {
    }

    /** Busca el nombre de alguna restricción conocida dentro del mensaje técnico. */
    public static String traducir(String mensajeTecnico) {
        if (mensajeTecnico != null) {
            String m = mensajeTecnico.toLowerCase();
            for (Map.Entry<String, String> e : MENSAJES.entrySet()) {
                if (m.contains(e.getKey())) {
                    return e.getValue();
                }
            }
        }
        return "La operación viola una restricción de integridad de los datos.";
    }
}
