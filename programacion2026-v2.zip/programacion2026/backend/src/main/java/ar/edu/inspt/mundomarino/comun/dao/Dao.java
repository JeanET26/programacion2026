package ar.edu.inspt.mundomarino.comun.dao;

import java.util.Optional;

/**
 * <b>Contrato genérico de DAO</b> (Data Access Object).
 *
 * <p>Define UNA vez las operaciones de persistencia que necesita cualquier
 * entidad. Cada módulo declara su contrato específico extendiendo este
 * (por ejemplo {@code ZonaDao extends Dao<Zona, UUID>}) y agrega solo sus
 * consultas propias.</p>
 *
 * <p>Relación con JPA:</p>
 * <pre>
 *   Servicio ──usa──▶ ZonaDao (interfaz, nuestra)          ← contrato
 *                        ▲ implementa
 *                     ZonaDaoJpa extends DaoJpa            ← adaptador
 *                        │ delega en
 *                     ZonaRepositorio extends JpaRepository ← herramienta de Spring Data
 * </pre>
 * Los servicios no conocen Spring Data: si mañana se cambia la tecnología
 * de persistencia, se escribe otro adaptador y los servicios no cambian.
 *
 * @param <T>  entidad
 * @param <ID> tipo de su identificador
 */
public interface Dao<T, ID> {

    Optional<T> buscarPorId(ID id);

    boolean existePorId(ID id);

    /** Página de resultados con orden; nunca carga toda la tabla. */
    Pagina<T> listar(SolicitudPagina solicitud);

    /** Inserta o actualiza y sincroniza con la base (flush) para detectar
     *  enseguida violaciones de restricciones dentro de la transacción. */
    T guardar(T entidad);

    /** Elimina y sincroniza con la base: si una clave foránea lo impide,
     *  el error aparece acá y no recién al confirmar. */
    void eliminar(T entidad);
}
