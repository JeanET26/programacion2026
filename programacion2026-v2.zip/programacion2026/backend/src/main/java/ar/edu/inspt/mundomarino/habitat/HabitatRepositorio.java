package ar.edu.inspt.mundomarino.habitat;

import java.util.List;
import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

interface HabitatRepositorio extends JpaRepository<Habitat, UUID> {

    boolean existsByNombreIgnoreCase(String nombre);

    boolean existsByNombreIgnoreCaseAndIdNot(String nombre, UUID id);

    @Query("select h from Habitat h where :patron is null or lower(h.nombre) like :patron or lower(h.clima) like :patron")
    Page<Habitat> buscar(@Param("patron") String patron, Pageable pageable);

    List<Habitat> findTop500ByOrderByNombreAsc();
}
