package ar.edu.inspt.mundomarino.especie;

import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.web.Opcion;
import ar.edu.inspt.mundomarino.comun.web.ParametrosPagina;
import ar.edu.inspt.mundomarino.especie.EspecieDtos.EspecieRespuesta;
import ar.edu.inspt.mundomarino.especie.EspecieDtos.EspecieSolicitud;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.UUID;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/especies")
@Tag(name = "Especies", description = "Solo administrador")
public class EspecieController {

    private final EspecieService servicio;

    public EspecieController(EspecieService servicio) {
        this.servicio = servicio;
    }

    @GetMapping
    public Pagina<EspecieRespuesta> listar(ParametrosPagina p, @RequestParam(required = false) UUID zonaId) {
        return servicio.listar(p.texto(), zonaId, p.aSolicitud());
    }

    @GetMapping("/opciones")
    public List<Opcion> opciones() {
        return servicio.opciones();
    }

    @GetMapping("/{id}")
    public EspecieRespuesta obtener(@PathVariable UUID id) {
        return servicio.obtener(id);
    }

    @PostMapping
    public ResponseEntity<EspecieRespuesta> crear(@Valid @RequestBody EspecieSolicitud solicitud) {
        EspecieRespuesta creada = servicio.crear(solicitud);
        return ResponseEntity.created(URI.create("/api/especies/" + creada.id())).body(creada);
    }

    @PutMapping("/{id}")
    public EspecieRespuesta actualizar(@PathVariable UUID id, @Valid @RequestBody EspecieSolicitud solicitud) {
        return servicio.actualizar(id, solicitud);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable UUID id) {
        servicio.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
