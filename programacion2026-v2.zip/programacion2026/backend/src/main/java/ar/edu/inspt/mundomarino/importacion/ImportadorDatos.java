package ar.edu.inspt.mundomarino.importacion;

import ar.edu.inspt.mundomarino.asignacion.AsignacionCuidado;
import ar.edu.inspt.mundomarino.asignacion.AsignacionCuidadoDao;
import ar.edu.inspt.mundomarino.asignacion.AsignacionGuia;
import ar.edu.inspt.mundomarino.asignacion.AsignacionGuiaDao;
import ar.edu.inspt.mundomarino.asignacion.ReglaHorarios;
import ar.edu.inspt.mundomarino.comun.error.DatoInvalidoException;
import ar.edu.inspt.mundomarino.comun.error.ReglaNegocioException;
import ar.edu.inspt.mundomarino.especie.Especie;
import ar.edu.inspt.mundomarino.especie.EspecieDao;
import ar.edu.inspt.mundomarino.habitat.Habitat;
import ar.edu.inspt.mundomarino.habitat.HabitatDao;
import ar.edu.inspt.mundomarino.importacion.RegistrosJson.AsignacionCuidadoJson;
import ar.edu.inspt.mundomarino.importacion.RegistrosJson.AsignacionGuiaJson;
import ar.edu.inspt.mundomarino.importacion.RegistrosJson.EspecieJson;
import ar.edu.inspt.mundomarino.importacion.RegistrosJson.HabitatJson;
import ar.edu.inspt.mundomarino.importacion.RegistrosJson.ItinerarioJson;
import ar.edu.inspt.mundomarino.importacion.RegistrosJson.UsuarioJson;
import ar.edu.inspt.mundomarino.importacion.RegistrosJson.ZonaJson;
import ar.edu.inspt.mundomarino.itinerario.Itinerario;
import ar.edu.inspt.mundomarino.itinerario.ItinerarioDao;
import ar.edu.inspt.mundomarino.personal.Administrador;
import ar.edu.inspt.mundomarino.personal.Cuidador;
import ar.edu.inspt.mundomarino.personal.Guia;
import ar.edu.inspt.mundomarino.personal.Rol;
import ar.edu.inspt.mundomarino.personal.Usuario;
import ar.edu.inspt.mundomarino.personal.UsuarioDao;
import ar.edu.inspt.mundomarino.seguridad.Pbkdf2LegadoPasswordEncoder;
import ar.edu.inspt.mundomarino.zona.Zona;
import ar.edu.inspt.mundomarino.zona.ZonaDao;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.function.Supplier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * Importa a MySQL los datos de versiones anteriores (JSON de la v2 o la
 * conversión del .dat de la v1). Garantías:
 * <ul>
 *   <li><b>Todo o nada:</b> validación y escritura en UNA transacción; ante
 *   cualquier error se hace rollback y no queda nada importado.</li>
 *   <li><b>Valida antes de escribir:</b> formato, valores, referencias,
 *   duplicados (dentro de los archivos y contra la base) y horarios.</li>
 *   <li><b>No pisa datos:</b> si un id o un dato único ya existe en la base, es un error.</li>
 *   <li><b>Conserva ids y relaciones:</b> se usan los mismos UUID.</li>
 *   <li><b>Solo lee los archivos originales</b> y deja un informe con su SHA-256.</li>
 * </ul>
 * Las reglas de dominio son las mismas del sistema: se construyen las
 * entidades con sus constructores (que validan) y se usa {@link ReglaHorarios}.
 */
@Service
public class ImportadorDatos {

    private static final Logger LOG = LoggerFactory.getLogger(ImportadorDatos.class);
    private static final long TAMANIO_MAXIMO_ARCHIVO = 50L * 1024 * 1024;

    private final ZonaDao zonas;
    private final HabitatDao habitats;
    private final EspecieDao especies;
    private final ItinerarioDao itinerarios;
    private final UsuarioDao usuarios;
    private final AsignacionGuiaDao horarios;
    private final AsignacionCuidadoDao cuidados;
    private final PasswordEncoder codificador;
    private final TransactionTemplate transaccion;
    private final ObjectMapper lector;

    public ImportadorDatos(ZonaDao zonas, HabitatDao habitats, EspecieDao especies, ItinerarioDao itinerarios,
            UsuarioDao usuarios, AsignacionGuiaDao horarios, AsignacionCuidadoDao cuidados, PasswordEncoder codificador,
            PlatformTransactionManager tm, ObjectMapper mapper) {
        this.zonas = zonas;
        this.habitats = habitats;
        this.especies = especies;
        this.itinerarios = itinerarios;
        this.usuarios = usuarios;
        this.horarios = horarios;
        this.cuidados = cuidados;
        this.codificador = codificador;
        this.transaccion = new TransactionTemplate(tm);
        this.lector = mapper.copy().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    /** Datos leídos de los archivos (sin validar todavía). */
    private record Lote(List<ZonaJson> zonas, List<HabitatJson> habitats, List<EspecieJson> especies,
            List<ItinerarioJson> itinerarios, List<UsuarioJson> usuarios, List<AsignacionGuiaJson> horarios,
            List<AsignacionCuidadoJson> cuidados) {
    }

    public InformeImportacion importar(Path directorio) {
        InformeImportacion informe = new InformeImportacion(directorio.toAbsolutePath().toString());
        Lote lote = leer(directorio, informe);
        if (lote == null || !informe.getErrores().isEmpty()) {
            return informe;
        }
        try {
            transaccion.executeWithoutResult(estado -> {
                Validacion v = new Validacion(informe);
                v.ejecutar(lote);
                if (!informe.getErrores().isEmpty()) {
                    estado.setRollbackOnly();
                    return;
                }
                v.guardar();
            });
            if (informe.getErrores().isEmpty()) {
                informe.confirmar();
            }
        } catch (RuntimeException ex) {
            // Cualquier fallo al escribir (por ejemplo, alguien cargó el mismo dato al mismo tiempo): rollback total.
            LOG.error("La importación falló y se deshizo", ex);
            informe.error("Error al escribir en la base; se deshizo todo: " + ex.getMessage());
        }
        return informe;
    }

    /* ============================ Lectura ============================ */

    private Lote leer(Path dir, InformeImportacion informe) {
        if (!Files.isDirectory(dir)) {
            informe.error("No existe el directorio " + dir.toAbsolutePath());
            return null;
        }
        return new Lote(
                leerArchivo(dir, "zonas.json", ZonaJson.class, informe),
                leerArchivo(dir, "habitats.json", HabitatJson.class, informe),
                leerArchivo(dir, "especies.json", EspecieJson.class, informe),
                leerArchivo(dir, "itinerarios.json", ItinerarioJson.class, informe),
                leerArchivo(dir, "usuarios.json", UsuarioJson.class, informe),
                leerArchivo(dir, "asignaciones_guia.json", AsignacionGuiaJson.class, informe),
                leerArchivo(dir, "asignaciones_cuidado.json", AsignacionCuidadoJson.class, informe));
    }

    private <T> List<T> leerArchivo(Path dir, String nombre, Class<T> tipo, InformeImportacion informe) {
        Path archivo = dir.resolve(nombre);
        if (Files.notExists(archivo)) {
            informe.advertencia(nombre + " no existe: se toma como lista vacía.");
            return List.of();
        }
        try {
            if (Files.size(archivo) > TAMANIO_MAXIMO_ARCHIVO) {
                informe.error(nombre + " supera el tamaño máximo de 50 MB.");
                return List.of();
            }
            byte[] contenido = Files.readAllBytes(archivo);
            List<T> registros = lector.readValue(contenido, lector.getTypeFactory().constructCollectionType(List.class, tipo));
            if (registros == null) {
                informe.error(nombre + " está vacío o contiene null; se esperaba una lista JSON.");
                return List.of();
            }
            informe.archivo(nombre, sha256(contenido), registros.size());
            return registros;
        } catch (JsonProcessingException ex) {
            informe.error(nombre + " está dañado o no es una lista JSON válida (línea "
                    + (ex.getLocation() == null ? "?" : ex.getLocation().getLineNr()) + "): " + ex.getOriginalMessage());
        } catch (IOException ex) {
            informe.error("No se pudo leer " + nombre + ": " + ex.getMessage());
        }
        return List.of();
    }

    private static String sha256(byte[] datos) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(datos));
        } catch (NoSuchAlgorithmException ex) {
            throw new IllegalStateException(ex);
        }
    }

    /* ======================= Validación y guardado ======================= */

    /** Estado de una importación: entidades construidas en memoria, todavía sin guardar. */
    private final class Validacion {

        private final InformeImportacion informe;
        private final Map<UUID, Zona> zonasNuevas = new LinkedHashMap<>();
        private final Map<UUID, Habitat> habitatsNuevos = new LinkedHashMap<>();
        private final Map<UUID, Especie> especiesNuevas = new LinkedHashMap<>();
        private final Map<UUID, Itinerario> itinerariosNuevos = new LinkedHashMap<>();
        private final Map<UUID, Usuario> usuariosNuevos = new LinkedHashMap<>();
        private final List<AsignacionGuia> horariosNuevos = new ArrayList<>();
        private final List<AsignacionCuidado> cuidadosNuevos = new ArrayList<>();

        Validacion(InformeImportacion informe) {
            this.informe = informe;
        }

        void ejecutar(Lote lote) {
            validarZonas(lote.zonas());
            validarHabitats(lote.habitats());
            validarEspecies(lote.especies());
            validarItinerarios(lote.itinerarios());
            validarUsuarios(lote.usuarios());
            validarHorarios(lote.horarios());
            validarCuidados(lote.cuidados());
        }

        void guardar() {
            zonasNuevas.values().forEach(zonas::guardar);
            habitatsNuevos.values().forEach(habitats::guardar);
            especiesNuevas.values().forEach(especies::guardar);
            itinerariosNuevos.values().forEach(itinerarios::guardar);
            usuariosNuevos.values().forEach(usuarios::guardar);
            horariosNuevos.forEach(horarios::guardar);
            cuidadosNuevos.forEach(cuidados::guardar);
            informe.importado("zonas", zonasNuevas.size());
            informe.importado("hábitats", habitatsNuevos.size());
            informe.importado("especies", especiesNuevas.size());
            informe.importado("itinerarios", itinerariosNuevos.size());
            informe.importado("usuarios", usuariosNuevos.size());
            informe.importado("horarios de guías", horariosNuevos.size());
            informe.importado("cuidados", cuidadosNuevos.size());
        }

        private void validarZonas(List<ZonaJson> lista) {
            Set<String> nombres = new HashSet<>();
            for (int i = 0; i < lista.size(); i++) {
                ZonaJson z = lista.get(i);
                String ctx = "zonas.json[" + i + "]";
                UUID id = idNuevo(ctx, z == null ? null : z.id(), zonasNuevas, zonas::existePorId);
                if (id == null) {
                    continue;
                }
                construir(ctx, () -> new Zona(id, z.nombre(), z.extensionM2())).ifPresent(zona -> {
                    if (!nombres.add(clave(zona.getNombre())) || zonas.existeNombre(zona.getNombre(), null)) {
                        informe.error(ctx + ": la zona '" + zona.getNombre() + "' está repetida o ya existe en la base.");
                    } else {
                        zonasNuevas.put(id, zona);
                    }
                });
            }
        }

        private void validarHabitats(List<HabitatJson> lista) {
            Set<String> nombres = new HashSet<>();
            for (int i = 0; i < lista.size(); i++) {
                HabitatJson h = lista.get(i);
                String ctx = "habitats.json[" + i + "]";
                UUID id = idNuevo(ctx, h == null ? null : h.id(), habitatsNuevos, habitats::existePorId);
                if (id == null) {
                    continue;
                }
                construir(ctx, () -> new Habitat(id, h.nombre(), h.clima(), h.vegetacion(),
                        h.continentes() == null ? Set.of() : new LinkedHashSet<>(h.continentes()))).ifPresent(hab -> {
                    if (!nombres.add(clave(hab.getNombre())) || habitats.existeNombre(hab.getNombre(), null)) {
                        informe.error(ctx + ": el hábitat '" + hab.getNombre() + "' está repetido o ya existe en la base.");
                    } else {
                        habitatsNuevos.put(id, hab);
                    }
                });
            }
        }

        private void validarEspecies(List<EspecieJson> lista) {
            Set<String> nombres = new HashSet<>();
            for (int i = 0; i < lista.size(); i++) {
                EspecieJson e = lista.get(i);
                String ctx = "especies.json[" + i + "]";
                UUID id = idNuevo(ctx, e == null ? null : e.id(), especiesNuevas, especies::existePorId);
                if (id == null) {
                    continue;
                }
                Zona zona = null;
                if (e.zonaId() != null) {
                    zona = referencia(ctx, "zonaId", e.zonaId(), zonasNuevas, zonas::buscarPorId);
                    if (zona == null) {
                        continue;
                    }
                }
                List<Habitat> hs = referencias(ctx, "habitatIds", e.habitatIds(), habitatsNuevos, habitats::buscarPorId);
                if (hs == null) {
                    continue;
                }
                Zona z = zona;
                construir(ctx, () -> new Especie(id, e.nombreEspanol(), e.nombreCientifico(), e.descripcion(), z, hs))
                        .ifPresent(esp -> {
                            if (!nombres.add(clave(esp.getNombreCientifico()))
                                    || especies.existeNombreCientifico(esp.getNombreCientifico(), null)) {
                                informe.error(ctx + ": el nombre científico '" + esp.getNombreCientifico()
                                        + "' está repetido o ya existe en la base.");
                            } else {
                                especiesNuevas.put(id, esp);
                            }
                        });
            }
        }

        private void validarItinerarios(List<ItinerarioJson> lista) {
            Set<String> codigos = new HashSet<>();
            for (int i = 0; i < lista.size(); i++) {
                ItinerarioJson it = lista.get(i);
                String ctx = "itinerarios.json[" + i + "]";
                UUID id = idNuevo(ctx, it == null ? null : it.id(), itinerariosNuevos, itinerarios::existePorId);
                if (id == null) {
                    continue;
                }
                List<Especie> esp = referencias(ctx, "especieIds", it.especieIds(), especiesNuevas, especies::buscarPorId);
                if (esp == null) {
                    continue;
                }
                construir(ctx, () -> new Itinerario(id, it.codigo(), entero(it.duracionMinutos()), it.longitudKm(),
                        entero(it.maximoVisitantes()), esp)).ifPresent(nuevo -> {
                    if (!codigos.add(nuevo.getCodigo()) || itinerarios.existeCodigo(nuevo.getCodigo())) {
                        informe.error(ctx + ": el código " + nuevo.getCodigo() + " está repetido o ya existe en la base.");
                    } else {
                        itinerariosNuevos.put(id, nuevo);
                    }
                });
            }
        }

        private void validarUsuarios(List<UsuarioJson> lista) {
            Set<String> nombres = new HashSet<>();
            for (int i = 0; i < lista.size(); i++) {
                UsuarioJson u = lista.get(i);
                String ctx = "usuarios.json[" + i + "]";
                UUID id = idNuevo(ctx, u == null ? null : u.id(), usuariosNuevos, usuarios::existePorId);
                if (id == null) {
                    continue;
                }
                Rol rol;
                try {
                    rol = Rol.valueOf(String.valueOf(u.rol()));
                } catch (IllegalArgumentException ex) {
                    informe.error(ctx + ": rol inválido '" + u.rol() + "'.");
                    continue;
                }
                String hash = hashImportado(ctx, u);
                LocalDate ingreso = fecha(ctx, "fechaIngreso", u.fechaIngreso(), rol != Rol.ADMINISTRADOR);
                if (hash == null || (rol != Rol.ADMINISTRADOR && ingreso == null)) {
                    continue;
                }
                Supplier<Usuario> fabrica = () -> switch (rol) {
                    case ADMINISTRADOR -> new Administrador(id, u.nombreUsuario(), hash, u.nombre());
                    case GUIA -> new Guia(id, u.nombreUsuario(), hash, u.nombre(), u.direccion(), u.telefono(), ingreso);
                    case CUIDADOR -> new Cuidador(id, u.nombreUsuario(), hash, u.nombre(), u.direccion(), u.telefono(), ingreso);
                };
                construir(ctx, fabrica).ifPresent(usr -> {
                    if (!nombres.add(usr.getNombreUsuario()) || usuarios.existeNombreUsuario(usr.getNombreUsuario())) {
                        informe.error(ctx + ": el usuario '" + usr.getNombreUsuario() + "' está repetido o ya existe en la base.");
                    } else {
                        usuariosNuevos.put(id, usr);
                    }
                });
            }
        }

        private void validarHorarios(List<AsignacionGuiaJson> lista) {
            Map<UUID, Object> ids = new HashMap<>();
            for (int i = 0; i < lista.size(); i++) {
                AsignacionGuiaJson a = lista.get(i);
                String ctx = "asignaciones_guia.json[" + i + "]";
                UUID id = idNuevo(ctx, a == null ? null : a.id(), ids, horarios::existePorId);
                if (id == null) {
                    continue;
                }
                ids.put(id, a);
                Usuario u = referencia(ctx, "guiaId", a.guiaId(), usuariosNuevos, usuarios::buscarPorId);
                Itinerario it = referencia(ctx, "itinerarioId", a.itinerarioId(), itinerariosNuevos, itinerarios::buscarPorId);
                LocalTime hora = hora(ctx, a.hora());
                if (u == null || it == null || hora == null) {
                    continue;
                }
                if (u.getRol() != Rol.GUIA) {
                    informe.error(ctx + ": guiaId " + u.getId() + " no corresponde a un guía.");
                    continue;
                }
                Guia guia = usuariosNuevos.containsKey(u.getId()) ? (Guia) u
                        : usuarios.buscarGuia(u.getId()).orElse(null);
                if (guia == null) {
                    informe.error(ctx + ": no se encontró el guía " + u.getId() + ".");
                    continue;
                }
                construir(ctx, () -> new AsignacionGuia(id, guia, it, hora)).ifPresent(horariosNuevos::add);
            }
            verificarSuperposiciones();
        }

        /** Revisa la regla de horarios entre lo importado y lo que ya tiene cada guía en la base. */
        private void verificarSuperposiciones() {
            Map<UUID, List<AsignacionGuia>> porGuia = new HashMap<>();
            horariosNuevos.forEach(a -> porGuia.computeIfAbsent(a.getGuia().getId(), k -> new ArrayList<>()).add(a));
            porGuia.forEach((guiaId, nuevos) -> {
                List<AsignacionGuia> todos = new ArrayList<>(nuevos);
                if (!usuariosNuevos.containsKey(guiaId)) {
                    todos.addAll(horarios.buscarPorGuia(guiaId));
                }
                for (int i = 0; i < todos.size(); i++) {
                    AsignacionGuia a = todos.get(i);
                    try {
                        ReglaHorarios.finDe(a.getHora(), a.getItinerario().getDuracionMinutos());
                    } catch (ReglaNegocioException ex) {
                        informe.error("Horario " + a.getId() + ": " + ex.getMessage());
                        continue;
                    }
                    for (int j = i + 1; j < todos.size(); j++) {
                        AsignacionGuia b = todos.get(j);
                        try {
                            if (ReglaHorarios.seSuperponen(a.getHora(), a.getItinerario().getDuracionMinutos(),
                                    b.getHora(), b.getItinerario().getDuracionMinutos())) {
                                informe.error("Horarios superpuestos para el guía " + guiaId + ": " + a.getHora() + " ("
                                        + a.getItinerario().getCodigo() + ") y " + b.getHora() + " ("
                                        + b.getItinerario().getCodigo() + ").");
                            }
                        } catch (ReglaNegocioException ex) {
                            // el error de medianoche ya se informa en el ciclo externo
                        }
                    }
                }
            });
        }

        private void validarCuidados(List<AsignacionCuidadoJson> lista) {
            Map<UUID, Object> ids = new HashMap<>();
            Set<String> pares = new HashSet<>();
            for (int i = 0; i < lista.size(); i++) {
                AsignacionCuidadoJson a = lista.get(i);
                String ctx = "asignaciones_cuidado.json[" + i + "]";
                UUID id = idNuevo(ctx, a == null ? null : a.id(), ids, cuidados::existePorId);
                if (id == null) {
                    continue;
                }
                ids.put(id, a);
                Usuario u = referencia(ctx, "cuidadorId", a.cuidadorId(), usuariosNuevos, usuarios::buscarPorId);
                Especie e = referencia(ctx, "especieId", a.especieId(), especiesNuevas, especies::buscarPorId);
                LocalDate fecha = fecha(ctx, "fechaAsignacion", a.fechaAsignacion(), true);
                if (u == null || e == null || fecha == null) {
                    continue;
                }
                if (u.getRol() != Rol.CUIDADOR) {
                    informe.error(ctx + ": cuidadorId " + u.getId() + " no corresponde a un cuidador.");
                    continue;
                }
                Cuidador c = usuariosNuevos.containsKey(u.getId()) ? (Cuidador) u
                        : usuarios.buscarCuidador(u.getId()).orElse(null);
                if (c == null) {
                    informe.error(ctx + ": no se encontró el cuidador " + u.getId() + ".");
                    continue;
                }
                if (!pares.add(c.getId() + "|" + e.getId()) || cuidados.existe(c.getId(), e.getId())) {
                    informe.error(ctx + ": el cuidado " + c.getNombreUsuario() + " → " + e.getNombreEspanol()
                            + " está repetido o ya existe en la base.");
                    continue;
                }
                construir(ctx, () -> new AsignacionCuidado(id, c, e, fecha)).ifPresent(cuidadosNuevos::add);
            }
        }

        /* --------------------------- auxiliares --------------------------- */

        /** UUID válido, no repetido en el archivo y que no exista ya en la base (nunca se pisa información). */
        private UUID idNuevo(String ctx, String texto, Map<UUID, ?> yaLeidos, Function<UUID, Boolean> existeEnBase) {
            if (texto == null) {
                informe.error(ctx + ": registro vacío o sin id.");
                return null;
            }
            UUID id;
            try {
                id = UUID.fromString(texto.strip());
            } catch (IllegalArgumentException ex) {
                informe.error(ctx + ": id '" + texto + "' no es un UUID válido.");
                return null;
            }
            if (yaLeidos.containsKey(id)) {
                informe.error(ctx + ": el id " + id + " está repetido en el archivo.");
                return null;
            }
            if (existeEnBase.apply(id)) {
                informe.error(ctx + ": el id " + id + " ya existe en la base; no se sobrescriben datos existentes.");
                return null;
            }
            return id;
        }

        private <T> T referencia(String ctx, String campo, String texto, Map<UUID, T> nuevos,
                Function<UUID, Optional<T>> enBase) {
            UUID id;
            try {
                id = UUID.fromString(String.valueOf(texto).strip());
            } catch (IllegalArgumentException ex) {
                informe.error(ctx + ": " + campo + " '" + texto + "' no es un UUID válido.");
                return null;
            }
            T encontrado = nuevos.containsKey(id) ? nuevos.get(id) : enBase.apply(id).orElse(null);
            if (encontrado == null) {
                informe.error(ctx + ": " + campo + " " + id + " no existe ni en los archivos ni en la base.");
            }
            return encontrado;
        }

        private <T> List<T> referencias(String ctx, String campo, List<String> textos, Map<UUID, T> nuevos,
                Function<UUID, Optional<T>> enBase) {
            List<T> resultado = new ArrayList<>();
            for (String t : textos == null ? List.<String>of() : textos) {
                T r = referencia(ctx, campo, t, nuevos, enBase);
                if (r == null) {
                    return null;
                }
                resultado.add(r);
            }
            return resultado;
        }

        /** Construye la entidad; si su constructor rechaza un dato, se informa con el contexto. */
        private <T> Optional<T> construir(String ctx, Supplier<T> constructor) {
            try {
                return Optional.of(constructor.get());
            } catch (DatoInvalidoException | ReglaNegocioException ex) {
                informe.error(ctx + ": " + ex.getMessage());
                return Optional.empty();
            } catch (RuntimeException ex) {
                informe.error(ctx + ": dato inválido (" + ex.getMessage() + ").");
                return Optional.empty();
            }
        }

        private String hashImportado(String ctx, UsuarioJson u) {
            String h = u.hashContrasena();
            if (h != null && h.startsWith("pbkdf2$")) {
                return "{" + Pbkdf2LegadoPasswordEncoder.ID + "}" + h;
            }
            if (h != null && h.startsWith("{bcrypt}")) {
                return h;
            }
            if (h != null && !h.isBlank()) {
                informe.error(ctx + ": formato de hashContrasena desconocido; no se puede importar con seguridad.");
                return null;
            }
            // Sin contraseña (datos de la v1): se asigna una aleatoria que nadie conoce.
            informe.advertencia(ctx + ": '" + u.nombreUsuario()
                    + "' no tenía contraseña; quedó bloqueado hasta que el administrador le asigne una.");
            byte[] secreto = new byte[32];
            new SecureRandom().nextBytes(secreto);
            return codificador.encode(Base64.getEncoder().encodeToString(secreto));
        }

        private LocalDate fecha(String ctx, String campo, String texto, boolean obligatoria) {
            if (texto == null || texto.isBlank()) {
                if (obligatoria) {
                    informe.error(ctx + ": falta " + campo + ".");
                }
                return null;
            }
            try {
                return LocalDate.parse(texto.strip());
            } catch (DateTimeParseException ex) {
                informe.error(ctx + ": " + campo + " '" + texto + "' no tiene el formato AAAA-MM-DD.");
                return null;
            }
        }

        private LocalTime hora(String ctx, String texto) {
            try {
                return LocalTime.parse(String.valueOf(texto).strip());
            } catch (DateTimeParseException ex) {
                informe.error(ctx + ": hora '" + texto + "' no tiene el formato HH:MM.");
                return null;
            }
        }

        private int entero(Integer valor) {
            return valor == null ? -1 : valor;
        }

        private String clave(String texto) {
            return texto.strip().toLowerCase();
        }
    }
}
