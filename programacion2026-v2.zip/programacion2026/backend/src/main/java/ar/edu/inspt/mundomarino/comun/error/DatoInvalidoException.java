package ar.edu.inspt.mundomarino.comun.error;

/** Un dato de entrada es incorrecto (referencia inexistente, valor fuera de rango) → HTTP 400. */
public class DatoInvalidoException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final String campo;

    public DatoInvalidoException(String campo, String mensaje) {
        super(mensaje);
        this.campo = campo;
    }

    public String getCampo() {
        return campo;
    }
}
