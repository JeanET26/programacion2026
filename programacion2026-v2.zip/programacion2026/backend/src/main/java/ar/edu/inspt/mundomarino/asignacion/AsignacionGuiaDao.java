package ar.edu.inspt.mundomarino.asignacion;

import ar.edu.inspt.mundomarino.comun.dao.Dao;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

/** Contrato DAO de horarios de guías. */
public interface AsignacionGuiaDao extends Dao<AsignacionGuia, UUID> {

    /** Horarios de un guía con su itinerario ya cargado (una consulta). */
    List<AsignacionGuia> buscarPorGuia(UUID guiaId);

    /** Horarios de varios guías con sus itinerarios (una consulta). */
    List<AsignacionGuia> buscarPorGuias(Collection<UUID> guiaIds);

    List<AsignacionGuia> buscarPorItinerario(UUID itinerarioId);

    Pagina<AsignacionGuia> buscar(UUID guiaId, UUID itinerarioId, SolicitudPagina solicitud);
}
