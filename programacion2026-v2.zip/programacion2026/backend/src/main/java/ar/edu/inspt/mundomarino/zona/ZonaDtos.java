package ar.edu.inspt.mundomarino.zona;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.UUID;

/** DTO de entrada y salida de zonas. Las entidades JPA nunca salen del servicio. */
public final class ZonaDtos {

    private ZonaDtos() {
    }

    /** Lo que envía el formulario. {@code version} solo se usa al modificar. */
    public record ZonaSolicitud(
            @NotBlank(message = "El nombre es obligatorio.") @Size(max = 80, message = "Máximo 80 caracteres.") String nombre,
            @NotNull(message = "La extensión es obligatoria.")
            @DecimalMin(value = "0.01", message = "La extensión debe ser mayor que 0.")
            @DecimalMax(value = "99999999.99", message = "La extensión es demasiado grande.")
            @Digits(integer = 8, fraction = 2, message = "Hasta 2 decimales.") BigDecimal extensionM2,
            Long version) {
    }

    public record ZonaRespuesta(UUID id, String nombre, BigDecimal extensionM2, long cantidadEspecies, Long version) {
    }
}
