package ar.edu.inspt.mundomarino.personal;

/**
 * <b>Puerto</b>: el módulo personal necesita cerrar las sesiones de un usuario
 * (al cambiar o restablecer su contraseña, o al eliminarlo), pero las sesiones
 * son un detalle de seguridad. El módulo seguridad implementa esta interfaz;
 * así personal no depende de seguridad y no hay ciclo entre módulos.
 */
public interface CierreSesiones {

    /**
     * Cierra todas las sesiones del usuario, salvo la indicada (puede ser null).
     * Se ejecuta DESPUÉS de confirmar la transacción: si la operación se
     * deshace, las sesiones siguen abiertas.
     */
    void cerrarSesionesDe(String nombreUsuario, String excepto);
}
