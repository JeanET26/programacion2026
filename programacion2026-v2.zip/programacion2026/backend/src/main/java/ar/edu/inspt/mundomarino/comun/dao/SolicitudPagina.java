package ar.edu.inspt.mundomarino.comun.dao;

import java.util.Set;

/**
 * Qué página se pide: número (desde 0), tamaño, campo de orden y dirección.
 * Es nuestra (no de Spring Data) para que los servicios no dependan de él.
 */
public record SolicitudPagina(int numero, int tamanio, String ordenarPor, boolean ascendente) {

    public static final int TAMANIO_MAXIMO = 100;

    public SolicitudPagina {
        if (numero < 0) {
            numero = 0;
        }
        if (tamanio < 1 || tamanio > TAMANIO_MAXIMO) {
            tamanio = Math.min(Math.max(tamanio, 1), TAMANIO_MAXIMO);
        }
    }

    /** Devuelve una copia con un campo de orden válido (evita ordenar por columnas arbitrarias). */
    public SolicitudPagina conOrdenPermitido(Set<String> permitidos, String porDefecto) {
        String campo = ordenarPor != null && permitidos.contains(ordenarPor) ? ordenarPor : porDefecto;
        return new SolicitudPagina(numero, tamanio, campo, ascendente);
    }
}
