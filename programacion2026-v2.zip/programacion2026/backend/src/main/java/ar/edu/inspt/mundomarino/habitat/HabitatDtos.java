package ar.edu.inspt.mundomarino.habitat;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import java.util.List;
import java.util.UUID;

public final class HabitatDtos {

    private HabitatDtos() {
    }

    public record HabitatSolicitud(
            @NotBlank(message = "El nombre es obligatorio.") @Size(max = 80) String nombre,
            @NotBlank(message = "El clima es obligatorio.") @Size(max = 80) String clima,
            @NotBlank(message = "La vegetación es obligatoria.") @Size(max = 120) String vegetacion,
            @NotEmpty(message = "Indicá al menos un continente.") @Size(max = 10)
            List<@NotBlank @Size(max = 30) String> continentes,
            Long version) {

        /** Copia defensiva: un record no copia sus listas por sí solo. */
        public HabitatSolicitud {
            continentes = continentes == null ? null : List.copyOf(continentes);
        }
    }

    public record HabitatRespuesta(UUID id, String nombre, String clima, String vegetacion, List<String> continentes,
            Long version) {

        public HabitatRespuesta {
            continentes = List.copyOf(continentes);
        }
    }
}
