package ar.edu.inspt.mundomarino.especie;

import jakarta.persistence.LockModeType;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

interface EspecieRepositorio extends JpaRepository<Especie, UUID> {

    boolean existsByNombreCientificoIgnoreCase(String nombreCientifico);

    boolean existsByNombreCientificoIgnoreCaseAndIdNot(String nombreCientifico, UUID id);

    /** {@code @EntityGraph} trae la zona en el mismo SELECT (JOIN): evita una consulta por fila. */
    @EntityGraph(attributePaths = "zona")
    @Query(value = """
            select e from Especie e
            where (:patron is null or lower(e.nombreEspanol) like :patron or lower(e.nombreCientifico) like :patron)
              and (:zonaId is null or e.zona.id = :zonaId)
            """,
            countQuery = """
            select count(e) from Especie e
            where (:patron is null or lower(e.nombreEspanol) like :patron or lower(e.nombreCientifico) like :patron)
              and (:zonaId is null or e.zona.id = :zonaId)
            """)
    Page<Especie> buscar(@Param("patron") String patron, @Param("zonaId") UUID zonaId, Pageable pageable);

    @EntityGraph(attributePaths = "zona")
    List<Especie> findTop1000ByOrderByNombreEspanolAsc();

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select e from Especie e where e.id = :id")
    Optional<Especie> buscarConBloqueoEscritura(@Param("id") UUID id);

    @Lock(LockModeType.PESSIMISTIC_READ)
    @Query("select e from Especie e where e.id in :ids order by e.id")
    List<Especie> buscarConBloqueoLectura(@Param("ids") Collection<UUID> ids);

    /** SQL nativo sobre la tabla intermedia: este módulo no depende del módulo itinerario. */
    @Query(value = "select exists(select 1 from itinerario_especie where especie_id = :id)", nativeQuery = true)
    long estaEnItinerario(@Param("id") String especieId);
}
