package ar.edu.inspt.mundomarino.especie;

import ar.edu.inspt.mundomarino.comun.dao.DaoJpa;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.stereotype.Repository;

@Repository
class EspecieDaoJpa extends DaoJpa<Especie, UUID> implements EspecieDao {

    private final EspecieRepositorio repositorio;

    EspecieDaoJpa(EspecieRepositorio repositorio) {
        super(repositorio);
        this.repositorio = repositorio;
    }

    @Override
    public boolean existeNombreCientifico(String nombreCientifico, UUID excluirId) {
        String n = nombreCientifico == null ? "" : nombreCientifico.strip();
        return excluirId == null ? repositorio.existsByNombreCientificoIgnoreCase(n)
                : repositorio.existsByNombreCientificoIgnoreCaseAndIdNot(n, excluirId);
    }

    @Override
    public Pagina<Especie> buscar(String texto, UUID zonaId, SolicitudPagina solicitud) {
        return aPagina(repositorio.buscar(patronBusqueda(texto), zonaId, aPageable(solicitud)));
    }

    @Override
    public List<Especie> opciones() {
        return repositorio.findTop1000ByOrderByNombreEspanolAsc();
    }

    @Override
    public Optional<Especie> buscarParaModificar(UUID id) {
        return repositorio.buscarConBloqueoEscritura(id);
    }

    @Override
    public List<Especie> buscarConBloqueoCompartido(Collection<UUID> ids) {
        return ids.isEmpty() ? List.of() : repositorio.buscarConBloqueoLectura(ids);
    }

    @Override
    public boolean estaEnAlgunItinerario(UUID especieId) {
        return repositorio.estaEnItinerario(especieId.toString()) != 0;
    }
}
