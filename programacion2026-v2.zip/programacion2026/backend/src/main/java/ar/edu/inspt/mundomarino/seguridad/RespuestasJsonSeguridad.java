package ar.edu.inspt.mundomarino.seguridad;

import ar.edu.inspt.mundomarino.comun.error.ApiError;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.Instant;
import org.springframework.http.MediaType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.csrf.CsrfException;
import org.springframework.stereotype.Component;

/**
 * Respuestas JSON para los errores que corta Spring Security antes de llegar
 * a los controladores: 401 (sin sesión) y 403 (sin permiso o sin token CSRF).
 * Sin esto, Spring respondería con una redirección a un formulario HTML.
 */
@Component
class RespuestasJsonSeguridad implements AuthenticationEntryPoint, AccessDeniedHandler {

    private final ObjectMapper json;

    RespuestasJsonSeguridad(ObjectMapper json) {
        this.json = json;
    }

    @Override
    public void commence(HttpServletRequest req, HttpServletResponse res, AuthenticationException ex) throws IOException {
        escribir(req, res, 401, "Tenés que iniciar sesión.");
    }

    @Override
    public void handle(HttpServletRequest req, HttpServletResponse res, AccessDeniedException ex) throws IOException {
        String mensaje = ex instanceof CsrfException
                ? "Falta o venció el token de seguridad (CSRF). Recargá la página."
                : "No tenés permiso para realizar esta operación.";
        escribir(req, res, 403, mensaje);
    }

    private void escribir(HttpServletRequest req, HttpServletResponse res, int estado, String mensaje) throws IOException {
        res.setStatus(estado);
        res.setContentType(MediaType.APPLICATION_JSON_VALUE);
        res.setCharacterEncoding("UTF-8");
        json.writeValue(res.getOutputStream(), new ApiError(estado, mensaje, null, req.getRequestURI(), Instant.now()));
    }
}
