package ar.edu.inspt.mundomarino.asignacion;

import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.CuidadoAlta;
import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.CuidadoCambio;
import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.CuidadoRespuesta;
import ar.edu.inspt.mundomarino.comun.dao.ControlVersion;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import ar.edu.inspt.mundomarino.comun.error.DatoInvalidoException;
import ar.edu.inspt.mundomarino.comun.error.RecursoNoEncontradoException;
import ar.edu.inspt.mundomarino.comun.error.ReglaNegocioException;
import ar.edu.inspt.mundomarino.especie.Especie;
import ar.edu.inspt.mundomarino.especie.EspecieDao;
import ar.edu.inspt.mundomarino.personal.Cuidador;
import ar.edu.inspt.mundomarino.personal.UsuarioDao;
import ar.edu.inspt.mundomarino.zona.Zona;
import java.util.Set;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Cuidados. La duplicación cuidador+especie la controla el servicio (mensaje
 * claro) y la garantiza la restricción única de la base (dos altas simultáneas).
 */
@Service
@Transactional
public class AsignacionCuidadoService {

    private static final Set<String> ORDENES = Set.of("fechaAsignacion", "cuidador.nombre", "especie.nombreEspanol");

    private final AsignacionCuidadoDao asignaciones;
    private final UsuarioDao usuarios;
    private final EspecieDao especies;

    public AsignacionCuidadoService(AsignacionCuidadoDao asignaciones, UsuarioDao usuarios, EspecieDao especies) {
        this.asignaciones = asignaciones;
        this.usuarios = usuarios;
        this.especies = especies;
    }

    @Transactional(readOnly = true)
    public Pagina<CuidadoRespuesta> listar(UUID cuidadorId, UUID especieId, SolicitudPagina solicitud) {
        return asignaciones.buscar(cuidadorId, especieId, solicitud.conOrdenPermitido(ORDENES, "cuidador.nombre"))
                .map(AsignacionCuidadoService::aRespuesta);
    }

    public CuidadoRespuesta asignar(CuidadoAlta alta) {
        Cuidador cuidador = usuarios.buscarCuidador(alta.cuidadorId())
                .orElseThrow(() -> new DatoInvalidoException("cuidadorId", "El cuidador elegido no existe."));
        Especie especie = especies.buscarPorId(alta.especieId())
                .orElseThrow(() -> new DatoInvalidoException("especieId", "La especie elegida no existe."));
        if (asignaciones.existe(cuidador.getId(), especie.getId())) {
            throw new ReglaNegocioException("Ese cuidador ya está a cargo de esa especie.");
        }
        return aRespuesta(asignaciones.guardar(
                new AsignacionCuidado(UUID.randomUUID(), cuidador, especie, alta.fechaAsignacion())));
    }

    public CuidadoRespuesta cambiarFecha(UUID id, CuidadoCambio cambio) {
        AsignacionCuidado a = buscar(id);
        ControlVersion.verificar(a.getVersion(), cambio.version());
        a.cambiarFecha(cambio.fechaAsignacion());
        return aRespuesta(asignaciones.guardar(a));
    }

    public void eliminar(UUID id) {
        asignaciones.eliminar(buscar(id));
    }

    private AsignacionCuidado buscar(UUID id) {
        return asignaciones.buscarPorId(id).orElseThrow(() -> new RecursoNoEncontradoException("La asignación no existe."));
    }

    static CuidadoRespuesta aRespuesta(AsignacionCuidado a) {
        Especie e = a.getEspecie();
        return new CuidadoRespuesta(a.getId(), a.getCuidador().getId(), a.getCuidador().getNombre(), e.getId(),
                e.getNombreEspanol(), e.getZona().map(Zona::getNombre).orElse(null), a.getFechaAsignacion(),
                a.getVersion());
    }
}
