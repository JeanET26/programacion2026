package ar.edu.inspt.mundomarino.asignacion;

import ar.edu.inspt.mundomarino.comun.dao.EntidadConId;
import ar.edu.inspt.mundomarino.comun.dao.Validaciones;
import ar.edu.inspt.mundomarino.comun.error.DatoInvalidoException;
import ar.edu.inspt.mundomarino.especie.Especie;
import ar.edu.inspt.mundomarino.personal.Cuidador;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.util.UUID;

/** Un cuidador está a cargo de una especie desde una fecha (tabla {@code asignacion_cuidado}). */
@Entity
@Table(name = "asignacion_cuidado")
public class AsignacionCuidado extends EntidadConId {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "cuidador_id", nullable = false, updatable = false)
    private Cuidador cuidador;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "especie_id", nullable = false, updatable = false)
    private Especie especie;

    @Column(name = "fecha_asignacion", nullable = false)
    private LocalDate fechaAsignacion;

    protected AsignacionCuidado() {
    }

    public AsignacionCuidado(UUID id, Cuidador cuidador, Especie especie, LocalDate fecha) {
        super(id);
        this.cuidador = Validaciones.obligatorio(cuidador, "cuidadorId");
        this.especie = Validaciones.obligatorio(especie, "especieId");
        this.fechaAsignacion = validarFecha(fecha);
    }

    public void cambiarFecha(LocalDate fecha) {
        this.fechaAsignacion = validarFecha(fecha);
    }

    private static LocalDate validarFecha(LocalDate fecha) {
        LocalDate f = Validaciones.obligatorio(fecha, "fechaAsignacion");
        if (f.isBefore(LocalDate.of(1950, 1, 1)) || f.isAfter(LocalDate.now().plusYears(1))) {
            throw new DatoInvalidoException("fechaAsignacion", "La fecha debe estar entre 1950 y un año desde hoy.");
        }
        return f;
    }

    public Cuidador getCuidador() {
        return cuidador;
    }

    public Especie getEspecie() {
        return especie;
    }

    public LocalDate getFechaAsignacion() {
        return fechaAsignacion;
    }
}
