package ar.edu.inspt.mundomarino.personal;

/**
 * Acciones protegidas. Cada tipo de usuario declara las suyas
 * ({@link Usuario#getPermisos()}) y Spring Security las usa como
 * "authorities" para autorizar cada ruta (ver SeguridadConfig).
 */
public enum Permiso {
    /** Gestionar zonas, hábitats, especies, itinerarios, personal y asignaciones. */
    ADMINISTRAR_PARQUE,
    /** Ver el propio perfil y cambiar la propia contraseña. */
    VER_PERFIL_PROPIO,
    /** Ver los recorridos y horarios propios (guías). */
    VER_RECORRIDOS_PROPIOS,
    /** Ver las especies a cargo (cuidadores). */
    VER_ESPECIES_PROPIAS
}
