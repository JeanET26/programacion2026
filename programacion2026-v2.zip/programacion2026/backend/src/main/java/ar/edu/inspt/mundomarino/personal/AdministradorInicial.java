package ar.edu.inspt.mundomarino.personal;

import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Crea el primer administrador si todavía no existe ninguno y se configuraron
 * las variables {@code MM_ADMIN_USUARIO} / {@code MM_ADMIN_CONTRASENA}.
 * Sin esas variables no hace nada (en desarrollo lo crean los datos de demostración).
 */
@Component
@Order(1)
class AdministradorInicial implements ApplicationRunner {

    private static final Logger LOG = LoggerFactory.getLogger(AdministradorInicial.class);

    private final UsuarioDao usuarios;
    private final PasswordEncoder codificador;
    private final String usuario;
    private final String contrasena;
    private final String nombre;

    AdministradorInicial(UsuarioDao usuarios, PasswordEncoder codificador,
            @Value("${app.admin-inicial.usuario:}") String usuario,
            @Value("${app.admin-inicial.contrasena:}") String contrasena,
            @Value("${app.admin-inicial.nombre:Administración}") String nombre) {
        this.usuarios = usuarios;
        this.codificador = codificador;
        this.usuario = usuario;
        this.contrasena = contrasena;
        this.nombre = nombre;
    }

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        if (usuario.isBlank() || contrasena.isBlank() || usuarios.existeAdministrador()) {
            return;
        }
        PoliticaContrasena.validar("MM_ADMIN_CONTRASENA", contrasena);
        usuarios.guardar(new Administrador(UUID.randomUUID(), usuario, codificador.encode(contrasena), nombre));
        LOG.info("Se creó el administrador inicial '{}'.", usuario);
    }
}
