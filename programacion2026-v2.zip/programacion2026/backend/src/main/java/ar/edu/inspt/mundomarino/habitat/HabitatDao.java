package ar.edu.inspt.mundomarino.habitat;

import ar.edu.inspt.mundomarino.comun.dao.Dao;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

/** Contrato DAO de hábitats. */
public interface HabitatDao extends Dao<Habitat, UUID> {

    boolean existeNombre(String nombre, UUID excluirId);

    Pagina<Habitat> buscar(String texto, SolicitudPagina solicitud);

    List<Habitat> opciones();

    /** Busca varios por id en una sola consulta (para validar referencias). */
    List<Habitat> buscarPorIds(Collection<UUID> ids);
}
