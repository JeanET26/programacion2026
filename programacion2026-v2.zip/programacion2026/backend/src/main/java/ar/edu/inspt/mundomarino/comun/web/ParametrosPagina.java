package ar.edu.inspt.mundomarino.comun.web;

import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;

/**
 * Parámetros de consulta comunes a los listados: {@code ?pagina=0&tamanio=20&orden=nombre&dir=asc&q=texto}.
 * Spring los completa automáticamente desde la URL (sin @RequestBody).
 */
public record ParametrosPagina(Integer pagina, Integer tamanio, String orden, String dir, String q) {

    public SolicitudPagina aSolicitud() {
        return new SolicitudPagina(pagina == null ? 0 : pagina, tamanio == null ? 20 : tamanio, orden,
                !"desc".equalsIgnoreCase(dir));
    }

    public String texto() {
        return q == null || q.isBlank() ? null : q.strip();
    }
}
