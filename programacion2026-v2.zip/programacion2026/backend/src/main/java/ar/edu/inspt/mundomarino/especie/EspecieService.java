package ar.edu.inspt.mundomarino.especie;

import ar.edu.inspt.mundomarino.comun.dao.ControlVersion;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import ar.edu.inspt.mundomarino.comun.error.DatoInvalidoException;
import ar.edu.inspt.mundomarino.comun.error.RecursoNoEncontradoException;
import ar.edu.inspt.mundomarino.comun.error.ReglaNegocioException;
import ar.edu.inspt.mundomarino.comun.web.Opcion;
import ar.edu.inspt.mundomarino.especie.EspecieDtos.EspecieRespuesta;
import ar.edu.inspt.mundomarino.especie.EspecieDtos.EspecieSolicitud;
import ar.edu.inspt.mundomarino.habitat.Habitat;
import ar.edu.inspt.mundomarino.habitat.HabitatDao;
import ar.edu.inspt.mundomarino.zona.Zona;
import ar.edu.inspt.mundomarino.zona.ZonaDao;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

/** Reglas de negocio de las especies. */
@Service
@Transactional
public class EspecieService {

    private static final Set<String> ORDENES = Set.of("nombreEspanol", "nombreCientifico");

    private final EspecieDao especies;
    private final ZonaDao zonas;
    private final HabitatDao habitats;

    public EspecieService(EspecieDao especies, ZonaDao zonas, HabitatDao habitats) {
        this.especies = especies;
        this.zonas = zonas;
        this.habitats = habitats;
    }

    @Transactional(readOnly = true)
    public Pagina<EspecieRespuesta> listar(String texto, UUID zonaId, SolicitudPagina solicitud) {
        return especies.buscar(texto, zonaId, solicitud.conOrdenPermitido(ORDENES, "nombreEspanol"))
                .map(EspecieService::aRespuesta);
    }

    @Transactional(readOnly = true)
    public EspecieRespuesta obtener(UUID id) {
        return aRespuesta(buscar(id));
    }

    /** Opciones para formularios; indica la zona porque solo las ubicadas pueden ir a un itinerario. */
    @Transactional(readOnly = true)
    public List<Opcion> opciones() {
        return especies.opciones().stream()
                .map(e -> new Opcion(e.getId(), e.getNombreEspanol() + " · " + e.getZona().map(Zona::getNombre).orElse("sin zona")))
                .toList();
    }

    public EspecieRespuesta crear(EspecieSolicitud s) {
        if (especies.existeNombreCientifico(s.nombreCientifico(), null)) {
            throw new ReglaNegocioException("Ya existe una especie con ese nombre científico.");
        }
        Especie e = new Especie(UUID.randomUUID(), s.nombreEspanol(), s.nombreCientifico(), s.descripcion(),
                zonaElegida(s.zonaId()), habitatsElegidos(s.habitatIds()));
        return aRespuesta(especies.guardar(e));
    }

    /**
     * Se bloquea la fila de la especie (FOR UPDATE) antes de comprobar si está
     * en un itinerario. Así, si al mismo tiempo alguien arma un itinerario con
     * ella (que la bloquea en modo compartido), una de las dos operaciones
     * espera a la otra y la regla "toda especie de un itinerario tiene zona"
     * no se puede romper. READ_COMMITTED hace que, después de esperar, la
     * consulta vea lo que confirmó la otra transacción.
     */
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public EspecieRespuesta actualizar(UUID id, EspecieSolicitud s) {
        Especie e = especies.buscarParaModificar(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("La especie no existe."));
        ControlVersion.verificar(e.getVersion(), s.version());
        if (especies.existeNombreCientifico(s.nombreCientifico(), id)) {
            throw new ReglaNegocioException("Ya existe una especie con ese nombre científico.");
        }
        if (s.zonaId() == null && especies.estaEnAlgunItinerario(id)) {
            throw new ReglaNegocioException("La especie forma parte de un itinerario: debe seguir ubicada en una zona.");
        }
        e.actualizar(s.nombreEspanol(), s.nombreCientifico(), s.descripcion(), zonaElegida(s.zonaId()),
                habitatsElegidos(s.habitatIds()));
        return aRespuesta(especies.guardar(e));
    }

    /** Si está en un itinerario o tiene cuidadores, las claves foráneas lo impiden (409). */
    public void eliminar(UUID id) {
        especies.eliminar(buscar(id));
    }

    private Especie buscar(UUID id) {
        return especies.buscarPorId(id).orElseThrow(() -> new RecursoNoEncontradoException("La especie no existe."));
    }

    private Zona zonaElegida(UUID zonaId) {
        if (zonaId == null) {
            return null;
        }
        return zonas.buscarPorId(zonaId).orElseThrow(() -> new DatoInvalidoException("zonaId", "La zona elegida no existe."));
    }

    private Set<Habitat> habitatsElegidos(List<UUID> ids) {
        Set<UUID> pedidos = new LinkedHashSet<>(ids);
        List<Habitat> encontrados = habitats.buscarPorIds(pedidos);
        if (encontrados.size() != pedidos.size()) {
            throw new DatoInvalidoException("habitatIds", "Alguno de los hábitats elegidos no existe.");
        }
        return new LinkedHashSet<>(encontrados);
    }

    static EspecieRespuesta aRespuesta(Especie e) {
        List<Opcion> hs = e.getHabitats().stream()
                .sorted(Comparator.comparing(Habitat::getNombre))
                .map(h -> new Opcion(h.getId(), h.getNombre())).toList();
        return new EspecieRespuesta(e.getId(), e.getNombreEspanol(), e.getNombreCientifico(), e.getDescripcion(),
                e.getZona().map(Zona::getId).orElse(null), e.getZona().map(Zona::getNombre).orElse(null), hs,
                e.getVersion());
    }
}
