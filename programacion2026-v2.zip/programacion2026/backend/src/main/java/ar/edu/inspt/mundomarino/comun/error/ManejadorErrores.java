package ar.edu.inspt.mundomarino.comun.error;

import jakarta.persistence.OptimisticLockException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolationException;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.dao.PessimisticLockingFailureException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

/**
 * Manejo centralizado de errores: convierte cada excepción en un código HTTP
 * coherente y en un {@link ApiError}. Los controladores no tienen try/catch.
 * Los errores inesperados se registran en el log con un código que también
 * recibe el usuario, sin exponerle detalles internos.
 */
@RestControllerAdvice
public class ManejadorErrores {

    private static final Logger LOG = LoggerFactory.getLogger(ManejadorErrores.class);

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiError> validacion(MethodArgumentNotValidException ex, HttpServletRequest req) {
        Map<String, String> errores = new LinkedHashMap<>();
        for (FieldError fe : ex.getBindingResult().getFieldErrors()) {
            errores.putIfAbsent(fe.getField(), fe.getDefaultMessage());
        }
        ex.getBindingResult().getGlobalErrors().forEach(ge -> errores.putIfAbsent(ge.getObjectName(), ge.getDefaultMessage()));
        return responder(HttpStatus.BAD_REQUEST, "Revisá los datos ingresados.", errores, req);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ApiError> validacionParametros(ConstraintViolationException ex, HttpServletRequest req) {
        Map<String, String> errores = new LinkedHashMap<>();
        ex.getConstraintViolations().forEach(v -> errores.putIfAbsent(v.getPropertyPath().toString(), v.getMessage()));
        return responder(HttpStatus.BAD_REQUEST, "Revisá los datos ingresados.", errores, req);
    }

    @ExceptionHandler(DatoInvalidoException.class)
    public ResponseEntity<ApiError> datoInvalido(DatoInvalidoException ex, HttpServletRequest req) {
        Map<String, String> errores = ex.getCampo() == null ? Map.of() : Map.of(ex.getCampo(), ex.getMessage());
        return responder(HttpStatus.BAD_REQUEST, ex.getMessage(), errores, req);
    }

    @ExceptionHandler({HttpMessageNotReadableException.class, MethodArgumentTypeMismatchException.class})
    public ResponseEntity<ApiError> formato(Exception ex, HttpServletRequest req) {
        return responder(HttpStatus.BAD_REQUEST, "El formato de la petición no es válido.", null, req);
    }

    @ExceptionHandler(RecursoNoEncontradoException.class)
    public ResponseEntity<ApiError> noEncontrado(RecursoNoEncontradoException ex, HttpServletRequest req) {
        return responder(HttpStatus.NOT_FOUND, ex.getMessage(), null, req);
    }

    @ExceptionHandler(NoResourceFoundException.class)
    public ResponseEntity<ApiError> rutaInexistente(NoResourceFoundException ex, HttpServletRequest req) {
        return responder(HttpStatus.NOT_FOUND, "Ruta inexistente.", null, req);
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ApiError> metodo(HttpRequestMethodNotSupportedException ex, HttpServletRequest req) {
        return responder(HttpStatus.METHOD_NOT_ALLOWED, "Método no permitido.", null, req);
    }

    @ExceptionHandler(ReglaNegocioException.class)
    public ResponseEntity<ApiError> reglaNegocio(ReglaNegocioException ex, HttpServletRequest req) {
        return responder(HttpStatus.CONFLICT, ex.getMessage(), null, req);
    }

    /** La base rechazó la operación (unicidad o clave foránea): puede pasar con pedidos simultáneos. */
    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<ApiError> integridad(DataIntegrityViolationException ex, HttpServletRequest req) {
        String detalle = ex.getMostSpecificCause().getMessage();
        LOG.info("Restricción de la base en {}: {}", req.getRequestURI(), detalle);
        return responder(HttpStatus.CONFLICT, TraductorRestricciones.traducir(detalle), null, req);
    }

    /** Otro usuario modificó el registro entre que lo leímos y lo guardamos (@Version). */
    @ExceptionHandler({OptimisticLockingFailureException.class, OptimisticLockException.class})
    public ResponseEntity<ApiError> optimista(Exception ex, HttpServletRequest req) {
        return responder(HttpStatus.CONFLICT,
                "Otra persona modificó este registro mientras lo editabas. Recargá los datos y volvé a intentar.", null, req);
    }

    /** No se obtuvo un bloqueo a tiempo o la base detectó un interbloqueo. */
    @ExceptionHandler(PessimisticLockingFailureException.class)
    public ResponseEntity<ApiError> bloqueo(PessimisticLockingFailureException ex, HttpServletRequest req) {
        LOG.warn("Conflicto de bloqueo en {}: {}", req.getRequestURI(), ex.getMessage());
        return responder(HttpStatus.CONFLICT, "Hay otra operación en curso sobre los mismos datos. Intentá de nuevo.", null, req);
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ApiError> accesoDenegado(AccessDeniedException ex, HttpServletRequest req) {
        return responder(HttpStatus.FORBIDDEN, "No tenés permiso para realizar esta operación.", null, req);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiError> inesperado(Exception ex, HttpServletRequest req) {
        String codigo = UUID.randomUUID().toString().substring(0, 8);
        LOG.error("Error inesperado [{}] en {} {}", codigo, req.getMethod(), req.getRequestURI(), ex);
        return responder(HttpStatus.INTERNAL_SERVER_ERROR,
                "Ocurrió un error interno (código " + codigo + "). Intentá de nuevo.", null, req);
    }

    private static ResponseEntity<ApiError> responder(HttpStatus estado, String mensaje, Map<String, String> errores,
            HttpServletRequest req) {
        return ResponseEntity.status(estado)
                .body(new ApiError(estado.value(), mensaje, errores, req.getRequestURI(), Instant.now()));
    }
}
