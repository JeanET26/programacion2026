package ar.edu.inspt.mundomarino.itinerario;

import ar.edu.inspt.mundomarino.comun.dao.DaoJpa;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.stereotype.Repository;

@Repository
class ItinerarioDaoJpa extends DaoJpa<Itinerario, UUID> implements ItinerarioDao {

    private final ItinerarioRepositorio repositorio;

    ItinerarioDaoJpa(ItinerarioRepositorio repositorio) {
        super(repositorio);
        this.repositorio = repositorio;
    }

    @Override
    public boolean existeCodigo(String codigo) {
        return repositorio.existsByCodigo(codigo);
    }

    @Override
    public Pagina<Itinerario> buscar(String texto, SolicitudPagina solicitud) {
        return aPagina(repositorio.buscar(patronBusqueda(texto), aPageable(solicitud)));
    }

    @Override
    public List<Itinerario> opciones() {
        return repositorio.findTop500ByOrderByCodigoAsc();
    }

    @Override
    public Optional<Itinerario> buscarParaModificar(UUID id) {
        return repositorio.buscarConBloqueoEscritura(id);
    }

    @Override
    public Optional<Itinerario> buscarConBloqueoCompartido(UUID id) {
        return repositorio.buscarConBloqueoLectura(id);
    }
}
