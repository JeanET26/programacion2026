package ar.edu.inspt.mundomarino.personal;

import jakarta.persistence.LockModeType;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

interface UsuarioRepositorio extends JpaRepository<Usuario, UUID> {

    Optional<Usuario> findByNombreUsuario(String nombreUsuario);

    boolean existsByNombreUsuario(String nombreUsuario);

    @Query("select count(a) from Administrador a")
    long contarAdministradores();

    @Query("select e from Empleado e where :patron is null or lower(e.nombre) like :patron or lower(e.nombreUsuario) like :patron")
    Page<Empleado> buscarEmpleados(@Param("patron") String patron, Pageable pageable);

    @Query("select g from Guia g where :patron is null or lower(g.nombre) like :patron or lower(g.nombreUsuario) like :patron")
    Page<Empleado> buscarGuias(@Param("patron") String patron, Pageable pageable);

    @Query("select c from Cuidador c where :patron is null or lower(c.nombre) like :patron or lower(c.nombreUsuario) like :patron")
    Page<Empleado> buscarCuidadores(@Param("patron") String patron, Pageable pageable);

    @Query("select e from Empleado e where e.id = :id")
    Optional<Empleado> buscarEmpleado(@Param("id") UUID id);

    @Query("select g from Guia g order by g.nombre")
    List<Empleado> opcionesGuias(Pageable limite);

    @Query("select c from Cuidador c order by c.nombre")
    List<Empleado> opcionesCuidadores(Pageable limite);

    @Query("select g from Guia g where g.id = :id")
    Optional<Guia> buscarGuia(@Param("id") UUID id);

    @Query("select c from Cuidador c where c.id = :id")
    Optional<Cuidador> buscarCuidador(@Param("id") UUID id);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select g from Guia g where g.id = :id")
    Optional<Guia> buscarGuiaConBloqueo(@Param("id") UUID id);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select g from Guia g where g.id in :ids order by g.id")
    List<Guia> bloquearGuias(@Param("ids") Collection<UUID> ids);
}
