package ar.edu.inspt.mundomarino.seguridad;

import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * Verifica las contraseñas importadas de la versión 2 (formato propio
 * {@code pbkdf2$iteraciones$sal$hash}, PBKDF2-HMAC-SHA256 de 256 bits).
 * Solo VERIFICA: nunca se usa para generar hashes nuevos. Al primer login
 * correcto, Spring reemplaza el hash por uno BCrypt (ver DetallesUsuarioService).
 */
public class Pbkdf2LegadoPasswordEncoder implements PasswordEncoder {

    public static final String ID = "pbkdf2-v2";

    @Override
    public String encode(CharSequence rawPassword) {
        throw new UnsupportedOperationException("El formato pbkdf2-v2 solo se usa para verificar contraseñas importadas.");
    }

    @Override
    public boolean matches(CharSequence rawPassword, String encodedPassword) {
        if (rawPassword == null || encodedPassword == null) {
            return false;
        }
        String[] partes = encodedPassword.split("\\$");
        if (partes.length != 4 || !"pbkdf2".equals(partes[0])) {
            return false;
        }
        try {
            int iteraciones = Integer.parseInt(partes[1]);
            byte[] sal = Base64.getDecoder().decode(partes[2]);
            byte[] esperado = Base64.getDecoder().decode(partes[3]);
            PBEKeySpec spec = new PBEKeySpec(rawPassword.toString().toCharArray(), sal, iteraciones, esperado.length * 8);
            try {
                byte[] calculado = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
                return MessageDigest.isEqual(esperado, calculado);
            } finally {
                spec.clearPassword();
            }
        } catch (IllegalArgumentException | GeneralSecurityException ex) {
            return false;
        }
    }

    @Override
    public boolean upgradeEncoding(String encodedPassword) {
        return true;
    }
}
