package ar.edu.inspt.mundomarino.personal;

/** Tipo de usuario. Es también el valor de la columna discriminadora {@code usuario.rol}. */
public enum Rol {
    ADMINISTRADOR, GUIA, CUIDADOR
}
