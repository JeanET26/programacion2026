package ar.edu.inspt.mundomarino.personal;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import java.util.EnumSet;
import java.util.Set;
import java.util.UUID;

/**
 * Usuario con permisos de administración.
 *
 * <p><b>¿Por qué ya no es {@code final}?</b> En la versión 2 lo era para dejar
 * explícito que no estaban previstas subclases. Ahora es una entidad JPA, y la
 * especificación de JPA exige que las entidades NO sean final: Hibernate crea
 * en tiempo de ejecución subclases "proxy" para la carga diferida. La
 * intención de diseño (no crear subtipos de administrador) se mantiene
 * documentada; la autorización NUNCA dependió de {@code final}, sino de los
 * permisos que Spring Security verifica en el servidor.</p>
 */
@Entity
@DiscriminatorValue("ADMINISTRADOR")
public class Administrador extends Usuario {

    protected Administrador() {
    }

    public Administrador(UUID id, String nombreUsuario, String hashContrasena, String nombre) {
        super(id, nombreUsuario, hashContrasena, nombre);
    }

    @Override
    public Rol getRol() {
        return Rol.ADMINISTRADOR;
    }

    @Override
    public Set<Permiso> getPermisos() {
        return Set.copyOf(EnumSet.of(Permiso.ADMINISTRAR_PARQUE, Permiso.VER_PERFIL_PROPIO));
    }
}
