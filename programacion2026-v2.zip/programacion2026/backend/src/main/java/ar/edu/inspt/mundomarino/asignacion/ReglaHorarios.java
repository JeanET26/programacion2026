package ar.edu.inspt.mundomarino.asignacion;

import ar.edu.inspt.mundomarino.comun.error.ReglaNegocioException;
import java.time.LocalTime;

/**
 * La regla de horarios, como funciones puras (sin base ni Spring): fácil de
 * probar y la misma para el servicio y para el importador.
 *
 * Un recorrido ocupa el intervalo [hora, hora + duración). Dos recorridos se
 * superponen si cada uno empieza antes de que termine el otro. Que uno termine
 * 10:45 y el siguiente empiece 10:45 NO es superposición.
 */
public final class ReglaHorarios {

    private ReglaHorarios() {
    }

    public static LocalTime finDe(LocalTime inicio, int duracionMinutos) {
        int finEnMinutos = inicio.getHour() * 60 + inicio.getMinute() + duracionMinutos;
        if (finEnMinutos > 24 * 60 - 1) {
            throw new ReglaNegocioException("El recorrido no puede terminar después de las 23:59.");
        }
        return LocalTime.of(finEnMinutos / 60, finEnMinutos % 60);
    }

    public static boolean seSuperponen(LocalTime inicioA, int duracionA, LocalTime inicioB, int duracionB) {
        return inicioA.isBefore(finDe(inicioB, duracionB)) && inicioB.isBefore(finDe(inicioA, duracionA));
    }
}
