package ar.edu.inspt.mundomarino.asignacion;

import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.CuidadoAlta;
import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.CuidadoCambio;
import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.CuidadoRespuesta;
import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.HorarioAlta;
import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.HorarioCambio;
import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.HorarioRespuesta;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.web.ParametrosPagina;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.UUID;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** Asignaciones del administrador: horarios de guías y cuidados de especies. */
@RestController
@Tag(name = "Asignaciones", description = "Solo administrador")
public class AsignacionController {

    private final AsignacionGuiaService horarios;
    private final AsignacionCuidadoService cuidados;

    public AsignacionController(AsignacionGuiaService horarios, AsignacionCuidadoService cuidados) {
        this.horarios = horarios;
        this.cuidados = cuidados;
    }

    @GetMapping("/api/asignaciones-guia")
    public Pagina<HorarioRespuesta> listarHorarios(ParametrosPagina p, @RequestParam(required = false) UUID guiaId,
            @RequestParam(required = false) UUID itinerarioId) {
        return horarios.listar(guiaId, itinerarioId, p.aSolicitud());
    }

    @PostMapping("/api/asignaciones-guia")
    public ResponseEntity<HorarioRespuesta> asignarGuia(@Valid @RequestBody HorarioAlta alta) {
        HorarioRespuesta creada = horarios.asignar(alta);
        return ResponseEntity.created(URI.create("/api/asignaciones-guia/" + creada.id())).body(creada);
    }

    @PutMapping("/api/asignaciones-guia/{id}")
    public HorarioRespuesta cambiarHora(@PathVariable UUID id, @Valid @RequestBody HorarioCambio cambio) {
        return horarios.cambiarHora(id, cambio);
    }

    @DeleteMapping("/api/asignaciones-guia/{id}")
    public ResponseEntity<Void> quitarHorario(@PathVariable UUID id) {
        horarios.eliminar(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/api/asignaciones-cuidado")
    public Pagina<CuidadoRespuesta> listarCuidados(ParametrosPagina p, @RequestParam(required = false) UUID cuidadorId,
            @RequestParam(required = false) UUID especieId) {
        return cuidados.listar(cuidadorId, especieId, p.aSolicitud());
    }

    @PostMapping("/api/asignaciones-cuidado")
    public ResponseEntity<CuidadoRespuesta> asignarCuidador(@Valid @RequestBody CuidadoAlta alta) {
        CuidadoRespuesta creada = cuidados.asignar(alta);
        return ResponseEntity.created(URI.create("/api/asignaciones-cuidado/" + creada.id())).body(creada);
    }

    @PutMapping("/api/asignaciones-cuidado/{id}")
    public CuidadoRespuesta cambiarFecha(@PathVariable UUID id, @Valid @RequestBody CuidadoCambio cambio) {
        return cuidados.cambiarFecha(id, cambio);
    }

    @DeleteMapping("/api/asignaciones-cuidado/{id}")
    public ResponseEntity<Void> quitarCuidado(@PathVariable UUID id) {
        cuidados.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
