package ar.edu.inspt.mundomarino.integracion;

import static org.assertj.core.api.Assertions.assertThat;

import ar.edu.inspt.mundomarino.soporte.ClienteHttp;
import ar.edu.inspt.mundomarino.soporte.ClienteHttp.Respuesta;
import ar.edu.inspt.mundomarino.soporte.PruebaHttp;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;

/** Contrato HTTP de la API: códigos, cuerpos JSON, validaciones, paginación y documentación. */
class ApiRestIT extends PruebaHttp {

    @Test
    void crudDeZonasConCodigosCoherentes() {
        ClienteHttp admin = comoAdministrador();

        Respuesta creada = admin.post("/api/zonas", Map.of("nombre", "Arrecife", "extensionM2", 850));
        assertThat(creada.estado()).isEqualTo(201);
        String id = creada.json().get("id").asText();
        assertThat(creada.encabezados().get("location")).containsExactly("/api/zonas/" + id);
        assertThat(creada.json().get("version").asLong()).isZero();

        assertThat(admin.get("/api/zonas/" + id).json().get("nombre").asText()).isEqualTo("Arrecife");
        assertThat(admin.post("/api/zonas", Map.of("nombre", "arrecife", "extensionM2", 10)).estado()).isEqualTo(409);

        Respuesta editada = admin.put("/api/zonas/" + id, Map.of("nombre", "Arrecife norte", "extensionM2", 900, "version", 0));
        assertThat(editada.estado()).isEqualTo(200);
        assertThat(admin.put("/api/zonas/" + id, Map.of("nombre", "Otro", "extensionM2", 900, "version", 0)).estado())
                .isEqualTo(409); // versión vieja

        assertThat(admin.delete("/api/zonas/" + id).estado()).isEqualTo(204);
        assertThat(admin.get("/api/zonas/" + id).estado()).isEqualTo(404);
    }

    @Test
    void lasValidacionesDevuelven400ConElDetallePorCampo() {
        ClienteHttp admin = comoAdministrador();
        Respuesta r = admin.post("/api/zonas", Map.of("nombre", "", "extensionM2", -3));
        assertThat(r.estado()).isEqualTo(400);
        assertThat(r.json().get("errores").has("nombre")).isTrue();
        assertThat(r.json().get("errores").has("extensionM2")).isTrue();

        assertThat(admin.get("/api/zonas/no-es-un-uuid").estado()).isEqualTo(400);
        assertThat(admin.enviar("POST", "/api/zonas", "texto que no es un objeto", true).estado()).isEqualTo(400);
    }

    @Test
    void elListadoEsPaginadoFiltradoYOrdenadoEnElServidor() {
        ClienteHttp admin = comoAdministrador();
        for (int i = 1; i <= 12; i++) {
            admin.post("/api/zonas", Map.of("nombre", String.format("Zona %02d", i), "extensionM2", i));
        }
        Respuesta r = admin.get("/api/zonas?pagina=1&tamanio=5&orden=nombre&dir=desc");
        assertThat(r.json().get("totalElementos").asInt()).isEqualTo(12);
        assertThat(r.json().get("totalPaginas").asInt()).isEqualTo(3);
        assertThat(r.json().get("contenido").get(0).get("nombre").asText()).isEqualTo("Zona 07");
        assertThat(admin.get("/api/zonas?q=zona%201").json().get("totalElementos").asInt()).isEqualTo(3);
        // un campo de orden no permitido se ignora (no se puede ordenar por columnas arbitrarias)
        assertThat(admin.get("/api/zonas?orden=hash_contrasena").estado()).isEqualTo(200);
        assertThat(admin.get("/api/zonas?tamanio=100000").json().get("tamanio").asInt()).isEqualTo(100);
    }

    @Test
    void flujoCompletoDeAsignacionDeHorarios() {
        ClienteHttp admin = comoAdministrador();
        String zona = admin.post("/api/zonas", Map.of("nombre", "Arrecife", "extensionM2", 850)).json().get("id").asText();
        String especie = admin.post("/api/especies", Map.of("nombreEspanol", "Pez payaso", "nombreCientifico", "Amphiprion ocellaris",
                "descripcion", "Vive en anémonas", "zonaId", zona, "habitatIds", List.of())).json().get("id").asText();
        String it = admin.post("/api/itinerarios", Map.of("numero", 1, "duracionMinutos", 45, "longitudKm", 1.8,
                "maximoVisitantes", 25, "especieIds", List.of(especie))).json().get("id").asText();
        String guia = admin.post("/api/empleados", Map.of("rol", "GUIA", "nombreUsuario", "guia.lucia", "contrasena", "Marino2026x",
                "nombre", "Lucía Gómez", "direccion", "Av. del Mar 120", "telefono", "11 5555-1000", "fechaIngreso", "2024-03-04"))
                .json().get("id").asText();

        Respuesta asignada = admin.post("/api/asignaciones-guia", Map.of("guiaId", guia, "itinerarioId", it, "hora", "10:00"));
        assertThat(asignada.estado()).isEqualTo(201);
        assertThat(asignada.json().get("horaFin").asText()).isEqualTo("10:45");
        assertThat(asignada.json().get("zonas").get(0).asText()).isEqualTo("Arrecife");

        Respuesta superpuesta = admin.post("/api/asignaciones-guia", Map.of("guiaId", guia, "itinerarioId", it, "hora", "10:30"));
        assertThat(superpuesta.estado()).isEqualTo(409);
        assertThat(superpuesta.json().get("mensaje").asText()).contains("superpone");

        ClienteHttp lucia = cliente();
        lucia.login("guia.lucia", "Marino2026x");
        Respuesta mios = lucia.get("/api/mi/recorridos");
        assertThat(mios.json()).hasSize(1);
        assertThat(mios.json().get(0).get("codigo").asText()).isEqualTo("IT-01");
        assertThat(mios.body()).doesNotContain("telefono").doesNotContain("direccion");
    }

    @Test
    void lasRespuestasNoExponenHashesNiDatosInternos() {
        ClienteHttp admin = comoAdministrador();
        admin.post("/api/empleados", Map.of("rol", "CUIDADOR", "nombreUsuario", "cuidador.x", "contrasena", "Marino2026x",
                "nombre", "X", "direccion", "Calle", "telefono", "11 5555-1000", "fechaIngreso", "2024-03-04"));
        String cuerpo = admin.get("/api/empleados").body();
        assertThat(cuerpo).doesNotContain("hash").doesNotContain("$2a$").doesNotContain("{bcrypt}");
    }

    @Test
    void eliminarAlgoEnUsoDevuelve409ConMensajeClaro() {
        ClienteHttp admin = comoAdministrador();
        String zona = admin.post("/api/zonas", Map.of("nombre", "Arrecife", "extensionM2", 850)).json().get("id").asText();
        admin.post("/api/especies", Map.of("nombreEspanol", "Pez", "nombreCientifico", "P. x", "descripcion", "d",
                "zonaId", zona, "habitatIds", List.of()));
        Respuesta r = admin.delete("/api/zonas/" + zona);
        assertThat(r.estado()).isEqualTo(409);
        assertThat(r.json().get("mensaje").asText()).contains("especies");
    }

    @Test
    void documentacionOpenApiYSaludDisponibles() {
        Respuesta docs = cliente().get("/v3/api-docs");
        assertThat(docs.estado()).isEqualTo(200);
        assertThat(docs.body()).contains("/api/zonas").contains("/api/asignaciones-guia");
        Respuesta salud = cliente().get("/actuator/health");
        assertThat(salud.estado()).isEqualTo(200);
        assertThat(salud.json().get("status").asText()).isEqualTo("UP");
    }

    @Test
    void unIdInexistenteDevuelve404() {
        assertThat(comoAdministrador().get("/api/especies/" + UUID.randomUUID()).estado()).isEqualTo(404);
    }
}
