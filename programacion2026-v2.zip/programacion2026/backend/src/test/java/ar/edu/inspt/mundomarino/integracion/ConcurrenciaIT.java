package ar.edu.inspt.mundomarino.integracion;

import static org.assertj.core.api.Assertions.assertThat;

import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.HorarioAlta;
import ar.edu.inspt.mundomarino.asignacion.AsignacionGuiaService;
import ar.edu.inspt.mundomarino.asignacion.ReglaHorarios;
import ar.edu.inspt.mundomarino.comun.error.ReglaNegocioException;
import ar.edu.inspt.mundomarino.itinerario.ItinerarioDtos.ItinerarioRespuesta;
import ar.edu.inspt.mundomarino.itinerario.ItinerarioDtos.ItinerarioSolicitud;
import ar.edu.inspt.mundomarino.itinerario.ItinerarioService;
import ar.edu.inspt.mundomarino.soporte.PruebaIntegracion;
import ar.edu.inspt.mundomarino.zona.ZonaDtos.ZonaSolicitud;
import ar.edu.inspt.mundomarino.zona.ZonaService;
import java.math.BigDecimal;
import java.sql.Time;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.dao.PessimisticLockingFailureException;

/**
 * Pedidos SIMULTÁNEOS de verdad (varios hilos que arrancan juntos) contra
 * MySQL. Verifica que las reglas se cumplan aunque dos administradores
 * operen al mismo tiempo.
 */
class ConcurrenciaIT extends PruebaIntegracion {

    @Autowired AsignacionGuiaService horarios;
    @Autowired ItinerarioService itinerarios;
    @Autowired ZonaService zonas;

    /** Ejecuta las tareas en paralelo, todas a la vez, y devuelve cuántas terminaron bien. */
    private int enParalelo(List<Callable<?>> tareas) throws Exception {
        ExecutorService ejecutor = Executors.newFixedThreadPool(tareas.size());
        CountDownLatch largada = new CountDownLatch(1);
        List<Future<Boolean>> resultados = new ArrayList<>();
        for (Callable<?> t : tareas) {
            resultados.add(ejecutor.submit(() -> {
                largada.await();
                try {
                    t.call();
                    return true;
                } catch (ReglaNegocioException | DataIntegrityViolationException | PessimisticLockingFailureException
                        | OptimisticLockingFailureException esperado) {
                    return false; // rechazo esperado por la regla o por la base
                }
            }));
        }
        largada.countDown();
        int exitos = 0;
        for (Future<Boolean> r : resultados) {
            if (r.get(60, TimeUnit.SECONDS)) {
                exitos++;
            }
        }
        ejecutor.shutdown();
        return exitos;
    }

    @Test
    void asignacionesSimultaneasSuperpuestasDelMismoGuiaSoloAceptanUna() throws Exception {
        UUID it = fabrica.itinerario(1, 45, fabrica.especie("Pez", fabrica.zona("Arrecife")));
        UUID guia = fabrica.guia("guia.a");
        List<Callable<?>> tareas = new ArrayList<>();
        for (int i = 0; i < 9; i++) { // 10:00, 10:05 ... 10:40: todas se superponen entre sí
            LocalTime hora = LocalTime.of(10, i * 5);
            tareas.add(() -> horarios.asignar(new HorarioAlta(guia, it, hora)));
        }
        assertThat(enParalelo(tareas)).isEqualTo(1);
        assertThat(contar("asignacion_guia")).isEqualTo(1);
    }

    @Test
    void guiasDistintosSePuedenAsignarEnParaleloSinBloquearse() throws Exception {
        UUID it = fabrica.itinerario(1, 45, fabrica.especie("Pez", fabrica.zona("Arrecife")));
        List<Callable<?>> tareas = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            UUID guia = fabrica.guia("guia.n" + i);
            tareas.add(() -> horarios.asignar(new HorarioAlta(guia, it, LocalTime.of(10, 0))));
        }
        assertThat(enParalelo(tareas)).isEqualTo(8);
    }

    @Test
    void altasSimultaneasConElMismoNombreDejanUnaSola() throws Exception {
        List<Callable<?>> tareas = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            tareas.add(() -> zonas.crear(new ZonaSolicitud("Zona concurrente", BigDecimal.TEN, null)));
        }
        assertThat(enParalelo(tareas)).isEqualTo(1);
        assertThat(contar("zona")).isEqualTo(1);
    }

    @Test
    void dosEdicionesConLaMismaVersionNoSePisan() throws Exception {
        UUID id = zonas.crear(new ZonaSolicitud("Original", BigDecimal.TEN, null)).id();
        List<Callable<?>> tareas = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            String nombre = "Editada " + i;
            tareas.add(() -> zonas.actualizar(id, new ZonaSolicitud(nombre, BigDecimal.TEN, 0L)));
        }
        assertThat(enParalelo(tareas)).isEqualTo(1);
        assertThat(zonas.obtener(id).version()).isEqualTo(1L);
    }

    /**
     * Carrera entre "alargar un itinerario" y "asignarle otro horario al guía".
     * Cada operación sola es válida; juntas dejarían horarios superpuestos.
     * Se repite varias veces para dar oportunidad a distintos ordenamientos.
     */
    @Test
    void cambioDeDuracionYAsignacionSimultaneosNoDejanSuperposiciones() throws Exception {
        for (int ronda = 0; ronda < 5; ronda++) {
            vaciarTablasParaRonda();
            UUID pez = fabrica.especie("Pez", fabrica.zona("Arrecife"));
            UUID it1 = fabrica.itinerario(1, 45, pez);
            UUID it2 = fabrica.itinerario(2, 30, pez);
            UUID guia = fabrica.guia("guia.a");
            fabrica.horario(guia, it1, LocalTime.of(10, 0));
            ItinerarioRespuesta r = itinerarios.obtener(it1);
            ItinerarioSolicitud alargar = new ItinerarioSolicitud(null, 90, r.longitudKm(), r.maximoVisitantes(),
                    r.especies().stream().map(o -> o.id()).toList(), r.version());

            int exitos = enParalelo(List.of(
                    () -> itinerarios.actualizar(it1, alargar),
                    () -> horarios.asignar(new HorarioAlta(guia, it2, LocalTime.of(11, 0)))));

            assertThat(exitos).isEqualTo(1);
            assertThat(haySuperposiciones(guia)).isFalse();
        }
    }

    private void vaciarTablasParaRonda() {
        vaciar("asignacion_guia", "itinerario_especie", "itinerario", "especie", "zona", "usuario");
    }

    /** Comprueba en la BASE (no en memoria) que los horarios del guía no se superponen. */
    private boolean haySuperposiciones(UUID guia) {
        List<Map<String, Object>> filas = jdbc.queryForList("""
                select a.hora, i.duracion_minutos from asignacion_guia a join itinerario i on i.id = a.itinerario_id
                where a.guia_id = ?""", guia.toString());
        for (int i = 0; i < filas.size(); i++) {
            for (int j = i + 1; j < filas.size(); j++) {
                LocalTime hi = ((Time) filas.get(i).get("hora")).toLocalTime();
                LocalTime hj = ((Time) filas.get(j).get("hora")).toLocalTime();
                int di = ((Number) filas.get(i).get("duracion_minutos")).intValue();
                int dj = ((Number) filas.get(j).get("duracion_minutos")).intValue();
                if (ReglaHorarios.seSuperponen(hi, di, hj, dj)) {
                    return true;
                }
            }
        }
        return false;
    }
}
