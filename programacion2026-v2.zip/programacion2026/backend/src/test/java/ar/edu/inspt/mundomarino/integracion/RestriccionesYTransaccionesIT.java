package ar.edu.inspt.mundomarino.integracion;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import ar.edu.inspt.mundomarino.comun.error.DatoInvalidoException;
import ar.edu.inspt.mundomarino.comun.error.ReglaNegocioException;
import ar.edu.inspt.mundomarino.especie.EspecieDtos.EspecieRespuesta;
import ar.edu.inspt.mundomarino.especie.EspecieDtos.EspecieSolicitud;
import ar.edu.inspt.mundomarino.especie.EspecieService;
import ar.edu.inspt.mundomarino.personal.PersonalDtos.EmpleadoCambios;
import ar.edu.inspt.mundomarino.personal.PersonalService;
import ar.edu.inspt.mundomarino.soporte.PruebaIntegracion;
import ar.edu.inspt.mundomarino.zona.Zona;
import ar.edu.inspt.mundomarino.zona.ZonaDao;
import ar.edu.inspt.mundomarino.zona.ZonaDtos.ZonaSolicitud;
import ar.edu.inspt.mundomarino.zona.ZonaService;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * Restricciones que garantiza MySQL (aunque se saltee el servicio) y
 * transacciones: una operación rechazada no deja cambios parciales.
 */
class RestriccionesYTransaccionesIT extends PruebaIntegracion {

    @Autowired ZonaDao zonaDao;
    @Autowired ZonaService zonas;
    @Autowired EspecieService especies;
    @Autowired PersonalService personal;
    @Autowired PlatformTransactionManager tm;

    @Test
    void laBaseRechazaNombresDuplicadosSinDistinguirMayusculas() {
        zonaDao.guardar(new Zona(UUID.randomUUID(), "Arrecife", BigDecimal.TEN));
        // Directo al DAO, sin la verificación previa del servicio: decide la restricción única.
        assertThatThrownBy(() -> zonaDao.guardar(new Zona(UUID.randomUUID(), "ARRECIFE", BigDecimal.ONE)))
                .isInstanceOf(DataIntegrityViolationException.class)
                .hasMessageContaining("uk_zona_nombre");
    }

    @Test
    void laBaseRechazaDatosInvalidosAunqueSeEscribaSinPasarPorJava() {
        assertThatThrownBy(() -> jdbc.update("insert into zona (id, nombre, extension_m2) values (?, ?, ?)",
                UUID.randomUUID().toString(), "Mala", -5)).isInstanceOf(DataIntegrityViolationException.class);
        assertThatThrownBy(() -> jdbc.update("insert into usuario (id, rol, nombre_usuario, hash_contrasena, nombre) values (?, 'GUIA', 'x.y', 'h', 'X')",
                UUID.randomUUID().toString())).isInstanceOf(DataIntegrityViolationException.class);
        assertThatThrownBy(() -> jdbc.update("insert into especie (id, nombre_espanol, nombre_cientifico, descripcion, zona_id) values (?, 'a', 'b', 'c', ?)",
                UUID.randomUUID().toString(), UUID.randomUUID().toString())).isInstanceOf(DataIntegrityViolationException.class);
    }

    @Test
    void elUuidSeGuardaComoTextoYSeReconstruyeIgual() {
        UUID id = zonas.crear(new ZonaSolicitud("Arrecife", BigDecimal.TEN, null)).id();
        String enLaBase = jdbc.queryForObject("select id from zona", String.class);
        assertThat(enLaBase).isEqualTo(id.toString());
        assertThat(zonaDao.buscarPorId(id)).map(Zona::getId).contains(id);
    }

    @Test
    void siFallaUnaParteDeLaTransaccionNoQuedaNadaGuardado() {
        TransactionTemplate tx = new TransactionTemplate(tm);
        assertThatThrownBy(() -> tx.executeWithoutResult(s -> {
            zonaDao.guardar(new Zona(UUID.randomUUID(), "Primera", BigDecimal.TEN));
            zonaDao.guardar(new Zona(UUID.randomUUID(), "primera", BigDecimal.ONE)); // viola la unicidad
        })).isInstanceOf(DataIntegrityViolationException.class);
        assertThat(contar("zona")).isZero(); // rollback: tampoco quedó la primera
    }

    @Test
    void unaEdicionRechazadaNoCambiaNada() {
        UUID pez = fabrica.especie("Pez", fabrica.zona("Arrecife"));
        EspecieRespuesta antes = especies.obtener(pez);
        assertThatThrownBy(() -> especies.actualizar(pez, new EspecieSolicitud("Otro nombre", antes.nombreCientifico(),
                antes.descripcion(), antes.zonaId(), List.of(UUID.randomUUID()), antes.version())))
                .isInstanceOf(DatoInvalidoException.class);
        EspecieRespuesta despues = especies.obtener(pez);
        assertThat(despues.nombreEspanol()).isEqualTo("Pez");
        assertThat(despues.version()).isEqualTo(antes.version());
    }

    @Test
    void unaVersionViejaNoPisaLosCambiosDeOtro() {
        UUID id = zonas.crear(new ZonaSolicitud("Arrecife", BigDecimal.TEN, null)).id();
        zonas.actualizar(id, new ZonaSolicitud("Arrecife norte", BigDecimal.TEN, 0L));
        assertThatThrownBy(() -> zonas.actualizar(id, new ZonaSolicitud("Arrecife sur", BigDecimal.ONE, 0L)))
                .isInstanceOf(ReglaNegocioException.class);
        assertThat(zonas.obtener(id).nombre()).isEqualTo("Arrecife norte");
    }

    @Test
    void unRestablecimientoDeContrasenaInvalidoNoModificaAlEmpleado() {
        UUID guia = fabrica.guia("guia.a");
        String hashAntes = jdbc.queryForObject("select hash_contrasena from usuario where id = ?", String.class, guia.toString());
        assertThatThrownBy(() -> personal.actualizar(guia, new EmpleadoCambios("corta", "Nuevo Nombre", "Calle", "11 5555-0000",
                LocalDate.of(2024, 1, 1), 0L))).isInstanceOf(DatoInvalidoException.class);
        assertThat(jdbc.queryForObject("select nombre from usuario where id = ?", String.class, guia.toString())).isEqualTo("Guía guia.a");
        assertThat(jdbc.queryForObject("select hash_contrasena from usuario where id = ?", String.class, guia.toString())).isEqualTo(hashAntes);
    }

    @Test
    void lasContrasenasSeGuardanConBcryptYSal() {
        fabrica.guia("guia.a");
        fabrica.guia("guia.b");
        List<String> hashes = jdbc.queryForList("select hash_contrasena from usuario", String.class);
        assertThat(hashes).allMatch(h -> h.startsWith("{bcrypt}$2"));
        assertThat(hashes.get(0)).isNotEqualTo(hashes.get(1)); // misma contraseña, distinto hash (sal)
    }
}
