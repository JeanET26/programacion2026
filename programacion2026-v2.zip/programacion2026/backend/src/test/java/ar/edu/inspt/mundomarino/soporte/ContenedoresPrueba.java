package ar.edu.inspt.mundomarino.soporte;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.context.annotation.Bean;
import org.testcontainers.containers.MySQLContainer;
import org.testcontainers.utility.DockerImageName;

/**
 * MySQL 8 REAL en un contenedor Docker para las pruebas de integración.
 * {@code @ServiceConnection} hace que Spring Boot use su URL, usuario y
 * contraseña automáticamente. Flyway crea el esquema como en producción.
 * Una base en memoria (H2) no serviría: los bloqueos, restricciones CHECK,
 * colaciones y mensajes de error son distintos.
 */
@TestConfiguration(proxyBeanMethods = false)
public class ContenedoresPrueba {

    @Bean
    @ServiceConnection
    MySQLContainer<?> mysql() {
        return new MySQLContainer<>(DockerImageName.parse("mysql:8.0.36"))
                .withDatabaseName("mundo_marino")
                .withCommand("--character-set-server=utf8mb4", "--collation-server=utf8mb4_0900_ai_ci");
    }
}
