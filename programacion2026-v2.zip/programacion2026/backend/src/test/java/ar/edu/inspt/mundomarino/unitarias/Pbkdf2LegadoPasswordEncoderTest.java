package ar.edu.inspt.mundomarino.unitarias;

import static org.assertj.core.api.Assertions.assertThat;

import ar.edu.inspt.mundomarino.seguridad.Pbkdf2LegadoPasswordEncoder;
import org.junit.jupiter.api.Test;

/** Las contraseñas guardadas por la versión 2 se pueden verificar después de importarlas. */
public class Pbkdf2LegadoPasswordEncoderTest {

    /** Hash generado por la versión 2 (HashContrasena) para la contraseña "Marino2026!". */
    public static final String HASH_V2 = "pbkdf2$120000$JGmXmsdMXnZWKKjGqYKuoA==$CNQzwgbKx374aXIWhZwteo/kir0Hh+SdfF0R4GbweUc=";

    private final Pbkdf2LegadoPasswordEncoder codificador = new Pbkdf2LegadoPasswordEncoder();

    @Test
    void verificaLaContrasenaCorrecta() {
        assertThat(codificador.matches("Marino2026!", HASH_V2)).isTrue();
    }

    @Test
    void rechazaLaIncorrectaYFormatosInvalidos() {
        assertThat(codificador.matches("otra-clave1", HASH_V2)).isFalse();
        assertThat(codificador.matches("Marino2026!", "texto-cualquiera")).isFalse();
        assertThat(codificador.matches("Marino2026!", "pbkdf2$x$y$z")).isFalse();
    }

    @Test
    void pideActualizarElHashABcrypt() {
        assertThat(codificador.upgradeEncoding(HASH_V2)).isTrue();
    }
}
