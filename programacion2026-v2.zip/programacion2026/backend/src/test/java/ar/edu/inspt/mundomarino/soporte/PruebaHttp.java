package ar.edu.inspt.mundomarino.soporte;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;

/** Igual que {@link PruebaIntegracion} pero con el servidor web real en un puerto libre. */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public abstract class PruebaHttp extends PruebaIntegracion {

    @LocalServerPort
    protected int puerto;

    protected ClienteHttp cliente() {
        return new ClienteHttp(puerto);
    }

    protected ClienteHttp comoAdministrador() {
        fabrica.administrador("admin.prueba");
        ClienteHttp c = cliente();
        c.login("admin.prueba", Fabrica.CLAVE);
        return c;
    }
}
