package ar.edu.inspt.mundomarino.soporte;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.net.CookieManager;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import java.util.Map;

/**
 * Cliente HTTP de prueba que se comporta como un navegador: guarda la cookie
 * de sesión y envía el token CSRF. Sirve para probar el flujo real completo.
 */
public final class ClienteHttp {

    public record Respuesta(int estado, String cuerpo, Map<String, List<String>> encabezados, JsonNode json) {
    }

    private static final ObjectMapper JSON = new ObjectMapper();

    private final String base;
    private final HttpClient http;
    private String encabezadoCsrf = "X-CSRF-TOKEN";
    private String tokenCsrf;

    public ClienteHttp(int puerto) {
        this.base = "http://localhost:" + puerto;
        this.http = HttpClient.newBuilder().cookieHandler(new CookieManager()).build();
    }

    /** Pide un token CSRF nuevo (se renueva al iniciar sesión). */
    public void renovarCsrf() {
        Respuesta r = enviar("GET", "/api/auth/csrf", null, false);
        encabezadoCsrf = r.json().get("encabezado").asText();
        tokenCsrf = r.json().get("token").asText();
    }

    public Respuesta login(String usuario, String contrasena) {
        renovarCsrf();
        Respuesta r = post("/api/auth/login", Map.of("nombreUsuario", usuario, "contrasena", contrasena));
        renovarCsrf();
        return r;
    }

    public Respuesta get(String ruta) {
        return enviar("GET", ruta, null, false);
    }

    public Respuesta post(String ruta, Object cuerpo) {
        return enviar("POST", ruta, cuerpo, true);
    }

    public Respuesta put(String ruta, Object cuerpo) {
        return enviar("PUT", ruta, cuerpo, true);
    }

    public Respuesta delete(String ruta) {
        return enviar("DELETE", ruta, null, true);
    }

    /** POST sin token CSRF (para comprobar que se rechaza). */
    public Respuesta postSinCsrf(String ruta, Object cuerpo) {
        return enviar("POST", ruta, cuerpo, false);
    }

    public Respuesta enviar(String metodo, String ruta, Object cuerpo, boolean conCsrf) {
        try {
            HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(base + ruta)).header("Accept", "application/json");
            String json = cuerpo == null ? "" : JSON.writeValueAsString(cuerpo);
            b.header("Content-Type", "application/json");
            if (conCsrf && tokenCsrf != null) {
                b.header(encabezadoCsrf, tokenCsrf);
            }
            b.method(metodo, cuerpo == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofString(json));
            HttpResponse<String> r = http.send(b.build(), HttpResponse.BodyHandlers.ofString());
            JsonNode nodo = r.body() == null || r.body().isBlank() ? null : leer(r.body());
            return new Respuesta(r.statusCode(), r.body(), r.headers().map(), nodo);
        } catch (IOException ex) {
            throw new IllegalStateException(ex);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException(ex);
        }
    }

    public Respuesta preflight(String ruta, String origen) {
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(base + ruta))
                    .method("OPTIONS", HttpRequest.BodyPublishers.noBody())
                    .header("Origin", origen)
                    .header("Access-Control-Request-Method", "POST")
                    .header("Access-Control-Request-Headers", "content-type,x-csrf-token")
                    .build();
            HttpResponse<String> r = http.send(req, HttpResponse.BodyHandlers.ofString());
            return new Respuesta(r.statusCode(), r.body(), r.headers().map(), null);
        } catch (IOException ex) {
            throw new IllegalStateException(ex);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException(ex);
        }
    }

    private static JsonNode leer(String texto) {
        try {
            return JSON.readTree(texto);
        } catch (IOException ex) {
            return null;
        }
    }
}
