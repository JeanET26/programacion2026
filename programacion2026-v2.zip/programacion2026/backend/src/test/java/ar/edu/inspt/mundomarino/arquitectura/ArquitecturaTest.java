package ar.edu.inspt.mundomarino.arquitectura;

import static com.tngtech.archunit.base.DescribedPredicate.describe;
import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes;
import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClasses;
import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noMethods;
import static com.tngtech.archunit.library.dependencies.SlicesRuleDefinition.slices;

import ar.edu.inspt.mundomarino.comun.dao.EntidadConId;
import com.tngtech.archunit.core.domain.JavaClass;
import com.tngtech.archunit.core.domain.JavaClasses;
import com.tngtech.archunit.core.domain.JavaModifier;
import com.tngtech.archunit.core.importer.ClassFileImporter;
import com.tngtech.archunit.core.importer.ImportOption;
import jakarta.persistence.Entity;
import org.junit.jupiter.api.Test;
import org.springframework.data.repository.Repository;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RestController;

/**
 * Reglas de arquitectura verificadas automáticamente: si alguien las rompe
 * en el futuro, esta prueba falla.
 */
class ArquitecturaTest {

    private static final JavaClasses CLASES = new ClassFileImporter()
            .withImportOption(ImportOption.Predefined.DO_NOT_INCLUDE_TESTS)
            .importPackages("ar.edu.inspt.mundomarino");

    @Test
    void losModulosNoTienenDependenciasCirculares() {
        slices().matching("ar.edu.inspt.mundomarino.(*)..").should().beFreeOfCycles().check(CLASES);
    }

    @Test
    void losControladoresNoAccedenALosRepositorios() {
        noClasses().that().areAnnotatedWith(RestController.class)
                .should().dependOnClassesThat().areAssignableTo(Repository.class)
                .check(CLASES);
    }

    @Test
    void losServiciosUsanContratosDaoYNoRepositoriosJpa() {
        noClasses().that().areAnnotatedWith(Service.class)
                .should().dependOnClassesThat().areAssignableTo(Repository.class)
                .check(CLASES);
    }

    @Test
    void losControladoresNoDevuelvenEntidades() {
        noMethods().that().areDeclaredInClassesThat().areAnnotatedWith(RestController.class)
                .should().haveRawReturnType(describe("una entidad JPA",
                        (JavaClass c) -> c.isAssignableTo(EntidadConId.class)))
                .check(CLASES);
    }

    @Test
    void lasEntidadesNoSonFinalParaQueHibernatePuedaCrearProxies() {
        classes().that().areAnnotatedWith(Entity.class).should().notHaveModifier(JavaModifier.FINAL).check(CLASES);
    }

    @Test
    void losRepositoriosJpaSoloSonVisiblesEnSuModulo() {
        classes().that().areAssignableTo(Repository.class).should().notBePublic().check(CLASES);
    }
}
