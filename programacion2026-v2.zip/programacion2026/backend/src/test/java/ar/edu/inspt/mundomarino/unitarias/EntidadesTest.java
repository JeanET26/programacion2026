package ar.edu.inspt.mundomarino.unitarias;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import ar.edu.inspt.mundomarino.comun.error.DatoInvalidoException;
import ar.edu.inspt.mundomarino.especie.Especie;
import ar.edu.inspt.mundomarino.habitat.Habitat;
import ar.edu.inspt.mundomarino.itinerario.Itinerario;
import ar.edu.inspt.mundomarino.personal.Guia;
import ar.edu.inspt.mundomarino.personal.Permiso;
import ar.edu.inspt.mundomarino.zona.Zona;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.junit.jupiter.api.Test;

/** Invariantes que protegen las propias entidades (sin base de datos). */
class EntidadesTest {

    private final Zona arrecife = new Zona(UUID.randomUUID(), "Arrecife", new BigDecimal("100"));
    private final Zona tunel = new Zona(UUID.randomUUID(), "Túnel", new BigDecimal("200"));

    private Especie especie(String nombre, Zona zona) {
        return new Especie(UUID.randomUUID(), nombre, "Cientifica " + nombre, "Desc", zona, List.of());
    }

    @Test
    void itinerarioExigeAlMenosUnaEspecie() {
        assertThatThrownBy(() -> new Itinerario(UUID.randomUUID(), "IT-01", 45, BigDecimal.ONE, 10, List.of()))
                .isInstanceOf(DatoInvalidoException.class);
    }

    @Test
    void itinerarioRechazaEspeciesSinZona() {
        Especie sinZona = especie("Raya", null);
        assertThatThrownBy(() -> new Itinerario(UUID.randomUUID(), "IT-01", 45, BigDecimal.ONE, 10, List.of(sinZona)))
                .isInstanceOf(DatoInvalidoException.class).hasMessageContaining("Raya");
    }

    @Test
    void itinerarioValidaCodigoYRangos() {
        Especie e = especie("Pez", arrecife);
        assertThatThrownBy(() -> new Itinerario(UUID.randomUUID(), "IT-1", 45, BigDecimal.ONE, 10, List.of(e)))
                .isInstanceOf(DatoInvalidoException.class);
        assertThatThrownBy(() -> new Itinerario(UUID.randomUUID(), "IT-02", 4, BigDecimal.ONE, 10, List.of(e)))
                .isInstanceOf(DatoInvalidoException.class);
        assertThatThrownBy(() -> new Itinerario(UUID.randomUUID(), "IT-02", 45, BigDecimal.ZERO, 10, List.of(e)))
                .isInstanceOf(DatoInvalidoException.class);
        assertThat(Itinerario.codigoPara(7)).isEqualTo("IT-07");
        assertThatThrownBy(() -> Itinerario.codigoPara(100)).isInstanceOf(DatoInvalidoException.class);
    }

    @Test
    void lasZonasSeDerivanDeLasEspeciesSinRepetir() {
        Itinerario it = new Itinerario(UUID.randomUUID(), "IT-01", 45, BigDecimal.ONE, 10,
                List.of(especie("Pez", arrecife), especie("Tiburón", tunel), especie("Coral", arrecife)));
        assertThat(it.getZonas()).extracting(Zona::getNombre).containsExactly("Arrecife", "Túnel");
    }

    @Test
    void unaEdicionInvalidaNoDejaLaEntidadAMedias() {
        Zona z = new Zona(UUID.randomUUID(), "Original", new BigDecimal("10"));
        assertThatThrownBy(() -> z.actualizar("Nuevo nombre", new BigDecimal("-1"))).isInstanceOf(DatoInvalidoException.class);
        assertThat(z.getNombre()).isEqualTo("Original");
    }

    @Test
    void lasColeccionesExpuestasSonDeSoloLectura() {
        Habitat h = new Habitat(UUID.randomUUID(), "Costa", "Frío", "Algas", new LinkedHashSet<>(Set.of("América")));
        assertThatThrownBy(() -> h.getContinentes().add("Europa")).isInstanceOf(UnsupportedOperationException.class);
        Itinerario it = new Itinerario(UUID.randomUUID(), "IT-01", 45, BigDecimal.ONE, 10, List.of(especie("Pez", arrecife)));
        assertThatThrownBy(() -> it.getEspecies().clear()).isInstanceOf(UnsupportedOperationException.class);
    }

    @Test
    void elGuiaTienePermisosDeGuiaYNoDeAdministrador() {
        Guia g = new Guia(UUID.randomUUID(), "guia.x", "{bcrypt}x", "Guía", "Calle 1", "11 5555-0000", LocalDate.of(2024, 1, 1));
        assertThat(g.getPermisos()).contains(Permiso.VER_RECORRIDOS_PROPIOS).doesNotContain(Permiso.ADMINISTRAR_PARQUE);
        assertThat(g.comoEmpleado()).isPresent();
    }

    @Test
    void elEmpleadoValidaTelefonoYFechaDeIngreso() {
        assertThatThrownBy(() -> new Guia(UUID.randomUUID(), "guia.y", "{bcrypt}x", "Guía", "Calle", "abc", LocalDate.of(2024, 1, 1)))
                .isInstanceOf(DatoInvalidoException.class);
        assertThatThrownBy(() -> new Guia(UUID.randomUUID(), "guia.y", "{bcrypt}x", "Guía", "Calle", "11 5555-0000",
                LocalDate.now().plusDays(1))).isInstanceOf(DatoInvalidoException.class);
    }
}
