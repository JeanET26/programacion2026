package ar.edu.inspt.mundomarino.integracion;

import static org.assertj.core.api.Assertions.assertThat;

import ar.edu.inspt.mundomarino.comun.dao.Dao;
import ar.edu.inspt.mundomarino.comun.dao.EntidadConId;
import ar.edu.inspt.mundomarino.comun.dao.Pagina;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import ar.edu.inspt.mundomarino.especie.Especie;
import ar.edu.inspt.mundomarino.especie.EspecieDao;
import ar.edu.inspt.mundomarino.habitat.Habitat;
import ar.edu.inspt.mundomarino.habitat.HabitatDao;
import ar.edu.inspt.mundomarino.personal.Guia;
import ar.edu.inspt.mundomarino.personal.Usuario;
import ar.edu.inspt.mundomarino.personal.UsuarioDao;
import ar.edu.inspt.mundomarino.soporte.PruebaIntegracion;
import ar.edu.inspt.mundomarino.zona.Zona;
import ar.edu.inspt.mundomarino.zona.ZonaDao;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * <b>Prueba de contrato del DAO genérico.</b> Las mismas pruebas se ejecutan
 * contra cada implementación: cualquier DAO que cumpla {@link Dao} debe pasarlas
 * (sustitución de Liskov aplicada a la persistencia).
 */
class DaoContratoIT extends PruebaIntegracion {

    /** Contrato común: cada subclase indica el DAO, cómo crear una entidad y por qué campo ordenar. */
    abstract class Contrato<T extends EntidadConId> {

        abstract Dao<T, UUID> dao();

        abstract T nueva(int n);

        abstract String campoOrden();

        @Test
        void guardaYRecuperaConElMismoUuid() {
            T e = nueva(1);
            dao().guardar(e);
            assertThat(dao().buscarPorId(e.getId())).isPresent().get().extracting(EntidadConId::getId).isEqualTo(e.getId());
            assertThat(dao().existePorId(e.getId())).isTrue();
            assertThat(dao().buscarPorId(UUID.randomUUID())).isEmpty();
        }

        @Test
        void asignaVersionCeroAlInsertar() {
            T e = dao().guardar(nueva(1));
            assertThat(e.getVersion()).isZero();
        }

        @Test
        void listaPaginadoYOrdenado() {
            for (int i = 5; i >= 1; i--) {
                dao().guardar(nueva(i));
            }
            Pagina<T> p = dao().listar(new SolicitudPagina(0, 2, campoOrden(), true));
            assertThat(p.totalElementos()).isEqualTo(5);
            assertThat(p.totalPaginas()).isEqualTo(3);
            assertThat(p.contenido()).hasSize(2);
            assertThat(dao().listar(new SolicitudPagina(2, 2, campoOrden(), true)).contenido()).hasSize(1);
        }

        @Test
        void eliminaYDejaDeExistir() {
            T e = dao().guardar(nueva(1));
            dao().eliminar(e);
            assertThat(dao().existePorId(e.getId())).isFalse();
        }

        @Test
        void laPaginaDevueltaNoSePuedeModificar() {
            dao().guardar(nueva(1));
            List<T> contenido = dao().listar(new SolicitudPagina(0, 10, campoOrden(), true)).contenido();
            org.assertj.core.api.Assertions.assertThatThrownBy(contenido::clear).isInstanceOf(UnsupportedOperationException.class);
        }
    }

    @Autowired ZonaDao zonas;
    @Autowired HabitatDao habitats;
    @Autowired EspecieDao especies;
    @Autowired UsuarioDao usuarios;

    @Nested
    class ZonaDaoCumpleElContrato extends Contrato<Zona> {
        Dao<Zona, UUID> dao() { return zonas; }
        Zona nueva(int n) { return new Zona(UUID.randomUUID(), "Zona " + n, BigDecimal.valueOf(n)); }
        String campoOrden() { return "nombre"; }
    }

    @Nested
    class HabitatDaoCumpleElContrato extends Contrato<Habitat> {
        Dao<Habitat, UUID> dao() { return habitats; }
        Habitat nueva(int n) { return new Habitat(UUID.randomUUID(), "Hábitat " + n, "Templado", "Algas", Set.of("América")); }
        String campoOrden() { return "nombre"; }
    }

    @Nested
    class EspecieDaoCumpleElContrato extends Contrato<Especie> {
        Dao<Especie, UUID> dao() { return especies; }
        Especie nueva(int n) { return new Especie(UUID.randomUUID(), "Especie " + n, "Cientifica " + n, "Desc", null, List.of()); }
        String campoOrden() { return "nombreEspanol"; }
    }

    @Nested
    class UsuarioDaoCumpleElContrato extends Contrato<Usuario> {
        Dao<Usuario, UUID> dao() { return usuarios; }
        Usuario nueva(int n) {
            return new Guia(UUID.randomUUID(), "guia.c" + n, "{bcrypt}x", "Guía " + n, "Calle", "11 5555-0000", LocalDate.of(2024, 1, 1));
        }
        String campoOrden() { return "nombre"; }
    }
}
