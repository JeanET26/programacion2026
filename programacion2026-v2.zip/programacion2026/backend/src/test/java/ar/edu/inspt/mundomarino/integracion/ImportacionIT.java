package ar.edu.inspt.mundomarino.integracion;

import static org.assertj.core.api.Assertions.assertThat;

import ar.edu.inspt.mundomarino.importacion.ImportadorDatos;
import ar.edu.inspt.mundomarino.importacion.InformeImportacion;
import ar.edu.inspt.mundomarino.soporte.PruebaIntegracion;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.HexFormat;
import java.util.Map;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

/** Importación controlada: todo o nada, sin duplicados, sin referencias rotas, archivos intactos. */
class ImportacionIT extends PruebaIntegracion {

    @Autowired ImportadorDatos importador;
    @Autowired AuthenticationManager autenticador;

    private static Path carpeta(String nombre) throws URISyntaxException {
        return Path.of(ImportacionIT.class.getResource("/importacion/" + nombre).toURI());
    }

    private static Map<String, String> huellas(Path dir) throws IOException {
        Map<String, String> h = new HashMap<>();
        try (Stream<Path> archivos = Files.list(dir)) {
            for (Path p : archivos.toList()) {
                try {
                    h.put(p.getFileName().toString(), HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(p))));
                } catch (java.security.NoSuchAlgorithmException ex) {
                    throw new IllegalStateException(ex);
                }
            }
        }
        return h;
    }

    @Test
    void importaLosDatosDeLaVersion1ConservandoIdsYRelaciones() throws Exception {
        Path dir = carpeta("v1");
        Map<String, String> antes = huellas(dir);
        InformeImportacion informe = importador.importar(dir);

        assertThat(informe.getErrores()).isEmpty();
        assertThat(informe.exitosa()).isTrue();
        assertThat(contar("zona")).isEqualTo(2);
        assertThat(contar("especie")).isEqualTo(4);
        assertThat(contar("itinerario")).isEqualTo(2);
        assertThat(contar("usuario")).isEqualTo(4);
        assertThat(contar("asignacion_guia")).isEqualTo(2);
        assertThat(contar("asignacion_cuidado")).isEqualTo(4);
        assertThat(jdbc.queryForObject("select nombre_usuario from usuario where id = '42e26d33-88d9-425d-bb9d-bcab8b1f0ada'",
                String.class)).isEqualTo("guia.mario");
        // Los usuarios de la v1 no tenían contraseña: quedan bloqueados y se avisa.
        assertThat(informe.getAdvertencias()).anyMatch(a -> a.contains("no tenía contraseña"));
        assertThat(huellas(dir)).isEqualTo(antes); // los archivos originales no se tocan
    }

    @Test
    void importarDosVecesNoDuplicaNiSobrescribe() throws Exception {
        assertThat(importador.importar(carpeta("v1")).exitosa()).isTrue();
        InformeImportacion segunda = importador.importar(carpeta("v1"));
        assertThat(segunda.exitosa()).isFalse();
        assertThat(segunda.getErrores()).anyMatch(e -> e.contains("ya existe en la base"));
        assertThat(contar("zona")).isEqualTo(2);
    }

    @Test
    void unArchivoDanadoCancelaTodaLaImportacion() throws Exception {
        InformeImportacion informe = importador.importar(carpeta("corrupto"));
        assertThat(informe.exitosa()).isFalse();
        assertThat(informe.getErrores()).anyMatch(e -> e.contains("especies.json"));
        assertThat(contar("zona")).isZero(); // ni siquiera las zonas, que estaban bien
    }

    @Test
    void unaReferenciaInexistenteCancelaTodaLaImportacion() throws Exception {
        InformeImportacion informe = importador.importar(carpeta("referencia-inexistente"));
        assertThat(informe.exitosa()).isFalse();
        assertThat(informe.getErrores()).anyMatch(e -> e.contains("zonaId") && e.contains("no existe"));
        assertThat(contar("zona") + contar("especie") + contar("usuario")).isZero();
    }

    @Test
    void horariosSuperpuestosCancelanLaImportacion() throws Exception {
        InformeImportacion informe = importador.importar(carpeta("superpuestos"));
        assertThat(informe.exitosa()).isFalse();
        assertThat(informe.getErrores()).anyMatch(e -> e.contains("superpuestos"));
        assertThat(contar("asignacion_guia")).isZero();
    }

    @Test
    void lasContrasenasDeLaVersion2SiguenFuncionando() throws Exception {
        assertThat(importador.importar(carpeta("v2")).getErrores()).isEmpty();
        var auth = autenticador.authenticate(UsernamePasswordAuthenticationToken.unauthenticated("guia.v2", "Marino2026!"));
        assertThat(auth.isAuthenticated()).isTrue();
        assertThat(jdbc.queryForObject("select hash_contrasena from usuario where nombre_usuario = 'guia.v2'", String.class))
                .startsWith("{bcrypt}"); // se actualizó al entrar
    }

    @Test
    void elInformeIncluyeArchivosHuellasYResultado() throws Exception {
        InformeImportacion informe = importador.importar(carpeta("v1"));
        String md = informe.comoMarkdown("prueba");
        assertThat(md).contains("IMPORTACIÓN CONFIRMADA").contains("zonas.json").contains("SHA-256");
    }
}
