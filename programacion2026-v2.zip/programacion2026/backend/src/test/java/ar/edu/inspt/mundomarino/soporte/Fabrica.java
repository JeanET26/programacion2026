package ar.edu.inspt.mundomarino.soporte;

import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.HorarioAlta;
import ar.edu.inspt.mundomarino.asignacion.AsignacionGuiaService;
import ar.edu.inspt.mundomarino.especie.EspecieDtos.EspecieSolicitud;
import ar.edu.inspt.mundomarino.especie.EspecieService;
import ar.edu.inspt.mundomarino.habitat.HabitatDtos.HabitatSolicitud;
import ar.edu.inspt.mundomarino.habitat.HabitatService;
import ar.edu.inspt.mundomarino.itinerario.ItinerarioDtos.ItinerarioSolicitud;
import ar.edu.inspt.mundomarino.itinerario.ItinerarioService;
import ar.edu.inspt.mundomarino.personal.Administrador;
import ar.edu.inspt.mundomarino.personal.PersonalDtos.EmpleadoAlta;
import ar.edu.inspt.mundomarino.personal.PersonalService;
import ar.edu.inspt.mundomarino.personal.Rol;
import ar.edu.inspt.mundomarino.personal.UsuarioDao;
import ar.edu.inspt.mundomarino.zona.ZonaDtos.ZonaSolicitud;
import ar.edu.inspt.mundomarino.zona.ZonaService;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.UUID;
import org.springframework.boot.test.context.TestComponent;
import org.springframework.security.crypto.password.PasswordEncoder;

/** Crea datos de prueba a través de los servicios reales (respetando todas las reglas). */
@TestComponent
public class Fabrica {

    public static final String CLAVE = "Prueba2026x";

    private final ZonaService zonas;
    private final HabitatService habitats;
    private final EspecieService especies;
    private final ItinerarioService itinerarios;
    private final PersonalService personal;
    private final AsignacionGuiaService horarios;
    private final UsuarioDao usuarios;
    private final PasswordEncoder codificador;

    public Fabrica(ZonaService zonas, HabitatService habitats, EspecieService especies, ItinerarioService itinerarios,
            PersonalService personal, AsignacionGuiaService horarios, UsuarioDao usuarios, PasswordEncoder codificador) {
        this.zonas = zonas;
        this.habitats = habitats;
        this.especies = especies;
        this.itinerarios = itinerarios;
        this.personal = personal;
        this.horarios = horarios;
        this.usuarios = usuarios;
        this.codificador = codificador;
    }

    public UUID zona(String nombre) {
        return zonas.crear(new ZonaSolicitud(nombre, new BigDecimal("100"), null)).id();
    }

    public UUID habitat(String nombre) {
        return habitats.crear(new HabitatSolicitud(nombre, "Templado", "Algas", List.of("América"), null)).id();
    }

    public UUID especie(String nombre, UUID zonaId) {
        return especies.crear(new EspecieSolicitud(nombre, "Cientifica " + nombre, "Descripción", zonaId, List.of(), null)).id();
    }

    public UUID itinerario(int numero, int duracion, UUID... especieIds) {
        return itinerarios.crear(new ItinerarioSolicitud(numero, duracion, new BigDecimal("1.5"), 20, List.of(especieIds), null)).id();
    }

    public UUID guia(String usuario) {
        return personal.crear(new EmpleadoAlta(Rol.GUIA, usuario, CLAVE, "Guía " + usuario, "Calle 1", "11 5555-0000",
                LocalDate.of(2024, 1, 1))).id();
    }

    public UUID cuidador(String usuario) {
        return personal.crear(new EmpleadoAlta(Rol.CUIDADOR, usuario, CLAVE, "Cuidador " + usuario, "Calle 2",
                "11 5555-0001", LocalDate.of(2024, 1, 1))).id();
    }

    public UUID administrador(String usuario) {
        UUID id = UUID.randomUUID();
        usuarios.guardar(new Administrador(id, usuario, codificador.encode(CLAVE), "Admin " + usuario));
        return id;
    }

    public UUID horario(UUID guiaId, UUID itinerarioId, LocalTime hora) {
        return horarios.asignar(new HorarioAlta(guiaId, itinerarioId, hora)).id();
    }
}
