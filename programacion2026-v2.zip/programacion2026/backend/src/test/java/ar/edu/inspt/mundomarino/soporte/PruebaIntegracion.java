package ar.edu.inspt.mundomarino.soporte;

import java.sql.Statement;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;

/**
 * Base de las pruebas de integración: contexto completo de Spring + MySQL en
 * Docker. Antes de cada prueba se vacían las tablas (no el esquema).
 */
@SpringBootTest
@ActiveProfiles("test")
@Import({ContenedoresPrueba.class, Fabrica.class})
public abstract class PruebaIntegracion {

    private static final String[] TABLAS = {
        "asignacion_cuidado", "asignacion_guia", "itinerario_especie", "itinerario", "especie_habitat",
        "especie", "habitat_continente", "habitat", "zona", "usuario",
        "SPRING_SESSION_ATTRIBUTES", "SPRING_SESSION"
    };

    @Autowired
    protected JdbcTemplate jdbc;

    @Autowired
    protected Fabrica fabrica;

    @BeforeEach
    void vaciarTablas() {
        vaciar(TABLAS);
    }

    /** Todo en UNA conexión: SET FOREIGN_KEY_CHECKS vale solo para la conexión que lo ejecuta. */
    protected void vaciar(String... tablas) {
        jdbc.execute((ConnectionCallback<Void>) con -> {
            try (Statement st = con.createStatement()) {
                st.execute("SET FOREIGN_KEY_CHECKS = 0");
                for (String t : tablas) {
                    st.execute("TRUNCATE TABLE " + t);
                }
                st.execute("SET FOREIGN_KEY_CHECKS = 1");
            }
            return null;
        });
    }

    protected int contar(String tabla) {
        Integer n = jdbc.queryForObject("select count(*) from " + tabla, Integer.class);
        return n == null ? 0 : n;
    }
}
