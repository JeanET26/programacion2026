package ar.edu.inspt.mundomarino.integracion;

import static org.assertj.core.api.Assertions.assertThat;

import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import ar.edu.inspt.mundomarino.especie.EspecieService;
import ar.edu.inspt.mundomarino.soporte.ClienteHttp;
import ar.edu.inspt.mundomarino.soporte.PruebaHttp;
import jakarta.persistence.EntityManagerFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import org.hibernate.SessionFactory;
import org.hibernate.stat.Statistics;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Volúmenes representativos y pedidos concurrentes. No mide "cuántos usuarios
 * soporta" (eso requiere pruebas de carga en el entorno real); verifica que
 * la cantidad de consultas no crece con la cantidad de datos (sin N+1) y
 * que muchas peticiones simultáneas responden bien.
 */
class VolumenIT extends PruebaHttp {

    @Autowired EspecieService especies;
    @Autowired EntityManagerFactory emf;

    private void cargarEspecies(int cantidad) {
        UUID zona = fabrica.zona("Zona grande");
        UUID h1 = fabrica.habitat("Hábitat 1");
        UUID h2 = fabrica.habitat("Hábitat 2");
        List<Object[]> filas = new ArrayList<>();
        List<Object[]> relaciones = new ArrayList<>();
        for (int i = 0; i < cantidad; i++) {
            String id = UUID.randomUUID().toString();
            filas.add(new Object[] {id, String.format("Especie %05d", i), "Cientifica " + i, "Descripción", zona.toString()});
            relaciones.add(new Object[] {id, (i % 2 == 0 ? h1 : h2).toString()});
        }
        jdbc.batchUpdate("insert into especie (id, nombre_espanol, nombre_cientifico, descripcion, zona_id) values (?, ?, ?, ?, ?)", filas);
        jdbc.batchUpdate("insert into especie_habitat (especie_id, habitat_id) values (?, ?)", relaciones);
    }

    @Test
    void unaPaginaUsaPocasConsultasAunqueHayaMilesDeRegistros() {
        cargarEspecies(3000);
        Statistics stats = emf.unwrap(SessionFactory.class).getStatistics();
        stats.clear();
        var pagina = especies.listar(null, null, new SolicitudPagina(10, 50, "nombreEspanol", true));
        assertThat(pagina.contenido()).hasSize(50);
        assertThat(pagina.totalElementos()).isEqualTo(3000);
        // 1 página (con la zona por JOIN) + 1 conteo + 1 lote de hábitats. Sin batch serían 50+ consultas.
        assertThat(stats.getPrepareStatementCount()).isLessThanOrEqualTo(4);
    }

    @Test
    void cincuentaPeticionesSimultaneasRespondenBien() throws Exception {
        cargarEspecies(500);
        ClienteHttp admin = comoAdministrador();
        ExecutorService ejecutor = Executors.newFixedThreadPool(16);
        List<Future<Integer>> respuestas = new ArrayList<>();
        for (int i = 0; i < 50; i++) {
            int pagina = i % 10;
            respuestas.add(ejecutor.submit(() -> admin.get("/api/especies?tamanio=20&pagina=" + pagina).estado()));
        }
        for (Future<Integer> r : respuestas) {
            assertThat(r.get(60, TimeUnit.SECONDS)).isEqualTo(200);
        }
        ejecutor.shutdown();
    }
}
