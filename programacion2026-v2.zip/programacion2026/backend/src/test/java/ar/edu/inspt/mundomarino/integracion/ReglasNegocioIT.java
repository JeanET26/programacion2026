package ar.edu.inspt.mundomarino.integracion;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import ar.edu.inspt.mundomarino.asignacion.AsignacionCuidadoService;
import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.CuidadoAlta;
import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.HorarioAlta;
import ar.edu.inspt.mundomarino.asignacion.AsignacionDtos.HorarioCambio;
import ar.edu.inspt.mundomarino.asignacion.AsignacionGuiaService;
import ar.edu.inspt.mundomarino.asignacion.MiPanelService;
import ar.edu.inspt.mundomarino.comun.dao.SolicitudPagina;
import ar.edu.inspt.mundomarino.comun.error.DatoInvalidoException;
import ar.edu.inspt.mundomarino.comun.error.ReglaNegocioException;
import ar.edu.inspt.mundomarino.especie.EspecieDtos.EspecieRespuesta;
import ar.edu.inspt.mundomarino.especie.EspecieDtos.EspecieSolicitud;
import ar.edu.inspt.mundomarino.especie.EspecieService;
import ar.edu.inspt.mundomarino.itinerario.ItinerarioDtos.ItinerarioRespuesta;
import ar.edu.inspt.mundomarino.itinerario.ItinerarioDtos.ItinerarioSolicitud;
import ar.edu.inspt.mundomarino.itinerario.ItinerarioService;
import ar.edu.inspt.mundomarino.personal.PersonalService;
import ar.edu.inspt.mundomarino.soporte.PruebaIntegracion;
import ar.edu.inspt.mundomarino.zona.ZonaService;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;

/** Reglas que deben conservarse, probadas a través de los servicios contra MySQL. */
class ReglasNegocioIT extends PruebaIntegracion {

    @Autowired ZonaService zonas;
    @Autowired EspecieService especies;
    @Autowired ItinerarioService itinerarios;
    @Autowired PersonalService personal;
    @Autowired AsignacionGuiaService horarios;
    @Autowired AsignacionCuidadoService cuidados;
    @Autowired MiPanelService miPanel;

    @Test
    void lasZonasDelItinerarioSeDerivanYSeActualizanAlMoverUnaEspecie() {
        UUID arrecife = fabrica.zona("Arrecife");
        UUID tunel = fabrica.zona("Túnel");
        UUID pez = fabrica.especie("Pez", arrecife);
        UUID tiburon = fabrica.especie("Tiburón", tunel);
        UUID it = fabrica.itinerario(1, 45, pez, tiburon);
        assertThat(itinerarios.obtener(it).zonas()).containsExactly("Arrecife", "Túnel");

        UUID costa = fabrica.zona("Costa");
        EspecieRespuesta e = especies.obtener(tiburon);
        especies.actualizar(tiburon, new EspecieSolicitud(e.nombreEspanol(), e.nombreCientifico(), e.descripcion(), costa,
                List.of(), e.version()));
        assertThat(itinerarios.obtener(it).zonas()).containsExactly("Arrecife", "Costa");
    }

    @Test
    void unItinerarioNecesitaEspeciesUbicadasEnUnaZona() {
        UUID sinZona = fabrica.especie("Raya", null);
        assertThatThrownBy(() -> fabrica.itinerario(1, 45, sinZona)).isInstanceOf(DatoInvalidoException.class);
        assertThatThrownBy(() -> itinerarios.crear(new ItinerarioSolicitud(1, 45, BigDecimal.ONE, 10, List.of(), null)))
                .isInstanceOf(DatoInvalidoException.class);
        assertThatThrownBy(() -> fabrica.itinerario(2, 45, UUID.randomUUID())).isInstanceOf(DatoInvalidoException.class);
        assertThat(contar("itinerario")).isZero();
    }

    @Test
    void noSePuedeQuitarLaZonaAUnaEspecieQueEstaEnUnItinerario() {
        UUID pez = fabrica.especie("Pez", fabrica.zona("Arrecife"));
        fabrica.itinerario(1, 45, pez);
        EspecieRespuesta e = especies.obtener(pez);
        assertThatThrownBy(() -> especies.actualizar(pez, new EspecieSolicitud(e.nombreEspanol(), e.nombreCientifico(),
                e.descripcion(), null, List.of(), e.version()))).isInstanceOf(ReglaNegocioException.class);
        assertThat(especies.obtener(pez).zonaId()).isNotNull();
    }

    @Test
    void elCodigoDeItinerarioNoSeRepite() {
        UUID pez = fabrica.especie("Pez", fabrica.zona("Arrecife"));
        fabrica.itinerario(1, 45, pez);
        assertThatThrownBy(() -> fabrica.itinerario(1, 30, pez)).isInstanceOf(ReglaNegocioException.class);
    }

    @Test
    void lasEliminacionesRespetanLasRelaciones() {
        UUID zona = fabrica.zona("Arrecife");
        UUID pez = fabrica.especie("Pez", zona);
        UUID it = fabrica.itinerario(1, 45, pez);
        UUID guia = fabrica.guia("guia.a");
        fabrica.horario(guia, it, LocalTime.of(10, 0));

        assertThatThrownBy(() -> zonas.eliminar(zona)).isInstanceOf(DataIntegrityViolationException.class);
        assertThatThrownBy(() -> especies.eliminar(pez)).isInstanceOf(DataIntegrityViolationException.class);
        assertThatThrownBy(() -> itinerarios.eliminar(it)).isInstanceOf(DataIntegrityViolationException.class);
        assertThatThrownBy(() -> personal.eliminar(guia)).isInstanceOf(DataIntegrityViolationException.class);
        assertThat(contar("zona")).isEqualTo(1);
        assertThat(contar("usuario")).isEqualTo(1);
    }

    @Test
    void unGuiaNoPuedeTenerRecorridosSuperpuestosPeroSiContiguos() {
        UUID pez = fabrica.especie("Pez", fabrica.zona("Arrecife"));
        UUID it1 = fabrica.itinerario(1, 45, pez);
        UUID it2 = fabrica.itinerario(2, 30, pez);
        UUID guia = fabrica.guia("guia.a");
        fabrica.horario(guia, it1, LocalTime.of(10, 0));

        assertThatThrownBy(() -> fabrica.horario(guia, it2, LocalTime.of(10, 30))).isInstanceOf(ReglaNegocioException.class);
        assertThatThrownBy(() -> fabrica.horario(guia, it2, LocalTime.of(9, 45))).isInstanceOf(ReglaNegocioException.class);
        fabrica.horario(guia, it2, LocalTime.of(10, 45)); // empieza justo cuando termina el anterior
        fabrica.horario(guia, it2, LocalTime.of(9, 30));  // termina justo cuando empieza el siguiente
        assertThat(contar("asignacion_guia")).isEqualTo(3);
    }

    @Test
    void cambiarLaHoraRespetaLaRegla() {
        UUID pez = fabrica.especie("Pez", fabrica.zona("Arrecife"));
        UUID it = fabrica.itinerario(1, 45, pez);
        UUID guia = fabrica.guia("guia.a");
        fabrica.horario(guia, it, LocalTime.of(10, 0));
        UUID tarde = fabrica.horario(guia, it, LocalTime.of(15, 0));

        assertThatThrownBy(() -> horarios.cambiarHora(tarde, new HorarioCambio(LocalTime.of(10, 15), 0L)))
                .isInstanceOf(ReglaNegocioException.class);
        assertThat(horarios.cambiarHora(tarde, new HorarioCambio(LocalTime.of(11, 0), 0L)).hora()).isEqualTo(LocalTime.of(11, 0));
        assertThatThrownBy(() -> horarios.cambiarHora(tarde, new HorarioCambio(LocalTime.of(23, 30), 1L)))
                .isInstanceOf(ReglaNegocioException.class);
    }

    @Test
    void alargarUnItinerarioNoPuedeSuperponerHorariosDeSusGuias() {
        UUID pez = fabrica.especie("Pez", fabrica.zona("Arrecife"));
        UUID it1 = fabrica.itinerario(1, 45, pez);
        UUID it2 = fabrica.itinerario(2, 30, pez);
        UUID guia = fabrica.guia("guia.a");
        fabrica.horario(guia, it1, LocalTime.of(10, 0));
        fabrica.horario(guia, it2, LocalTime.of(11, 0));

        ItinerarioRespuesta actual = itinerarios.obtener(it1);
        assertThatThrownBy(() -> itinerarios.actualizar(it1, solicitud(actual, 90))).isInstanceOf(ReglaNegocioException.class);
        assertThat(itinerarios.obtener(it1).duracionMinutos()).isEqualTo(45);
        assertThat(itinerarios.actualizar(it1, solicitud(actual, 60)).duracionMinutos()).isEqualTo(60); // termina 11:00 justo
    }

    @Test
    void lasAsignacionesValidanReferenciasYRoles() {
        UUID pez = fabrica.especie("Pez", fabrica.zona("Arrecife"));
        UUID it = fabrica.itinerario(1, 45, pez);
        UUID cuidador = fabrica.cuidador("cuidador.a");
        UUID guia = fabrica.guia("guia.a");
        assertThatThrownBy(() -> horarios.asignar(new HorarioAlta(cuidador, it, LocalTime.of(10, 0))))
                .isInstanceOf(DatoInvalidoException.class);
        assertThatThrownBy(() -> cuidados.asignar(new CuidadoAlta(guia, pez, LocalDate.now())))
                .isInstanceOf(DatoInvalidoException.class);
        cuidados.asignar(new CuidadoAlta(cuidador, pez, LocalDate.now()));
        assertThatThrownBy(() -> cuidados.asignar(new CuidadoAlta(cuidador, pez, LocalDate.now())))
                .isInstanceOf(ReglaNegocioException.class);
    }

    @Test
    void cadaEmpleadoVeSoloLoSuyo() {
        UUID pez = fabrica.especie("Pez", fabrica.zona("Arrecife"));
        UUID it = fabrica.itinerario(1, 45, pez);
        UUID lucia = fabrica.guia("guia.lucia");
        UUID martin = fabrica.guia("guia.martin");
        fabrica.horario(lucia, it, LocalTime.of(10, 0));
        fabrica.horario(martin, it, LocalTime.of(12, 0));
        UUID diego = fabrica.cuidador("cuidador.diego");
        UUID sofia = fabrica.cuidador("cuidador.sofia");
        cuidados.asignar(new CuidadoAlta(diego, pez, LocalDate.of(2025, 1, 1)));
        cuidados.asignar(new CuidadoAlta(sofia, pez, LocalDate.of(2025, 2, 1)));

        assertThat(miPanel.misRecorridos(lucia)).singleElement()
                .satisfies(r -> assertThat(r.hora()).isEqualTo(LocalTime.of(10, 0)));
        assertThat(miPanel.misEspecies(diego)).singleElement()
                .satisfies(e -> assertThat(e.otrosCuidadores()).containsExactly("Cuidador cuidador.sofia"));
        assertThat(miPanel.misRecorridos(diego)).isEmpty();
    }

    @Test
    void elListadoEsPaginadoYFiltradoEnLaBase() {
        for (int i = 0; i < 25; i++) {
            fabrica.zona(String.format("Zona %02d", i));
        }
        var pagina = zonas.listar("zona 1", new SolicitudPagina(0, 5, "nombre", true));
        assertThat(pagina.totalElementos()).isEqualTo(10); // Zona 10 a Zona 19
        assertThat(pagina.contenido()).hasSize(5);
        assertThat(pagina.totalPaginas()).isEqualTo(2);
        assertThat(pagina.contenido().get(0).nombre()).isEqualTo("Zona 10");
    }

    private static ItinerarioSolicitud solicitud(ItinerarioRespuesta r, int duracion) {
        return new ItinerarioSolicitud(null, duracion, r.longitudKm(), r.maximoVisitantes(),
                r.especies().stream().map(o -> o.id()).toList(), r.version());
    }
}
