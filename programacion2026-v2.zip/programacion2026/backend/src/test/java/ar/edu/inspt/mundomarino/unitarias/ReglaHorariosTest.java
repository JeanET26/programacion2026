package ar.edu.inspt.mundomarino.unitarias;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import ar.edu.inspt.mundomarino.asignacion.ReglaHorarios;
import ar.edu.inspt.mundomarino.comun.error.ReglaNegocioException;
import java.time.LocalTime;
import org.junit.jupiter.api.Test;

/** Regla de horarios aislada: sin base de datos ni Spring. */
class ReglaHorariosTest {

    private static LocalTime h(int hora, int minuto) {
        return LocalTime.of(hora, minuto);
    }

    @Test
    void recorridosQueSeCruzanSeSuperponen() {
        assertThat(ReglaHorarios.seSuperponen(h(10, 0), 45, h(10, 30), 30)).isTrue();
        assertThat(ReglaHorarios.seSuperponen(h(10, 30), 30, h(10, 0), 45)).isTrue();
    }

    @Test
    void unoDentroDelOtroSeSuperpone() {
        assertThat(ReglaHorarios.seSuperponen(h(9, 0), 180, h(10, 0), 15)).isTrue();
    }

    @Test
    void recorridosContiguosNoSeSuperponen() {
        assertThat(ReglaHorarios.seSuperponen(h(10, 0), 45, h(10, 45), 30)).isFalse();
        assertThat(ReglaHorarios.seSuperponen(h(10, 45), 30, h(10, 0), 45)).isFalse();
    }

    @Test
    void mismaHoraSiempreSeSuperpone() {
        assertThat(ReglaHorarios.seSuperponen(h(15, 0), 5, h(15, 0), 5)).isTrue();
    }

    @Test
    void calculaLaHoraDeFin() {
        assertThat(ReglaHorarios.finDe(h(10, 0), 45)).isEqualTo(h(10, 45));
        assertThat(ReglaHorarios.finDe(h(23, 0), 59)).isEqualTo(h(23, 59));
    }

    @Test
    void rechazaRecorridosQuePasanLaMedianoche() {
        assertThatThrownBy(() -> ReglaHorarios.finDe(h(23, 30), 45)).isInstanceOf(ReglaNegocioException.class);
    }
}
