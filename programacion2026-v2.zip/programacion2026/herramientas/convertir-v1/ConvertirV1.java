import grupoctema12.modelo.*;
import java.nio.file.*;
import java.util.*;

/** Convierte datos_mundo_marino.dat (v1, serializacion Java) al formato JSON v2. Solo lectura del .dat. */
public class ConvertirV1 {
    static String q(Object o) { return o == null ? "null" : "\"" + o.toString().replace("\\", "\\\\").replace("\"", "\\\"") + "\""; }
    static String lista(Collection<?> c) { StringJoiner j = new StringJoiner(",", "[", "]"); c.forEach(x -> j.add(q(x))); return j.toString(); }
    public static void main(String[] a) throws Exception {
        Path dat = Path.of(a[0]), out = Path.of(a[1]);
        Files.createDirectories(out);
        SistemaMundoMarino s = new PersistenciaMundoMarino(dat).cargar().orElseThrow();
        Administrador adm = new Administrador("conversor", "Conversor");
        StringJoiner zonas = new StringJoiner(",\n", "[\n", "\n]");
        for (Zona z : s.listarZonas(adm)) zonas.add("{\"id\":" + q(z.getId()) + ",\"nombre\":" + q(z.getNombre()) + ",\"extensionM2\":" + z.getExtensionMetrosCuadrados() + "}");
        StringJoiner habs = new StringJoiner(",\n", "[\n", "\n]");
        for (Habitat h : s.listarHabitats(adm)) habs.add("{\"id\":" + q(h.getId()) + ",\"nombre\":" + q(h.getNombre()) + ",\"clima\":" + q(h.getClima()) + ",\"vegetacion\":" + q(h.getVegetacionPredominante()) + ",\"continentes\":" + lista(h.getContinentes()) + "}");
        StringJoiner esp = new StringJoiner(",\n", "[\n", "\n]");
        for (Especie e : s.listarEspecies(adm)) {
            List<UUID> hs = new ArrayList<>(); e.getHabitats().forEach(h -> hs.add(h.getId()));
            esp.add("{\"id\":" + q(e.getId()) + ",\"nombreEspanol\":" + q(e.getNombreEspanol()) + ",\"nombreCientifico\":" + q(e.getNombreCientifico()) + ",\"descripcion\":" + q(e.getDescripcionGeneral()) + ",\"zonaId\":" + q(e.getZona() == null ? null : e.getZona().getId()) + ",\"habitatIds\":" + lista(hs) + "}");
        }
        StringJoiner its = new StringJoiner(",\n", "[\n", "\n]");
        for (Itinerario i : s.listarItinerarios(adm)) {
            List<UUID> es = new ArrayList<>(); i.getEspeciesVisitadas().forEach(e -> es.add(e.getId()));
            its.add("{\"id\":" + q(i.getId()) + ",\"codigo\":" + q(i.getCodigo()) + ",\"duracionMinutos\":" + i.getDuracion().toMinutes() + ",\"longitudKm\":" + i.getLongitudKilometros() + ",\"maximoVisitantes\":" + i.getMaximoVisitantes() + ",\"especieIds\":" + lista(es) + "}");
        }
        StringJoiner us = new StringJoiner(",\n", "[\n", "\n]");
        StringJoiner ag = new StringJoiner(",\n", "[\n", "\n]");
        StringJoiner ac = new StringJoiner(",\n", "[\n", "\n]");
        for (Guia g : s.listarGuias(adm)) {
            us.add("{\"id\":" + q(g.getId()) + ",\"rol\":\"GUIA\",\"nombreUsuario\":" + q(g.getNombreUsuario()) + ",\"nombre\":" + q(g.getNombre()) + ",\"direccion\":" + q(g.getDireccion()) + ",\"telefono\":" + q(g.getTelefono()) + ",\"fechaIngreso\":" + q(g.getFechaIngreso()) + "}");
            for (AsignacionGuia x : g.getAsignaciones()) {
                UUID id = UUID.nameUUIDFromBytes(("v1-guia|" + g.getId() + "|" + x.getItinerario().getId() + "|" + x.getHora()).getBytes());
                ag.add("{\"id\":" + q(id) + ",\"guiaId\":" + q(g.getId()) + ",\"itinerarioId\":" + q(x.getItinerario().getId()) + ",\"hora\":" + q(x.getHora()) + "}");
            }
        }
        for (Cuidador c : s.listarCuidadores(adm)) {
            us.add("{\"id\":" + q(c.getId()) + ",\"rol\":\"CUIDADOR\",\"nombreUsuario\":" + q(c.getNombreUsuario()) + ",\"nombre\":" + q(c.getNombre()) + ",\"direccion\":" + q(c.getDireccion()) + ",\"telefono\":" + q(c.getTelefono()) + ",\"fechaIngreso\":" + q(c.getFechaIngreso()) + "}");
            for (AsignacionCuidado x : c.getResponsabilidades()) {
                UUID id = UUID.nameUUIDFromBytes(("v1-cuidado|" + c.getId() + "|" + x.getEspecie().getId()).getBytes());
                ac.add("{\"id\":" + q(id) + ",\"cuidadorId\":" + q(c.getId()) + ",\"especieId\":" + q(x.getEspecie().getId()) + ",\"fechaAsignacion\":" + q(x.getFechaAsignacion()) + "}");
            }
        }
        Files.writeString(out.resolve("zonas.json"), zonas.toString());
        Files.writeString(out.resolve("habitats.json"), habs.toString());
        Files.writeString(out.resolve("especies.json"), esp.toString());
        Files.writeString(out.resolve("itinerarios.json"), its.toString());
        Files.writeString(out.resolve("usuarios.json"), us.toString());
        Files.writeString(out.resolve("asignaciones_guia.json"), ag.toString());
        Files.writeString(out.resolve("asignaciones_cuidado.json"), ac.toString());
        System.out.printf("zonas=%d habitats=%d especies=%d itinerarios=%d guias=%d cuidadores=%d%n",
            s.listarZonas(adm).size(), s.listarHabitats(adm).size(), s.listarEspecies(adm).size(), s.listarItinerarios(adm).size(), s.listarGuias(adm).size(), s.listarCuidadores(adm).size());
    }
}
