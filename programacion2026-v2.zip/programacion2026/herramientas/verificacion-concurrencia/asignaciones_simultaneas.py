import pymysql, threading, uuid, time
def con():
    c = pymysql.connect(host='localhost', user='prueba', password='prueba', database='mm_prueba', autocommit=False)
    c.cursor().execute("SET SESSION innodb_lock_wait_timeout = 5")
    return c
def preparar():
    c = con(); cur = c.cursor()
    cur.execute("SET FOREIGN_KEY_CHECKS=0")
    for t in ['asignacion_guia','itinerario_especie','itinerario','usuario']: cur.execute(f"TRUNCATE TABLE {t}")
    cur.execute("SET FOREIGN_KEY_CHECKS=1")
    cur.execute("INSERT INTO usuario (id,rol,nombre_usuario,hash_contrasena,nombre,direccion,telefono,fecha_ingreso) VALUES ('g1','GUIA','guia.a','x','A','d','11 5555-0000','2024-01-01')")
    cur.execute("INSERT INTO itinerario (id,codigo,duracion_minutos,longitud_km,maximo_visitantes) VALUES ('i1','IT-01',45,1.5,20)")
    c.commit(); c.close()
def superpone(h1,d1,h2,d2): return h1 < h2+d2 and h2 < h1+d1
def asignar(minuto, con_bloqueo, resultados, largada):
    c = con(); cur = c.cursor()
    cur.execute("SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED")
    largada.wait()
    try:
        c.begin()
        if con_bloqueo:
            cur.execute("SELECT id FROM itinerario WHERE id='i1' FOR SHARE")
            cur.execute("SELECT id FROM usuario WHERE id='g1' FOR UPDATE")
        cur.execute("SELECT TIME_TO_SEC(a.hora)/60, i.duracion_minutos FROM asignacion_guia a JOIN itinerario i ON i.id=a.itinerario_id WHERE a.guia_id='g1'")
        existentes = cur.fetchall()
        time.sleep(0.05)  # ventana de carrera: entre la consulta y el INSERT
        if any(superpone(600+minuto,45,float(h),d) for h,d in existentes):
            c.rollback(); resultados.append('rechazada'); return
        cur.execute("INSERT INTO asignacion_guia (id,guia_id,itinerario_id,hora) VALUES (%s,'g1','i1',SEC_TO_TIME(%s))", (str(uuid.uuid4()), (600+minuto)*60))
        c.commit(); resultados.append('ok')
    except pymysql.MySQLError as e:
        c.rollback(); resultados.append(f'error {e.args[0]}')
    finally: c.close()
for con_bloqueo in (False, True):
    preparar(); res=[]; largada=threading.Barrier(9)
    hilos=[threading.Thread(target=asignar,args=(m*5,con_bloqueo,res,largada)) for m in range(9)]
    [h.start() for h in hilos]; [h.join() for h in hilos]
    c=con(); cur=c.cursor(); cur.execute("SELECT COUNT(*) FROM asignacion_guia"); n=cur.fetchone()[0]; c.close()
    print(("CON bloqueo FOR UPDATE del guía" if con_bloqueo else "SIN bloqueo (solo consulta previa)") + f": aceptadas={res.count('ok')} filas en la base={n} detalle={sorted(set(res))}")
