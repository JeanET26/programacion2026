import pymysql, threading, uuid, time
def con():
    c = pymysql.connect(host='localhost', user='prueba', password='prueba', database='mm_prueba', autocommit=False)
    cur=c.cursor(); cur.execute("SET SESSION innodb_lock_wait_timeout = 5"); cur.execute("SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED"); return c
def preparar():
    c = con(); cur = c.cursor(); cur.execute("SET FOREIGN_KEY_CHECKS=0")
    for t in ['asignacion_guia','itinerario','usuario']: cur.execute(f"TRUNCATE TABLE {t}")
    cur.execute("SET FOREIGN_KEY_CHECKS=1")
    cur.execute("INSERT INTO usuario (id,rol,nombre_usuario,hash_contrasena,nombre,direccion,telefono,fecha_ingreso) VALUES ('g1','GUIA','guia.a','x','A','d','11 5555-0000','2024-01-01')")
    cur.execute("INSERT INTO itinerario (id,codigo,duracion_minutos,longitud_km,maximo_visitantes) VALUES ('i1','IT-01',45,1.5,20),('i2','IT-02',30,1,20)")
    cur.execute("INSERT INTO asignacion_guia (id,guia_id,itinerario_id,hora) VALUES ('a1','g1','i1','10:00:00')")
    c.commit(); c.close()
def horarios(cur):
    cur.execute("SELECT a.itinerario_id, TIME_TO_SEC(a.hora)/60, i.duracion_minutos FROM asignacion_guia a JOIN itinerario i ON i.id=a.itinerario_id WHERE a.guia_id='g1'")
    return cur.fetchall()
def sup(a,b): return a[1] < b[1]+b[2] and b[1] < a[1]+a[2]
def alargar(res, largada):
    c=con(); cur=c.cursor(); largada.wait()
    try:
        c.begin(); cur.execute("SELECT id FROM itinerario WHERE id='i1' FOR UPDATE")
        cur.execute("SELECT DISTINCT guia_id FROM asignacion_guia WHERE itinerario_id='i1' ORDER BY guia_id")
        for (g,) in cur.fetchall(): cur.execute("SELECT id FROM usuario WHERE id=%s FOR UPDATE", (g,))
        hs=[(i,float(h),90 if i=='i1' else d) for i,h,d in horarios(cur)]; time.sleep(0.03)
        if any(sup(a,b) for x,a in enumerate(hs) for b in hs[x+1:]): c.rollback(); res.append('alargar rechazado'); return
        cur.execute("UPDATE itinerario SET duracion_minutos=90 WHERE id='i1'"); c.commit(); res.append('alargar ok')
    except pymysql.MySQLError as e: c.rollback(); res.append(f'alargar error {e.args[0]}')
    finally: c.close()
def asignar(res, largada):
    c=con(); cur=c.cursor(); largada.wait()
    try:
        c.begin(); cur.execute("SELECT id FROM itinerario WHERE id='i2' FOR SHARE"); cur.execute("SELECT id FROM usuario WHERE id='g1' FOR UPDATE")
        hs=[(i,float(h),d) for i,h,d in horarios(cur)]; time.sleep(0.03)
        if any(sup(('i2',660,30),b) for b in hs): c.rollback(); res.append('asignar rechazado'); return
        cur.execute("INSERT INTO asignacion_guia (id,guia_id,itinerario_id,hora) VALUES (%s,'g1','i2','11:00:00')",(str(uuid.uuid4()),)); c.commit(); res.append('asignar ok')
    except pymysql.MySQLError as e: c.rollback(); res.append(f'asignar error {e.args[0]}')
    finally: c.close()
conteo={}; violaciones=0
for ronda in range(30):
    preparar(); res=[]; b=threading.Barrier(2)
    t=[threading.Thread(target=alargar,args=(res,b)), threading.Thread(target=asignar,args=(res,b))]; [x.start() for x in t]; [x.join() for x in t]
    c=con(); cur=c.cursor(); hs=[(i,float(h),d) for i,h,d in horarios(cur)]; c.close()
    if any(sup(a,b2) for x,a in enumerate(hs) for b2 in hs[x+1:]): violaciones+=1
    k=' + '.join(sorted(res)); conteo[k]=conteo.get(k,0)+1
print("30 rondas alargar(IT-01 a 90 min) vs asignar(11:00):", conteo)
print("Rondas que terminaron con horarios superpuestos en la base:", violaciones)
