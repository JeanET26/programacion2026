# Guía paso a paso: cómo funciona el sistema

Esta guía sigue **un caso concreto** de punta a punta: el administrador le
asigna a la guía Lucía el itinerario IT-02 a las 11:00. En el camino se
explica cada tecnología y cada decisión. Al terminar deberías poder contestar
"¿qué pasa cuando aprieto Guardar?".

Diagrama del recorrido completo: `docs/diagramas/secuencia_asignacion.png`.

---

## 0. Las piezas y cómo se construyen

```text
programacion2026/
├── backend/    Java 21 + Spring Boot (API REST)      → se construye con Maven
├── frontend/   React + Vite (pantallas)              → se construye con npm
├── docs/       diagramas y documentación
└── docker-compose.yml   MySQL 8 para desarrollo
```

**Maven** es la herramienta que construye el backend. Lee `backend/pom.xml`,
donde están las **dependencias** (Spring Boot, Hibernate, el driver de MySQL...),
las descarga y compila, prueba y empaqueta. Reemplaza al `build.xml` de Ant
que generaba NetBeans: ahora el proyecto se construye igual en cualquier
computadora con `./mvnw verify`. `mvnw` es el *Maven Wrapper*: descarga la
versión exacta de Maven que usa el proyecto, así no hace falta instalarla.

**Spring Boot** es el framework del backend. Con
`@SpringBootApplication` (`MundoMarinoApplication.java`), Spring:
1. busca las clases marcadas `@RestController`, `@Service`, `@Repository`, `@Component`;
2. **crea un objeto de cada una** y le pasa por el constructor los otros objetos
   que pide (**inyección de dependencias**);
3. levanta un servidor web (Tomcat) en el puerto 8080;
4. configura la base, las transacciones, la seguridad y la conversión JSON.

**React** es la biblioteca del frontend: la pantalla se arma con
**componentes** (funciones que devuelven HTML) y, cuando cambian los datos, React
actualiza la pantalla solo. **Vite** es el servidor de desarrollo y el
empaquetador (`npm run build` genera archivos estáticos en `frontend/dist`).

Backend y frontend son **dos programas separados**: se construyen y se publican
por separado, y se comunican solo por HTTP con JSON.

---

## 1. El formulario (React)

Archivo: `frontend/src/paginas/admin/secciones.jsx`, sección `horarios`.

```js
campos: (a) => [
  { nombre: 'guiaId', tipo: 'seleccion', requerido: true, opciones: opciones('/api/empleados/opciones?rol=GUIA') },
  { nombre: 'itinerarioId', tipo: 'seleccion', requerido: true, opciones: opciones('/api/itinerarios/opciones') },
  { nombre: 'hora', tipo: 'hora', requerido: true, valor: '10:00' },
]
```

`SeccionCrud.jsx` muestra la tabla y, al tocar **+ Asignar horario**, abre
`Formulario.jsx`. El formulario pide al servidor las listas de guías e
itinerarios. Al tocar **Guardar**:

1. Valida lo básico en el navegador (campos obligatorios). Es solo comodidad:
   **la validación que cuenta es la del servidor**.
2. Llama a `api.post('/api/asignaciones-guia', { guiaId, itinerarioId, hora: '11:00' })`.
3. Mientras espera muestra **"Guardando…"** y desactiva el botón.
4. Si el servidor responde con error, muestra el mensaje **dentro** del
   formulario y no lo cierra. Si responde bien, muestra **"Registro creado."** y
   recarga la tabla.

## 2. La llamada HTTP (cliente de la API)

Archivo: `frontend/src/api/cliente.js`. Es el **único** lugar que habla con el backend.

```http
POST /api/asignaciones-guia
Content-Type: application/json
X-CSRF-TOKEN: 8f1c...            ← token anti-CSRF
Cookie: MMSESION=YzM0...         ← la pone el navegador solo (HttpOnly)

{"guiaId":"…","itinerarioId":"…","hora":"11:00"}
```

**API REST:** el backend expone **recursos** en URLs (`/api/asignaciones-guia`)
y se opera sobre ellos con los verbos HTTP: `GET` lee, `POST` crea, `PUT`
modifica y `DELETE` elimina. El **código de respuesta** dice qué pasó:
`201` creado, `400` dato inválido, `401` sin sesión, `403` sin permiso,
`404` no existe, `409` conflicto con una regla.

**Cookie de sesión:** al iniciar sesión, el servidor guardó la sesión en MySQL
y le dio al navegador solo un identificador en la cookie `MMSESION`, marcada
`HttpOnly` (JavaScript no la puede leer, así un script malicioso no la roba). El
navegador la envía sola en cada pedido (`credentials: 'include'`).

**CSRF:** como la cookie viaja sola, otra página web podría intentar enviar un
formulario a nuestra API "en nombre" del usuario. Para impedirlo, cada
POST/PUT/DELETE debe llevar además un **token** que solo nuestro frontend
conoce (lo obtuvo de `GET /api/auth/csrf`).

## 3. Spring Security (antes de llegar al código)

Archivo: `backend/.../seguridad/SeguridadConfig.java`. Una cadena de filtros
revisa cada pedido **antes** del controlador:

1. **CORS:** si el pedido viene de otro origen, ¿está en la lista permitida? (nunca `*`)
2. **Sesión:** busca la sesión de la cookie en la tabla `SPRING_SESSION` y recupera al usuario.
3. **CSRF:** ¿el encabezado `X-CSRF-TOKEN` coincide con el de la sesión? Si no → **403**.
4. **Autorización:** `/api/asignaciones-guia/**` exige el permiso
   `ADMINISTRAR_PARQUE`. Ana lo tiene (`Administrador.getPermisos()`); un guía
   recibiría **403**. Sin sesión → **401**.

## 4. El controlador y el DTO

Archivo: `backend/.../asignacion/AsignacionController.java`

```java
@PostMapping("/api/asignaciones-guia")
public ResponseEntity<HorarioRespuesta> asignarGuia(@Valid @RequestBody HorarioAlta alta) {
    HorarioRespuesta creada = horarios.asignar(alta);
    return ResponseEntity.created(URI.create("/api/asignaciones-guia/" + creada.id())).body(creada);
}
```

- `@RequestBody`: **Jackson** convierte el JSON en el objeto Java `HorarioAlta`.
- **DTO** (*Data Transfer Object*): `HorarioAlta` y `HorarioRespuesta`
  (`AsignacionDtos.java`) son `record` que definen **exactamente** qué entra y
  qué sale por la API. Las entidades JPA nunca salen del servicio: así no se
  exponen hashes de contraseñas, datos personales ni objetos que se podrían
  modificar saltándose las reglas.
- `@Valid`: aplica las anotaciones del DTO (`@NotNull` en guía, itinerario y
  hora). Si falla, responde **400** con el detalle por campo, sin llegar al servicio.
- El controlador **no tiene reglas ni SQL**: solo traduce HTTP ⇄ servicio.

## 5. El servicio: regla de negocio y transacción

Archivo: `backend/.../asignacion/AsignacionGuiaService.java`

```java
@Transactional(isolation = Isolation.READ_COMMITTED)
public HorarioRespuesta asignar(HorarioAlta alta) {
    Itinerario itinerario = itinerarios.buscarConBloqueoCompartido(alta.itinerarioId())...;  // ①
    Guia guia = usuarios.buscarGuiaParaModificar(alta.guiaId())...;                          // ②
    AsignacionGuia nueva = new AsignacionGuia(UUID.randomUUID(), guia, itinerario, alta.hora()); // ③
    verificador.verificarDisponible(guia.getId(), nueva.getHora(), itinerario.getDuracionMinutos(), null); // ④
    AsignacionGuia guardada = asignaciones.guardar(nueva);                                    // ⑤
    return aRespuesta(guardada);                                                              // ⑥
}
```

**Transacción** (`@Transactional`): todo lo que pasa dentro del método es
**una unidad**. Si termina bien, Spring hace `COMMIT`; si lanza una excepción,
hace `ROLLBACK` y la base queda **exactamente como estaba**. Nunca queda una
asignación a medias.

**Inyección de dependencias:** el servicio no crea sus colaboradores; los
recibe en el constructor:

```java
public AsignacionGuiaService(AsignacionGuiaDao asignaciones, ItinerarioDao itinerarios,
                             UsuarioDao usuarios, VerificadorHorarios verificador)
```

Spring ve que pide un `UsuarioDao` (una **interfaz**), encuentra la
implementación `UsuarioDaoJpa` y se la pasa. Es la **D de SOLID**: el servicio
depende de la abstracción, no de JPA.

Paso a paso:

- **① y ② Bloqueos.** ¿Qué pasa si dos administradores asignan a Lucía al
  mismo tiempo, uno a las 11:00 y otro a las 11:15? Si cada uno solo
  *consultara* "¿está libre?", los dos verían que sí y los dos guardarían.
  Para evitarlo:
  - ② lee la fila de Lucía con **`SELECT … FOR UPDATE`**: el segundo
    administrador **espera** a que el primero termine (solo si es la MISMA
    guía; con otros guías no hay espera).
  - ① lee el itinerario con **`FOR SHARE`**: nadie puede cambiarle la duración
    mientras tanto.
  - `READ_COMMITTED`: después de esperar, la consulta ve lo que el otro confirmó.
  - Detalle y pruebas en `docs/CONCURRENCIA.md`.
- **③ UUID.** El id se genera en Java (`UUID.randomUUID()`) antes de guardar.
- **④ Regla.** `VerificadorHorarios` trae los horarios de Lucía y aplica
  `ReglaHorarios.seSuperponen(...)`. Si IT-01 a las 10:00 dura 45 minutos
  (termina 10:45), IT-02 a las 11:00 no se superpone. Si se superpusiera, lanza
  `ReglaNegocioException` → rollback → **409** con el mensaje.
- **⑤ Guardar** por medio del **DAO**.
- **⑥** Se arma el DTO de respuesta **dentro** de la transacción.

## 6. El DAO, el repositorio JPA e Hibernate

```text
AsignacionGuiaService ──▶ AsignacionGuiaDao (interfaz: CONTRATO)
                              ▲ implementa
                         AsignacionGuiaDaoJpa extends DaoJpa  (ADAPTADOR)
                              │ delega
                         AsignacionGuiaRepositorio extends JpaRepository (Spring Data)
                              │
                         Hibernate (JPA) ──SQL──▶ MySQL
```

- **DAO** (*Data Access Object*): el contrato que usan los servicios para
  guardar y buscar. `Dao<T, ID>` es el **contrato genérico** (buscar por id,
  listar paginado, guardar, eliminar) y `AsignacionGuiaDao` agrega lo
  específico (`buscarPorGuia`).
- **JPA** (*Jakarta Persistence API*): el estándar de Java para mapear clases a
  tablas con anotaciones: `@Entity`, `@Table(name = "asignacion_guia")`,
  `@ManyToOne` para `guia_id`, `@Version` para el control de cambios.
- **Hibernate**: la implementación de JPA que traduce las operaciones sobre
  objetos a SQL. `guardar(nueva)` termina en:

```sql
INSERT INTO asignacion_guia (hora, guia_id, itinerario_id, version, id)
VALUES ('11:00:00', '6b1f…', '9c2a…', 0, '3589334b-…');
```

- **Spring Data JPA**: genera la implementación de `AsignacionGuiaRepositorio`.
  Por ejemplo, la consulta con `@Query("select a from AsignacionGuia a join fetch a.itinerario where a.guia.id = :guiaId")`
  trae cada horario **con** su itinerario en un solo SELECT (sin N+1).

## 7. MySQL: lo que garantiza la base

Esquema: `backend/src/main/resources/db/migration/V1__esquema_inicial.sql`,
aplicado por **Flyway** al arrancar (migraciones **versionadas**: V1, V2...; nunca
se edita una migración ya aplicada, se agrega una nueva).

En la tabla `asignacion_guia`:
- `PRIMARY KEY (id)`: el UUID como texto `CHAR(36)`.
- `FOREIGN KEY (guia_id) REFERENCES usuario(id) ON DELETE RESTRICT`: no se puede
  borrar a Lucía mientras tenga horarios.
- `UNIQUE (guia_id, hora)`: red de seguridad; aunque fallara todo lo anterior,
  la base no acepta dos salidas de Lucía a la misma hora.

Hibernate arranca con `ddl-auto: validate`: **no crea tablas**, solo verifica
que las entidades coincidan con lo que creó Flyway.

## 8. El commit y la respuesta

Al salir de `asignar(...)` sin excepciones, Spring hace **COMMIT**: recién ahí
la asignación es visible para los demás y se liberan los bloqueos. El
controlador responde:

```http
HTTP/1.1 201 Created
Location: /api/asignaciones-guia/3589334b-…
{"id":"3589334b-…","guiaNombre":"Lucía Gómez","itinerarioCodigo":"IT-02","hora":"11:00","horaFin":"11:30","zonas":["Costa austral"],"version":0}
```

El éxito se informa **solo después** del commit. Si el commit fallara, la
respuesta sería un error.

## 9. Lucía ve su nuevo horario

Lucía inicia sesión y su pantalla pide `GET /api/mi/recorridos`. El controlador
**no recibe ningún id**:

```java
public List<RecorridoPropio> misRecorridos(@AuthenticationPrincipal(expression = "id") UUID usuarioId)
```

El id sale de la **sesión del servidor**, no de la URL. Aunque Lucía escriba
`/api/mi/recorridos?guiaId=<id de otro>`, ve solo lo suyo
(prueba: `SeguridadApiIT.cadaGuiaRecibeSoloSusRecorridosSegunLaSesion`).

---

## Resumen de conceptos con este recorrido

| Concepto | Dónde lo viste |
|---|---|
| Maven | `pom.xml`, `./mvnw verify` construye y prueba todo |
| Spring Boot | crea los objetos, levanta el servidor y configura base, seguridad y JSON |
| React | `Formulario.jsx` y `SeccionCrud.jsx` muestran estados y errores |
| API REST | `POST /api/asignaciones-guia` → `201`, `409`, `403` |
| DTO | `HorarioAlta` (entrada) y `HorarioRespuesta` (salida) |
| DAO | `AsignacionGuiaDao` (contrato) y `AsignacionGuiaDaoJpa` (implementación) |
| JPA / Hibernate | `@Entity AsignacionGuia` → `INSERT INTO asignacion_guia` |
| Transacción | `@Transactional`: todo o nada; los bloqueos duran hasta el commit |
| Inyección de dependencias | el constructor de `AsignacionGuiaService` recibe interfaces |
| UUID | `UUID.randomUUID()` en Java → `CHAR(36)` en MySQL |
| SOLID | ver `docs/RESPUESTAS_PROFESOR.md` |
