# Mundo Marino — Sistema del personal (Grupo C, Tema 12)

Sistema interno para el personal de Mundo Marino. **No es para visitantes.**
Entran tres roles:

| Rol | Qué puede hacer |
|---|---|
| **Administrador** | Gestiona zonas, hábitats, especies, itinerarios y personal. Asigna horarios de recorrido a los guías y especies a los cuidadores. |
| **Guía** | Ve **solo sus** horarios y recorridos (itinerario, hora de salida y fin, especies y zonas). |
| **Cuidador** | Ve **solo las** especies que tiene a cargo (con hábitats, zona y compañeros que también la cuidan). |

Todos pueden cambiar su propia contraseña.

> **Sobre la tecnología.** La elección de Maven, Spring Boot, Spring Data JPA,
> Spring Security, Flyway, MySQL y React + Vite es **la propuesta del grupo**
> para cumplir los requisitos (persistencia real, API REST, seguridad, pruebas).
> No es una exigencia de la cátedra respecto de esos frameworks puntuales.

---

## Estructura del repositorio

```
backend/              API REST: Java 21, Spring Boot 3.3, Maven (con Maven Wrapper)
frontend/             Interfaz web: React 18 + Vite 5
docs/                 Documentación técnica y diagramas
datos-importacion/    Datos de la v1 convertidos a JSON (para importar)
herramientas/         Conversor de la v1 y scripts de verificación de concurrencia
respaldo/             Proyecto original Ant (v2) y archivo de datos de la v1, SIN modificar
docker-compose.yml    MySQL 8 para desarrollo
GUIA_PASO_A_PASO.md   Recorrido completo de una asignación, de React a MySQL
CAMBIOS.md            Qué se cambió respecto de la v2 y por qué
```

El proyecto Ant (NetBeans) quedó **solo como respaldo** en `respaldo/v2-ant/`.
La construcción actual es con Maven.

---

## Requisitos

- **JDK 21** (por ejemplo Eclipse Temurin 21). No hace falta instalar Maven: se usa `./mvnw`.
- **Docker** (con Docker Compose) para la base de datos y para las pruebas de integración.
- **Node.js 20** o superior, con npm.

---

## Cómo levantarlo (desarrollo)

Se usan **tres terminales**: base de datos, backend y frontend.

### 1. Base de datos

```bash
cp .env.ejemplo .env          # opcional: cambiar las contraseñas de ejemplo
docker compose up -d          # MySQL 8 en localhost:3306 (solo local)
```

### 2. Backend (http://localhost:8080)

```bash
cd backend
./mvnw spring-boot:run        # Windows: mvnw.cmd spring-boot:run
```

- Usa el perfil `dev` por defecto.
- **Flyway** crea las tablas al arrancar (`db/migration/V1__…`, `V2__…`). Hibernate **no** crea
  ni modifica tablas: solo valida que coincidan (`ddl-auto: validate`).
- Con la base **vacía**, el perfil `dev` carga datos de demostración. Si ya hay usuarios, **no toca nada**.
- Documentación interactiva de la API: http://localhost:8080/swagger-ui.html (solo en `dev`).
- Salud: http://localhost:8080/actuator/health

### 3. Frontend (http://localhost:5173)

```bash
cd frontend
npm install
npm run dev
```

El servidor de Vite reenvía `/api` al backend, así el navegador ve un solo origen.

### Usuarios de demostración (solo perfil `dev`, base vacía)

| Usuario | Contraseña | Rol |
|---|---|---|
| `admin.ana` | `Admin2026!` | Administrador |
| `guia.lucia`, `guia.martin` | `Marino2026!` | Guía |
| `cuidador.diego`, `cuidador.sofia` | `Marino2026!` | Cuidador |

Son datos de prueba: **no** se cargan en producción y **nunca** reemplazan datos existentes.

---

## Pruebas

```bash
cd backend
./mvnw verify          # unitarias + arquitectura + integración con MySQL real (Testcontainers, necesita Docker)
./mvnw test            # solo unitarias y de arquitectura (sin Docker)

cd frontend
npm test               # Vitest + Testing Library (backend simulado con MSW)
npm run build          # construcción de producción en frontend/dist
```

Qué se pudo verificar y qué no al preparar esta entrega: **[docs/VERIFICACION.md](docs/VERIFICACION.md)**.

---

## Configuración y producción

Nada sensible está en el código. Todo se configura con variables de entorno
(ver `backend/.env.ejemplo` y `frontend/.env.ejemplo`):

| Variable | Para qué |
|---|---|
| `DB_URL`, `DB_USUARIO`, `DB_CONTRASENA` | Conexión a MySQL |
| `DB_POOL_MAXIMO` | Tamaño del pool de conexiones (HikariCP) |
| `ORIGENES_PERMITIDOS` | Orígenes del frontend aceptados por CORS (lista; `*` está prohibido) |
| `MM_ADMIN_USUARIO`, `MM_ADMIN_CONTRASENA` | Primer administrador, solo si no existe ninguno |
| `COOKIE_SEGURA`, `COOKIE_SAME_SITE`, `SESION_MINUTOS` | Atributos de la cookie de sesión |
| `VITE_API_URL` | (frontend) URL del backend si se publica en otro dominio |

Producción:

```bash
cd backend && ./mvnw -DskipTests package
SPRING_PROFILES_ACTIVE=prod DB_URL=... DB_USUARIO=... DB_CONTRASENA=... \
ORIGENES_PERMITIDOS=https://personal.ejemplo.com java -jar target/mundo-marino-api.jar

cd frontend && npm ci && npm run build      # publicar frontend/dist en un servidor web
```

En `prod`: cookie `Secure`, Swagger desactivado, sin datos de demostración, todas las variables obligatorias.

---

## Importar los datos de las versiones anteriores

Importación controlada (valida todo, conserva los IDs, detecta duplicados y referencias
faltantes, **no hace importaciones parciales**, no modifica los archivos originales y escribe
un informe). Detalle en [docs/IMPORTACION_RESPALDO.md](docs/IMPORTACION_RESPALDO.md).

```bash
cd backend
./mvnw spring-boot:run -Dspring-boot.run.profiles=dev,importacion \
  -Dspring-boot.run.arguments="--app.importacion.directorio=../datos-importacion/v1-convertido"
```

---

## Documentación

| Documento | Contenido |
|---|---|
| [GUIA_PASO_A_PASO.md](GUIA_PASO_A_PASO.md) | Una asignación de guía de punta a punta: React → REST → Security → controlador → DTO → servicio → DAO → JPA/Hibernate → MySQL |
| [docs/RESPUESTAS_PROFESOR.md](docs/RESPUESTAS_PROFESOR.md) | Respuestas a las correcciones: SOLID, interfaces, inyección, DAO genérico, UUID, `Empleado` abstracta, `Administrador` |
| [docs/ARQUITECTURA.md](docs/ARQUITECTURA.md) | Capas, módulos, DAO vs JpaRepository vs servicio |
| [docs/API.md](docs/API.md) | Endpoints, códigos HTTP, formato de errores |
| [docs/BASE_DE_DATOS.md](docs/BASE_DE_DATOS.md) | Tablas, claves, índices, migraciones |
| [docs/SEGURIDAD.md](docs/SEGURIDAD.md) | Sesiones, contraseñas, roles, CSRF, CORS, cookies |
| [docs/CONCURRENCIA.md](docs/CONCURRENCIA.md) | Transacciones, bloqueos y horarios superpuestos |
| [docs/IMPORTACION_RESPALDO.md](docs/IMPORTACION_RESPALDO.md) | Importación, respaldo y recuperación |
| [docs/ESCALABILIDAD.md](docs/ESCALABILIDAD.md) | Monolito modular, paginación, pool, varias instancias |
| [docs/VERIFICACION.md](docs/VERIFICACION.md) | Qué se verificó y qué no |
| [docs/diagramas/](docs/diagramas/) | Dominio, arquitectura, módulos, base de datos, casos de uso, secuencia |
