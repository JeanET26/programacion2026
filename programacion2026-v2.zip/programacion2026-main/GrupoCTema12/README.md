# programacion2026: Mundo Marino (Grupo C, Tema 12)

Sistema interno del personal de Mundo Marino. El **administrador** gestiona especies, zonas, hábitats, itinerarios y personal, y asigna horarios y cuidados. Cada **guía** ve solo sus recorridos y horarios, y cada **cuidador** ve solo las especies que tiene a cargo.

Se puede usar desde el **navegador** (interfaz principal) o desde la **consola**. Las dos usan los mismos servicios.

## Cómo ejecutarlo

**NetBeans:** *File → Open Project* → `GrupoCTema12` → *Run* (F6). Después abrir **http://localhost:8080**.
Para el modo consola: *Properties → Run → Arguments:* `consola`.

**Terminal** (desde la carpeta `GrupoCTema12`):

```bash
java -jar dist/GrupoCTema12.jar           # web en http://localhost:8080
java -jar dist/GrupoCTema12.jar consola   # menú de texto
```

Requiere Java 21 y no tiene dependencias externas. La primera vez crea la carpeta `datos/` con datos de ejemplo.

| Usuario | Contraseña | Rol |
|---|---|---|
| `admin.ana` | `Admin2026!` | Administrador |
| `guia.lucia`, `guia.martin` | `Marino2026!` | Guía |
| `cuidador.diego`, `cuidador.sofia` | `Marino2026!` | Cuidador |

Para volver a los datos iniciales, borrar la carpeta `datos/`.

## Entregables

| Recurso | Ubicación |
|---|---|
| Ejecutable JAR | `dist/GrupoCTema12.jar` |
| Código fuente Java | `src/grupoctema12/` |
| Frontend (HTML/CSS/JS) | `src/web/` |
| Javadoc | `docs/Javadoc_Mundo_Marino/index.html` |
| **Respuestas a la corrección** | `docs/RESPUESTAS_A_LA_CORRECCION.md` |
| Diagrama de clases | `../diagrama_uml_mundo_marino.png` |
| Diagrama de capas (DAO / servicios) | `docs/diagrama_capas.png` |
| Script de base de datos | `docs/schema.sql` |
| Casos de uso | `../Casos_de_uso.drawio` |
| Informe técnico (1.ª parte) | `docs/Informe_Tecnico_Mundo_Marino.pdf`: **hay que actualizarlo** con la arquitectura nueva |

## Arquitectura

```text
src/grupoctema12/
├── modelo/       Entidades + interfaces Identificable y ConPermisos
├── dao/          Contrato genérico Dao<T, ID> + una interfaz por entidad + FabricaDao
│   ├── json/     Implementación con archivos JSON (la que se usa)
│   └── jdbc/     Ejemplo con MySQL (EspecieDaoJdbc)
├── servicio/     Reglas de negocio; reciben los DAO por constructor
├── seguridad/    Hash de contraseñas (PBKDF2) y ControlAcceso por permisos
├── web/          Servidor HTTP del JDK, sesiones y API JSON
├── consola/      Menús de texto
├── util/         Validaciones y lector/escritor JSON
└── excepciones/  Errores de negocio → códigos HTTP
src/web/          Frontend: Bootstrap 5 + JavaScript (módulos ES)
```

Cómo se comunican el frontend y el backend:

```text
Navegador ── fetch("/api/...") con JSON ──▶ Enrutador ──▶ Controlador ──▶ Servicio ──▶ DAO ──▶ datos/*.json
                                                                                       └──▶ (o MySQL con dao.jdbc)
```

### API JSON

| Método | Ruta | Quién |
|---|---|---|
| POST / GET / DELETE | `/api/sesion` | Iniciar sesión / quién soy / salir |
| PUT | `/api/sesion/contrasena` | Cualquier usuario |
| GET, POST · PUT, DELETE `/{id}` | `/api/zonas`, `/api/habitats`, `/api/especies`, `/api/itinerarios`, `/api/empleados` | Administrador |
| GET, POST · PUT, DELETE `/{id}` | `/api/asignaciones-guia`, `/api/asignaciones-cuidado` | Administrador |
| GET | `/api/mis-recorridos` | Guía (solo los suyos) |
| GET | `/api/mis-especies` | Cuidador (solo las suyas) |

### Pasar a una base de datos

1. Ejecutar `docs/schema.sql` en MySQL.
2. Agregar el driver `mysql-connector-j` en *Properties → Libraries*.
3. Completar una clase `...DaoJdbc` por entidad, tomando `dao/jdbc/EspecieDaoJdbc.java` como modelo, y una `FabricaDaoJdbc`.
4. En `GrupoCTema12.main`, cambiar `new FabricaDaoJson(...)` por `new FabricaDaoJdbc(...)`. Ningún servicio cambia.

## Seguridad

- Contraseñas guardadas con hash PBKDF2 y sal; nunca en texto plano.
- Sesión en una cookie `HttpOnly` y `SameSite=Strict`, que vence a los 30 minutos sin uso.
- Permisos controlados **en el servidor**, en cada servicio. Un guía que llame a `/api/empleados` recibe 403.
- Protección CSRF: el servidor exige JSON y verifica el `Origin`.
- Bloqueo tras 5 intentos fallidos de inicio de sesión por usuario.
- Cabeceras CSP, `X-Frame-Options` y `nosniff`. El frontend arma el HTML sin `innerHTML`, para evitar XSS.
- El servidor escucha solo en `localhost`. Para usarlo en red habría que ponerlo detrás de HTTPS.

## Autores

- Jean Pier Graterol
- Mauricio Castellano
