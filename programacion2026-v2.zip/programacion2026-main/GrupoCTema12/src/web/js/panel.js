/**
 * Panel principal. Pide al servidor quién inició sesión y muestra la vista
 * que corresponde a su rol. El servidor igual controla cada permiso: si un
 * guía intentara llamar a /api/empleados recibiría 403.
 */
import { api } from "./api.js";
import { el, reemplazar } from "./seguridad.js";
import { abrirFormulario, mostrarInfo, avisar } from "./componentes/modal.js";
import { fecha, NOMBRE_ROL } from "./formato.js";
import { vistaAdmin } from "./vistas/admin.js";
import { vistaGuia } from "./vistas/guia.js";
import { vistaCuidador } from "./vistas/cuidador.js";

// Para sumar un rol nuevo: agregar su vista acá (no se modifica el resto).
const VISTAS = {
  ADMINISTRADOR: { vista: vistaAdmin, subtitulo: "Gestioná especies, itinerarios, personal y asignaciones." },
  GUIA: { vista: vistaGuia, subtitulo: "Estos son tus recorridos y horarios." },
  CUIDADOR: { vista: vistaCuidador, subtitulo: "Estas son las especies que tenés a cargo." },
};

const contenido = document.getElementById("contenido");

async function iniciar() {
  let usuario;
  try {
    usuario = await api.get("/api/sesion");
  } catch {
    location.replace("index.html");
    return;
  }
  const config = VISTAS[usuario.rol];
  document.getElementById("rol").textContent = NOMBRE_ROL[usuario.rol] ?? usuario.rol;
  document.getElementById("menu-usuario").textContent = usuario.nombre;
  document.getElementById("saludo").textContent = `Hola, ${usuario.nombre.split(" ")[0]}`;
  document.getElementById("subtitulo").textContent = config?.subtitulo ?? "";
  document.title = `${NOMBRE_ROL[usuario.rol]} · Mundo Marino`;

  document.getElementById("btn-perfil").addEventListener("click", () => verPerfil(usuario));
  document.getElementById("btn-contrasena").addEventListener("click", cambiarContrasena);
  document.getElementById("btn-salir").addEventListener("click", salir);

  if (!config) {
    reemplazar(contenido, el("div", { class: "alert alert-warning" }, "Tu rol no tiene una vista asignada."));
    return;
  }
  try {
    await config.vista(contenido, usuario);
  } catch (e) {
    reemplazar(contenido, el("div", { class: "alert alert-danger", role: "alert" }, e.message));
  }
}

function verPerfil(u) {
  const filas = [
    ["Nombre", u.nombre], ["Usuario", u.nombreUsuario], ["Rol", NOMBRE_ROL[u.rol]],
    ["Teléfono", u.telefono], ["Dirección", u.direccion], ["Ingreso", u.fechaIngreso ? fecha(u.fechaIngreso) : null],
  ].filter(([, v]) => v);
  mostrarInfo({
    titulo: "Mi perfil",
    cuerpo: [
      el("dl", { class: "row mb-2" }, filas.flatMap(([k, v]) => [el("dt", { class: "col-4 text-suave" }, k), el("dd", { class: "col-8" }, v)])),
      el("p", { class: "small text-suave mb-0" }, "Si algún dato es incorrecto, pedile al administrador que lo actualice."),
    ],
  });
}

function cambiarContrasena() {
  let nueva = "";
  abrirFormulario({
    titulo: "Cambiar contraseña",
    textoBoton: "Cambiar",
    campos: [
      { nombre: "actual", etiqueta: "Contraseña actual", tipo: "password", requerido: true },
      { nombre: "nueva", etiqueta: "Nueva contraseña", tipo: "password", requerido: true, ayuda: "Mínimo 8 caracteres, con letras y números.",
        validar: (v) => { nueva = v; return v.length < 8 || !/[A-Za-z]/.test(v) || !/\d/.test(v) ? "Mínimo 8 caracteres, con letras y números." : null; } },
      { nombre: "repetir", etiqueta: "Repetí la nueva contraseña", tipo: "password", requerido: true,
        validar: (v) => (v !== nueva ? "No coincide con la nueva contraseña." : null) },
    ],
    alEnviar: async ({ actual, nueva: clave }) => {
      await api.put("/api/sesion/contrasena", { actual, nueva: clave });
      avisar("Contraseña actualizada. Se cerraron las sesiones en otros dispositivos.");
    },
  });
}

async function salir() {
  try {
    await api.delete("/api/sesion");
  } finally {
    location.replace("index.html");
  }
}

iniciar();
