/** Formatos de fecha, hora y duración en español de Argentina. */
export function fecha(iso) {
  if (!iso) return "—";
  const [a, m, d] = iso.split("-").map(Number);
  return new Date(a, m - 1, d).toLocaleDateString("es-AR", { day: "2-digit", month: "2-digit", year: "numeric" });
}

export function duracion(min) {
  const h = Math.floor(min / 60), m = min % 60;
  return h ? `${h} h${m ? ` ${m} min` : ""}` : `${m} min`;
}

export function hora(texto) {
  return (texto || "").slice(0, 5);
}

/** Suma minutos a "HH:MM". */
export function sumarMinutos(horaTexto, minutos) {
  const [h, m] = horaTexto.split(":").map(Number);
  const total = h * 60 + m + minutos;
  return `${String(Math.floor(total / 60) % 24).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
}

export function minutosDelDia(horaTexto) {
  const [h, m] = horaTexto.split(":").map(Number);
  return h * 60 + m;
}

export function diasDesde(iso) {
  const [a, m, d] = iso.split("-").map(Number);
  return Math.max(0, Math.floor((Date.now() - new Date(a, m - 1, d)) / 86400000));
}

export const NOMBRE_ROL = { ADMINISTRADOR: "Administración", GUIA: "Guía", CUIDADOR: "Cuidador/a" };
