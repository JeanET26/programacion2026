/**
 * Vista del administrador: resumen + pestañas para gestionar todo el parque.
 * Cada pestaña es una configuración de crearSeccion().
 */
import { api } from "../api.js";
import { el, reemplazar } from "../seguridad.js";
import { crearSeccion } from "../componentes/seccionCrud.js";
import { duracion, fecha, hora, sumarMinutos, NOMBRE_ROL } from "../formato.js";

const ENDPOINTS = {
  zonas: "/api/zonas",
  habitats: "/api/habitats",
  especies: "/api/especies",
  itinerarios: "/api/itinerarios",
  empleados: "/api/empleados",
  asignacionesGuia: "/api/asignaciones-guia",
  asignacionesCuidado: "/api/asignaciones-cuidado",
};

/* ---------- Búsquedas por id (los datos llegan con ids, como en la base) ---------- */
const buscar = (lista, id) => lista.find((x) => x.id === id);
const nombreEmpleado = (d, id) => buscar(d.empleados, id)?.nombre ?? "(eliminado)";
const nombreEspecie = (d, id) => buscar(d.especies, id)?.nombreEspanol ?? "(eliminada)";
const nombreZona = (d, id) => (id ? buscar(d.zonas, id)?.nombre ?? "—" : "Sin zona");
const chips = (textos) => (textos.length ? el("div", {}, textos.map((t) => el("span", { class: "chip" }, t))) : "—");
const hoy = () => new Date().toISOString().slice(0, 10);

const opcionesGuias = (d) => d.empleados.filter((e) => e.rol === "GUIA").map((e) => ({ valor: e.id, texto: e.nombre }));
const opcionesCuidadores = (d) => d.empleados.filter((e) => e.rol === "CUIDADOR").map((e) => ({ valor: e.id, texto: e.nombre }));

/* ======================= Configuración de cada pestaña ======================= */

const SECCIONES = [
  {
    clave: "horarios",
    pestana: "Horarios de guías",
    titulo: "Horarios de guías",
    descripcion: "Qué guía conduce cada itinerario y a qué hora. Un guía no puede tener recorridos superpuestos.",
    coleccion: "asignacionesGuia",
    singular: "horario",
    textoNuevo: "Asignar horario",
    ordenar: (a, b, d) => nombreEmpleado(d, a.guiaId).localeCompare(nombreEmpleado(d, b.guiaId)) || a.hora.localeCompare(b.hora),
    columnas: [
      { titulo: "Guía", valor: (a, d) => el("strong", {}, nombreEmpleado(d, a.guiaId)) },
      { titulo: "Horario", valor: (a, d) => {
        const it = buscar(d.itinerarios, a.itinerarioId);
        return `${hora(a.hora)} – ${it ? sumarMinutos(hora(a.hora), it.duracionMinutos) : "?"}`;
      } },
      { titulo: "Itinerario", valor: (a, d) => el("span", { class: "codigo" }, buscar(d.itinerarios, a.itinerarioId)?.codigo ?? "—") },
      { titulo: "Zonas", valor: (a, d) => chips(buscar(d.itinerarios, a.itinerarioId)?.zonas ?? []) },
    ],
    campos: (a, d) => [
      { nombre: "guiaId", etiqueta: "Guía", tipo: "seleccion", requerido: true, valor: a?.guiaId, opciones: opcionesGuias(d), deshabilitado: Boolean(a) },
      { nombre: "itinerarioId", etiqueta: "Itinerario", tipo: "seleccion", requerido: true, valor: a?.itinerarioId, deshabilitado: Boolean(a),
        opciones: d.itinerarios.map((i) => ({ valor: i.id, texto: `${i.codigo} · ${duracion(i.duracionMinutos)} · ${i.zonas.join(", ")}` })) },
      { nombre: "hora", etiqueta: "Hora de salida", tipo: "hora", requerido: true, valor: a ? hora(a.hora) : "10:00",
        ayuda: a ? "Para cambiar de guía o itinerario, eliminá el horario y creá uno nuevo." : "El sistema controla que no se superponga con otros recorridos del mismo guía." },
    ],
    textoBorrar: (a, d) => `¿Quitar a ${nombreEmpleado(d, a.guiaId)} del ${buscar(d.itinerarios, a.itinerarioId)?.codigo ?? "itinerario"} de las ${hora(a.hora)}?`,
  },
  {
    clave: "cuidados",
    pestana: "Cuidados",
    titulo: "Cuidado de especies",
    descripcion: "Qué cuidador está a cargo de cada especie y desde cuándo.",
    coleccion: "asignacionesCuidado",
    singular: "asignación",
    textoNuevo: "Asignar cuidador",
    ordenar: (a, b, d) => nombreEmpleado(d, a.cuidadorId).localeCompare(nombreEmpleado(d, b.cuidadorId)),
    columnas: [
      { titulo: "Cuidador/a", valor: (a, d) => el("strong", {}, nombreEmpleado(d, a.cuidadorId)) },
      { titulo: "Especie", valor: (a, d) => nombreEspecie(d, a.especieId) },
      { titulo: "Zona", valor: (a, d) => nombreZona(d, buscar(d.especies, a.especieId)?.zonaId) },
      { titulo: "Desde", valor: (a) => fecha(a.fechaAsignacion) },
    ],
    campos: (a, d) => [
      { nombre: "cuidadorId", etiqueta: "Cuidador/a", tipo: "seleccion", requerido: true, valor: a?.cuidadorId, opciones: opcionesCuidadores(d), deshabilitado: Boolean(a) },
      { nombre: "especieId", etiqueta: "Especie", tipo: "seleccion", requerido: true, valor: a?.especieId, deshabilitado: Boolean(a),
        opciones: d.especies.map((e) => ({ valor: e.id, texto: `${e.nombreEspanol} · ${nombreZona(d, e.zonaId)}` })) },
      { nombre: "fechaAsignacion", etiqueta: "A cargo desde", tipo: "fecha", requerido: true, valor: a?.fechaAsignacion ?? hoy() },
    ],
    textoBorrar: (a, d) => `¿Quitar a ${nombreEmpleado(d, a.cuidadorId)} del cuidado de ${nombreEspecie(d, a.especieId)}?`,
  },
  {
    clave: "itinerarios",
    pestana: "Itinerarios",
    titulo: "Itinerarios",
    descripcion: "Recorridos guiados. Las zonas se calculan solas a partir de las especies elegidas.",
    coleccion: "itinerarios",
    singular: "itinerario",
    textoNuevo: "Nuevo itinerario",
    ordenar: (a, b) => a.codigo.localeCompare(b.codigo),
    columnas: [
      { titulo: "Código", valor: (i) => el("span", { class: "codigo" }, i.codigo) },
      { titulo: "Duración", valor: (i) => duracion(i.duracionMinutos) },
      { titulo: "Longitud", valor: (i) => `${i.longitudKm.toLocaleString("es-AR")} km` },
      { titulo: "Cupo", valor: (i) => `${i.maximoVisitantes} pers.` },
      { titulo: "Zonas", valor: (i) => chips(i.zonas) },
      { titulo: "Especies", valor: (i, d) => i.especieIds.map((id) => nombreEspecie(d, id)).join(", ") },
      { titulo: "Guías", valor: (i, d) => d.asignacionesGuia.filter((a) => a.itinerarioId === i.id)
        .map((a) => `${hora(a.hora)} ${nombreEmpleado(d, a.guiaId)}`).join(" · ") || "Sin asignar" },
    ],
    campos: (i, d) => [
      { nombre: "numero", etiqueta: "Número (genera el código IT-XX)", tipo: "numero", requerido: !i, min: 1, max: 99, valor: i?.numero,
        deshabilitado: Boolean(i), ayuda: i ? "El código no se puede cambiar." : "Del 1 al 99." },
      { nombre: "duracionMinutos", etiqueta: "Duración (minutos)", tipo: "numero", requerido: true, min: 5, max: 480, valor: i?.duracionMinutos ?? 45 },
      { nombre: "longitudKm", etiqueta: "Longitud (km)", tipo: "numero", requerido: true, min: 0.1, max: 50, paso: "0.1", valor: i?.longitudKm },
      { nombre: "maximoVisitantes", etiqueta: "Máximo de visitantes", tipo: "numero", requerido: true, min: 1, max: 500, valor: i?.maximoVisitantes ?? 25 },
      { nombre: "especieIds", etiqueta: "Especies que visita", tipo: "casillas", requerido: true, valor: i?.especieIds ?? [], alias: ["especies"],
        ayuda: "Solo se pueden elegir especies ubicadas en una zona.",
        opciones: d.especies.map((e) => ({ valor: e.id, texto: `${e.nombreEspanol} · ${nombreZona(d, e.zonaId)}`, deshabilitada: !e.zonaId })) },
    ],
    textoBorrar: (i) => `¿Eliminar el itinerario ${i.codigo}?`,
  },
  {
    clave: "especies",
    pestana: "Especies",
    titulo: "Especies",
    coleccion: "especies",
    singular: "especie",
    textoNuevo: "Nueva especie",
    ordenar: (a, b) => a.nombreEspanol.localeCompare(b.nombreEspanol),
    columnas: [
      { titulo: "Especie", valor: (e) => el("div", {}, [el("strong", {}, e.nombreEspanol), el("div", { class: "small fst-italic text-suave" }, e.nombreCientifico)]) },
      { titulo: "Zona", valor: (e, d) => nombreZona(d, e.zonaId) },
      { titulo: "Hábitats", valor: (e, d) => chips(e.habitatIds.map((id) => buscar(d.habitats, id)?.nombre).filter(Boolean)) },
      { titulo: "Cuidadores", valor: (e, d) => d.asignacionesCuidado.filter((a) => a.especieId === e.id).map((a) => nombreEmpleado(d, a.cuidadorId)).join(", ") || "Sin asignar" },
    ],
    campos: (e, d) => [
      { nombre: "nombreEspanol", etiqueta: "Nombre en español", tipo: "texto", requerido: true, valor: e?.nombreEspanol, maxLength: 80 },
      { nombre: "nombreCientifico", etiqueta: "Nombre científico", tipo: "texto", requerido: true, valor: e?.nombreCientifico },
      { nombre: "descripcion", etiqueta: "Descripción", tipo: "area", requerido: true, valor: e?.descripcion },
      { nombre: "zonaId", etiqueta: "Zona del parque", tipo: "seleccion", valor: e?.zonaId, opciones: d.zonas.map((z) => ({ valor: z.id, texto: z.nombre })) },
      { nombre: "habitatIds", etiqueta: "Hábitats naturales", tipo: "casillas", valor: e?.habitatIds ?? [], opciones: d.habitats.map((h) => ({ valor: h.id, texto: h.nombre })) },
    ],
    textoBorrar: (e) => `¿Eliminar la especie ${e.nombreEspanol}?`,
  },
  {
    clave: "zonas",
    pestana: "Zonas",
    titulo: "Zonas",
    coleccion: "zonas",
    singular: "zona",
    textoNuevo: "Nueva zona",
    ordenar: (a, b) => a.nombre.localeCompare(b.nombre),
    columnas: [
      { titulo: "Zona", valor: (z) => el("strong", {}, z.nombre) },
      { titulo: "Extensión", valor: (z) => `${z.extensionM2.toLocaleString("es-AR")} m²` },
      { titulo: "Especies", valor: (z) => String(z.cantidadEspecies) },
    ],
    campos: (z) => [
      { nombre: "nombre", etiqueta: "Nombre", tipo: "texto", requerido: true, valor: z?.nombre, maxLength: 80 },
      { nombre: "extensionM2", etiqueta: "Extensión (m²)", tipo: "numero", requerido: true, min: 1, paso: "0.01", valor: z?.extensionM2 },
    ],
    textoBorrar: (z) => `¿Eliminar la zona ${z.nombre}?`,
  },
  {
    clave: "habitats",
    pestana: "Hábitats",
    titulo: "Hábitats",
    coleccion: "habitats",
    singular: "hábitat",
    textoNuevo: "Nuevo hábitat",
    ordenar: (a, b) => a.nombre.localeCompare(b.nombre),
    columnas: [
      { titulo: "Hábitat", valor: (h) => el("strong", {}, h.nombre) },
      { titulo: "Clima", valor: (h) => h.clima },
      { titulo: "Vegetación", valor: (h) => h.vegetacion },
      { titulo: "Continentes", valor: (h) => chips(h.continentes) },
    ],
    campos: (h) => [
      { nombre: "nombre", etiqueta: "Nombre", tipo: "texto", requerido: true, valor: h?.nombre, maxLength: 80 },
      { nombre: "clima", etiqueta: "Clima", tipo: "texto", requerido: true, valor: h?.clima, maxLength: 80 },
      { nombre: "vegetacion", etiqueta: "Vegetación predominante", tipo: "texto", requerido: true, valor: h?.vegetacion },
      { nombre: "continentes", etiqueta: "Continentes", tipo: "lista", requerido: true, valor: h?.continentes, ayuda: "Separados por coma. Ej: América, Oceanía" },
    ],
    textoBorrar: (h) => `¿Eliminar el hábitat ${h.nombre}?`,
  },
  {
    clave: "personal",
    pestana: "Personal",
    titulo: "Guías y cuidadores",
    descripcion: "Cada persona entra con su usuario y solo ve sus propios horarios o especies.",
    coleccion: "empleados",
    singular: "empleado",
    textoNuevo: "Nuevo empleado",
    ordenar: (a, b) => a.rol.localeCompare(b.rol) || a.nombre.localeCompare(b.nombre),
    columnas: [
      { titulo: "Nombre", valor: (e) => el("strong", {}, e.nombre) },
      { titulo: "Usuario", valor: (e) => el("code", {}, e.nombreUsuario) },
      { titulo: "Rol", valor: (e) => el("span", { class: "chip" }, NOMBRE_ROL[e.rol]) },
      { titulo: "Teléfono", valor: (e) => e.telefono },
      { titulo: "Ingreso", valor: (e) => fecha(e.fechaIngreso) },
    ],
    campos: (e) => [
      { nombre: "rol", etiqueta: "Rol", tipo: "seleccion", requerido: !e, valor: e?.rol, deshabilitado: Boolean(e),
        opciones: [{ valor: "GUIA", texto: "Guía" }, { valor: "CUIDADOR", texto: "Cuidador/a" }] },
      { nombre: "nombreUsuario", etiqueta: "Usuario para ingresar", tipo: "texto", requerido: !e, valor: e?.nombreUsuario, deshabilitado: Boolean(e),
        maxLength: 30, ayuda: e ? "El usuario no se puede cambiar." : "Minúsculas, números, punto o guion bajo. Ej: guia.juan",
        validar: (v) => (v && !/^[a-z0-9._]{3,30}$/.test(v) ? "Entre 3 y 30 caracteres: minúsculas, números, punto o guion bajo." : null) },
      { nombre: "contrasena", etiqueta: e ? "Nueva contraseña" : "Contraseña inicial", tipo: "password", requerido: !e, maxLength: 64,
        ayuda: e ? "Dejala vacía para no cambiarla." : "Mínimo 8 caracteres, con letras y números.",
        validar: (v) => (v && (v.length < 8 || !/[A-Za-z]/.test(v) || !/\d/.test(v)) ? "Mínimo 8 caracteres, con letras y números." : null) },
      { nombre: "nombre", etiqueta: "Nombre y apellido", tipo: "texto", requerido: true, valor: e?.nombre, maxLength: 80 },
      { nombre: "direccion", etiqueta: "Dirección", tipo: "texto", requerido: true, valor: e?.direccion },
      { nombre: "telefono", etiqueta: "Teléfono", tipo: "texto", requerido: true, valor: e?.telefono, maxLength: 20 },
      { nombre: "fechaIngreso", etiqueta: "Fecha de ingreso", tipo: "fecha", requerido: true, valor: e?.fechaIngreso ?? hoy(), max: hoy() },
    ],
    textoBorrar: (e) => `¿Eliminar a ${e.nombre}? Solo se puede si no tiene asignaciones.`,
  },
];

/* ============================ Armado de la vista ============================ */

export async function vistaAdmin(contenedor) {
  const datos = {};
  const ctx = { datos, recargar };
  let secciones = [];

  async function recargar() {
    const claves = Object.keys(ENDPOINTS);
    const resultados = await Promise.all(claves.map((k) => api.get(ENDPOINTS[k])));
    claves.forEach((k, i) => { datos[k] = resultados[i]; });
    actualizarMetricas();
    secciones.forEach((s) => s.render());
  }

  const metricas = {
    guias: el("div", { class: "numero" }, "–"),
    cuidadores: el("div", { class: "numero" }, "–"),
    itinerarios: el("div", { class: "numero" }, "–"),
    especies: el("div", { class: "numero" }, "–"),
  };
  function actualizarMetricas() {
    metricas.guias.textContent = datos.empleados.filter((e) => e.rol === "GUIA").length;
    metricas.cuidadores.textContent = datos.empleados.filter((e) => e.rol === "CUIDADOR").length;
    metricas.itinerarios.textContent = datos.itinerarios.length;
    metricas.especies.textContent = datos.especies.length;
  }
  const tarjetaMetrica = (nodo, etiqueta) => el("div", { class: "col-6 col-md-3" }, el("div", { class: "tarjeta metrica" }, [nodo, el("div", { class: "etiqueta" }, etiqueta)]));

  await recargar();

  const pestanas = el("ul", { class: "nav pestanas mb-3", role: "tablist" });
  const paneles = el("div");
  secciones = SECCIONES.map((cfg) => ({ ...crearSeccion({ ...cfg, endpoint: ENDPOINTS[cfg.coleccion] }, ctx), cfg }));

  let activa = sessionStorageSeguro("mm-pestana") ?? SECCIONES[0].clave;
  if (!SECCIONES.some((s) => s.clave === activa)) activa = SECCIONES[0].clave;

  function mostrar(clave) {
    activa = sessionStorageSeguro("mm-pestana", clave);
    for (const s of secciones) {
      const boton = pestanas.querySelector(`[data-clave="${s.cfg.clave}"]`);
      const sel = s.cfg.clave === clave;
      boton.classList.toggle("active", sel);
      boton.setAttribute("aria-selected", String(sel));
      boton.tabIndex = sel ? 0 : -1;
      s.nodo.hidden = !sel;
    }
  }

  for (const s of secciones) {
    const boton = el("button", { type: "button", class: "nav-link", role: "tab", "data-clave": s.cfg.clave, id: `tab-${s.cfg.clave}`, "aria-controls": `panel-${s.cfg.clave}` }, s.cfg.pestana);
    boton.addEventListener("click", () => mostrar(s.cfg.clave));
    pestanas.append(el("li", { class: "nav-item", role: "presentation" }, boton));
    s.nodo.setAttribute("role", "tabpanel");
    s.nodo.id = `panel-${s.cfg.clave}`;
    s.nodo.setAttribute("aria-labelledby", `tab-${s.cfg.clave}`);
    paneles.append(s.nodo);
  }
  // Flechas izquierda/derecha para moverse entre pestañas (accesibilidad).
  pestanas.addEventListener("keydown", (ev) => {
    if (!["ArrowLeft", "ArrowRight"].includes(ev.key)) return;
    const i = SECCIONES.findIndex((s) => s.clave === activa);
    const sig = SECCIONES[(i + (ev.key === "ArrowRight" ? 1 : SECCIONES.length - 1)) % SECCIONES.length].clave;
    mostrar(sig);
    pestanas.querySelector(`[data-clave="${sig}"]`).focus();
  });

  reemplazar(contenedor, [
    el("div", { class: "row g-3 mb-4" }, [
      tarjetaMetrica(metricas.guias, "Guías"),
      tarjetaMetrica(metricas.cuidadores, "Cuidadores"),
      tarjetaMetrica(metricas.itinerarios, "Itinerarios"),
      tarjetaMetrica(metricas.especies, "Especies"),
    ]),
    pestanas,
    paneles,
  ]);
  mostrar(activa);
}

/** Recuerda la pestaña abierta (solo comodidad; si falla no pasa nada). */
function sessionStorageSeguro(clave, valor) {
  try {
    if (valor !== undefined) sessionStorage.setItem(clave, valor);
    return valor ?? sessionStorage.getItem(clave);
  } catch {
    return valor ?? null;
  }
}
