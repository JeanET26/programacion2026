/**
 * Vista del cuidador: las especies que tiene a cargo. El servidor solo
 * devuelve las suyas y, de sus compañeros, únicamente el nombre.
 */
import { api } from "../api.js";
import { el, reemplazar } from "../seguridad.js";
import { fecha, diasDesde } from "../formato.js";

export async function vistaCuidador(contenedor) {
  const especies = await api.get("/api/mis-especies");

  if (especies.length === 0) {
    reemplazar(contenedor, el("div", { class: "tarjeta vacio" }, [
      el("p", { class: "fw-semibold mb-1" }, "Todavía no tenés especies a cargo."),
      el("p", { class: "mb-0" }, "Cuando el administrador te asigne una especie, la vas a ver acá."),
    ]));
    return;
  }

  const fichas = especies.map((e) => el("div", { class: "col-md-6 col-xl-4" }, el("article", { class: "tarjeta ficha-especie" }, [
    el("div", { class: "franja" }, el("span", { class: "inicial", "aria-hidden": "true" }, e.nombreEspanol.charAt(0))),
    el("div", { class: "cuerpo" }, [
      el("h2", { class: "h5 mb-0" }, e.nombreEspanol),
      el("p", { class: "cientifico small mb-2" }, e.nombreCientifico),
      el("p", { class: "mb-0" }, e.descripcion),
      el("dl", {}, [
        el("dt", {}, "Zona"), el("dd", {}, e.zona ?? "Sin zona asignada"),
        el("dt", {}, "Hábitat"), el("dd", {}, e.habitats.length ? e.habitats.map((h) => `${h.nombre} (${h.clima})`).join(", ") : "—"),
        el("dt", {}, "A cargo"), el("dd", {}, `desde ${fecha(e.desde)} · ${diasDesde(e.desde)} días`),
        el("dt", {}, "Equipo"), el("dd", {}, e.otrosCuidadores.length ? `También la cuida: ${e.otrosCuidadores.join(", ")}` : "Sos la única persona a cargo"),
      ]),
    ]),
  ])));

  reemplazar(contenedor, [
    el("div", { class: "tarjeta metrica mb-4 d-inline-block" }, [
      el("div", { class: "numero" }, String(especies.length)),
      el("div", { class: "etiqueta" }, especies.length === 1 ? "Especie a tu cargo" : "Especies a tu cargo"),
    ]),
    el("div", { class: "row g-4" }, fichas),
  ]);
}
