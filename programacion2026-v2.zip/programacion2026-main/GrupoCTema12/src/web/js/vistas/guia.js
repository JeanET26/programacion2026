/**
 * Vista del guía: su agenda diaria. Solo recibe del servidor SUS recorridos
 * (/api/mis-recorridos usa el usuario de la sesión, no un id del navegador).
 */
import { api } from "../api.js";
import { el, reemplazar } from "../seguridad.js";
import { duracion, hora, minutosDelDia } from "../formato.js";

export async function vistaGuia(contenedor) {
  const recorridos = await api.get("/api/mis-recorridos");

  if (recorridos.length === 0) {
    reemplazar(contenedor, el("div", { class: "tarjeta vacio" }, [
      el("p", { class: "fw-semibold mb-1" }, "Todavía no tenés recorridos asignados."),
      el("p", { class: "mb-0" }, "Cuando el administrador te asigne un horario, lo vas a ver acá."),
    ]));
    return;
  }

  const ahora = new Date().getHours() * 60 + new Date().getMinutes();
  const estado = (r) => {
    const ini = minutosDelDia(hora(r.hora)), fin = minutosDelDia(hora(r.horaFin));
    if (ahora >= fin) return "terminado";
    if (ahora >= ini) return "en-curso";
    return "pendiente";
  };
  const siguiente = recorridos.find((r) => estado(r) === "pendiente");
  const minutosTotales = recorridos.reduce((t, r) => t + r.duracionMinutos, 0);

  const turnos = recorridos.map((r) => {
    let e = estado(r);
    if (r === siguiente && !recorridos.some((x) => estado(x) === "en-curso")) e = "siguiente";
    const etiqueta = { "en-curso": "En curso", siguiente: "Próximo" }[e];
    return el("article", { class: `turno ${e}`, "aria-label": `Recorrido ${r.codigo} a las ${hora(r.hora)}` }, [
      el("div", { class: "horario" }, [
        el("div", { class: "inicio" }, hora(r.hora)),
        el("div", { class: "fin" }, `hasta ${hora(r.horaFin)}`),
      ]),
      el("div", {}, [
        el("div", { class: "d-flex align-items-center gap-2 flex-wrap" }, [
          el("span", { class: "codigo fs-5" }, r.codigo),
          etiqueta ? el("span", { class: `estado-turno ${e}` }, etiqueta) : null,
        ]),
        el("div", { class: "metricas-mini" }, [
          el("span", {}, [el("strong", {}, duracion(r.duracionMinutos)), " de recorrido"]),
          el("span", {}, [el("strong", {}, `${r.longitudKm.toLocaleString("es-AR")} km`)]),
          el("span", {}, ["hasta ", el("strong", {}, `${r.maximoVisitantes} visitantes`)]),
        ]),
        el("p", { class: "small fw-semibold mb-1" }, "Zonas, en orden"),
        el("div", { class: "mb-2" }, r.zonas.map((z) => el("span", { class: "chip" }, z))),
        el("p", { class: "small fw-semibold mb-1" }, "Especies que vas a presentar"),
        el("ul", { class: "mb-0 ps-3" }, r.especies.map((s) => el("li", {}, [s.nombreEspanol, " ", el("span", { class: "fst-italic text-suave small" }, s.nombreCientifico)]))),
      ]),
    ]);
  });

  reemplazar(contenedor, el("div", { class: "row g-4" }, [
    el("div", { class: "col-lg-8" }, el("section", { class: "tarjeta agenda", "aria-labelledby": "t-agenda" }, [
      el("div", { class: "p-3 border-bottom" }, [
        el("h2", { class: "h5 mb-0", id: "t-agenda" }, "Mi agenda de hoy"),
        el("p", { class: "small text-suave mb-0" }, "Los horarios se repiten todos los días hasta que el administrador los cambie."),
      ]),
      ...turnos,
    ])),
    el("div", { class: "col-lg-4" }, el("div", { class: "row g-3" }, [
      el("div", { class: "col-6 col-lg-12" }, el("div", { class: "tarjeta metrica" }, [el("div", { class: "numero" }, String(recorridos.length)), el("div", { class: "etiqueta" }, "Recorridos por día")])),
      el("div", { class: "col-6 col-lg-12" }, el("div", { class: "tarjeta metrica" }, [el("div", { class: "numero" }, duracion(minutosTotales)), el("div", { class: "etiqueta" }, "Tiempo guiando")])),
      siguiente ? el("div", { class: "col-12" }, el("div", { class: "tarjeta metrica" }, [
        el("div", { class: "etiqueta" }, "Tu próximo recorrido"),
        el("div", { class: "numero" }, hora(siguiente.hora)),
        el("div", { class: "codigo" }, siguiente.codigo),
      ])) : null,
    ])),
  ]));
}
