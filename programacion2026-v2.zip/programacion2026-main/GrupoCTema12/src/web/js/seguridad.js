/**
 * Utilidades de seguridad del frontend.
 *
 * Todo el HTML dinámico se arma con el() usando textContent, NUNCA con
 * innerHTML: si un nombre guardado trae "<script>", se muestra como texto.
 * Igual, la seguridad real está en el servidor Java (permisos, validaciones).
 */
export function el(etiqueta, atributos = {}, hijos = []) {
  const nodo = document.createElement(etiqueta);
  for (const [clave, valor] of Object.entries(atributos)) {
    if (valor === null || valor === undefined || valor === false) continue;
    if (clave.startsWith("on")) throw new Error("Usá addEventListener, no eventos inline.");
    if ((clave === "href" || clave === "src") && !/^(https?:|\/|[\w.-]+\.html|#)/.test(String(valor))) continue;
    nodo.setAttribute(clave, valor === true ? "" : String(valor));
  }
  for (const hijo of Array.isArray(hijos) ? hijos : [hijos]) {
    if (hijo === null || hijo === undefined || hijo === false) continue;
    nodo.append(hijo instanceof Node ? hijo : document.createTextNode(String(hijo)));
  }
  return nodo;
}

export function reemplazar(contenedor, nodos) {
  contenedor.replaceChildren(...(Array.isArray(nodos) ? nodos : [nodos]).filter(Boolean));
}

/** Normaliza para buscar sin tildes ni mayúsculas. */
export function normalizar(texto) {
  return String(texto ?? "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
}
