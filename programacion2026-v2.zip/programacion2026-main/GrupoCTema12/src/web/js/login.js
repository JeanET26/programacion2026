import { api } from "./api.js";

const form = document.getElementById("form-login");
const error = document.getElementById("error-login");
const boton = document.getElementById("ingresar");

if (new URLSearchParams(location.search).get("vencida")) {
  error.textContent = "Tu sesión venció. Ingresá de nuevo.";
  error.hidden = false;
}

// Si ya hay sesión abierta, ir directo al panel.
api.get("/api/sesion").then(() => location.replace("panel.html")).catch(() => {});

form.addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const nombreUsuario = document.getElementById("usuario").value.trim().toLowerCase();
  const contrasena = document.getElementById("contrasena").value;
  if (!nombreUsuario || !contrasena) {
    error.textContent = "Completá usuario y contraseña.";
    error.hidden = false;
    return;
  }
  boton.disabled = true;
  boton.textContent = "Ingresando…";
  try {
    await api.post("/api/sesion", { nombreUsuario, contrasena });
    location.replace("panel.html");
  } catch (e) {
    error.textContent = e.message;
    error.hidden = false;
    document.getElementById("contrasena").value = "";
    document.getElementById("contrasena").focus();
  } finally {
    boton.disabled = false;
    boton.textContent = "Ingresar";
  }
});
