/**
 * Única puerta de comunicación con el backend Java (mismo servidor, /api).
 *
 * - La sesión viaja en una cookie HttpOnly que JavaScript no puede leer.
 * - Se envía siempre Content-Type: application/json: el servidor rechaza
 *   cualquier otra cosa (protección CSRF).
 * - Si el servidor responde 401 (sesión vencida) se vuelve al login.
 */
export class ErrorApi extends Error {
  constructor(mensaje, estado, errores) {
    super(mensaje);
    this.estado = estado;
    this.errores = errores || {};
  }
}

async function pedir(metodo, ruta, cuerpo) {
  const controlador = new AbortController();
  const corte = setTimeout(() => controlador.abort(), 15000);
  let r;
  try {
    r = await fetch(ruta, {
      method: metodo,
      credentials: "same-origin",
      headers: metodo === "GET" ? { Accept: "application/json" }
        : { Accept: "application/json", "Content-Type": "application/json" },
      body: cuerpo === undefined ? (metodo === "GET" ? undefined : "{}") : JSON.stringify(cuerpo),
      signal: controlador.signal,
    });
  } catch (e) {
    throw new ErrorApi(e.name === "AbortError" ? "El servidor tardó demasiado." : "No se pudo conectar con el servidor. ¿Está corriendo el programa Java?", 0);
  } finally {
    clearTimeout(corte);
  }
  if (r.status === 204) return null;
  const tipo = r.headers.get("Content-Type") || "";
  const datos = tipo.includes("application/json") ? await r.json() : null;
  if (!r.ok) {
    if (r.status === 401 && !ruta.startsWith("/api/sesion")) {
      location.replace("index.html?vencida=1");
    }
    throw new ErrorApi(datos?.mensaje || `Error ${r.status}`, r.status, datos?.errores);
  }
  return datos;
}

export const api = {
  get: (ruta) => pedir("GET", ruta),
  post: (ruta, cuerpo) => pedir("POST", ruta, cuerpo),
  put: (ruta, cuerpo) => pedir("PUT", ruta, cuerpo),
  delete: (ruta) => pedir("DELETE", ruta),
};
