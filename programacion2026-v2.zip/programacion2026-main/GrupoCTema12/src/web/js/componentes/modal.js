/**
 * Ventanas modales reutilizables (Bootstrap 5):
 *  - abrirFormulario(): arma un formulario a partir de una lista de campos.
 *  - confirmar(): pregunta "¿Seguro?" antes de eliminar.
 *  - mostrarInfo(): muestra contenido de solo lectura.
 */
import { el, reemplazar } from "../seguridad.js";

let contenedorModal = null;

function obtenerModal() {
  if (!contenedorModal) {
    contenedorModal = el("div", { class: "modal fade", tabindex: "-1", "aria-hidden": "true", "aria-labelledby": "modal-titulo" }, [
      el("div", { class: "modal-dialog modal-dialog-scrollable" }, el("div", { class: "modal-content" })),
    ]);
    document.body.append(contenedorModal);
  }
  return {
    nodo: contenedorModal,
    contenido: contenedorModal.querySelector(".modal-content"),
    instancia: window.bootstrap.Modal.getOrCreateInstance(contenedorModal),
  };
}

let contadorIds = 0;

/**
 * Tipos de campo: texto, password, numero, fecha, hora, area, seleccion, casillas, lista.
 * Cada campo: { nombre, etiqueta, tipo, requerido, valor, opciones:[{valor,texto,deshabilitada}],
 *               ayuda, min, max, paso, maxLength, deshabilitado, alias:[nombres de error del servidor] }
 */
function crearCampo(c) {
  const id = `campo-${++contadorIds}`;
  const comunes = { id, name: c.nombre, required: c.requerido, disabled: c.deshabilitado, "aria-describedby": `${id}-ayuda` };
  let control;
  switch (c.tipo) {
    case "area":
      control = el("textarea", { ...comunes, class: "form-control", rows: "3", maxlength: c.maxLength ?? 500 }, c.valor ?? "");
      break;
    case "seleccion": {
      const opciones = [el("option", { value: "" }, c.requerido ? "Elegí una opción…" : "— Ninguna —")];
      for (const o of c.opciones ?? []) {
        opciones.push(el("option", { value: o.valor, selected: String(o.valor) === String(c.valor ?? ""), disabled: o.deshabilitada }, o.texto));
      }
      control = el("select", { ...comunes, class: "form-select" }, opciones);
      break;
    }
    case "casillas": {
      const elegidos = new Set((c.valor ?? []).map(String));
      const items = (c.opciones ?? []).map((o, i) => el("div", { class: "form-check" }, [
        el("input", { class: "form-check-input", type: "checkbox", id: `${id}-${i}`, value: o.valor, name: c.nombre,
          checked: elegidos.has(String(o.valor)), disabled: o.deshabilitada || c.deshabilitado }),
        el("label", { class: "form-check-label", for: `${id}-${i}` }, o.texto),
      ]));
      control = el("div", { id, class: "lista-opciones", role: "group", "aria-labelledby": `${id}-etiqueta` },
        items.length ? items : el("p", { class: "text-suave small mb-0" }, "No hay opciones disponibles."));
      break;
    }
    default: {
      const tipos = { texto: "text", password: "password", numero: "number", fecha: "date", hora: "time", lista: "text" };
      control = el("input", {
        ...comunes, class: "form-control", type: tipos[c.tipo] ?? "text",
        value: Array.isArray(c.valor) ? c.valor.join(", ") : (c.valor ?? ""),
        min: c.min, max: c.max, step: c.paso, maxlength: c.maxLength ?? (c.tipo === "texto" || c.tipo === "lista" ? 120 : null),
        autocomplete: c.tipo === "password" ? "new-password" : "off",
      });
    }
  }
  const etiqueta = el("label", { class: "form-label fw-semibold", for: id, id: `${id}-etiqueta` },
    [c.etiqueta, c.requerido ? el("span", { class: "text-danger", "aria-hidden": "true" }, " *") : null]);
  return {
    config: c,
    control,
    nodo: el("div", { class: "mb-3", "data-campo": c.nombre }, [
      etiqueta, control,
      el("div", { class: "form-text", id: `${id}-ayuda` }, c.ayuda ?? ""),
      el("div", { class: "invalid-feedback d-block", hidden: true }),
    ]),
  };
}

function leerValor({ config: c, control }) {
  if (c.tipo === "casillas") {
    return [...control.querySelectorAll("input:checked")].map((i) => i.value);
  }
  const v = control.value.trim();
  if (c.tipo === "numero") return v === "" ? null : Number(v);
  if (c.tipo === "lista") return v.split(",").map((x) => x.trim()).filter(Boolean);
  if (c.tipo === "password") return control.value; // sin trim: los espacios pueden ser parte de la clave
  return v === "" ? null : v;
}

function marcarError(campo, mensaje) {
  const fb = campo.nodo.querySelector(".invalid-feedback");
  fb.textContent = mensaje || "";
  fb.hidden = !mensaje;
  if (campo.config.tipo !== "casillas") campo.control.classList.toggle("is-invalid", Boolean(mensaje));
}

/** Validación rápida en el navegador; el servidor vuelve a validar todo. */
function validarLocal(campo, valor) {
  const c = campo.config;
  const vacio = valor === null || (Array.isArray(valor) && valor.length === 0) || valor === "";
  if (c.requerido && vacio) return "Este campo es obligatorio.";
  if (c.tipo === "numero" && valor !== null) {
    if (Number.isNaN(valor)) return "Ingresá un número.";
    if (c.min !== undefined && valor < c.min) return `Debe ser mayor o igual a ${c.min}.`;
    if (c.max !== undefined && valor > c.max) return `Debe ser menor o igual a ${c.max}.`;
  }
  return c.validar ? c.validar(valor) : null;
}

/**
 * Abre un formulario. alEnviar(valores) debe devolver una promesa; si lanza
 * un ErrorApi, el mensaje se muestra dentro del modal y no se cierra.
 */
export function abrirFormulario({ titulo, campos, textoBoton = "Guardar", alEnviar }) {
  const { contenido, instancia, nodo } = obtenerModal();
  const lista = campos.map(crearCampo);
  const alerta = el("div", { class: "alert alert-danger", role: "alert", hidden: true });
  const boton = el("button", { type: "submit", class: "btn btn-oceano" }, textoBoton);
  const form = el("form", { novalidate: true }, [
    el("div", { class: "modal-header" }, [
      el("h2", { class: "modal-title h5", id: "modal-titulo" }, titulo),
      el("button", { type: "button", class: "btn-close", "data-bs-dismiss": "modal", "aria-label": "Cerrar" }),
    ]),
    el("div", { class: "modal-body" }, [alerta, ...lista.map((c) => c.nodo)]),
    el("div", { class: "modal-footer" }, [
      el("button", { type: "button", class: "btn btn-link", "data-bs-dismiss": "modal" }, "Cancelar"),
      boton,
    ]),
  ]);
  reemplazar(contenido, form);

  form.addEventListener("submit", async (ev) => {
    ev.preventDefault();
    alerta.hidden = true;
    const valores = {};
    let primero = null;
    for (const campo of lista) {
      const valor = leerValor(campo);
      const error = validarLocal(campo, valor);
      marcarError(campo, error);
      if (error && !primero) primero = campo;
      if (!campo.config.deshabilitado) valores[campo.config.nombre] = valor;
    }
    if (primero) {
      (primero.control.querySelector?.("input") ?? primero.control).focus();
      return;
    }
    boton.disabled = true;
    try {
      await alEnviar(valores);
      instancia.hide();
    } catch (e) {
      alerta.textContent = e.message;
      alerta.hidden = false;
      for (const [nombreCampo, mensaje] of Object.entries(e.errores ?? {})) {
        const campo = lista.find((c) => c.config.nombre === nombreCampo || c.config.alias?.includes(nombreCampo));
        if (campo) marcarError(campo, mensaje);
      }
      alerta.scrollIntoView({ block: "nearest" });
    } finally {
      boton.disabled = false;
    }
  });
  nodo.addEventListener("shown.bs.modal", () => form.querySelector("input:not([disabled]), select:not([disabled]), textarea")?.focus(), { once: true });
  instancia.show();
}

/** Pide confirmación. Devuelve una promesa con true/false. */
export function confirmar({ titulo, mensaje, textoBoton = "Eliminar" }) {
  return new Promise((resolver) => {
    const { contenido, instancia, nodo } = obtenerModal();
    let aceptado = false;
    const boton = el("button", { type: "button", class: "btn btn-danger" }, textoBoton);
    boton.addEventListener("click", () => { aceptado = true; instancia.hide(); });
    reemplazar(contenido, [
      el("div", { class: "modal-header" }, [
        el("h2", { class: "modal-title h5", id: "modal-titulo" }, titulo),
        el("button", { type: "button", class: "btn-close", "data-bs-dismiss": "modal", "aria-label": "Cerrar" }),
      ]),
      el("div", { class: "modal-body" }, el("p", { class: "mb-0" }, mensaje)),
      el("div", { class: "modal-footer" }, [
        el("button", { type: "button", class: "btn btn-link", "data-bs-dismiss": "modal" }, "Cancelar"), boton,
      ]),
    ]);
    nodo.addEventListener("hidden.bs.modal", () => resolver(aceptado), { once: true });
    nodo.addEventListener("shown.bs.modal", () => boton.focus(), { once: true });
    instancia.show();
  });
}

/** Muestra contenido de solo lectura. */
export function mostrarInfo({ titulo, cuerpo }) {
  const { contenido, instancia } = obtenerModal();
  reemplazar(contenido, [
    el("div", { class: "modal-header" }, [
      el("h2", { class: "modal-title h5", id: "modal-titulo" }, titulo),
      el("button", { type: "button", class: "btn-close", "data-bs-dismiss": "modal", "aria-label": "Cerrar" }),
    ]),
    el("div", { class: "modal-body" }, cuerpo),
  ]);
  instancia.show();
}

/** Aviso breve en la esquina inferior. */
export function avisar(mensaje, tipo = "ok") {
  const caja = document.getElementById("avisos");
  if (!caja) return;
  const aviso = el("div", { class: `aviso ${tipo === "error" ? "error" : ""}`, role: tipo === "error" ? "alert" : "status" }, mensaje);
  caja.append(aviso);
  setTimeout(() => aviso.remove(), 4000);
}
