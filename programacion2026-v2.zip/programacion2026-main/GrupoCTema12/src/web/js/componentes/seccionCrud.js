/**
 * Sección genérica de administración: tabla + buscador + alta, edición y baja.
 *
 * Cada pestaña del administrador es solo una CONFIGURACIÓN de esta función
 * (columnas, campos del formulario y endpoint). Agregar una pestaña nueva no
 * requiere tocar este archivo: mismo principio Abierto/Cerrado que en Java.
 */
import { api } from "../api.js";
import { el, reemplazar, normalizar } from "../seguridad.js";
import { abrirFormulario, confirmar, avisar } from "./modal.js";

/**
 * @param {object} cfg
 *   titulo, descripcion, coleccion, endpoint, singular,
 *   columnas: [{ titulo, valor(item, datos) -> string|Node, texto?(item, datos) }],
 *   campos(item|null, datos) -> lista de campos para el modal,
 *   ordenar?(a, b, datos), textoBorrar?(item, datos), puedeEditar?=true
 * @param {object} ctx  { datos, recargar() }
 */
export function crearSeccion(cfg, ctx) {
  const buscador = el("input", { type: "search", class: "form-control", placeholder: "Buscar…", "aria-label": `Buscar en ${cfg.titulo}`, maxlength: "40" });
  const contador = el("span", { class: "text-suave small" });
  const botonNuevo = el("button", { type: "button", class: "btn btn-coral" }, `+ ${cfg.textoNuevo ?? `Nuevo ${cfg.singular}`}`);
  const cuerpoTabla = el("tbody");
  const vacio = el("div", { class: "vacio", hidden: true });

  const nodo = el("section", { class: "tarjeta", "aria-labelledby": `titulo-${cfg.coleccion}` }, [
    el("div", { class: "d-flex flex-wrap align-items-center gap-2 p-3 border-bottom" }, [
      el("div", { class: "me-auto" }, [
        el("h2", { class: "h5 mb-0", id: `titulo-${cfg.coleccion}` }, cfg.titulo),
        el("p", { class: "small text-suave mb-0" }, cfg.descripcion ?? ""),
      ]),
      el("div", { class: "d-flex gap-2 align-items-center flex-wrap" }, [contador, el("div", { class: "flex-grow-1" }, buscador), botonNuevo]),
    ]),
    el("div", { class: "table-responsive" }, el("table", { class: "table table-hover tabla-mm" }, [
      el("thead", {}, el("tr", {}, [...cfg.columnas.map((c) => el("th", { scope: "col" }, c.titulo)), el("th", { scope: "col", class: "text-end" }, "Acciones")])),
      cuerpoTabla,
    ])),
    vacio,
  ]);

  function textoFila(item) {
    return normalizar(cfg.columnas.map((c) => {
      const v = c.texto ? c.texto(item, ctx.datos) : c.valor(item, ctx.datos);
      return v instanceof Node ? v.textContent : v;
    }).join(" "));
  }

  function render() {
    let items = [...(ctx.datos[cfg.coleccion] ?? [])];
    if (cfg.ordenar) items.sort((a, b) => cfg.ordenar(a, b, ctx.datos));
    const filtro = normalizar(buscador.value.trim());
    const visibles = filtro ? items.filter((i) => textoFila(i).includes(filtro)) : items;
    contador.textContent = filtro ? `${visibles.length} de ${items.length}` : `${items.length} en total`;

    reemplazar(cuerpoTabla, visibles.map((item) => {
      const acciones = [];
      if (cfg.puedeEditar !== false) {
        const editar = el("button", { type: "button", class: "btn btn-outline-secondary btn-icono me-1" }, "Editar");
        editar.addEventListener("click", () => abrir(item));
        acciones.push(editar);
      }
      const borrar = el("button", { type: "button", class: "btn btn-outline-danger btn-icono" }, "Eliminar");
      borrar.addEventListener("click", () => eliminar(item));
      acciones.push(borrar);
      return el("tr", {}, [
        ...cfg.columnas.map((c) => el("td", {}, c.valor(item, ctx.datos) ?? "—")),
        el("td", { class: "acciones" }, acciones),
      ]);
    }));
    vacio.hidden = visibles.length > 0;
    vacio.textContent = filtro ? "No hay resultados para esa búsqueda." : `Todavía no hay ${cfg.titulo.toLowerCase()} cargados.`;
  }

  function abrir(item = null) {
    abrirFormulario({
      titulo: item ? `Editar ${cfg.singular}` : (cfg.textoNuevo ?? `Nuevo ${cfg.singular}`),
      campos: cfg.campos(item, ctx.datos),
      alEnviar: async (valores) => {
        if (item) await api.put(`${cfg.endpoint}/${encodeURIComponent(item.id)}`, valores);
        else await api.post(cfg.endpoint, valores);
        await ctx.recargar();
        avisar(item ? "Cambios guardados." : "Registro creado.");
      },
    });
  }

  async function eliminar(item) {
    const ok = await confirmar({
      titulo: `Eliminar ${cfg.singular}`,
      mensaje: cfg.textoBorrar ? cfg.textoBorrar(item, ctx.datos) : "¿Seguro que querés eliminarlo? No se puede deshacer.",
    });
    if (!ok) return;
    try {
      await api.delete(`${cfg.endpoint}/${encodeURIComponent(item.id)}`);
      await ctx.recargar();
      avisar("Eliminado.");
    } catch (e) {
      avisar(e.message, "error");
    }
  }

  buscador.addEventListener("input", render);
  botonNuevo.addEventListener("click", () => abrir());
  render();
  return { nodo, render };
}
