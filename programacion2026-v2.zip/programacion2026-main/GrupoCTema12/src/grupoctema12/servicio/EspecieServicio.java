package grupoctema12.servicio;

import grupoctema12.dao.AsignacionCuidadoDao;
import grupoctema12.dao.EspecieDao;
import grupoctema12.dao.HabitatDao;
import grupoctema12.dao.ItinerarioDao;
import grupoctema12.dao.ZonaDao;
import grupoctema12.excepciones.ConflictoException;
import grupoctema12.excepciones.DatoInvalidoException;
import grupoctema12.excepciones.NoEncontradoException;
import grupoctema12.modelo.Especie;
import grupoctema12.modelo.Itinerario;
import grupoctema12.modelo.Permiso;
import grupoctema12.modelo.Usuario;
import grupoctema12.seguridad.ControlAcceso;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Reglas de negocio de las especies.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class EspecieServicio {
    private final EspecieDao especies;
    private final ZonaDao zonas;
    private final HabitatDao habitats;
    private final ItinerarioDao itinerarios;
    private final AsignacionCuidadoDao cuidados;

    public EspecieServicio(EspecieDao especies, ZonaDao zonas, HabitatDao habitats,
            ItinerarioDao itinerarios, AsignacionCuidadoDao cuidados) {
        this.especies = especies;
        this.zonas = zonas;
        this.habitats = habitats;
        this.itinerarios = itinerarios;
        this.cuidados = cuidados;
    }

    public List<Especie> listar(Usuario actor) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        return especies.listarTodos().stream().sorted(Comparator.comparing(Especie::getNombreEspanol)).toList();
    }

    public Especie crear(Usuario actor, Datos.Especie d) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        verificarReferencias(d);
        Especie especie = new Especie(UUID.randomUUID(), d.nombreEspanol(), d.nombreCientifico(), d.descripcion(),
                d.zonaId(), d.habitatIds());
        verificarNombreCientificoUnico(especie.getNombreCientifico(), null);
        especies.guardar(especie);
        return especie;
    }

    public Especie actualizar(Usuario actor, UUID id, Datos.Especie d) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        obtener(id);
        verificarReferencias(d);
        if (d.zonaId() == null && !itinerarios.buscarPorEspecie(id).isEmpty()) {
            throw new ConflictoException("La especie forma parte de un itinerario: debe seguir ubicada en una zona.");
        }
        Especie nueva = new Especie(id, d.nombreEspanol(), d.nombreCientifico(), d.descripcion(),
                d.zonaId(), d.habitatIds());
        verificarNombreCientificoUnico(nueva.getNombreCientifico(), id);
        especies.actualizar(nueva);
        return nueva;
    }

    public void eliminar(Usuario actor, UUID id) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        obtener(id);
        List<Itinerario> enUso = itinerarios.buscarPorEspecie(id);
        if (!enUso.isEmpty()) {
            String codigos = enUso.stream().map(Itinerario::getCodigo).collect(Collectors.joining(", "));
            throw new ConflictoException("No se puede eliminar: la especie está en los itinerarios " + codigos + ".");
        }
        if (!cuidados.buscarPorEspecie(id).isEmpty()) {
            throw new ConflictoException("No se puede eliminar: la especie tiene cuidadores asignados.");
        }
        especies.eliminar(id);
    }

    private Especie obtener(UUID id) {
        return especies.buscarPorId(id).orElseThrow(() -> new NoEncontradoException("La especie no existe."));
    }

    private void verificarReferencias(Datos.Especie d) {
        if (d.zonaId() != null && !zonas.existe(d.zonaId())) {
            throw new DatoInvalidoException("zonaId", "La zona elegida no existe.");
        }
        Set<UUID> hs = d.habitatIds() == null ? Set.of() : d.habitatIds();
        if (hs.stream().anyMatch(h -> !habitats.existe(h))) {
            throw new DatoInvalidoException("habitatIds", "Alguno de los hábitats elegidos no existe.");
        }
    }

    private void verificarNombreCientificoUnico(String nombre, UUID idPropio) {
        especies.buscarPorNombreCientifico(nombre).filter(e -> !e.getId().equals(idPropio)).ifPresent(e -> {
            throw new ConflictoException("Ya existe una especie con el nombre científico " + nombre + ".");
        });
    }
}
