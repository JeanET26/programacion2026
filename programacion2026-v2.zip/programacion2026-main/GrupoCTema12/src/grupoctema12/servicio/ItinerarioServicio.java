package grupoctema12.servicio;

import grupoctema12.dao.AsignacionGuiaDao;
import grupoctema12.dao.EspecieDao;
import grupoctema12.dao.ItinerarioDao;
import grupoctema12.dao.ZonaDao;
import grupoctema12.excepciones.ConflictoException;
import grupoctema12.excepciones.DatoInvalidoException;
import grupoctema12.excepciones.NoEncontradoException;
import grupoctema12.modelo.AsignacionGuia;
import grupoctema12.modelo.Especie;
import grupoctema12.modelo.Itinerario;
import grupoctema12.modelo.Permiso;
import grupoctema12.modelo.Usuario;
import grupoctema12.modelo.Zona;
import grupoctema12.seguridad.ControlAcceso;
import grupoctema12.util.Validaciones;
import java.time.Duration;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * Reglas de negocio de los itinerarios.
 * <ul>
 *   <li>El código IT-XX se genera a partir de un número del 1 al 99 y no se repite.</li>
 *   <li>Debe tener al menos una especie y todas deben estar ubicadas en una zona.</li>
 *   <li>Las zonas se calculan a partir de las especies ({@link #zonasDe}).</li>
 * </ul>
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class ItinerarioServicio {
    private final ItinerarioDao itinerarios;
    private final EspecieDao especies;
    private final ZonaDao zonas;
    private final AsignacionGuiaDao asignaciones;
    private final VerificadorHorarios horarios;

    public ItinerarioServicio(ItinerarioDao itinerarios, EspecieDao especies, ZonaDao zonas,
            AsignacionGuiaDao asignaciones, VerificadorHorarios horarios) {
        this.itinerarios = itinerarios;
        this.especies = especies;
        this.zonas = zonas;
        this.asignaciones = asignaciones;
        this.horarios = horarios;
    }

    public List<Itinerario> listar(Usuario actor) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        return itinerarios.listarTodos().stream().sorted(Comparator.comparing(Itinerario::getCodigo)).toList();
    }

    public Itinerario crear(Usuario actor, Datos.Itinerario d) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        Validaciones.obligatorio(d.numero(), "numero");
        String codigo = Itinerario.codigoPara(d.numero());
        if (itinerarios.buscarPorCodigo(codigo).isPresent()) {
            throw new ConflictoException("Ya existe el itinerario " + codigo + ".");
        }
        verificarEspecies(d.especieIds());
        Itinerario nuevo = new Itinerario(UUID.randomUUID(), codigo, Duration.ofMinutes(d.duracionMinutos()),
                d.longitudKm(), d.maximoVisitantes(), d.especieIds());
        itinerarios.guardar(nuevo);
        return nuevo;
    }

    public Itinerario actualizar(Usuario actor, UUID id, Datos.Itinerario d) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        Itinerario actual = obtener(id);
        verificarEspecies(d.especieIds());
        Itinerario nuevo = new Itinerario(id, actual.getCodigo(), Duration.ofMinutes(d.duracionMinutos()),
                d.longitudKm(), d.maximoVisitantes(), d.especieIds());
        // Si cambia la duración, los guías asignados podrían quedar superpuestos.
        for (AsignacionGuia a : asignaciones.buscarPorItinerario(id)) {
            horarios.verificarDisponible(a.getGuiaId(), a.getHora(), nuevo.getDuracion(), a.getId());
        }
        itinerarios.actualizar(nuevo);
        return nuevo;
    }

    public void eliminar(Usuario actor, UUID id) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        obtener(id);
        if (!asignaciones.buscarPorItinerario(id).isEmpty()) {
            throw new ConflictoException("No se puede eliminar: el itinerario tiene guías asignados. Quitá primero esas asignaciones.");
        }
        itinerarios.eliminar(id);
    }

    /** Especies del itinerario en el orden en que se cargaron. */
    public List<Especie> especiesDe(Itinerario itinerario) {
        return itinerario.getEspecieIds().stream().map(especies::buscarPorId)
                .flatMap(Optional::stream).toList();
    }

    /** Zonas que recorre: se calculan a partir de sus especies, sin repetir. */
    public List<Zona> zonasDe(Itinerario itinerario) {
        return especiesDe(itinerario).stream().map(Especie::getZonaId).flatMap(Optional::stream)
                .distinct().map(zonas::buscarPorId).flatMap(Optional::stream).toList();
    }

    private Itinerario obtener(UUID id) {
        return itinerarios.buscarPorId(id).orElseThrow(() -> new NoEncontradoException("El itinerario no existe."));
    }

    private void verificarEspecies(Set<UUID> ids) {
        Validaciones.noVacia(ids, "especies");
        for (UUID id : ids) {
            Especie e = especies.buscarPorId(Objects.requireNonNull(id)).orElseThrow(() ->
                    new DatoInvalidoException("especieIds", "Alguna de las especies elegidas no existe."));
            if (e.getZonaId().isEmpty()) {
                throw new DatoInvalidoException("especieIds", "La especie " + e.getNombreEspanol()
                        + " no está ubicada en ninguna zona; ubicála antes de sumarla a un itinerario.");
            }
        }
    }
}
