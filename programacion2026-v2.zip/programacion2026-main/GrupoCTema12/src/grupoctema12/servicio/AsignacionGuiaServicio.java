package grupoctema12.servicio;

import grupoctema12.dao.AsignacionGuiaDao;
import grupoctema12.dao.ItinerarioDao;
import grupoctema12.dao.UsuarioDao;
import grupoctema12.excepciones.ConflictoException;
import grupoctema12.excepciones.DatoInvalidoException;
import grupoctema12.excepciones.NoEncontradoException;
import grupoctema12.modelo.AsignacionGuia;
import grupoctema12.modelo.Guia;
import grupoctema12.modelo.Itinerario;
import grupoctema12.modelo.Permiso;
import grupoctema12.modelo.Usuario;
import grupoctema12.seguridad.ControlAcceso;
import grupoctema12.util.Validaciones;
import java.time.LocalTime;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * El administrador asigna guías a itinerarios con una hora de salida.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class AsignacionGuiaServicio {
    private final AsignacionGuiaDao asignaciones;
    private final UsuarioDao usuarios;
    private final ItinerarioDao itinerarios;
    private final VerificadorHorarios horarios;

    public AsignacionGuiaServicio(AsignacionGuiaDao asignaciones, UsuarioDao usuarios, ItinerarioDao itinerarios,
            VerificadorHorarios horarios) {
        this.asignaciones = asignaciones;
        this.usuarios = usuarios;
        this.itinerarios = itinerarios;
        this.horarios = horarios;
    }

    public List<AsignacionGuia> listar(Usuario actor) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        return asignaciones.listarTodos().stream().sorted(Comparator.comparing(AsignacionGuia::getHora)).toList();
    }

    public AsignacionGuia asignar(Usuario actor, UUID guiaId, UUID itinerarioId, LocalTime hora) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        usuarios.buscarPorIdYTipo(Validaciones.obligatorio(guiaId, "guiaId"), Guia.class)
                .orElseThrow(() -> new DatoInvalidoException("guiaId", "El guía elegido no existe."));
        Itinerario itinerario = itinerarios.buscarPorId(Validaciones.obligatorio(itinerarioId, "itinerarioId"))
                .orElseThrow(() -> new DatoInvalidoException("itinerarioId", "El itinerario elegido no existe."));
        AsignacionGuia nueva = new AsignacionGuia(guiaId, itinerarioId, hora);
        horarios.verificarDisponible(guiaId, nueva.getHora(), itinerario.getDuracion(), null);
        asignaciones.guardar(nueva);
        return nueva;
    }

    public AsignacionGuia cambiarHora(Usuario actor, UUID asignacionId, LocalTime nuevaHora) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        AsignacionGuia actual = obtener(asignacionId);
        Itinerario itinerario = itinerarios.buscarPorId(actual.getItinerarioId())
                .orElseThrow(() -> new ConflictoException("El itinerario de esta asignación ya no existe."));
        AsignacionGuia nueva = new AsignacionGuia(actual.getId(), actual.getGuiaId(), actual.getItinerarioId(), nuevaHora);
        horarios.verificarDisponible(actual.getGuiaId(), nueva.getHora(), itinerario.getDuracion(), actual.getId());
        asignaciones.actualizar(nueva);
        return nueva;
    }

    public void eliminar(Usuario actor, UUID asignacionId) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        obtener(asignacionId);
        asignaciones.eliminar(asignacionId);
    }

    private AsignacionGuia obtener(UUID id) {
        return asignaciones.buscarPorId(id).orElseThrow(() -> new NoEncontradoException("La asignación no existe."));
    }
}
