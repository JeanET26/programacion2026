package grupoctema12.servicio;

import grupoctema12.dao.FabricaDao;
import grupoctema12.seguridad.HashContrasena;

/**
 * <b>Raíz de composición</b>: el único lugar donde se crean los servicios y
 * se les entregan sus dependencias (inyección por constructor, sin
 * frameworks). La consola y el servidor web reciben este objeto ya armado;
 * ninguna clase hace {@code new} de un DAO por su cuenta.
 *
 * <p>Cambiar de archivos JSON a MySQL = pasar otra {@link FabricaDao}.</p>
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class Servicios {
    private final AutenticacionServicio autenticacion;
    private final ZonaServicio zonas;
    private final HabitatServicio habitats;
    private final EspecieServicio especies;
    private final ItinerarioServicio itinerarios;
    private final PersonalServicio personal;
    private final AsignacionGuiaServicio asignacionesGuia;
    private final AsignacionCuidadoServicio asignacionesCuidado;
    private final MisRecorridosServicio misRecorridos;
    private final MisEspeciesServicio misEspecies;

    public Servicios(FabricaDao dao) {
        HashContrasena hash = new HashContrasena();
        VerificadorHorarios horarios = new VerificadorHorarios(dao.asignacionesGuia(), dao.itinerarios());
        autenticacion = new AutenticacionServicio(dao.usuarios(), hash);
        zonas = new ZonaServicio(dao.zonas(), dao.especies());
        habitats = new HabitatServicio(dao.habitats(), dao.especies());
        especies = new EspecieServicio(dao.especies(), dao.zonas(), dao.habitats(), dao.itinerarios(),
                dao.asignacionesCuidado());
        itinerarios = new ItinerarioServicio(dao.itinerarios(), dao.especies(), dao.zonas(),
                dao.asignacionesGuia(), horarios);
        personal = new PersonalServicio(dao.usuarios(), hash, dao.asignacionesGuia(), dao.asignacionesCuidado());
        asignacionesGuia = new AsignacionGuiaServicio(dao.asignacionesGuia(), dao.usuarios(), dao.itinerarios(),
                horarios);
        asignacionesCuidado = new AsignacionCuidadoServicio(dao.asignacionesCuidado(), dao.usuarios(),
                dao.especies());
        misRecorridos = new MisRecorridosServicio(dao.asignacionesGuia(), dao.itinerarios(), itinerarios);
        misEspecies = new MisEspeciesServicio(dao.asignacionesCuidado(), dao.especies(), dao.zonas(),
                dao.habitats(), dao.usuarios());
    }

    public AutenticacionServicio autenticacion() { return autenticacion; }
    public ZonaServicio zonas() { return zonas; }
    public HabitatServicio habitats() { return habitats; }
    public EspecieServicio especies() { return especies; }
    public ItinerarioServicio itinerarios() { return itinerarios; }
    public PersonalServicio personal() { return personal; }
    public AsignacionGuiaServicio asignacionesGuia() { return asignacionesGuia; }
    public AsignacionCuidadoServicio asignacionesCuidado() { return asignacionesCuidado; }
    public MisRecorridosServicio misRecorridos() { return misRecorridos; }
    public MisEspeciesServicio misEspecies() { return misEspecies; }
}
