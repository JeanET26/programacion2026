package grupoctema12.servicio;

import grupoctema12.dao.AsignacionCuidadoDao;
import grupoctema12.dao.AsignacionGuiaDao;
import grupoctema12.dao.UsuarioDao;
import grupoctema12.excepciones.ConflictoException;
import grupoctema12.excepciones.DatoInvalidoException;
import grupoctema12.excepciones.NoEncontradoException;
import grupoctema12.modelo.Cuidador;
import grupoctema12.modelo.Empleado;
import grupoctema12.modelo.Guia;
import grupoctema12.modelo.Permiso;
import grupoctema12.modelo.Rol;
import grupoctema12.modelo.Usuario;
import grupoctema12.seguridad.ControlAcceso;
import grupoctema12.seguridad.HashContrasena;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * Alta, modificación y baja de guías y cuidadores.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class PersonalServicio {
    private final UsuarioDao usuarios;
    private final HashContrasena hash;
    private final AsignacionGuiaDao asignacionesGuia;
    private final AsignacionCuidadoDao asignacionesCuidado;

    public PersonalServicio(UsuarioDao usuarios, HashContrasena hash, AsignacionGuiaDao asignacionesGuia,
            AsignacionCuidadoDao asignacionesCuidado) {
        this.usuarios = usuarios;
        this.hash = hash;
        this.asignacionesGuia = asignacionesGuia;
        this.asignacionesCuidado = asignacionesCuidado;
    }

    public List<Empleado> listar(Usuario actor) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        return usuarios.listarPorTipo(Empleado.class).stream()
                .sorted(Comparator.comparing(Empleado::getRol).thenComparing(Empleado::getNombre)).toList();
    }

    public List<Guia> listarGuias(Usuario actor) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        return usuarios.listarPorTipo(Guia.class);
    }

    public List<Cuidador> listarCuidadores(Usuario actor) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        return usuarios.listarPorTipo(Cuidador.class);
    }

    public Empleado crear(Usuario actor, Datos.Empleado d) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        if (d.nombreUsuario() != null && usuarios.buscarPorNombreUsuario(d.nombreUsuario()).isPresent()) {
            throw new ConflictoException("El nombre de usuario " + d.nombreUsuario() + " ya está en uso.");
        }
        Empleado nuevo = construir(UUID.randomUUID(), d.rol(), d.nombreUsuario(), hash.generar(d.contrasena()), d);
        usuarios.guardar(nuevo);
        return nuevo;
    }

    public Empleado actualizar(Usuario actor, UUID id, Datos.Empleado d) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        Empleado actual = obtener(id);
        String nuevoHash = d.contrasena() == null || d.contrasena().isEmpty()
                ? actual.getHashContrasena() : hash.generar(d.contrasena());
        // El rol y el usuario no se cambian: se conservan los actuales.
        Empleado nuevo = construir(id, actual.getRol(), actual.getNombreUsuario(), nuevoHash, d);
        usuarios.actualizar(nuevo);
        return nuevo;
    }

    public void eliminar(Usuario actor, UUID id) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        obtener(id);
        if (!asignacionesGuia.buscarPorGuia(id).isEmpty() || !asignacionesCuidado.buscarPorCuidador(id).isEmpty()) {
            throw new ConflictoException("No se puede eliminar: la persona tiene asignaciones. Quitalas primero.");
        }
        usuarios.eliminar(id);
    }

    private Empleado obtener(UUID id) {
        return usuarios.buscarPorIdYTipo(id, Empleado.class)
                .orElseThrow(() -> new NoEncontradoException("El empleado no existe."));
    }

    /** Fábrica: crea la subclase que corresponde al rol elegido. */
    private static Empleado construir(UUID id, Rol rol, String usuario, String hashClave, Datos.Empleado d) {
        if (rol == null) {
            throw new DatoInvalidoException("rol", "Elegí si es guía o cuidador.");
        }
        return switch (rol) {
            case GUIA -> new Guia(id, usuario, hashClave, d.nombre(), d.direccion(), d.telefono(), d.fechaIngreso());
            case CUIDADOR -> new Cuidador(id, usuario, hashClave, d.nombre(), d.direccion(), d.telefono(),
                    d.fechaIngreso());
            case ADMINISTRADOR -> throw new DatoInvalidoException("rol", "Desde aquí solo se registran guías y cuidadores.");
        };
    }
}
