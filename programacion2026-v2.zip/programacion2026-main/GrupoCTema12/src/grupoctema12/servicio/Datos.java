package grupoctema12.servicio;

import grupoctema12.modelo.Rol;
import java.time.LocalDate;
import java.util.Set;
import java.util.UUID;

/**
 * Datos de entrada de los servicios (lo que llega de un formulario web o de
 * la consola). Son {@code record}: inmutables y sin lógica; las validaciones
 * las hacen las entidades y los servicios.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class Datos {
    private Datos() { }

    public record Zona(String nombre, double extensionM2) { }

    public record Habitat(String nombre, String clima, String vegetacion, Set<String> continentes) { }

    public record Especie(String nombreEspanol, String nombreCientifico, String descripcion,
            UUID zonaId, Set<UUID> habitatIds) { }

    /** {@code numero} (1..99) solo se usa al crear; el código IT-XX no cambia después. */
    public record Itinerario(Integer numero, int duracionMinutos, double longitudKm, int maximoVisitantes,
            Set<UUID> especieIds) { }

    /** {@code contrasena} es obligatoria al crear y opcional al modificar (si viene, se reemplaza). */
    public record Empleado(Rol rol, String nombreUsuario, String contrasena, String nombre,
            String direccion, String telefono, LocalDate fechaIngreso) { }
}
