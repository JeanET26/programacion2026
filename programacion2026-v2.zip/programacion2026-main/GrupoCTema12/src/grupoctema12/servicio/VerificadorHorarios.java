package grupoctema12.servicio;

import grupoctema12.dao.AsignacionGuiaDao;
import grupoctema12.dao.ItinerarioDao;
import grupoctema12.excepciones.ConflictoException;
import grupoctema12.modelo.AsignacionGuia;
import grupoctema12.modelo.Itinerario;
import java.time.Duration;
import java.time.LocalTime;
import java.util.UUID;

/**
 * Única regla de horarios del sistema: un guía no puede tener dos recorridos
 * que se superpongan. Un recorrido ocupa desde su hora de salida hasta la
 * hora de salida + duración.
 *
 * <p>Antes había dos reglas distintas (al asignar se comparaba solo la misma
 * hora y el mismo itinerario; al cambiar la hora, cualquier itinerario). Al
 * estar en una sola clase, la usan todos los servicios y no se contradicen.</p>
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class VerificadorHorarios {
    private final AsignacionGuiaDao asignaciones;
    private final ItinerarioDao itinerarios;

    public VerificadorHorarios(AsignacionGuiaDao asignaciones, ItinerarioDao itinerarios) {
        this.asignaciones = asignaciones;
        this.itinerarios = itinerarios;
    }

    /**
     * @param guiaId        guía a controlar
     * @param inicio        hora de salida propuesta
     * @param duracion      duración del recorrido propuesto
     * @param ignorarId     asignación que se está modificando (no se compara consigo misma), o null
     */
    public void verificarDisponible(UUID guiaId, LocalTime inicio, Duration duracion, UUID ignorarId) {
        LocalTime fin = finDe(inicio, duracion);
        for (AsignacionGuia otra : asignaciones.buscarPorGuia(guiaId)) {
            if (otra.getId().equals(ignorarId)) {
                continue;
            }
            Duration durOtra = itinerarios.buscarPorId(otra.getItinerarioId())
                    .map(Itinerario::getDuracion).orElse(Duration.ZERO);
            LocalTime finOtra = finDe(otra.getHora(), durOtra);
            boolean seSuperponen = inicio.isBefore(finOtra) && otra.getHora().isBefore(fin);
            if (seSuperponen) {
                throw new ConflictoException("El guía ya tiene un recorrido de " + otra.getHora() + " a " + finOtra
                        + " que se superpone con el horario " + inicio + "–" + fin + ".");
            }
        }
    }

    /** Hora de finalización; si pasaría la medianoche se rechaza. */
    public static LocalTime finDe(LocalTime inicio, Duration duracion) {
        LocalTime fin = inicio.plus(duracion);
        if (fin.isBefore(inicio) || (fin.equals(LocalTime.MIDNIGHT) && !duracion.isZero())) {
            throw new ConflictoException("El recorrido no puede terminar después de la medianoche.");
        }
        return fin;
    }
}
