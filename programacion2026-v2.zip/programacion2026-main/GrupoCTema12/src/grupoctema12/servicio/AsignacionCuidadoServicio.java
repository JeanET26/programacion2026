package grupoctema12.servicio;

import grupoctema12.dao.AsignacionCuidadoDao;
import grupoctema12.dao.EspecieDao;
import grupoctema12.dao.UsuarioDao;
import grupoctema12.excepciones.ConflictoException;
import grupoctema12.excepciones.DatoInvalidoException;
import grupoctema12.excepciones.NoEncontradoException;
import grupoctema12.modelo.AsignacionCuidado;
import grupoctema12.modelo.Cuidador;
import grupoctema12.modelo.Permiso;
import grupoctema12.modelo.Usuario;
import grupoctema12.seguridad.ControlAcceso;
import grupoctema12.util.Validaciones;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * El administrador asigna cuidadores a especies desde una fecha.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class AsignacionCuidadoServicio {
    private final AsignacionCuidadoDao asignaciones;
    private final UsuarioDao usuarios;
    private final EspecieDao especies;

    public AsignacionCuidadoServicio(AsignacionCuidadoDao asignaciones, UsuarioDao usuarios, EspecieDao especies) {
        this.asignaciones = asignaciones;
        this.usuarios = usuarios;
        this.especies = especies;
    }

    public List<AsignacionCuidado> listar(Usuario actor) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        return asignaciones.listarTodos().stream()
                .sorted(Comparator.comparing(AsignacionCuidado::getFechaAsignacion)).toList();
    }

    public AsignacionCuidado asignar(Usuario actor, UUID cuidadorId, UUID especieId, LocalDate fecha) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        usuarios.buscarPorIdYTipo(Validaciones.obligatorio(cuidadorId, "cuidadorId"), Cuidador.class)
                .orElseThrow(() -> new DatoInvalidoException("cuidadorId", "El cuidador elegido no existe."));
        if (!especies.existe(Validaciones.obligatorio(especieId, "especieId"))) {
            throw new DatoInvalidoException("especieId", "La especie elegida no existe.");
        }
        boolean repetida = asignaciones.buscarPorCuidador(cuidadorId).stream()
                .anyMatch(a -> a.getEspecieId().equals(especieId));
        if (repetida) {
            throw new ConflictoException("Ese cuidador ya está a cargo de esa especie.");
        }
        AsignacionCuidado nueva = new AsignacionCuidado(cuidadorId, especieId, fecha);
        asignaciones.guardar(nueva);
        return nueva;
    }

    public AsignacionCuidado cambiarFecha(Usuario actor, UUID asignacionId, LocalDate fecha) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        AsignacionCuidado a = obtener(asignacionId);
        AsignacionCuidado nueva = new AsignacionCuidado(a.getId(), a.getCuidadorId(), a.getEspecieId(), fecha);
        asignaciones.actualizar(nueva);
        return nueva;
    }

    public void eliminar(Usuario actor, UUID asignacionId) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        obtener(asignacionId);
        asignaciones.eliminar(asignacionId);
    }

    private AsignacionCuidado obtener(UUID id) {
        return asignaciones.buscarPorId(id).orElseThrow(() -> new NoEncontradoException("La asignación no existe."));
    }
}
