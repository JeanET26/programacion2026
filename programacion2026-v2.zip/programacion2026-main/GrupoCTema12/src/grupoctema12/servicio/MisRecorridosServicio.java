package grupoctema12.servicio;

import grupoctema12.dao.AsignacionGuiaDao;
import grupoctema12.dao.ItinerarioDao;
import grupoctema12.modelo.AsignacionGuia;
import grupoctema12.modelo.Especie;
import grupoctema12.modelo.Itinerario;
import grupoctema12.modelo.Permiso;
import grupoctema12.modelo.Usuario;
import grupoctema12.modelo.Zona;
import grupoctema12.seguridad.ControlAcceso;
import java.time.LocalTime;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * Lo que ve un guía: SOLO sus propios horarios y recorridos. El id se toma
 * del usuario que inició sesión, nunca de un dato que mande el navegador,
 * así un guía no puede pedir los recorridos de otro.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class MisRecorridosServicio {
    private final AsignacionGuiaDao asignaciones;
    private final ItinerarioDao itinerarios;
    private final ItinerarioServicio itinerarioServicio;

    public MisRecorridosServicio(AsignacionGuiaDao asignaciones, ItinerarioDao itinerarios,
            ItinerarioServicio itinerarioServicio) {
        this.asignaciones = asignaciones;
        this.itinerarios = itinerarios;
        this.itinerarioServicio = itinerarioServicio;
    }

    /** Recorrido asignado con todo lo necesario para mostrarlo. */
    public record RecorridoAsignado(AsignacionGuia asignacion, LocalTime horaFin, Itinerario itinerario,
            List<Zona> zonas, List<Especie> especies) { }

    public List<RecorridoAsignado> consultar(Usuario actor) {
        ControlAcceso.exigir(actor, Permiso.VER_RECORRIDOS_PROPIOS);
        return asignaciones.buscarPorGuia(actor.getId()).stream()
                .sorted(Comparator.comparing(AsignacionGuia::getHora))
                .map(a -> itinerarios.buscarPorId(a.getItinerarioId()).map(it -> new RecorridoAsignado(a,
                        VerificadorHorarios.finDe(a.getHora(), it.getDuracion()), it,
                        itinerarioServicio.zonasDe(it), itinerarioServicio.especiesDe(it))))
                .flatMap(Optional::stream)
                .toList();
    }
}
