package grupoctema12.servicio;

import grupoctema12.dao.EspecieDao;
import grupoctema12.dao.HabitatDao;
import grupoctema12.excepciones.ConflictoException;
import grupoctema12.excepciones.NoEncontradoException;
import grupoctema12.modelo.Habitat;
import grupoctema12.modelo.Permiso;
import grupoctema12.modelo.Usuario;
import grupoctema12.seguridad.ControlAcceso;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * Reglas de negocio de los hábitats.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class HabitatServicio {
    private final HabitatDao habitats;
    private final EspecieDao especies;

    public HabitatServicio(HabitatDao habitats, EspecieDao especies) {
        this.habitats = habitats;
        this.especies = especies;
    }

    public List<Habitat> listar(Usuario actor) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        return habitats.listarTodos().stream().sorted(Comparator.comparing(Habitat::getNombre)).toList();
    }

    public Habitat crear(Usuario actor, Datos.Habitat d) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        Habitat habitat = new Habitat(d.nombre(), d.clima(), d.vegetacion(), d.continentes());
        verificarNombreUnico(habitat.getNombre(), null);
        habitats.guardar(habitat);
        return habitat;
    }

    public Habitat actualizar(Usuario actor, UUID id, Datos.Habitat d) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        obtener(id);
        Habitat nuevo = new Habitat(id, d.nombre(), d.clima(), d.vegetacion(), d.continentes());
        verificarNombreUnico(nuevo.getNombre(), id);
        habitats.actualizar(nuevo);
        return nuevo;
    }

    public void eliminar(Usuario actor, UUID id) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        obtener(id);
        if (!especies.buscarPorHabitat(id).isEmpty()) {
            throw new ConflictoException("No se puede eliminar: hay especies asociadas a este hábitat.");
        }
        habitats.eliminar(id);
    }

    private Habitat obtener(UUID id) {
        return habitats.buscarPorId(id).orElseThrow(() -> new NoEncontradoException("El hábitat no existe."));
    }

    private void verificarNombreUnico(String nombre, UUID idPropio) {
        habitats.buscarPorNombre(nombre).filter(h -> !h.getId().equals(idPropio)).ifPresent(h -> {
            throw new ConflictoException("Ya existe un hábitat llamado " + nombre + ".");
        });
    }
}
