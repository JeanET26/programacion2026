package grupoctema12.servicio;

import grupoctema12.dao.AsignacionCuidadoDao;
import grupoctema12.dao.EspecieDao;
import grupoctema12.dao.HabitatDao;
import grupoctema12.dao.UsuarioDao;
import grupoctema12.dao.ZonaDao;
import grupoctema12.modelo.AsignacionCuidado;
import grupoctema12.modelo.Cuidador;
import grupoctema12.modelo.Especie;
import grupoctema12.modelo.Habitat;
import grupoctema12.modelo.Permiso;
import grupoctema12.modelo.Usuario;
import grupoctema12.modelo.Zona;
import grupoctema12.seguridad.ControlAcceso;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * Lo que ve un cuidador: SOLO las especies a su cargo, con su zona,
 * hábitats y quiénes más las cuidan (solo el nombre, sin datos personales).
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class MisEspeciesServicio {
    private final AsignacionCuidadoDao asignaciones;
    private final EspecieDao especies;
    private final ZonaDao zonas;
    private final HabitatDao habitats;
    private final UsuarioDao usuarios;

    public MisEspeciesServicio(AsignacionCuidadoDao asignaciones, EspecieDao especies, ZonaDao zonas,
            HabitatDao habitats, UsuarioDao usuarios) {
        this.asignaciones = asignaciones;
        this.especies = especies;
        this.zonas = zonas;
        this.habitats = habitats;
        this.usuarios = usuarios;
    }

    public record EspecieACargo(AsignacionCuidado asignacion, Especie especie, Optional<Zona> zona,
            List<Habitat> habitats, List<String> otrosCuidadores) { }

    public List<EspecieACargo> consultar(Usuario actor) {
        ControlAcceso.exigir(actor, Permiso.VER_ESPECIES_PROPIAS);
        return asignaciones.buscarPorCuidador(actor.getId()).stream()
                .sorted(Comparator.comparing(AsignacionCuidado::getFechaAsignacion))
                .map(a -> especies.buscarPorId(a.getEspecieId()).map(e -> new EspecieACargo(a, e,
                        e.getZonaId().flatMap(zonas::buscarPorId),
                        e.getHabitatIds().stream().map(habitats::buscarPorId).flatMap(Optional::stream).toList(),
                        otrosCuidadores(e, actor))))
                .flatMap(Optional::stream)
                .toList();
    }

    private List<String> otrosCuidadores(Especie e, Usuario actor) {
        return asignaciones.buscarPorEspecie(e.getId()).stream()
                .filter(a -> !a.getCuidadorId().equals(actor.getId()))
                .map(a -> usuarios.buscarPorIdYTipo(a.getCuidadorId(), Cuidador.class).map(Cuidador::getNombre))
                .flatMap(Optional::stream).toList();
    }

    /** Días que lleva a cargo (útil para mostrar "hace N días"). */
    public static long diasACargo(LocalDate desde) {
        return Math.max(0, java.time.temporal.ChronoUnit.DAYS.between(desde, LocalDate.now()));
    }
}
