package grupoctema12.servicio;

import grupoctema12.dao.UsuarioDao;
import grupoctema12.excepciones.DatoInvalidoException;
import grupoctema12.excepciones.NoAutenticadoException;
import grupoctema12.modelo.Permiso;
import grupoctema12.modelo.Usuario;
import grupoctema12.seguridad.ControlAcceso;
import grupoctema12.seguridad.HashContrasena;
import java.util.Optional;
import java.util.UUID;

/**
 * Inicio de sesión y cambio de contraseña.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class AutenticacionServicio {
    private static final String MENSAJE_GENERICO = "Usuario o contraseña incorrectos.";

    private final UsuarioDao usuarios;
    private final HashContrasena hash;
    /** Hash de relleno: se verifica igual aunque el usuario no exista, para que la demora no revele si existe. */
    private final String hashRelleno;

    public AutenticacionServicio(UsuarioDao usuarios, HashContrasena hash) {
        this.usuarios = usuarios;
        this.hash = hash;
        this.hashRelleno = hash.generar("relleno-" + UUID.randomUUID().toString().substring(0, 8) + "1");
    }

    /**
     * Devuelve el usuario si la contraseña es correcta. El mensaje de error es
     * siempre el mismo para no revelar qué nombres de usuario existen.
     */
    public Usuario autenticar(String nombreUsuario, String contrasena) {
        Optional<Usuario> usuario = usuarios.buscarPorNombreUsuario(nombreUsuario == null ? "" : nombreUsuario);
        String guardado = usuario.map(Usuario::getHashContrasena).orElse(hashRelleno);
        boolean correcta = hash.verificar(contrasena, guardado);
        if (usuario.isEmpty() || !correcta) {
            throw new NoAutenticadoException(MENSAJE_GENERICO);
        }
        return usuario.get();
    }

    public Optional<Usuario> buscarPorId(UUID id) {
        return usuarios.buscarPorId(id);
    }

    public void cambiarContrasena(Usuario actor, String actual, String nueva) {
        ControlAcceso.exigir(actor, Permiso.VER_PERFIL_PROPIO);
        if (!hash.verificar(actual, actor.getHashContrasena())) {
            throw new DatoInvalidoException("actual", "La contraseña actual no es correcta.");
        }
        if (nueva != null && nueva.equals(actual)) {
            throw new DatoInvalidoException("nueva", "La nueva contraseña debe ser distinta de la actual.");
        }
        actor.setHashContrasena(hash.generar(nueva));
        usuarios.actualizar(actor);
    }

    /** Indica si ya existe al menos un usuario (si no, hay que crear el primer administrador). */
    public boolean hayUsuarios() {
        return !usuarios.listarTodos().isEmpty();
    }
}
