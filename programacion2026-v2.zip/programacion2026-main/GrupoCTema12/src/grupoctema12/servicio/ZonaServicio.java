package grupoctema12.servicio;

import grupoctema12.dao.EspecieDao;
import grupoctema12.dao.ZonaDao;
import grupoctema12.excepciones.ConflictoException;
import grupoctema12.excepciones.NoEncontradoException;
import grupoctema12.modelo.Permiso;
import grupoctema12.modelo.Usuario;
import grupoctema12.modelo.Zona;
import grupoctema12.seguridad.ControlAcceso;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * Reglas de negocio de las zonas. Recibe los DAO por constructor
 * (inyección de dependencias): no sabe si los datos están en JSON o MySQL.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class ZonaServicio {
    private final ZonaDao zonas;
    private final EspecieDao especies;

    public ZonaServicio(ZonaDao zonas, EspecieDao especies) {
        this.zonas = zonas;
        this.especies = especies;
    }

    public List<Zona> listar(Usuario actor) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        return zonas.listarTodos().stream().sorted(Comparator.comparing(Zona::getNombre)).toList();
    }

    public Zona crear(Usuario actor, Datos.Zona datos) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        Zona zona = new Zona(datos.nombre(), datos.extensionM2());
        verificarNombreUnico(zona.getNombre(), null);
        zonas.guardar(zona);
        return zona;
    }

    public Zona actualizar(Usuario actor, UUID id, Datos.Zona datos) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        obtener(id);
        Zona nueva = new Zona(id, datos.nombre(), datos.extensionM2());
        verificarNombreUnico(nueva.getNombre(), id);
        zonas.actualizar(nueva);
        return nueva;
    }

    public void eliminar(Usuario actor, UUID id) {
        ControlAcceso.exigir(actor, Permiso.ADMINISTRAR_PARQUE);
        obtener(id);
        if (!especies.buscarPorZona(id).isEmpty()) {
            throw new ConflictoException("No se puede eliminar: hay especies ubicadas en esta zona.");
        }
        zonas.eliminar(id);
    }

    public int cantidadEspecies(UUID zonaId) {
        return especies.buscarPorZona(zonaId).size();
    }

    private Zona obtener(UUID id) {
        return zonas.buscarPorId(id).orElseThrow(() -> new NoEncontradoException("La zona no existe."));
    }

    private void verificarNombreUnico(String nombre, UUID idPropio) {
        zonas.buscarPorNombre(nombre).filter(z -> !z.getId().equals(idPropio)).ifPresent(z -> {
            throw new ConflictoException("Ya existe una zona llamada " + nombre + ".");
        });
    }
}
