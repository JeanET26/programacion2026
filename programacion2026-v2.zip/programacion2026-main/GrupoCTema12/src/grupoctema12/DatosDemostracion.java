package grupoctema12;

import grupoctema12.dao.FabricaDao;
import grupoctema12.modelo.Administrador;
import grupoctema12.modelo.Empleado;
import grupoctema12.modelo.Especie;
import grupoctema12.modelo.Habitat;
import grupoctema12.modelo.Itinerario;
import grupoctema12.modelo.Rol;
import grupoctema12.modelo.Zona;
import grupoctema12.seguridad.HashContrasena;
import grupoctema12.servicio.Datos;
import grupoctema12.servicio.Servicios;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Carga datos de ejemplo la primera vez que se ejecuta (cuando no hay
 * usuarios). Todo pasa por los servicios, así se respetan las mismas
 * reglas que en el uso normal.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class DatosDemostracion {
    public static final String CLAVE_ADMIN = "Admin2026!";
    public static final String CLAVE_EMPLEADOS = "Marino2026!";

    private DatosDemostracion() { }

    public static boolean cargarSiHaceFalta(FabricaDao dao, Servicios s) {
        if (s.autenticacion().hayUsuarios()) {
            return false;
        }
        Administrador admin = new Administrador("admin.ana", new HashContrasena().generar(CLAVE_ADMIN), "Ana Ruiz");
        dao.usuarios().guardar(admin);

        Zona arrecife = s.zonas().crear(admin, new Datos.Zona("Arrecife central", 850));
        Zona tunel = s.zonas().crear(admin, new Datos.Zona("Túnel oceánico", 1100));
        Zona costa = s.zonas().crear(admin, new Datos.Zona("Costa austral", 1400));
        Zona bahia = s.zonas().crear(admin, new Datos.Zona("Bahía de los delfines", 2600));

        Habitat coral = s.habitats().crear(admin, new Datos.Habitat("Arrecife coralino", "Tropical cálido",
                "Corales y algas", Set.of("Oceanía", "América", "Asia")));
        Habitat rocosa = s.habitats().crear(admin, new Datos.Habitat("Costa rocosa", "Templado frío",
                "Algas pardas", Set.of("América")));
        Habitat abierto = s.habitats().crear(admin, new Datos.Habitat("Mar abierto", "Variable",
                "Fitoplancton", Set.of("América", "África", "Europa", "Asia", "Oceanía")));

        Especie payaso = especie(s, admin, "Pez payaso", "Amphiprion ocellaris",
                "Pez marino que vive asociado a las anémonas.", arrecife, coral);
        Especie tiburon = especie(s, admin, "Tiburón de punta negra", "Carcharhinus melanopterus",
                "Tiburón costero de arrecifes tropicales.", tunel, coral);
        Especie tortuga = especie(s, admin, "Tortuga verde", "Chelonia mydas",
                "Tortuga marina herbívora que migra miles de kilómetros.", tunel, coral, abierto);
        Especie lobo = especie(s, admin, "Lobo marino sudamericano", "Otaria flavescens",
                "Mamífero marino de las costas de Sudamérica.", costa, rocosa);
        Especie pinguino = especie(s, admin, "Pingüino de Magallanes", "Spheniscus magellanicus",
                "Ave marina que anida en la costa patagónica.", costa, rocosa, abierto);
        Especie delfin = especie(s, admin, "Delfín nariz de botella", "Tursiops truncatus",
                "Cetáceo muy sociable que se comunica con silbidos.", bahia, abierto);

        Itinerario it1 = s.itinerarios().crear(admin, new Datos.Itinerario(1, 45, 1.8, 25,
                ids(payaso, tiburon, tortuga)));
        Itinerario it2 = s.itinerarios().crear(admin, new Datos.Itinerario(2, 60, 2.4, 30,
                ids(lobo, pinguino, delfin)));

        Empleado lucia = s.personal().crear(admin, new Datos.Empleado(Rol.GUIA, "guia.lucia", CLAVE_EMPLEADOS,
                "Lucía Gómez", "Av. del Mar 120", "11 5555-1000", LocalDate.of(2024, 3, 4)));
        Empleado martin = s.personal().crear(admin, new Datos.Empleado(Rol.GUIA, "guia.martin", CLAVE_EMPLEADOS,
                "Martín Sosa", "Calle Ostra 9", "11 5555-1001", LocalDate.of(2025, 1, 10)));
        Empleado diego = s.personal().crear(admin, new Datos.Empleado(Rol.CUIDADOR, "cuidador.diego",
                CLAVE_EMPLEADOS, "Diego Pérez", "Calle Coral 45", "11 5555-2000", LocalDate.of(2023, 8, 15)));
        Empleado sofia = s.personal().crear(admin, new Datos.Empleado(Rol.CUIDADOR, "cuidador.sofia",
                CLAVE_EMPLEADOS, "Sofía Ibarra", "Pasaje Ancla 3", "11 5555-2001", LocalDate.of(2024, 6, 1)));

        s.asignacionesGuia().asignar(admin, lucia.getId(), it1.getId(), LocalTime.of(10, 0));
        s.asignacionesGuia().asignar(admin, lucia.getId(), it2.getId(), LocalTime.of(15, 0));
        s.asignacionesGuia().asignar(admin, martin.getId(), it2.getId(), LocalTime.of(11, 0));
        s.asignacionesCuidado().asignar(admin, diego.getId(), payaso.getId(), LocalDate.of(2025, 2, 1));
        s.asignacionesCuidado().asignar(admin, diego.getId(), tortuga.getId(), LocalDate.of(2025, 5, 12));
        s.asignacionesCuidado().asignar(admin, sofia.getId(), tortuga.getId(), LocalDate.of(2025, 7, 1));
        s.asignacionesCuidado().asignar(admin, sofia.getId(), lobo.getId(), LocalDate.of(2024, 9, 20));
        return true;
    }

    private static Especie especie(Servicios s, Administrador admin, String nombre, String cientifico,
            String descripcion, Zona zona, Habitat... habitats) {
        Set<UUID> hs = new LinkedHashSet<>();
        for (Habitat h : habitats) {
            hs.add(h.getId());
        }
        return s.especies().crear(admin, new Datos.Especie(nombre, cientifico, descripcion, zona.getId(), hs));
    }

    private static Set<UUID> ids(Especie... especies) {
        Set<UUID> r = new LinkedHashSet<>();
        List.of(especies).forEach(e -> r.add(e.getId()));
        return r;
    }

}
