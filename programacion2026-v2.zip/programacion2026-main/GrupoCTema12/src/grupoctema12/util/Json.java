package grupoctema12.util;

import grupoctema12.excepciones.DatoInvalidoException;
import java.math.BigDecimal;
import java.time.temporal.Temporal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Lector y escritor de JSON mínimo, sin librerías externas.
 * <ul>
 *   <li>{@link #leer(String)}: convierte texto JSON en Map / List / String /
 *   Long / Double / Boolean / null.</li>
 *   <li>{@link #escribir(Object)}: hace lo inverso. También acepta UUID y
 *   fechas/horas (usa su toString ISO).</li>
 * </ul>
 * En un proyecto profesional se usaría Jackson o Gson; acá se escribe a mano
 * para no agregar dependencias al proyecto Ant de NetBeans.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class Json {
    private static final int PROFUNDIDAD_MAXIMA = 32;

    private final String texto;
    private int pos;

    private Json(String texto) {
        this.texto = texto;
    }

    /* ============================ Lectura ============================ */

    public static Object leer(String texto) {
        if (texto == null) {
            throw error("Cuerpo JSON vacío.");
        }
        Json lector = new Json(texto);
        lector.saltarEspacios();
        Object valor = lector.valor(0);
        lector.saltarEspacios();
        if (lector.pos != texto.length()) {
            throw error("Hay caracteres de más después del JSON.");
        }
        return valor;
    }

    /** Lee un JSON que tiene que ser un objeto {...}. */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> leerObjeto(String texto) {
        Object valor = leer(texto);
        if (!(valor instanceof Map)) {
            throw error("Se esperaba un objeto JSON.");
        }
        return (Map<String, Object>) valor;
    }

    private Object valor(int profundidad) {
        if (profundidad > PROFUNDIDAD_MAXIMA) {
            throw error("JSON demasiado anidado.");
        }
        if (pos >= texto.length()) {
            throw error("JSON incompleto.");
        }
        char c = texto.charAt(pos);
        return switch (c) {
            case '{' -> objeto(profundidad);
            case '[' -> arreglo(profundidad);
            case '"' -> cadena();
            case 't' -> literal("true", Boolean.TRUE);
            case 'f' -> literal("false", Boolean.FALSE);
            case 'n' -> literal("null", null);
            default -> numero();
        };
    }

    private Map<String, Object> objeto(int profundidad) {
        Map<String, Object> mapa = new LinkedHashMap<>();
        pos++;
        saltarEspacios();
        if (consumir('}')) {
            return mapa;
        }
        do {
            saltarEspacios();
            if (pos >= texto.length() || texto.charAt(pos) != '"') {
                throw error("Se esperaba el nombre de un campo.");
            }
            String clave = cadena();
            saltarEspacios();
            if (!consumir(':')) {
                throw error("Falta ':' después de \"" + clave + "\".");
            }
            saltarEspacios();
            mapa.put(clave, valor(profundidad + 1));
            saltarEspacios();
        } while (consumir(','));
        if (!consumir('}')) {
            throw error("Falta '}'.");
        }
        return mapa;
    }

    private List<Object> arreglo(int profundidad) {
        List<Object> lista = new ArrayList<>();
        pos++;
        saltarEspacios();
        if (consumir(']')) {
            return lista;
        }
        do {
            saltarEspacios();
            lista.add(valor(profundidad + 1));
            saltarEspacios();
        } while (consumir(','));
        if (!consumir(']')) {
            throw error("Falta ']'.");
        }
        return lista;
    }

    private String cadena() {
        StringBuilder sb = new StringBuilder();
        pos++;
        while (pos < texto.length()) {
            char c = texto.charAt(pos++);
            if (c == '"') {
                return sb.toString();
            }
            if (c == '\\') {
                if (pos >= texto.length()) {
                    break;
                }
                char e = texto.charAt(pos++);
                switch (e) {
                    case '"', '\\', '/' -> sb.append(e);
                    case 'b' -> sb.append('\b');
                    case 'f' -> sb.append('\f');
                    case 'n' -> sb.append('\n');
                    case 'r' -> sb.append('\r');
                    case 't' -> sb.append('\t');
                    case 'u' -> {
                        if (pos + 4 > texto.length()) {
                            throw error("Escape \\u incompleto.");
                        }
                        try {
                            sb.append((char) Integer.parseInt(texto.substring(pos, pos + 4), 16));
                        } catch (NumberFormatException ex) {
                            throw error("Escape \\u inválido.");
                        }
                        pos += 4;
                    }
                    default -> throw error("Escape inválido.");
                }
            } else if (c < 0x20) {
                throw error("Carácter de control dentro de un texto.");
            } else {
                sb.append(c);
            }
        }
        throw error("Texto sin cerrar.");
    }

    private Object numero() {
        int inicio = pos;
        while (pos < texto.length() && "+-0123456789.eE".indexOf(texto.charAt(pos)) >= 0) {
            pos++;
        }
        String n = texto.substring(inicio, pos);
        if (n.isEmpty()) {
            throw error("Valor JSON inválido.");
        }
        try {
            if (n.matches("-?\\d{1,18}")) {
                return Long.parseLong(n);
            }
            double d = Double.parseDouble(n);
            if (Double.isNaN(d) || Double.isInfinite(d)) {
                throw error("Número inválido.");
            }
            return d;
        } catch (NumberFormatException ex) {
            throw error("Número inválido: " + n);
        }
    }

    private Object literal(String palabra, Object valor) {
        if (!texto.startsWith(palabra, pos)) {
            throw error("Valor JSON inválido.");
        }
        pos += palabra.length();
        return valor;
    }

    private boolean consumir(char c) {
        if (pos < texto.length() && texto.charAt(pos) == c) {
            pos++;
            return true;
        }
        return false;
    }

    private void saltarEspacios() {
        while (pos < texto.length() && Character.isWhitespace(texto.charAt(pos))) {
            pos++;
        }
    }

    private static DatoInvalidoException error(String mensaje) {
        return new DatoInvalidoException(null, "JSON inválido: " + mensaje);
    }

    /* ============================ Escritura ============================ */

    public static String escribir(Object valor) {
        StringBuilder sb = new StringBuilder();
        escribir(valor, sb);
        return sb.toString();
    }

    private static void escribir(Object v, StringBuilder sb) {
        if (v == null) {
            sb.append("null");
        } else if (v instanceof Map<?, ?> mapa) {
            sb.append('{');
            boolean primero = true;
            for (Map.Entry<?, ?> e : mapa.entrySet()) {
                if (!primero) {
                    sb.append(',');
                }
                primero = false;
                escribirTexto(String.valueOf(e.getKey()), sb);
                sb.append(':');
                escribir(e.getValue(), sb);
            }
            sb.append('}');
        } else if (v instanceof Collection<?> lista) {
            sb.append('[');
            boolean primero = true;
            for (Object item : lista) {
                if (!primero) {
                    sb.append(',');
                }
                primero = false;
                escribir(item, sb);
            }
            sb.append(']');
        } else if (v instanceof Boolean b) {
            sb.append(b);
        } else if (v instanceof Double d && (d.isNaN() || d.isInfinite())) {
            sb.append("null");
        } else if (v instanceof Number n) {
            sb.append(n instanceof Double || n instanceof Float
                    ? BigDecimal.valueOf(n.doubleValue()).stripTrailingZeros().toPlainString()
                    : n.toString());
        } else if (v instanceof UUID || v instanceof Temporal || v instanceof Enum<?>) {
            escribirTexto(v.toString(), sb);
        } else {
            escribirTexto(v.toString(), sb);
        }
    }

    /** Escapa comillas, barras, controles y también &lt; &gt; &amp; (evita inyectar HTML). */
    private static void escribirTexto(String s, StringBuilder sb) {
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20 || c == '<' || c == '>' || c == '&' || c == 0x2028 || c == 0x2029) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
                }
            }
        }
        sb.append('"');
    }
}
