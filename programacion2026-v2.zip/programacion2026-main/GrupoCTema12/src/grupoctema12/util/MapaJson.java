package grupoctema12.util;

import grupoctema12.excepciones.DatoInvalidoException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Envoltorio de un objeto JSON ya leído ({@code Map}) con getters tipados.
 * Convierte y valida cada campo; si algo no tiene el tipo esperado lanza
 * {@link DatoInvalidoException} indicando el campo. Lo usan los DAO JSON y
 * los controladores web.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class MapaJson {
    private final Map<String, Object> datos;

    public MapaJson(Map<String, Object> datos) {
        this.datos = datos == null ? Map.of() : datos;
    }

    public static MapaJson desdeTexto(String texto) {
        return new MapaJson(Json.leerObjeto(texto));
    }

    public boolean tiene(String campo) {
        return datos.get(campo) != null;
    }

    public String texto(String campo) {
        Object v = datos.get(campo);
        if (v == null) {
            return null;
        }
        if (!(v instanceof String s)) {
            throw invalido(campo, "debe ser un texto");
        }
        return s;
    }

    public long entero(String campo) {
        Object v = requerido(campo);
        if (v instanceof Long l) {
            return l;
        }
        if (v instanceof Double d && d == Math.rint(d)) {
            return d.longValue();
        }
        if (v instanceof String s) {
            try {
                return Long.parseLong(s.strip());
            } catch (NumberFormatException ex) {
                throw invalido(campo, "debe ser un número entero");
            }
        }
        throw invalido(campo, "debe ser un número entero");
    }

    public int enteroInt(String campo) {
        long v = entero(campo);
        if (v > Integer.MAX_VALUE || v < Integer.MIN_VALUE) {
            throw invalido(campo, "está fuera de rango");
        }
        return (int) v;
    }

    public double decimal(String campo) {
        Object v = requerido(campo);
        if (v instanceof Number n) {
            return n.doubleValue();
        }
        if (v instanceof String s) {
            try {
                return Double.parseDouble(s.strip().replace(',', '.'));
            } catch (NumberFormatException ex) {
                throw invalido(campo, "debe ser un número");
            }
        }
        throw invalido(campo, "debe ser un número");
    }

    public UUID uuid(String campo) {
        String s = texto(campo);
        if (s == null || s.isBlank()) {
            return null;
        }
        try {
            return UUID.fromString(s.strip());
        } catch (IllegalArgumentException ex) {
            throw invalido(campo, "no es un identificador válido");
        }
    }

    public UUID uuidRequerido(String campo) {
        UUID id = uuid(campo);
        if (id == null) {
            throw new DatoInvalidoException(campo, "El campo " + campo + " es obligatorio.");
        }
        return id;
    }

    public LocalDate fecha(String campo) {
        String s = texto(campo);
        if (s == null || s.isBlank()) {
            return null;
        }
        try {
            return LocalDate.parse(s.strip());
        } catch (DateTimeParseException ex) {
            throw invalido(campo, "debe tener el formato AAAA-MM-DD");
        }
    }

    public LocalTime hora(String campo) {
        String s = texto(campo);
        if (s == null || s.isBlank()) {
            return null;
        }
        try {
            return LocalTime.parse(s.strip());
        } catch (DateTimeParseException ex) {
            throw invalido(campo, "debe tener el formato HH:MM");
        }
    }

    public Duration minutos(String campo) {
        return Duration.ofMinutes(entero(campo));
    }

    public Set<String> listaTextos(String campo) {
        Set<String> resultado = new LinkedHashSet<>();
        for (Object o : lista(campo)) {
            if (!(o instanceof String s)) {
                throw invalido(campo, "debe contener solo textos");
            }
            resultado.add(s);
        }
        return resultado;
    }

    public Set<UUID> listaUuids(String campo) {
        Set<UUID> resultado = new LinkedHashSet<>();
        for (Object o : lista(campo)) {
            try {
                resultado.add(UUID.fromString(String.valueOf(o)));
            } catch (IllegalArgumentException ex) {
                throw invalido(campo, "contiene un identificador inválido");
            }
        }
        return resultado;
    }

    private Collection<?> lista(String campo) {
        Object v = datos.get(campo);
        if (v == null) {
            return List.of();
        }
        if (!(v instanceof Collection<?> c)) {
            throw invalido(campo, "debe ser una lista");
        }
        if (c.size() > 200) {
            throw invalido(campo, "tiene demasiados elementos");
        }
        return c;
    }

    private Object requerido(String campo) {
        Object v = datos.get(campo);
        if (v == null || (v instanceof String s && s.isBlank())) {
            throw new DatoInvalidoException(campo, "El campo " + campo + " es obligatorio.");
        }
        return v;
    }

    private static DatoInvalidoException invalido(String campo, String detalle) {
        return new DatoInvalidoException(campo, "El campo " + campo + " " + detalle + ".");
    }
}
