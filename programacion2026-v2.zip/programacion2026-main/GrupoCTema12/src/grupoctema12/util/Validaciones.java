package grupoctema12.util;

import grupoctema12.excepciones.DatoInvalidoException;
import java.util.Collection;
import java.util.Objects;

/**
 * Validaciones reutilizables por todas las clases del sistema.
 * Antes estaban dentro de {@code Usuario}, lo que obligaba a una Especie a
 * depender de Usuario para validar un texto (responsabilidad mal ubicada).
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class Validaciones {
    private Validaciones() { }

    /** Exige un texto no vacío de como máximo {@code largoMaximo} caracteres y lo devuelve sin espacios extremos. */
    public static String texto(String valor, String campo, int largoMaximo) {
        if (valor == null || valor.isBlank()) {
            throw new DatoInvalidoException(campo, "El campo " + campo + " es obligatorio.");
        }
        String limpio = valor.strip().replaceAll("\\s+", " ");
        if (limpio.length() > largoMaximo) {
            throw new DatoInvalidoException(campo, "El campo " + campo + " admite hasta " + largoMaximo + " caracteres.");
        }
        return limpio;
    }

    /** Exige que el texto cumpla una expresión regular. */
    public static String formato(String valor, String campo, String regex, String mensaje) {
        String limpio = texto(valor, campo, 200);
        if (!limpio.matches(regex)) {
            throw new DatoInvalidoException(campo, mensaje);
        }
        return limpio;
    }

    public static double positivo(double valor, String campo) {
        if (!(valor > 0) || Double.isInfinite(valor)) {
            throw new DatoInvalidoException(campo, "El campo " + campo + " debe ser mayor que cero.");
        }
        return valor;
    }

    public static int entero(int valor, String campo, int minimo, int maximo) {
        if (valor < minimo || valor > maximo) {
            throw new DatoInvalidoException(campo, "El campo " + campo + " debe estar entre " + minimo + " y " + maximo + ".");
        }
        return valor;
    }

    public static <T> T obligatorio(T valor, String campo) {
        if (valor == null) {
            throw new DatoInvalidoException(campo, "El campo " + campo + " es obligatorio.");
        }
        return valor;
    }

    public static <T extends Collection<?>> T noVacia(T coleccion, String campo) {
        if (coleccion == null || coleccion.isEmpty() || coleccion.stream().anyMatch(Objects::isNull)) {
            throw new DatoInvalidoException(campo, "Debe indicar al menos un valor en " + campo + ".");
        }
        return coleccion;
    }
}
