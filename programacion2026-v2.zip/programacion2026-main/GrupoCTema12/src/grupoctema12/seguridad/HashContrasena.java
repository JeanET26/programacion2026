package grupoctema12.seguridad;

import grupoctema12.excepciones.DatoInvalidoException;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Convierte contraseñas en un hash que no se puede revertir (PBKDF2 con
 * SHA-256, incluido en el JDK). Se guarda
 * {@code pbkdf2$iteraciones$sal$hash}; la contraseña real nunca se guarda.
 *
 * <ul>
 *   <li><b>Sal aleatoria:</b> dos usuarios con la misma contraseña tienen
 *   hashes distintos.</li>
 *   <li><b>Muchas iteraciones:</b> hacen lento probar millones de contraseñas
 *   si alguien roba el archivo.</li>
 *   <li><b>Comparación en tiempo constante:</b> {@code MessageDigest.isEqual}
 *   no da pistas por cuánto tarda en responder.</li>
 * </ul>
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class HashContrasena {
    private static final String ALGORITMO = "PBKDF2WithHmacSHA256";
    private static final int ITERACIONES = 120_000;
    private static final int BITS = 256;
    private static final SecureRandom ALEATORIO = new SecureRandom();

    /** Reglas mínimas: 8 a 64 caracteres, con al menos una letra y un número. */
    public void validarPolitica(String contrasena) {
        if (contrasena == null || contrasena.length() < 8 || contrasena.length() > 64
                || !contrasena.matches(".*[A-Za-z].*") || !contrasena.matches(".*\\d.*")) {
            throw new DatoInvalidoException("contrasena",
                    "La contraseña debe tener entre 8 y 64 caracteres e incluir letras y números.");
        }
    }

    public String generar(String contrasena) {
        validarPolitica(contrasena);
        byte[] sal = new byte[16];
        ALEATORIO.nextBytes(sal);
        byte[] hash = derivar(contrasena.toCharArray(), sal, ITERACIONES);
        Base64.Encoder b64 = Base64.getEncoder();
        return "pbkdf2$" + ITERACIONES + "$" + b64.encodeToString(sal) + "$" + b64.encodeToString(hash);
    }

    public boolean verificar(String contrasena, String guardado) {
        if (contrasena == null || guardado == null) {
            return false;
        }
        String[] partes = guardado.split("\\$");
        if (partes.length != 4 || !"pbkdf2".equals(partes[0])) {
            return false;
        }
        try {
            int iteraciones = Integer.parseInt(partes[1]);
            byte[] sal = Base64.getDecoder().decode(partes[2]);
            byte[] esperado = Base64.getDecoder().decode(partes[3]);
            return MessageDigest.isEqual(esperado, derivar(contrasena.toCharArray(), sal, iteraciones));
        } catch (IllegalArgumentException ex) {
            return false;
        }
    }

    private static byte[] derivar(char[] contrasena, byte[] sal, int iteraciones) {
        try {
            PBEKeySpec spec = new PBEKeySpec(contrasena, sal, iteraciones, BITS);
            try {
                return SecretKeyFactory.getInstance(ALGORITMO).generateSecret(spec).getEncoded();
            } finally {
                spec.clearPassword();
            }
        } catch (GeneralSecurityException ex) {
            throw new IllegalStateException("El JDK no soporta " + ALGORITMO, ex);
        }
    }
}
