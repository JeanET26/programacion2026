package grupoctema12.seguridad;

import grupoctema12.excepciones.AccesoDenegadoException;
import grupoctema12.excepciones.NoAutenticadoException;
import grupoctema12.modelo.Permiso;
import grupoctema12.modelo.Usuario;

/**
 * Verifica permisos SIN {@code instanceof}: le pregunta al usuario si tiene
 * el permiso (polimorfismo a través de {@code ConPermisos}). Agregar un rol
 * nuevo no obliga a modificar esta clase.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class ControlAcceso {
    private ControlAcceso() { }

    public static void exigir(Usuario usuario, Permiso permiso) {
        if (usuario == null) {
            throw new NoAutenticadoException("Tenés que iniciar sesión.");
        }
        if (!usuario.tienePermiso(permiso)) {
            throw new AccesoDenegadoException("No tenés permiso para realizar esta operación.");
        }
    }
}
