package grupoctema12;

import grupoctema12.consola.Consola;
import grupoctema12.consola.MenuAdministrador;
import grupoctema12.consola.MenuCuidador;
import grupoctema12.consola.MenuGuia;
import grupoctema12.consola.MenuPrincipal;
import grupoctema12.dao.FabricaDao;
import grupoctema12.dao.json.FabricaDaoJson;
import grupoctema12.servicio.Servicios;
import grupoctema12.web.ServidorWeb;
import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

/**
 * Punto de entrada. Arma todo el sistema (raíz de composición) y elige la
 * interfaz:
 * <ul>
 *   <li>{@code java -jar GrupoCTema12.jar} → servidor web en http://localhost:8080</li>
 *   <li>{@code java -jar GrupoCTema12.jar consola} → menú de consola</li>
 * </ul>
 * Para usar MySQL en lugar de archivos JSON solo se cambia la línea de la
 * {@link FabricaDao}.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public class GrupoCTema12 {
    private static final Path CARPETA_DATOS = Path.of("datos");
    private static final int PUERTO = 8080;

    public static void main(String[] args) throws IOException {
        FabricaDao dao = new FabricaDaoJson(CARPETA_DATOS);
        Servicios servicios = new Servicios(dao);
        if (DatosDemostracion.cargarSiHaceFalta(dao, servicios)) {
            System.out.println("Se cargaron datos de ejemplo en " + CARPETA_DATOS.toAbsolutePath());
            System.out.println("  admin.ana / " + DatosDemostracion.CLAVE_ADMIN);
            System.out.println("  guia.lucia, guia.martin, cuidador.diego, cuidador.sofia / "
                    + DatosDemostracion.CLAVE_EMPLEADOS);
        }

        if (args.length > 0 && args[0].equalsIgnoreCase("consola")) {
            Consola consola = new Consola();
            new MenuPrincipal(consola, servicios.autenticacion(), List.of(
                    new MenuAdministrador(consola, servicios),
                    new MenuGuia(consola, servicios.misRecorridos()),
                    new MenuCuidador(consola, servicios.misEspecies()))).iniciar();
        } else {
            ServidorWeb servidor = new ServidorWeb(PUERTO, servicios);
            servidor.iniciar();
            System.out.println("Mundo Marino en http://localhost:" + PUERTO + "  (Ctrl+C para detener)");
        }
    }
}
