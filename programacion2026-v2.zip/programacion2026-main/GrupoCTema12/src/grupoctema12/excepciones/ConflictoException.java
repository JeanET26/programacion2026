package grupoctema12.excepciones;

/**
 * La operación rompe una regla del negocio (duplicados, elementos en uso, horarios superpuestos).
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public class ConflictoException extends MundoMarinoException {
    private static final long serialVersionUID = 1L;

    public ConflictoException(String mensaje) {
        super(mensaje);
    }

    @Override
    public int getCodigoHttp() {
        return 409;
    }
}
