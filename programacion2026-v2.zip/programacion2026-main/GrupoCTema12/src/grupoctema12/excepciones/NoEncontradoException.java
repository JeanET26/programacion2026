package grupoctema12.excepciones;

/**
 * El elemento solicitado no existe.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public class NoEncontradoException extends MundoMarinoException {
    private static final long serialVersionUID = 1L;

    public NoEncontradoException(String mensaje) {
        super(mensaje);
    }

    @Override
    public int getCodigoHttp() {
        return 404;
    }
}
