package grupoctema12.excepciones;

/**
 * Datos con formato o valor incorrecto.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public class DatoInvalidoException extends MundoMarinoException {
    private static final long serialVersionUID = 1L;
    private final String campo;

    public DatoInvalidoException(String campo, String mensaje) {
        super(mensaje);
        this.campo = campo;
    }

    /** Campo del formulario que provocó el error (puede ser null). */
    @Override
    public String getCampo() {
        return campo;
    }

    @Override
    public int getCodigoHttp() {
        return 400;
    }
}
