package grupoctema12.excepciones;

/**
 * El usuario autenticado no tiene permiso para la operación.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public class AccesoDenegadoException extends MundoMarinoException {
    private static final long serialVersionUID = 1L;

    public AccesoDenegadoException(String mensaje) {
        super(mensaje);
    }

    @Override
    public int getCodigoHttp() {
        return 403;
    }
}
