package grupoctema12.excepciones;

/**
 * No hay sesión iniciada o las credenciales son incorrectas.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public class NoAutenticadoException extends MundoMarinoException {
    private static final long serialVersionUID = 1L;

    public NoAutenticadoException(String mensaje) {
        super(mensaje);
    }

    @Override
    public int getCodigoHttp() {
        return 401;
    }
}
