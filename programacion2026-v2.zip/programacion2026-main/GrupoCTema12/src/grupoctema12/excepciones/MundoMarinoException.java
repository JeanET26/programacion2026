package grupoctema12.excepciones;

/**
 * Base de los errores de negocio. Cada subclase representa un tipo de problema
 * y la capa web la traduce a un código HTTP (400, 401, 403, 404, 409).
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public abstract class MundoMarinoException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    protected MundoMarinoException(String mensaje) {
        super(mensaje);
    }

    /** Código HTTP equivalente; lo usa la capa web sin necesidad de instanceof. */
    public abstract int getCodigoHttp();

    /** Campo del formulario relacionado con el error; por defecto ninguno. */
    public String getCampo() {
        return null;
    }
}
