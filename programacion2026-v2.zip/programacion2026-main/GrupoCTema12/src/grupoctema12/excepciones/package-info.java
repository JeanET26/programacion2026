/**
 * Errores de negocio.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
package grupoctema12.excepciones;
