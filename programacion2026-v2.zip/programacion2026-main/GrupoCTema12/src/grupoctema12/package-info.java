/**
 * Sistema de gestión del personal de Mundo Marino (Grupo C, Tema 12).
 *
 * <pre>
 * modelo      entidades del dominio e interfaces Identificable / ConPermisos
 * dao         contrato genérico Dao&lt;T, ID&gt;, interfaces por entidad y FabricaDao
 * dao.json    implementación con archivos JSON (la que se usa)
 * dao.jdbc    ejemplo de implementación con base de datos
 * servicio    reglas de negocio; reciben los DAO por constructor
 * seguridad   hash de contraseñas y control de acceso por permisos
 * web         servidor HTTP, sesiones y API JSON
 * consola     menús de texto
 * </pre>
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
package grupoctema12;
