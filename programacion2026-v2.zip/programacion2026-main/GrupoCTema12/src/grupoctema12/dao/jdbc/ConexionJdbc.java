package grupoctema12.dao.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Abre conexiones a la base de datos. Los datos de conexión se leen de
 * variables de entorno para no dejar la contraseña escrita en el código:
 * <pre>
 *   MM_DB_URL=jdbc:mysql://localhost:3306/mundo_marino
 *   MM_DB_USUARIO=mm_app
 *   MM_DB_CLAVE=********
 * </pre>
 * Para MySQL hay que agregar el driver (mysql-connector-j.jar) en
 * NetBeans → Properties → Libraries.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class ConexionJdbc {
    private final String url;
    private final String usuario;
    private final String clave;

    public ConexionJdbc(String url, String usuario, String clave) {
        this.url = url;
        this.usuario = usuario;
        this.clave = clave;
    }

    public static ConexionJdbc desdeVariablesDeEntorno() {
        return new ConexionJdbc(System.getenv("MM_DB_URL"), System.getenv("MM_DB_USUARIO"),
                System.getenv("MM_DB_CLAVE"));
    }

    public Connection abrir() throws SQLException {
        return DriverManager.getConnection(url, usuario, clave);
    }
}
