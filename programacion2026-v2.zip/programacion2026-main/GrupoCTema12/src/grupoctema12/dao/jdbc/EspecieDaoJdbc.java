package grupoctema12.dao.jdbc;

import grupoctema12.dao.EspecieDao;
import grupoctema12.modelo.Especie;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * <b>Ejemplo</b> de cómo se implementa el mismo contrato {@link EspecieDao}
 * contra una base de datos (tablas de {@code docs/schema.sql}).
 *
 * <p>Los servicios no cambian: reciben un {@code EspecieDao} y no saben si
 * detrás hay archivos JSON o MySQL. Para completar la migración se escribe
 * una clase así por cada DAO y una {@code FabricaDaoJdbc}.</p>
 *
 * <p><b>Seguridad:</b> siempre {@link PreparedStatement} con {@code ?}.
 * Nunca concatenar datos del usuario dentro del SQL (inyección SQL).</p>
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class EspecieDaoJdbc implements EspecieDao {
    private static final String SELECT = """
            SELECT id, nombre_espanol, nombre_cientifico, descripcion, zona_id FROM especie
            """;

    private final ConexionJdbc conexion;

    public EspecieDaoJdbc(ConexionJdbc conexion) {
        this.conexion = conexion;
    }

    @Override
    public Optional<Especie> buscarPorId(UUID id) {
        List<Especie> r = consultar(SELECT + " WHERE id = ?", id.toString());
        return r.stream().findFirst();
    }

    @Override
    public List<Especie> listarTodos() {
        return consultar(SELECT + " ORDER BY nombre_espanol");
    }

    @Override
    public List<Especie> buscarPorZona(UUID zonaId) {
        return consultar(SELECT + " WHERE zona_id = ?", zonaId.toString());
    }

    @Override
    public List<Especie> buscarPorHabitat(UUID habitatId) {
        return consultar(SELECT + " WHERE id IN (SELECT especie_id FROM especie_habitat WHERE habitat_id = ?)",
                habitatId.toString());
    }

    @Override
    public Optional<Especie> buscarPorNombreCientifico(String nombreCientifico) {
        return consultar(SELECT + " WHERE LOWER(nombre_cientifico) = LOWER(?)", nombreCientifico.strip())
                .stream().findFirst();
    }

    @Override
    public void guardar(Especie e) {
        String sql = "INSERT INTO especie (id, nombre_espanol, nombre_cientifico, descripcion, zona_id) VALUES (?,?,?,?,?)";
        enTransaccion(con -> {
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                cargarParametros(ps, e);
                ps.executeUpdate();
            }
            guardarHabitats(con, e);
        });
    }

    @Override
    public void actualizar(Especie e) {
        String sql = "UPDATE especie SET id = ?, nombre_espanol = ?, nombre_cientifico = ?, descripcion = ?, zona_id = ? WHERE id = ?";
        enTransaccion(con -> {
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                cargarParametros(ps, e);
                ps.setString(6, e.getId().toString());
                ps.executeUpdate();
            }
            try (PreparedStatement ps = con.prepareStatement("DELETE FROM especie_habitat WHERE especie_id = ?")) {
                ps.setString(1, e.getId().toString());
                ps.executeUpdate();
            }
            guardarHabitats(con, e);
        });
    }

    @Override
    public boolean eliminar(UUID id) {
        try (Connection con = conexion.abrir();
                PreparedStatement ps = con.prepareStatement("DELETE FROM especie WHERE id = ?")) {
            ps.setString(1, id.toString());
            return ps.executeUpdate() > 0; // especie_habitat se borra por ON DELETE CASCADE
        } catch (SQLException ex) {
            throw new IllegalStateException("Error al eliminar la especie.", ex);
        }
    }

    /* ------------------------- auxiliares ------------------------- */

    private static void cargarParametros(PreparedStatement ps, Especie e) throws SQLException {
        ps.setString(1, e.getId().toString());
        ps.setString(2, e.getNombreEspanol());
        ps.setString(3, e.getNombreCientifico());
        ps.setString(4, e.getDescripcionGeneral());
        ps.setString(5, e.getZonaId().map(UUID::toString).orElse(null));
    }

    private static void guardarHabitats(Connection con, Especie e) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO especie_habitat (especie_id, habitat_id) VALUES (?, ?)")) {
            for (UUID habitatId : e.getHabitatIds()) {
                ps.setString(1, e.getId().toString());
                ps.setString(2, habitatId.toString());
                ps.addBatch();
            }
            ps.executeBatch();
        }
    }

    private List<Especie> consultar(String sql, String... parametros) {
        try (Connection con = conexion.abrir(); PreparedStatement ps = con.prepareStatement(sql)) {
            for (int i = 0; i < parametros.length; i++) {
                ps.setString(i + 1, parametros[i]);
            }
            List<Especie> resultado = new ArrayList<>();
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String id = rs.getString("id");
                    String zona = rs.getString("zona_id");
                    resultado.add(new Especie(UUID.fromString(id), rs.getString("nombre_espanol"),
                            rs.getString("nombre_cientifico"), rs.getString("descripcion"),
                            zona == null ? null : UUID.fromString(zona), habitatsDe(con, id)));
                }
            }
            return resultado;
        } catch (SQLException ex) {
            throw new IllegalStateException("Error al consultar especies.", ex);
        }
    }

    private static Set<UUID> habitatsDe(Connection con, String especieId) throws SQLException {
        Set<UUID> ids = new LinkedHashSet<>();
        try (PreparedStatement ps = con.prepareStatement("SELECT habitat_id FROM especie_habitat WHERE especie_id = ?")) {
            ps.setString(1, especieId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    ids.add(UUID.fromString(rs.getString(1)));
                }
            }
        }
        return ids;
    }

    @FunctionalInterface
    private interface Operacion {
        void ejecutar(Connection con) throws SQLException;
    }

    /** Si falla una parte (por ejemplo los hábitats), se deshace todo. */
    private void enTransaccion(Operacion operacion) {
        try (Connection con = conexion.abrir()) {
            con.setAutoCommit(false);
            try {
                operacion.ejecutar(con);
                con.commit();
            } catch (SQLException ex) {
                con.rollback();
                throw ex;
            }
        } catch (SQLException ex) {
            throw new IllegalStateException("Error al guardar la especie.", ex);
        }
    }
}
