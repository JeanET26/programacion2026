/**
 * Ejemplo de DAO con base de datos (JDBC).
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
package grupoctema12.dao.jdbc;
