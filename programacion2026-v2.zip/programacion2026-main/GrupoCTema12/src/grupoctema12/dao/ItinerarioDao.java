package grupoctema12.dao;

import grupoctema12.modelo.Itinerario;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * DAO de itinerarios.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public interface ItinerarioDao extends Dao<Itinerario, UUID> {
    Optional<Itinerario> buscarPorCodigo(String codigo);

    List<Itinerario> buscarPorEspecie(UUID especieId);
}
