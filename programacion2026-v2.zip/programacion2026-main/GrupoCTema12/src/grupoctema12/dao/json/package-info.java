/**
 * DAO que guardan cada entidad en un archivo JSON.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
package grupoctema12.dao.json;
