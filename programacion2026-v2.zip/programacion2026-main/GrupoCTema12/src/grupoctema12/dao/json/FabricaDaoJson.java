package grupoctema12.dao.json;

import grupoctema12.dao.AsignacionCuidadoDao;
import grupoctema12.dao.AsignacionGuiaDao;
import grupoctema12.dao.EspecieDao;
import grupoctema12.dao.FabricaDao;
import grupoctema12.dao.HabitatDao;
import grupoctema12.dao.ItinerarioDao;
import grupoctema12.dao.UsuarioDao;
import grupoctema12.dao.ZonaDao;
import java.nio.file.Path;

/**
 * Fábrica que crea todos los DAO basados en archivos JSON dentro de una carpeta.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class FabricaDaoJson implements FabricaDao {
    private final ZonaDao zonas;
    private final HabitatDao habitats;
    private final EspecieDao especies;
    private final ItinerarioDao itinerarios;
    private final UsuarioDao usuarios;
    private final AsignacionGuiaDao asignacionesGuia;
    private final AsignacionCuidadoDao asignacionesCuidado;

    public FabricaDaoJson(Path carpeta) {
        zonas = new ZonaDaoJson(carpeta);
        habitats = new HabitatDaoJson(carpeta);
        especies = new EspecieDaoJson(carpeta);
        itinerarios = new ItinerarioDaoJson(carpeta);
        usuarios = new UsuarioDaoJson(carpeta);
        asignacionesGuia = new AsignacionGuiaDaoJson(carpeta);
        asignacionesCuidado = new AsignacionCuidadoDaoJson(carpeta);
    }

    @Override public ZonaDao zonas() { return zonas; }
    @Override public HabitatDao habitats() { return habitats; }
    @Override public EspecieDao especies() { return especies; }
    @Override public ItinerarioDao itinerarios() { return itinerarios; }
    @Override public UsuarioDao usuarios() { return usuarios; }
    @Override public AsignacionGuiaDao asignacionesGuia() { return asignacionesGuia; }
    @Override public AsignacionCuidadoDao asignacionesCuidado() { return asignacionesCuidado; }
}
