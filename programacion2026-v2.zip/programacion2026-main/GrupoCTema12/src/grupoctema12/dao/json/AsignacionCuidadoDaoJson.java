package grupoctema12.dao.json;

import grupoctema12.dao.AsignacionCuidadoDao;
import grupoctema12.modelo.AsignacionCuidado;
import grupoctema12.util.MapaJson;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Asignaciones cuidador–especie guardadas en {@code asignaciones_cuidado.json}.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class AsignacionCuidadoDaoJson extends DaoJson<AsignacionCuidado> implements AsignacionCuidadoDao {

    public AsignacionCuidadoDaoJson(Path carpeta) {
        super(carpeta, "asignaciones_cuidado.json");
    }

    @Override
    public List<AsignacionCuidado> buscarPorCuidador(UUID cuidadorId) {
        return filtrar(a -> a.getCuidadorId().equals(cuidadorId));
    }

    @Override
    public List<AsignacionCuidado> buscarPorEspecie(UUID especieId) {
        return filtrar(a -> a.getEspecieId().equals(especieId));
    }

    @Override
    protected Map<String, Object> aJson(AsignacionCuidado a) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", a.getId());
        m.put("cuidadorId", a.getCuidadorId());
        m.put("especieId", a.getEspecieId());
        m.put("fechaAsignacion", a.getFechaAsignacion());
        return m;
    }

    @Override
    protected AsignacionCuidado desdeJson(MapaJson j) {
        return new AsignacionCuidado(j.uuidRequerido("id"), j.uuidRequerido("cuidadorId"),
                j.uuidRequerido("especieId"), j.fecha("fechaAsignacion"));
    }
}
