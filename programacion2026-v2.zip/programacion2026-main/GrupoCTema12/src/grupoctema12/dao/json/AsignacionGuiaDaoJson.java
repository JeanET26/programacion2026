package grupoctema12.dao.json;

import grupoctema12.dao.AsignacionGuiaDao;
import grupoctema12.modelo.AsignacionGuia;
import grupoctema12.util.MapaJson;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Asignaciones guía–itinerario guardadas en {@code asignaciones_guia.json}.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class AsignacionGuiaDaoJson extends DaoJson<AsignacionGuia> implements AsignacionGuiaDao {

    public AsignacionGuiaDaoJson(Path carpeta) {
        super(carpeta, "asignaciones_guia.json");
    }

    @Override
    public List<AsignacionGuia> buscarPorGuia(UUID guiaId) {
        return filtrar(a -> a.getGuiaId().equals(guiaId));
    }

    @Override
    public List<AsignacionGuia> buscarPorItinerario(UUID itinerarioId) {
        return filtrar(a -> a.getItinerarioId().equals(itinerarioId));
    }

    @Override
    protected Map<String, Object> aJson(AsignacionGuia a) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", a.getId());
        m.put("guiaId", a.getGuiaId());
        m.put("itinerarioId", a.getItinerarioId());
        m.put("hora", a.getHora());
        return m;
    }

    @Override
    protected AsignacionGuia desdeJson(MapaJson j) {
        return new AsignacionGuia(j.uuidRequerido("id"), j.uuidRequerido("guiaId"),
                j.uuidRequerido("itinerarioId"), j.hora("hora"));
    }
}
