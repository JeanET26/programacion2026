package grupoctema12.dao.json;

import grupoctema12.dao.HabitatDao;
import grupoctema12.modelo.Habitat;
import grupoctema12.util.MapaJson;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Hábitats guardados en {@code habitats.json}.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class HabitatDaoJson extends DaoJson<Habitat> implements HabitatDao {

    public HabitatDaoJson(Path carpeta) {
        super(carpeta, "habitats.json");
    }

    @Override
    public Optional<Habitat> buscarPorNombre(String nombre) {
        return primero(h -> h.getNombre().equalsIgnoreCase(nombre.strip()));
    }

    @Override
    protected Map<String, Object> aJson(Habitat h) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", h.getId());
        m.put("nombre", h.getNombre());
        m.put("clima", h.getClima());
        m.put("vegetacion", h.getVegetacionPredominante());
        m.put("continentes", List.copyOf(h.getContinentes()));
        return m;
    }

    @Override
    protected Habitat desdeJson(MapaJson j) {
        return new Habitat(j.uuidRequerido("id"), j.texto("nombre"), j.texto("clima"),
                j.texto("vegetacion"), j.listaTextos("continentes"));
    }
}
