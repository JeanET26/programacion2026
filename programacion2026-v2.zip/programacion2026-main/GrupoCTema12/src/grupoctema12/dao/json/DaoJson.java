package grupoctema12.dao.json;

import grupoctema12.dao.Dao;
import grupoctema12.excepciones.ConflictoException;
import grupoctema12.modelo.Identificable;
import grupoctema12.util.Json;
import grupoctema12.util.MapaJson;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Predicate;

/**
 * Implementación genérica del {@link Dao} que guarda cada entidad en un
 * archivo JSON (por ejemplo {@code datos/especies.json}).
 *
 * <p>El CRUD completo está escrito una sola vez acá. Cada subclase solo
 * indica cómo convertir SU entidad a JSON y de vuelta (patrón
 * <i>Template Method</i>): métodos {@link #aJson} y {@link #desdeJson}.</p>
 *
 * <p>Reemplaza a la serialización con {@code ObjectOutputStream}: el JSON se
 * puede leer y editar a mano, no se rompe si cambia una clase y no permite
 * ejecutar código al leer un archivo manipulado.</p>
 *
 * <p>Los métodos son {@code synchronized} porque el servidor web atiende
 * varios pedidos al mismo tiempo.</p>
 *
 * @param <T> entidad que se persiste
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public abstract class DaoJson<T extends Identificable> implements Dao<T, UUID> {
    private final Path archivo;
    private final Map<UUID, T> elementos = new LinkedHashMap<>();
    private boolean cargado;

    protected DaoJson(Path carpeta, String nombreArchivo) {
        this.archivo = carpeta.resolve(nombreArchivo);
    }

    /** Convierte la entidad en un objeto JSON. */
    protected abstract Map<String, Object> aJson(T entidad);

    /** Reconstruye la entidad a partir del objeto JSON guardado. */
    protected abstract T desdeJson(MapaJson json);

    @Override
    public synchronized Optional<T> buscarPorId(UUID id) {
        asegurarCargado();
        return Optional.ofNullable(elementos.get(id));
    }

    @Override
    public synchronized List<T> listarTodos() {
        asegurarCargado();
        return List.copyOf(elementos.values());
    }

    @Override
    public synchronized void guardar(T entidad) {
        asegurarCargado();
        if (elementos.containsKey(entidad.getId())) {
            throw new ConflictoException("Ya existe un elemento con ese id.");
        }
        elementos.put(entidad.getId(), entidad);
        escribirArchivo();
    }

    @Override
    public synchronized void actualizar(T entidad) {
        asegurarCargado();
        if (!elementos.containsKey(entidad.getId())) {
            throw new ConflictoException("No se puede actualizar un elemento que no fue guardado.");
        }
        elementos.put(entidad.getId(), entidad);
        escribirArchivo();
    }

    @Override
    public synchronized boolean eliminar(UUID id) {
        asegurarCargado();
        boolean existia = elementos.remove(id) != null;
        if (existia) {
            escribirArchivo();
        }
        return existia;
    }

    /** Ayuda para las consultas propias de cada DAO concreto. */
    protected synchronized List<T> filtrar(Predicate<T> condicion) {
        asegurarCargado();
        return elementos.values().stream().filter(condicion).toList();
    }

    protected synchronized Optional<T> primero(Predicate<T> condicion) {
        asegurarCargado();
        return elementos.values().stream().filter(condicion).findFirst();
    }

    /** Convierte una colección de UUID en lista de textos para el JSON. */
    protected static List<String> ids(java.util.Collection<UUID> ids) {
        return ids.stream().map(UUID::toString).toList();
    }

    /**
     * Lee el archivo la primera vez que se usa el DAO (carga diferida).
     * No se hace en el constructor porque llamaría a {@link #desdeJson}, un
     * método de la subclase, antes de que la subclase termine de construirse.
     */
    private void asegurarCargado() {
        if (cargado) {
            return;
        }
        cargado = true;
        if (Files.notExists(archivo)) {
            return;
        }
        try {
            Object contenido = Json.leer(Files.readString(archivo, StandardCharsets.UTF_8));
            if (!(contenido instanceof List<?> lista)) {
                throw new IllegalStateException("El archivo " + archivo + " no contiene una lista JSON.");
            }
            for (Object item : lista) {
                @SuppressWarnings("unchecked")
                Map<String, Object> mapa = (Map<String, Object>) item;
                T entidad = desdeJson(new MapaJson(mapa));
                elementos.put(entidad.getId(), entidad);
            }
        } catch (IOException ex) {
            throw new UncheckedIOException("No se pudo leer " + archivo, ex);
        }
    }

    /** Escribe primero un archivo temporal y después lo renombra: si se corta la luz no queda un JSON a medias. */
    private void escribirArchivo() {
        List<Map<String, Object>> lista = new ArrayList<>();
        elementos.values().forEach(e -> lista.add(aJson(e)));
        try {
            Files.createDirectories(archivo.toAbsolutePath().getParent());
            Path temporal = archivo.resolveSibling(archivo.getFileName() + ".tmp");
            Files.writeString(temporal, Json.escribir(lista), StandardCharsets.UTF_8);
            Files.move(temporal, archivo, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException ex) {
            throw new UncheckedIOException("No se pudo guardar " + archivo, ex);
        }
    }
}
