package grupoctema12.dao.json;

import grupoctema12.dao.ItinerarioDao;
import grupoctema12.modelo.Itinerario;
import grupoctema12.util.MapaJson;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Itinerarios guardados en {@code itinerarios.json}.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class ItinerarioDaoJson extends DaoJson<Itinerario> implements ItinerarioDao {

    public ItinerarioDaoJson(Path carpeta) {
        super(carpeta, "itinerarios.json");
    }

    @Override
    public Optional<Itinerario> buscarPorCodigo(String codigo) {
        return primero(i -> i.getCodigo().equalsIgnoreCase(codigo.strip()));
    }

    @Override
    public List<Itinerario> buscarPorEspecie(UUID especieId) {
        return filtrar(i -> i.getEspecieIds().contains(especieId));
    }

    @Override
    protected Map<String, Object> aJson(Itinerario i) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", i.getId());
        m.put("codigo", i.getCodigo());
        m.put("duracionMinutos", i.getDuracion().toMinutes());
        m.put("longitudKm", i.getLongitudKilometros());
        m.put("maximoVisitantes", i.getMaximoVisitantes());
        m.put("especieIds", ids(i.getEspecieIds()));
        return m;
    }

    @Override
    protected Itinerario desdeJson(MapaJson j) {
        return new Itinerario(j.uuidRequerido("id"), j.texto("codigo"), j.minutos("duracionMinutos"),
                j.decimal("longitudKm"), j.enteroInt("maximoVisitantes"), j.listaUuids("especieIds"));
    }
}
