package grupoctema12.dao.json;

import grupoctema12.dao.EspecieDao;
import grupoctema12.modelo.Especie;
import grupoctema12.util.MapaJson;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Especies guardadas en {@code especies.json}.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class EspecieDaoJson extends DaoJson<Especie> implements EspecieDao {

    public EspecieDaoJson(Path carpeta) {
        super(carpeta, "especies.json");
    }

    @Override
    public List<Especie> buscarPorZona(UUID zonaId) {
        return filtrar(e -> e.getZonaId().map(zonaId::equals).orElse(false));
    }

    @Override
    public List<Especie> buscarPorHabitat(UUID habitatId) {
        return filtrar(e -> e.getHabitatIds().contains(habitatId));
    }

    @Override
    public Optional<Especie> buscarPorNombreCientifico(String nombreCientifico) {
        return primero(e -> e.getNombreCientifico().equalsIgnoreCase(nombreCientifico.strip()));
    }

    @Override
    protected Map<String, Object> aJson(Especie e) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", e.getId());
        m.put("nombreEspanol", e.getNombreEspanol());
        m.put("nombreCientifico", e.getNombreCientifico());
        m.put("descripcion", e.getDescripcionGeneral());
        m.put("zonaId", e.getZonaId().orElse(null));
        m.put("habitatIds", ids(e.getHabitatIds()));
        return m;
    }

    @Override
    protected Especie desdeJson(MapaJson j) {
        return new Especie(j.uuidRequerido("id"), j.texto("nombreEspanol"), j.texto("nombreCientifico"),
                j.texto("descripcion"), j.uuid("zonaId"), j.listaUuids("habitatIds"));
    }
}
