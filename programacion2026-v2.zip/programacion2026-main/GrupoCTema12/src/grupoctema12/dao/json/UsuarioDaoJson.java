package grupoctema12.dao.json;

import grupoctema12.dao.UsuarioDao;
import grupoctema12.modelo.Administrador;
import grupoctema12.modelo.Cuidador;
import grupoctema12.modelo.Guia;
import grupoctema12.modelo.Rol;
import grupoctema12.modelo.Usuario;
import grupoctema12.util.MapaJson;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Usuarios guardados en {@code usuarios.json}. La contraseña se guarda solo como hash.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class UsuarioDaoJson extends DaoJson<Usuario> implements UsuarioDao {

    public UsuarioDaoJson(Path carpeta) {
        super(carpeta, "usuarios.json");
    }

    @Override
    public Optional<Usuario> buscarPorNombreUsuario(String nombreUsuario) {
        String buscado = nombreUsuario == null ? "" : nombreUsuario.strip();
        return primero(u -> u.getNombreUsuario().equalsIgnoreCase(buscado));
    }

    @Override
    public <U extends Usuario> List<U> listarPorTipo(Class<U> tipo) {
        return filtrar(tipo::isInstance).stream().map(tipo::cast).toList();
    }

    @Override
    public <U extends Usuario> Optional<U> buscarPorIdYTipo(UUID id, Class<U> tipo) {
        return buscarPorId(id).filter(tipo::isInstance).map(tipo::cast);
    }

    @Override
    protected Map<String, Object> aJson(Usuario u) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", u.getId());
        m.put("rol", u.getRol());
        m.put("nombreUsuario", u.getNombreUsuario());
        m.put("hashContrasena", u.getHashContrasena());
        m.put("nombre", u.getNombre());
        // Los datos laborales solo existen en Empleado (polimorfismo, sin instanceof).
        u.comoEmpleado().ifPresent(e -> {
            m.put("direccion", e.getDireccion());
            m.put("telefono", e.getTelefono());
            m.put("fechaIngreso", e.getFechaIngreso());
        });
        return m;
    }

    @Override
    protected Usuario desdeJson(MapaJson j) {
        UUID id = j.uuidRequerido("id");
        Rol rol = Rol.valueOf(j.texto("rol"));
        // Fábrica simple: según el rol guardado se crea la clase correspondiente.
        return switch (rol) {
            case ADMINISTRADOR -> new Administrador(id, j.texto("nombreUsuario"), j.texto("hashContrasena"),
                    j.texto("nombre"));
            case GUIA -> new Guia(id, j.texto("nombreUsuario"), j.texto("hashContrasena"), j.texto("nombre"),
                    j.texto("direccion"), j.texto("telefono"), j.fecha("fechaIngreso"));
            case CUIDADOR -> new Cuidador(id, j.texto("nombreUsuario"), j.texto("hashContrasena"),
                    j.texto("nombre"), j.texto("direccion"), j.texto("telefono"), j.fecha("fechaIngreso"));
        };
    }
}
