package grupoctema12.dao.json;

import grupoctema12.dao.ZonaDao;
import grupoctema12.modelo.Zona;
import grupoctema12.util.MapaJson;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Zonas guardadas en {@code zonas.json}.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class ZonaDaoJson extends DaoJson<Zona> implements ZonaDao {

    public ZonaDaoJson(Path carpeta) {
        super(carpeta, "zonas.json");
    }

    @Override
    public Optional<Zona> buscarPorNombre(String nombre) {
        return primero(z -> z.getNombre().equalsIgnoreCase(nombre.strip()));
    }

    @Override
    protected Map<String, Object> aJson(Zona z) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", z.getId());
        m.put("nombre", z.getNombre());
        m.put("extensionM2", z.getExtensionMetrosCuadrados());
        return m;
    }

    @Override
    protected Zona desdeJson(MapaJson j) {
        return new Zona(j.uuidRequerido("id"), j.texto("nombre"), j.decimal("extensionM2"));
    }
}
