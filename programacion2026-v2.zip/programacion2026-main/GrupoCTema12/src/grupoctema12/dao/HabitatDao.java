package grupoctema12.dao;

import grupoctema12.modelo.Habitat;
import java.util.Optional;
import java.util.UUID;

/**
 * DAO de hábitats.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public interface HabitatDao extends Dao<Habitat, UUID> {
    Optional<Habitat> buscarPorNombre(String nombre);
}
