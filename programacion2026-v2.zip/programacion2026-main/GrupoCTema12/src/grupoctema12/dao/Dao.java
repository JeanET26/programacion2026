package grupoctema12.dao;

import java.util.List;
import java.util.Optional;

/**
 * <b>Contrato genérico de DAO</b> (Data Access Object).
 *
 * <p>Define las operaciones básicas de persistencia una sola vez, para
 * cualquier tipo {@code T} con identificador {@code ID}. Cada entidad tiene
 * su propia interfaz que extiende esta (por ejemplo {@link EspecieDao}) y
 * agrega solo sus consultas particulares.</p>
 *
 * <p><b>¿Por qué se usa?</b></p>
 * <ul>
 *   <li><b>Separa responsabilidades (S de SOLID):</b> los servicios aplican
 *   reglas de negocio; el DAO solo guarda y busca.</li>
 *   <li><b>Inversión de dependencias (D de SOLID):</b> los servicios dependen
 *   de esta interfaz, no de un archivo ni de MySQL. Se puede pasar de
 *   archivos JSON a una base de datos escribiendo otra implementación, sin
 *   tocar los servicios.</li>
 *   <li><b>Evita repetir código:</b> el CRUD se escribe una vez en
 *   {@code DaoJson<T>} y lo heredan todas las entidades.</li>
 * </ul>
 *
 * @param <T>  tipo de entidad
 * @param <ID> tipo del identificador
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public interface Dao<T, ID> {

    Optional<T> buscarPorId(ID id);

    List<T> listarTodos();

    /** Da de alta una entidad nueva. */
    void guardar(T entidad);

    /** Guarda los cambios de una entidad existente. */
    void actualizar(T entidad);

    /** Elimina por id; devuelve false si no existía. */
    boolean eliminar(ID id);

    default boolean existe(ID id) {
        return buscarPorId(id).isPresent();
    }
}
