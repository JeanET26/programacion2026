package grupoctema12.dao;

import grupoctema12.modelo.Zona;
import java.util.Optional;
import java.util.UUID;

/**
 * DAO de zonas.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public interface ZonaDao extends Dao<Zona, UUID> {
    Optional<Zona> buscarPorNombre(String nombre);
}
