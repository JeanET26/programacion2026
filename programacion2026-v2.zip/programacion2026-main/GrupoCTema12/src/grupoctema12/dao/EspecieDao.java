package grupoctema12.dao;

import grupoctema12.modelo.Especie;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * DAO de especies.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public interface EspecieDao extends Dao<Especie, UUID> {
    List<Especie> buscarPorZona(UUID zonaId);

    List<Especie> buscarPorHabitat(UUID habitatId);

    Optional<Especie> buscarPorNombreCientifico(String nombreCientifico);
}
