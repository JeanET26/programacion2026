package grupoctema12.dao;

import grupoctema12.modelo.Usuario;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * DAO de usuarios (administradores, guías y cuidadores).
 * Los métodos genéricos por tipo evitan tener que castear en los servicios.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public interface UsuarioDao extends Dao<Usuario, UUID> {
    Optional<Usuario> buscarPorNombreUsuario(String nombreUsuario);

    /** Ej.: {@code listarPorTipo(Guia.class)}. */
    <U extends Usuario> List<U> listarPorTipo(Class<U> tipo);

    /** Ej.: {@code buscarPorIdYTipo(id, Cuidador.class)}. */
    <U extends Usuario> Optional<U> buscarPorIdYTipo(UUID id, Class<U> tipo);
}
