package grupoctema12.dao;

import grupoctema12.modelo.AsignacionCuidado;
import java.util.List;
import java.util.UUID;

/**
 * DAO de asignaciones de cuidadores a especies.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public interface AsignacionCuidadoDao extends Dao<AsignacionCuidado, UUID> {
    List<AsignacionCuidado> buscarPorCuidador(UUID cuidadorId);

    List<AsignacionCuidado> buscarPorEspecie(UUID especieId);
}
