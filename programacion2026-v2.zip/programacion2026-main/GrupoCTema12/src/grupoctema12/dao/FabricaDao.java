package grupoctema12.dao;

/**
 * Fábrica abstracta de DAOs. El programa principal elige UNA implementación
 * (hoy {@code FabricaDaoJson}; mañana una con JDBC) y el resto del sistema
 * no se entera del cambio.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public interface FabricaDao {
    ZonaDao zonas();
    HabitatDao habitats();
    EspecieDao especies();
    ItinerarioDao itinerarios();
    UsuarioDao usuarios();
    AsignacionGuiaDao asignacionesGuia();
    AsignacionCuidadoDao asignacionesCuidado();
}
