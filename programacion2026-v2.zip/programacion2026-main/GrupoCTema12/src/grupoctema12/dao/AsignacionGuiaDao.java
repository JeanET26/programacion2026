package grupoctema12.dao;

import grupoctema12.modelo.AsignacionGuia;
import java.util.List;
import java.util.UUID;

/**
 * DAO de asignaciones de guías a itinerarios.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public interface AsignacionGuiaDao extends Dao<AsignacionGuia, UUID> {
    List<AsignacionGuia> buscarPorGuia(UUID guiaId);

    List<AsignacionGuia> buscarPorItinerario(UUID itinerarioId);
}
