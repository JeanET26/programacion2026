package grupoctema12.web;

import grupoctema12.excepciones.NoAutenticadoException;
import grupoctema12.modelo.Usuario;
import grupoctema12.servicio.AutenticacionServicio;
import grupoctema12.util.MapaJson;
import java.util.Map;

/**
 * Iniciar sesión, consultar quién soy, cambiar contraseña y salir.
 * <pre>
 * POST   /api/sesion             {nombreUsuario, contrasena} → usuario
 * GET    /api/sesion             → usuario de la sesión (401 si no hay)
 * PUT    /api/sesion/contrasena  {actual, nueva}
 * DELETE /api/sesion             → cierra la sesión
 * </pre>
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class SesionControlador implements Controlador {
    private final AutenticacionServicio autenticacion;
    private final GestorSesiones sesiones;
    private final LimitadorIntentos porUsuario = new LimitadorIntentos(5);
    private final LimitadorIntentos porIp = new LimitadorIntentos(30);

    public SesionControlador(AutenticacionServicio autenticacion, GestorSesiones sesiones) {
        this.autenticacion = autenticacion;
        this.sesiones = sesiones;
    }

    @Override
    public void registrarRutas(Enrutador r) {
        r.post("/api/sesion", this::iniciar);
        r.get("/api/sesion", p -> ConvertidorJson.usuario(p.usuario()));
        r.put("/api/sesion/contrasena", this::cambiarContrasena);
        r.delete("/api/sesion", this::cerrar);
    }

    private Object iniciar(Peticion p) {
        MapaJson j = p.json();
        String usuario = j.texto("nombreUsuario") == null ? "" : j.texto("nombreUsuario").strip().toLowerCase();
        String claveIp = "ip:" + p.ip();
        String claveUsuario = "usuario:" + usuario;
        porIp.verificar(claveIp);
        porUsuario.verificar(claveUsuario);
        Usuario u;
        try {
            u = autenticacion.autenticar(usuario, j.texto("contrasena"));
        } catch (NoAutenticadoException ex) {
            porIp.registrarFallo(claveIp);
            porUsuario.registrarFallo(claveUsuario);
            throw ex;
        }
        porUsuario.limpiar(claveUsuario);
        // Token nuevo en cada inicio de sesión (evita "fijación de sesión").
        p.agregarCabecera("Set-Cookie", sesiones.cookie(sesiones.crear(u.getId())));
        return ConvertidorJson.usuario(u);
    }

    private Object cambiarContrasena(Peticion p) {
        Usuario u = p.usuario();
        MapaJson j = p.json();
        autenticacion.cambiarContrasena(u, j.texto("actual"), j.texto("nueva"));
        // Cierra las sesiones abiertas en otros dispositivos y renueva la actual.
        sesiones.cerrarTodasDe(u.getId(), null);
        p.agregarCabecera("Set-Cookie", sesiones.cookie(sesiones.crear(u.getId())));
        return Map.of("mensaje", "Contraseña actualizada.");
    }

    private Object cerrar(Peticion p) {
        sesiones.cerrar(p.tokenSesion());
        p.agregarCabecera("Set-Cookie", sesiones.cookieBorrada());
        return null;
    }
}
