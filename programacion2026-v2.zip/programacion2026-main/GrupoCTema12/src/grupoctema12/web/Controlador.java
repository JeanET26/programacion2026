package grupoctema12.web;

/**
 * Cada controlador registra sus propias rutas. Para agregar una
 * funcionalidad nueva se crea otro Controlador y se lo suma a la lista de
 * {@link ServidorWeb}; no se modifica el enrutador ni los controladores
 * existentes (principio Abierto/Cerrado).
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public interface Controlador {
    void registrarRutas(Enrutador enrutador);
}
