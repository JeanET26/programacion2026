package grupoctema12.web;

import grupoctema12.servicio.AsignacionCuidadoServicio;
import grupoctema12.servicio.AsignacionGuiaServicio;
import grupoctema12.util.MapaJson;

/**
 * Asignaciones del administrador.
 * <pre>
 * GET/POST /api/asignaciones-guia       {guiaId, itinerarioId, hora}
 * PUT      /api/asignaciones-guia/{id}  {hora}
 * DELETE   /api/asignaciones-guia/{id}
 * GET/POST /api/asignaciones-cuidado    {cuidadorId, especieId, fechaAsignacion}
 * PUT      /api/asignaciones-cuidado/{id} {fechaAsignacion}
 * DELETE   /api/asignaciones-cuidado/{id}
 * </pre>
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class AsignacionControlador implements Controlador {
    private final AsignacionGuiaServicio guias;
    private final AsignacionCuidadoServicio cuidados;

    public AsignacionControlador(AsignacionGuiaServicio guias, AsignacionCuidadoServicio cuidados) {
        this.guias = guias;
        this.cuidados = cuidados;
    }

    @Override
    public void registrarRutas(Enrutador r) {
        r.get("/api/asignaciones-guia", p -> guias.listar(p.usuario()).stream().map(ConvertidorJson::asignacionGuia).toList());
        r.post("/api/asignaciones-guia", p -> {
            MapaJson j = p.json();
            p.responderCon(201);
            return ConvertidorJson.asignacionGuia(guias.asignar(p.usuario(), j.uuidRequerido("guiaId"),
                    j.uuidRequerido("itinerarioId"), j.hora("hora")));
        });
        r.put("/api/asignaciones-guia/{id}", p -> ConvertidorJson.asignacionGuia(
                guias.cambiarHora(p.usuario(), p.id(), p.json().hora("hora"))));
        r.delete("/api/asignaciones-guia/{id}", p -> {
            guias.eliminar(p.usuario(), p.id());
            return null;
        });

        r.get("/api/asignaciones-cuidado", p -> cuidados.listar(p.usuario()).stream()
                .map(ConvertidorJson::asignacionCuidado).toList());
        r.post("/api/asignaciones-cuidado", p -> {
            MapaJson j = p.json();
            p.responderCon(201);
            return ConvertidorJson.asignacionCuidado(cuidados.asignar(p.usuario(), j.uuidRequerido("cuidadorId"),
                    j.uuidRequerido("especieId"), j.fecha("fechaAsignacion")));
        });
        r.put("/api/asignaciones-cuidado/{id}", p -> ConvertidorJson.asignacionCuidado(
                cuidados.cambiarFecha(p.usuario(), p.id(), p.json().fecha("fechaAsignacion"))));
        r.delete("/api/asignaciones-cuidado/{id}", p -> {
            cuidados.eliminar(p.usuario(), p.id());
            return null;
        });
    }
}
