package grupoctema12.web;

import grupoctema12.excepciones.DatoInvalidoException;
import grupoctema12.modelo.Rol;
import grupoctema12.servicio.Datos;
import grupoctema12.servicio.PersonalServicio;
import grupoctema12.util.MapaJson;

/**
 * Guías y cuidadores.
 * <pre>
 * GET/POST /api/empleados     PUT/DELETE /api/empleados/{id}
 * </pre>
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class PersonalControlador implements Controlador {
    private final PersonalServicio personal;

    public PersonalControlador(PersonalServicio personal) {
        this.personal = personal;
    }

    @Override
    public void registrarRutas(Enrutador r) {
        r.get("/api/empleados", p -> personal.listar(p.usuario()).stream().map(ConvertidorJson::usuario).toList());
        r.post("/api/empleados", p -> {
            p.responderCon(201);
            return ConvertidorJson.usuario(personal.crear(p.usuario(), datos(p.json())));
        });
        r.put("/api/empleados/{id}", p -> ConvertidorJson.usuario(personal.actualizar(p.usuario(), p.id(), datos(p.json()))));
        r.delete("/api/empleados/{id}", p -> {
            personal.eliminar(p.usuario(), p.id());
            return null;
        });
    }

    private static Datos.Empleado datos(MapaJson j) {
        Rol rol = null;
        String texto = j.texto("rol");
        if (texto != null && !texto.isBlank()) {
            try {
                rol = Rol.valueOf(texto);
            } catch (IllegalArgumentException ex) {
                throw new DatoInvalidoException("rol", "Rol inválido.");
            }
        }
        String usuario = j.texto("nombreUsuario");
        return new Datos.Empleado(rol, usuario == null ? null : usuario.strip().toLowerCase(), j.texto("contrasena"),
                j.texto("nombre"), j.texto("direccion"), j.texto("telefono"), j.fecha("fechaIngreso"));
    }
}
