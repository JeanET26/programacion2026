package grupoctema12.web;

import grupoctema12.excepciones.MundoMarinoException;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Frena los intentos de adivinar contraseñas: como máximo {@code maximo}
 * intentos fallidos por clave cada 10 minutos. Se usan dos: uno por usuario
 * (estricto) y otro por IP (más amplio, porque en una red local muchos
 * empleados comparten la misma IP).
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class LimitadorIntentos {
    private static final Duration VENTANA = Duration.ofMinutes(10);

    private final Map<String, Deque<Instant>> fallos = new ConcurrentHashMap<>();
    private final int maximo;

    public LimitadorIntentos(int maximo) {
        this.maximo = maximo;
    }

    /** Error 429: demasiados intentos. */
    public static final class DemasiadosIntentosException extends MundoMarinoException {
        private static final long serialVersionUID = 1L;

        DemasiadosIntentosException() {
            super("Demasiados intentos fallidos. Esperá unos minutos y volvé a probar.");
        }

        @Override
        public int getCodigoHttp() {
            return 429;
        }
    }

    public void verificar(String... claves) {
        Instant limite = Instant.now().minus(VENTANA);
        for (String clave : claves) {
            Deque<Instant> lista = fallos.get(clave);
            if (lista == null) {
                continue;
            }
            synchronized (lista) {
                lista.removeIf(i -> i.isBefore(limite));
                if (lista.size() >= maximo) {
                    throw new DemasiadosIntentosException();
                }
            }
        }
    }

    public void registrarFallo(String... claves) {
        for (String clave : claves) {
            Deque<Instant> lista = fallos.computeIfAbsent(clave, k -> new ArrayDeque<>());
            synchronized (lista) {
                lista.add(Instant.now());
            }
        }
    }

    public void limpiar(String... claves) {
        for (String clave : claves) {
            fallos.remove(clave);
        }
    }
}
