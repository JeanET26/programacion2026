package grupoctema12.web;

import grupoctema12.servicio.Datos;
import grupoctema12.servicio.Servicios;
import grupoctema12.util.MapaJson;

/**
 * Administración de zonas, hábitats, especies e itinerarios.
 * Todas las rutas exigen sesión y el permiso lo controla cada servicio.
 * <pre>
 * GET/POST   /api/zonas         PUT/DELETE /api/zonas/{id}
 * GET/POST   /api/habitats      PUT/DELETE /api/habitats/{id}
 * GET/POST   /api/especies      PUT/DELETE /api/especies/{id}
 * GET/POST   /api/itinerarios   PUT/DELETE /api/itinerarios/{id}
 * </pre>
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class ParqueControlador implements Controlador {
    private final Servicios s;

    public ParqueControlador(Servicios servicios) {
        this.s = servicios;
    }

    @Override
    public void registrarRutas(Enrutador r) {
        r.get("/api/zonas", p -> s.zonas().listar(p.usuario()).stream()
                .map(z -> ConvertidorJson.zona(z, s.zonas().cantidadEspecies(z.getId()))).toList());
        r.post("/api/zonas", p -> {
            p.responderCon(201);
            return ConvertidorJson.zona(s.zonas().crear(p.usuario(), zona(p.json())), 0);
        });
        r.put("/api/zonas/{id}", p -> ConvertidorJson.zona(s.zonas().actualizar(p.usuario(), p.id(), zona(p.json())),
                s.zonas().cantidadEspecies(p.id())));
        r.delete("/api/zonas/{id}", p -> {
            s.zonas().eliminar(p.usuario(), p.id());
            return null;
        });

        r.get("/api/habitats", p -> s.habitats().listar(p.usuario()).stream().map(ConvertidorJson::habitat).toList());
        r.post("/api/habitats", p -> {
            p.responderCon(201);
            return ConvertidorJson.habitat(s.habitats().crear(p.usuario(), habitat(p.json())));
        });
        r.put("/api/habitats/{id}", p -> ConvertidorJson.habitat(
                s.habitats().actualizar(p.usuario(), p.id(), habitat(p.json()))));
        r.delete("/api/habitats/{id}", p -> {
            s.habitats().eliminar(p.usuario(), p.id());
            return null;
        });

        r.get("/api/especies", p -> s.especies().listar(p.usuario()).stream().map(ConvertidorJson::especie).toList());
        r.post("/api/especies", p -> {
            p.responderCon(201);
            return ConvertidorJson.especie(s.especies().crear(p.usuario(), especie(p.json())));
        });
        r.put("/api/especies/{id}", p -> ConvertidorJson.especie(
                s.especies().actualizar(p.usuario(), p.id(), especie(p.json()))));
        r.delete("/api/especies/{id}", p -> {
            s.especies().eliminar(p.usuario(), p.id());
            return null;
        });

        r.get("/api/itinerarios", p -> s.itinerarios().listar(p.usuario()).stream()
                .map(i -> ConvertidorJson.itinerario(i, s.itinerarios())).toList());
        r.post("/api/itinerarios", p -> {
            p.responderCon(201);
            return ConvertidorJson.itinerario(s.itinerarios().crear(p.usuario(), itinerario(p.json(), true)),
                    s.itinerarios());
        });
        r.put("/api/itinerarios/{id}", p -> ConvertidorJson.itinerario(
                s.itinerarios().actualizar(p.usuario(), p.id(), itinerario(p.json(), false)), s.itinerarios()));
        r.delete("/api/itinerarios/{id}", p -> {
            s.itinerarios().eliminar(p.usuario(), p.id());
            return null;
        });
    }

    private static Datos.Zona zona(MapaJson j) {
        return new Datos.Zona(j.texto("nombre"), j.decimal("extensionM2"));
    }

    private static Datos.Habitat habitat(MapaJson j) {
        return new Datos.Habitat(j.texto("nombre"), j.texto("clima"), j.texto("vegetacion"), j.listaTextos("continentes"));
    }

    private static Datos.Especie especie(MapaJson j) {
        return new Datos.Especie(j.texto("nombreEspanol"), j.texto("nombreCientifico"), j.texto("descripcion"),
                j.uuid("zonaId"), j.listaUuids("habitatIds"));
    }

    private static Datos.Itinerario itinerario(MapaJson j, boolean esAlta) {
        return new Datos.Itinerario(esAlta ? j.enteroInt("numero") : null, j.enteroInt("duracionMinutos"),
                j.decimal("longitudKm"), j.enteroInt("maximoVisitantes"), j.listaUuids("especieIds"));
    }
}
