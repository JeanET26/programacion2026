package grupoctema12.web;

/**
 * Lo que hace una ruta. Devuelve el objeto que se convertirá a JSON
 * (Map, List...) o {@code null} para responder 204 sin contenido.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
@FunctionalInterface
public interface Manejador {
    Object atender(Peticion peticion);
}
