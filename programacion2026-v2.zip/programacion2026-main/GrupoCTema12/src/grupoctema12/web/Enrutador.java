package grupoctema12.web;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import grupoctema12.excepciones.DatoInvalidoException;
import grupoctema12.excepciones.MundoMarinoException;
import grupoctema12.modelo.Usuario;
import grupoctema12.servicio.AutenticacionServicio;
import grupoctema12.util.Json;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Recibe todos los pedidos a {@code /api/...}, busca la ruta que coincide y
 * llama a su {@link Manejador}. Además centraliza la seguridad común a todas
 * las rutas (así ningún controlador se la puede olvidar):
 * <ul>
 *   <li>Lee la cookie de sesión y obtiene el usuario.</li>
 *   <li>Protección CSRF: en POST/PUT/DELETE exige {@code Content-Type: application/json}
 *   y que el {@code Origin} (si viene) sea este mismo servidor.</li>
 *   <li>Limita el tamaño del cuerpo (64 KB).</li>
 *   <li>Agrega cabeceras de seguridad y {@code Cache-Control: no-store}.</li>
 *   <li>Traduce las excepciones a códigos HTTP sin mostrar detalles internos.</li>
 * </ul>
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class Enrutador implements HttpHandler {
    private static final Logger LOG = Logger.getLogger(Enrutador.class.getName());
    private static final int MAX_CUERPO = 64 * 1024;

    private record Ruta(String metodo, Pattern patron, List<String> nombres, Manejador manejador) { }

    private final List<Ruta> rutas = new ArrayList<>();
    private final GestorSesiones sesiones;
    private final AutenticacionServicio autenticacion;

    public Enrutador(GestorSesiones sesiones, AutenticacionServicio autenticacion) {
        this.sesiones = sesiones;
        this.autenticacion = autenticacion;
    }

    public void get(String ruta, Manejador m) { agregar("GET", ruta, m); }
    public void post(String ruta, Manejador m) { agregar("POST", ruta, m); }
    public void put(String ruta, Manejador m) { agregar("PUT", ruta, m); }
    public void delete(String ruta, Manejador m) { agregar("DELETE", ruta, m); }

    /** Convierte "/api/especies/{id}" en una expresión regular con grupo "id". */
    private void agregar(String metodo, String ruta, Manejador manejador) {
        List<String> nombres = new ArrayList<>();
        Matcher m = Pattern.compile("\\{(\\w+)}").matcher(ruta);
        StringBuilder regex = new StringBuilder("^");
        int ultimo = 0;
        while (m.find()) {
            regex.append(Pattern.quote(ruta.substring(ultimo, m.start()))).append("([^/]+)");
            nombres.add(m.group(1));
            ultimo = m.end();
        }
        regex.append(Pattern.quote(ruta.substring(ultimo))).append("$");
        rutas.add(new Ruta(metodo, Pattern.compile(regex.toString()), nombres, manejador));
    }

    @Override
    public void handle(HttpExchange ex) throws IOException {
        try (ex) {
            agregarCabecerasSeguridad(ex.getResponseHeaders());
            ex.getResponseHeaders().set("Cache-Control", "no-store");
            try {
                atender(ex);
            } catch (MundoMarinoException e) {
                Map<String, Object> error = new LinkedHashMap<>();
                error.put("mensaje", e.getMessage());
                if (e.getCampo() != null) {
                    error.put("errores", Map.of(e.getCampo(), e.getMessage()));
                }
                enviar(ex, e.getCodigoHttp(), error);
            } catch (RuntimeException e) {
                LOG.log(Level.SEVERE, "Error no controlado en " + ex.getRequestURI().getPath(), e);
                enviar(ex, 500, Map.of("mensaje", "Ocurrió un error interno. Intentá de nuevo."));
            }
        }
    }

    private void atender(HttpExchange ex) throws IOException {
        String metodo = ex.getRequestMethod();
        String ruta = ex.getRequestURI().getPath();
        boolean rutaExiste = false;
        for (Ruta r : rutas) {
            Matcher m = r.patron().matcher(ruta);
            if (!m.matches()) {
                continue;
            }
            rutaExiste = true;
            if (!r.metodo().equals(metodo)) {
                continue;
            }
            if (!"GET".equals(metodo)) {
                verificarCsrf(ex);
            }
            Map<String, String> parametros = new HashMap<>();
            for (int i = 0; i < r.nombres().size(); i++) {
                parametros.put(r.nombres().get(i), m.group(i + 1));
            }
            String token = leerCookie(ex.getRequestHeaders(), GestorSesiones.COOKIE);
            Optional<Usuario> usuario = sesiones.usuarioDe(token).flatMap(autenticacion::buscarPorId);
            Peticion p = new Peticion(metodo, parametros, leerCuerpo(ex), ip(ex), usuario, token);
            Object resultado = r.manejador().atender(p);
            p.cabecerasRespuesta().forEach(c -> ex.getResponseHeaders().add(c[0], c[1]));
            if (resultado == null) {
                ex.sendResponseHeaders(204, -1);
            } else {
                enviar(ex, p.codigoRespuesta(), resultado);
            }
            return;
        }
        enviar(ex, rutaExiste ? 405 : 404, Map.of("mensaje", rutaExiste ? "Método no permitido." : "Ruta inexistente."));
    }

    /**
     * Un formulario HTML de otro sitio no puede mandar {@code application/json}
     * sin que el navegador pida permiso antes (CORS), y además se compara el
     * Origin. Con eso, otra página no puede hacer acciones en nombre del usuario.
     */
    private static void verificarCsrf(HttpExchange ex) {
        Headers h = ex.getRequestHeaders();
        String tipo = Optional.ofNullable(h.getFirst("Content-Type")).orElse("");
        if (!tipo.toLowerCase().startsWith("application/json")) {
            throw new DatoInvalidoException(null, "Las peticiones deben enviarse como JSON.");
        }
        String origen = h.getFirst("Origin");
        String host = h.getFirst("Host");
        if (origen != null && host != null && !origen.equals("http://" + host) && !origen.equals("https://" + host)) {
            throw new grupoctema12.excepciones.AccesoDenegadoException("Origen no permitido.");
        }
    }

    private static String leerCuerpo(HttpExchange ex) throws IOException {
        try (InputStream in = ex.getRequestBody()) {
            byte[] datos = in.readNBytes(MAX_CUERPO + 1);
            if (datos.length > MAX_CUERPO) {
                throw new DatoInvalidoException(null, "El contenido enviado es demasiado grande.");
            }
            return new String(datos, StandardCharsets.UTF_8);
        }
    }

    static String leerCookie(Headers h, String nombre) {
        List<String> cookies = h.get("Cookie");
        if (cookies == null) {
            return null;
        }
        for (String linea : cookies) {
            for (String par : linea.split(";")) {
                String[] kv = par.strip().split("=", 2);
                if (kv.length == 2 && kv[0].equals(nombre)) {
                    return kv[1];
                }
            }
        }
        return null;
    }

    private static String ip(HttpExchange ex) {
        return ex.getRemoteAddress() == null ? "?" : ex.getRemoteAddress().getAddress().getHostAddress();
    }

    static void agregarCabecerasSeguridad(Headers h) {
        h.set("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; "
                + "img-src 'self' data:; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'");
        h.set("X-Content-Type-Options", "nosniff");
        h.set("X-Frame-Options", "DENY");
        h.set("Referrer-Policy", "same-origin");
        h.set("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
    }

    private static void enviar(HttpExchange ex, int codigo, Object cuerpo) throws IOException {
        byte[] bytes = Json.escribir(cuerpo).getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        ex.sendResponseHeaders(codigo, bytes.length);
        try (OutputStream out = ex.getResponseBody()) {
            out.write(bytes);
        }
    }
}
