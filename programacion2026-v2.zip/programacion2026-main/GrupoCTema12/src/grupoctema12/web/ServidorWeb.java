package grupoctema12.web;

import com.sun.net.httpserver.HttpServer;
import grupoctema12.servicio.Servicios;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.List;
import java.util.concurrent.Executors;

/**
 * Servidor HTTP incluido en el JDK ({@code com.sun.net.httpserver}), sin
 * librerías externas. Sirve el frontend en {@code /} y la API JSON en
 * {@code /api/}. Al estar en el mismo origen no hace falta configurar CORS.
 *
 * <p>Escucha solo en {@code 127.0.0.1}: desde otra computadora no se puede
 * entrar. Para publicarlo habría que ponerlo detrás de HTTPS.</p>
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class ServidorWeb {
    private final HttpServer servidor;

    public ServidorWeb(int puerto, Servicios s) throws IOException {
        GestorSesiones sesiones = new GestorSesiones();
        Enrutador enrutador = new Enrutador(sesiones, s.autenticacion());
        // Para agregar una funcionalidad se suma un controlador a esta lista.
        List<Controlador> controladores = List.of(
                new SesionControlador(s.autenticacion(), sesiones),
                new ParqueControlador(s),
                new PersonalControlador(s.personal()),
                new AsignacionControlador(s.asignacionesGuia(), s.asignacionesCuidado()),
                new MiPanelControlador(s.misRecorridos(), s.misEspecies()));
        controladores.forEach(c -> c.registrarRutas(enrutador));

        servidor = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), puerto), 0);
        servidor.createContext("/api/", enrutador);
        servidor.createContext("/", new ArchivosEstaticos());
        servidor.setExecutor(Executors.newFixedThreadPool(8));
    }

    public void iniciar() {
        servidor.start();
    }

    public void detener() {
        servidor.stop(0);
    }
}
