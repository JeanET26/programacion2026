package grupoctema12.web;

import grupoctema12.excepciones.NoAutenticadoException;
import grupoctema12.modelo.Usuario;
import grupoctema12.util.MapaJson;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Datos de un pedido HTTP ya procesado por el {@link Enrutador}: parámetros
 * de la ruta, cuerpo JSON y usuario de la sesión. Los controladores trabajan
 * con esta clase y no con el {@code HttpExchange} del JDK.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class Peticion {
    private final String metodo;
    private final Map<String, String> parametrosRuta;
    private final String cuerpo;
    private final String ip;
    private final Optional<Usuario> usuario;
    private final String tokenSesion;
    private final List<String[]> cabecerasRespuesta = new ArrayList<>();
    private int codigoRespuesta = 200;

    Peticion(String metodo, Map<String, String> parametrosRuta, String cuerpo, String ip, Optional<Usuario> usuario,
            String tokenSesion) {
        this.metodo = metodo;
        this.parametrosRuta = parametrosRuta;
        this.cuerpo = cuerpo;
        this.ip = ip;
        this.usuario = usuario;
        this.tokenSesion = tokenSesion;
    }

    public String metodo() { return metodo; }
    public String ip() { return ip; }

    /** Usuario que inició sesión; si no hay, lanza 401. */
    public Usuario usuario() {
        return usuario.orElseThrow(() -> new NoAutenticadoException("Tenés que iniciar sesión."));
    }

    public MapaJson json() {
        return MapaJson.desdeTexto(cuerpo == null || cuerpo.isBlank() ? "{}" : cuerpo);
    }

    /** Id de la ruta, por ejemplo el {id} de /api/especies/{id}. */
    public UUID id() {
        try {
            return UUID.fromString(parametrosRuta.get("id"));
        } catch (IllegalArgumentException | NullPointerException ex) {
            throw new grupoctema12.excepciones.NoEncontradoException("El elemento solicitado no existe.");
        }
    }

    /** Cambia el código HTTP de la respuesta (por ejemplo 201 al crear). */
    public void responderCon(int codigo) {
        this.codigoRespuesta = codigo;
    }

    public void agregarCabecera(String nombre, String valor) {
        cabecerasRespuesta.add(new String[] {nombre, valor});
    }

    String tokenSesion() { return tokenSesion; }
    int codigoRespuesta() { return codigoRespuesta; }
    List<String[]> cabecerasRespuesta() { return cabecerasRespuesta; }
}
