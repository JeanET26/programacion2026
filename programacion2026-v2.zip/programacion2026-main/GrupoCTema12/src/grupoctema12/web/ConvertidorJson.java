package grupoctema12.web;

import grupoctema12.modelo.AsignacionCuidado;
import grupoctema12.modelo.AsignacionGuia;
import grupoctema12.modelo.Especie;
import grupoctema12.modelo.Habitat;
import grupoctema12.modelo.Itinerario;
import grupoctema12.modelo.Usuario;
import grupoctema12.modelo.Zona;
import grupoctema12.servicio.ItinerarioServicio;
import grupoctema12.servicio.MisEspeciesServicio.EspecieACargo;
import grupoctema12.servicio.MisRecorridosServicio.RecorridoAsignado;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Arma el JSON que se envía al navegador (equivale a los DTO). Decide
 * exactamente qué datos salen: por ejemplo, el hash de la contraseña nunca
 * se incluye, y a un cuidador solo se le muestran los <i>nombres</i> de sus
 * compañeros, no su dirección ni teléfono.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class ConvertidorJson {
    private ConvertidorJson() { }

    public static Map<String, Object> zona(Zona z, int cantidadEspecies) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", z.getId());
        m.put("nombre", z.getNombre());
        m.put("extensionM2", z.getExtensionMetrosCuadrados());
        m.put("cantidadEspecies", cantidadEspecies);
        return m;
    }

    public static Map<String, Object> habitat(Habitat h) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", h.getId());
        m.put("nombre", h.getNombre());
        m.put("clima", h.getClima());
        m.put("vegetacion", h.getVegetacionPredominante());
        m.put("continentes", List.copyOf(h.getContinentes()));
        return m;
    }

    public static Map<String, Object> especie(Especie e) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", e.getId());
        m.put("nombreEspanol", e.getNombreEspanol());
        m.put("nombreCientifico", e.getNombreCientifico());
        m.put("descripcion", e.getDescripcionGeneral());
        m.put("zonaId", e.getZonaId().orElse(null));
        m.put("habitatIds", List.copyOf(e.getHabitatIds()));
        return m;
    }

    public static Map<String, Object> itinerario(Itinerario i, ItinerarioServicio servicio) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", i.getId());
        m.put("codigo", i.getCodigo());
        m.put("numero", Integer.parseInt(i.getCodigo().substring(3)));
        m.put("duracionMinutos", i.getDuracion().toMinutes());
        m.put("longitudKm", i.getLongitudKilometros());
        m.put("maximoVisitantes", i.getMaximoVisitantes());
        m.put("especieIds", List.copyOf(i.getEspecieIds()));
        m.put("zonas", servicio.zonasDe(i).stream().map(Zona::getNombre).toList());
        return m;
    }

    /** Datos de un usuario SIN el hash de la contraseña. */
    public static Map<String, Object> usuario(Usuario u) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", u.getId());
        m.put("nombreUsuario", u.getNombreUsuario());
        m.put("nombre", u.getNombre());
        m.put("rol", u.getRol());
        m.put("permisos", u.getPermisos().stream().map(Enum::name).sorted().toList());
        u.comoEmpleado().ifPresent(e -> {
            m.put("direccion", e.getDireccion());
            m.put("telefono", e.getTelefono());
            m.put("fechaIngreso", e.getFechaIngreso());
        });
        return m;
    }

    public static Map<String, Object> asignacionGuia(AsignacionGuia a) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", a.getId());
        m.put("guiaId", a.getGuiaId());
        m.put("itinerarioId", a.getItinerarioId());
        m.put("hora", a.getHora());
        return m;
    }

    public static Map<String, Object> asignacionCuidado(AsignacionCuidado a) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", a.getId());
        m.put("cuidadorId", a.getCuidadorId());
        m.put("especieId", a.getEspecieId());
        m.put("fechaAsignacion", a.getFechaAsignacion());
        return m;
    }

    public static Map<String, Object> recorridoAsignado(RecorridoAsignado r) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("asignacionId", r.asignacion().getId());
        m.put("hora", r.asignacion().getHora());
        m.put("horaFin", r.horaFin());
        m.put("codigo", r.itinerario().getCodigo());
        m.put("duracionMinutos", r.itinerario().getDuracion().toMinutes());
        m.put("longitudKm", r.itinerario().getLongitudKilometros());
        m.put("maximoVisitantes", r.itinerario().getMaximoVisitantes());
        m.put("zonas", r.zonas().stream().map(Zona::getNombre).toList());
        m.put("especies", r.especies().stream().map(e -> Map.of(
                "nombreEspanol", e.getNombreEspanol(), "nombreCientifico", e.getNombreCientifico())).toList());
        return m;
    }

    public static Map<String, Object> especieACargo(EspecieACargo e) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("asignacionId", e.asignacion().getId());
        m.put("desde", e.asignacion().getFechaAsignacion());
        m.put("nombreEspanol", e.especie().getNombreEspanol());
        m.put("nombreCientifico", e.especie().getNombreCientifico());
        m.put("descripcion", e.especie().getDescripcionGeneral());
        m.put("zona", e.zona().map(Zona::getNombre).orElse(null));
        m.put("habitats", e.habitats().stream().map(h -> Map.of("nombre", h.getNombre(), "clima", h.getClima())).toList());
        m.put("otrosCuidadores", e.otrosCuidadores());
        return m;
    }
}
