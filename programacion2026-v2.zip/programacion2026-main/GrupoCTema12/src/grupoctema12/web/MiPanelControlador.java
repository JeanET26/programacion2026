package grupoctema12.web;

import grupoctema12.servicio.MisEspeciesServicio;
import grupoctema12.servicio.MisRecorridosServicio;

/**
 * Lo que consulta cada empleado sobre sí mismo.
 * <pre>
 * GET /api/mis-recorridos   (guías)
 * GET /api/mis-especies     (cuidadores)
 * </pre>
 * No reciben ningún id: siempre se usa el usuario de la sesión.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class MiPanelControlador implements Controlador {
    private final MisRecorridosServicio recorridos;
    private final MisEspeciesServicio especies;

    public MiPanelControlador(MisRecorridosServicio recorridos, MisEspeciesServicio especies) {
        this.recorridos = recorridos;
        this.especies = especies;
    }

    @Override
    public void registrarRutas(Enrutador r) {
        r.get("/api/mis-recorridos", p -> recorridos.consultar(p.usuario()).stream()
                .map(ConvertidorJson::recorridoAsignado).toList());
        r.get("/api/mis-especies", p -> especies.consultar(p.usuario()).stream()
                .map(ConvertidorJson::especieACargo).toList());
    }
}
