package grupoctema12.web;

import java.security.SecureRandom;
import java.time.Duration;
import java.time.Instant;
import java.util.Base64;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Sesiones en memoria. Al iniciar sesión se entrega al navegador un token
 * aleatorio de 256 bits en una cookie {@code HttpOnly} (JavaScript no la
 * puede leer, así un ataque XSS no la roba) y {@code SameSite=Strict} (el
 * navegador no la envía desde otros sitios: protege contra CSRF).
 *
 * <p>La sesión vence a los 30 minutos sin uso o a las 8 horas.</p>
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class GestorSesiones {
    public static final String COOKIE = "MM_SESION";
    private static final Duration INACTIVIDAD = Duration.ofMinutes(30);
    private static final Duration MAXIMA = Duration.ofHours(8);
    private static final SecureRandom ALEATORIO = new SecureRandom();

    private record Sesion(UUID usuarioId, Instant creada, Instant ultimoUso) { }

    private final Map<String, Sesion> sesiones = new ConcurrentHashMap<>();

    public String crear(UUID usuarioId) {
        limpiarVencidas();
        byte[] bytes = new byte[32];
        ALEATORIO.nextBytes(bytes);
        String token = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
        Instant ahora = Instant.now();
        sesiones.put(token, new Sesion(usuarioId, ahora, ahora));
        return token;
    }

    public Optional<UUID> usuarioDe(String token) {
        if (token == null) {
            return Optional.empty();
        }
        Sesion s = sesiones.get(token);
        Instant ahora = Instant.now();
        if (s == null || vencida(s, ahora)) {
            sesiones.remove(token);
            return Optional.empty();
        }
        sesiones.put(token, new Sesion(s.usuarioId(), s.creada(), ahora));
        return Optional.of(s.usuarioId());
    }

    public void cerrar(String token) {
        if (token != null) {
            sesiones.remove(token);
        }
    }

    /** Cierra todas las sesiones de un usuario (por ejemplo al cambiar la contraseña). */
    public void cerrarTodasDe(UUID usuarioId, String excepto) {
        sesiones.entrySet().removeIf(e -> e.getValue().usuarioId().equals(usuarioId) && !e.getKey().equals(excepto));
    }

    public String cookie(String token) {
        return COOKIE + "=" + token + "; Path=/; HttpOnly; SameSite=Strict; Max-Age=" + MAXIMA.toSeconds();
    }

    public String cookieBorrada() {
        return COOKIE + "=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0";
    }

    private static boolean vencida(Sesion s, Instant ahora) {
        return s.ultimoUso().plus(INACTIVIDAD).isBefore(ahora) || s.creada().plus(MAXIMA).isBefore(ahora);
    }

    private void limpiarVencidas() {
        Instant ahora = Instant.now();
        sesiones.values().removeIf(s -> vencida(s, ahora));
    }
}
