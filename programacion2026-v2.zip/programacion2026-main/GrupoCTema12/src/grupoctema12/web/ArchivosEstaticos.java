package grupoctema12.web;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;

/**
 * Sirve el frontend (HTML, CSS, JS, imágenes) desde la carpeta
 * {@code src/web} que viaja dentro del JAR. Solo entrega extensiones
 * conocidas y rechaza rutas con {@code ..} (no se puede pedir
 * {@code /../../datos/usuarios.json}).
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class ArchivosEstaticos implements HttpHandler {
    private static final String BASE = "/web";
    private static final Map<String, String> TIPOS = Map.of(
            "html", "text/html; charset=utf-8",
            "css", "text/css; charset=utf-8",
            "js", "text/javascript; charset=utf-8",
            "svg", "image/svg+xml",
            "png", "image/png",
            "ico", "image/x-icon",
            "txt", "text/plain; charset=utf-8");

    @Override
    public void handle(HttpExchange ex) throws IOException {
        try (ex) {
            Enrutador.agregarCabecerasSeguridad(ex.getResponseHeaders());
            if (!"GET".equals(ex.getRequestMethod()) && !"HEAD".equals(ex.getRequestMethod())) {
                ex.sendResponseHeaders(405, -1);
                return;
            }
            String ruta = ex.getRequestURI().getPath();
            if (ruta.equals("/")) {
                ruta = "/index.html";
            }
            String extension = ruta.contains(".") ? ruta.substring(ruta.lastIndexOf('.') + 1) : "";
            String tipo = TIPOS.get(extension);
            boolean sospechosa = ruta.contains("..") || ruta.contains("\\") || ruta.contains("//");
            InputStream recurso = sospechosa || tipo == null ? null : getClass().getResourceAsStream(BASE + ruta);
            if (recurso == null) {
                byte[] msg = "404 - No encontrado".getBytes(java.nio.charset.StandardCharsets.UTF_8);
                ex.getResponseHeaders().set("Content-Type", "text/plain; charset=utf-8");
                ex.sendResponseHeaders(404, msg.length);
                try (OutputStream out = ex.getResponseBody()) {
                    out.write(msg);
                }
                return;
            }
            try (recurso) {
                byte[] bytes = recurso.readAllBytes();
                ex.getResponseHeaders().set("Content-Type", tipo);
                ex.getResponseHeaders().set("Cache-Control", "no-cache");
                ex.sendResponseHeaders(200, "HEAD".equals(ex.getRequestMethod()) ? -1 : bytes.length);
                if (!"HEAD".equals(ex.getRequestMethod())) {
                    try (OutputStream out = ex.getResponseBody()) {
                        out.write(bytes);
                    }
                }
            }
        }
    }
}
