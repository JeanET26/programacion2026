package grupoctema12.modelo;

import grupoctema12.util.Validaciones;
import java.time.LocalDate;
import java.util.UUID;

/**
 * Relación cuidador–especie con la fecha desde la que es responsable.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class AsignacionCuidado implements Identificable {
    private final UUID id;
    private final UUID cuidadorId;
    private final UUID especieId;
    private LocalDate fechaAsignacion;

    public AsignacionCuidado(UUID cuidadorId, UUID especieId, LocalDate fecha) {
        this(UUID.randomUUID(), cuidadorId, especieId, fecha);
    }

    public AsignacionCuidado(UUID id, UUID cuidadorId, UUID especieId, LocalDate fecha) {
        this.id = Validaciones.obligatorio(id, "id");
        this.cuidadorId = Validaciones.obligatorio(cuidadorId, "cuidadorId");
        this.especieId = Validaciones.obligatorio(especieId, "especieId");
        cambiarFecha(fecha);
    }

    public void cambiarFecha(LocalDate fecha) {
        this.fechaAsignacion = Validaciones.obligatorio(fecha, "fechaAsignacion");
    }

    @Override
    public UUID getId() { return id; }
    public UUID getCuidadorId() { return cuidadorId; }
    public UUID getEspecieId() { return especieId; }
    public LocalDate getFechaAsignacion() { return fechaAsignacion; }
}
