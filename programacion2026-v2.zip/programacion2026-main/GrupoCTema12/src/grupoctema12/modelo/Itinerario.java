package grupoctema12.modelo;

import grupoctema12.util.Validaciones;
import java.time.Duration;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Recorrido guiado. Guarda solo las especies que visita; las zonas NO se
 * guardan: se calculan a partir de las especies (ver
 * {@code ItinerarioServicio.zonasDe}). Antes se guardaban por separado y,
 * si una especie cambiaba de zona, el itinerario quedaba con la zona vieja.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class Itinerario implements Identificable {
    public static final int MAX_NUMERO = 99;

    private final UUID id;
    private final String codigo;
    private Duration duracion;
    private double longitudKilometros;
    private int maximoVisitantes;
    private final Set<UUID> especieIds = new LinkedHashSet<>();

    public Itinerario(int numero, Duration duracion, double longitudKm, int maximoVisitantes, Set<UUID> especieIds) {
        this(UUID.randomUUID(), codigoPara(numero), duracion, longitudKm, maximoVisitantes, especieIds);
    }

    public Itinerario(UUID id, String codigo, Duration duracion, double longitudKm, int maximoVisitantes,
            Set<UUID> especieIds) {
        this.id = Validaciones.obligatorio(id, "id");
        this.codigo = Validaciones.formato(codigo, "codigo", "^IT-\\d{2}$", "El código debe tener el formato IT-XX.");
        actualizar(duracion, longitudKm, maximoVisitantes, especieIds);
    }

    /** Convierte el número 1..99 en el código IT-01..IT-99. */
    public static String codigoPara(int numero) {
        Validaciones.entero(numero, "numero", 1, MAX_NUMERO);
        return String.format("IT-%02d", numero);
    }

    public void actualizar(Duration duracion, double longitudKm, int maximoVisitantes, Set<UUID> especieIds) {
        this.duracion = Validaciones.obligatorio(duracion, "duracionMinutos");
        Validaciones.entero((int) duracion.toMinutes(), "duracionMinutos", 5, 480);
        this.longitudKilometros = Validaciones.positivo(longitudKm, "longitudKm");
        this.maximoVisitantes = Validaciones.entero(maximoVisitantes, "maximoVisitantes", 1, 500);
        Validaciones.noVacia(especieIds, "especies");
        this.especieIds.clear();
        this.especieIds.addAll(especieIds);
    }

    @Override
    public UUID getId() { return id; }
    public String getCodigo() { return codigo; }
    public Duration getDuracion() { return duracion; }
    public double getLongitudKilometros() { return longitudKilometros; }
    public int getMaximoVisitantes() { return maximoVisitantes; }
    public Set<UUID> getEspecieIds() { return Collections.unmodifiableSet(especieIds); }
    public int getNumeroEspeciesVisitadas() { return especieIds.size(); }
}
