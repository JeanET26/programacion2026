package grupoctema12.modelo;

/**
 * Roles del personal. Se usa para guardar y mostrar el tipo de usuario,
 * NO para decidir permisos (eso lo hace {@link Permiso}).
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public enum Rol {
    ADMINISTRADOR, GUIA, CUIDADOR
}
