package grupoctema12.modelo;

import java.time.LocalDate;
import java.util.EnumSet;
import java.util.Set;
import java.util.UUID;

/**
 * Empleado que conduce itinerarios. Solo puede ver su perfil y sus recorridos.
 * Ya no guarda listas de asignaciones: esas relaciones viven en su propio DAO
 * (antes había referencias cruzadas que había que mantener sincronizadas a mano).
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class Guia extends Empleado {
    private static final Set<Permiso> PERMISOS =
            EnumSet.of(Permiso.VER_PERFIL_PROPIO, Permiso.VER_RECORRIDOS_PROPIOS);

    public Guia(String nombreUsuario, String hashContrasena, String nombre, String direccion,
            String telefono, LocalDate fechaIngreso) {
        this(UUID.randomUUID(), nombreUsuario, hashContrasena, nombre, direccion, telefono, fechaIngreso);
    }

    public Guia(UUID id, String nombreUsuario, String hashContrasena, String nombre, String direccion,
            String telefono, LocalDate fechaIngreso) {
        super(id, nombreUsuario, hashContrasena, nombre, direccion, telefono, fechaIngreso);
    }

    @Override
    public Set<Permiso> getPermisos() {
        return Set.copyOf(PERMISOS);
    }

    @Override
    public Rol getRol() {
        return Rol.GUIA;
    }
}
