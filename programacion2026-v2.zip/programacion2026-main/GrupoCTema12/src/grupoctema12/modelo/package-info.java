/**
 * Entidades del dominio de Mundo Marino.
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
package grupoctema12.modelo;
