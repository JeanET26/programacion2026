package grupoctema12.modelo;

import grupoctema12.util.Validaciones;
import java.time.LocalDate;
import java.util.Optional;
import java.util.UUID;

/**
 * Datos comunes a guías y cuidadores.
 *
 * <p><b>¿Por qué sigue siendo abstracta?</b> Heredar de una clase abstracta
 * no vuelve abstracta a la subclase: una clase es abstracta solo si se la
 * declara así. Empleado debe serlo por dos razones:</p>
 * <ol>
 *   <li><b>De diseño:</b> en Mundo Marino no existe "un empleado" a secas; siempre
 *   es un Guía o un Cuidador. Si fuera concreta se podría hacer
 *   {@code new Empleado(...)}, un objeto sin permisos ni rol definidos.</li>
 *   <li><b>Del compilador:</b> no implementa {@code getPermisos()} ni
 *   {@code getRol()} (abstractos en Usuario/ConPermisos). Una clase que no
 *   implementa todos los métodos abstractos que hereda <i>tiene</i> que ser
 *   abstracta o no compila.</li>
 * </ol>
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public abstract class Empleado extends Usuario {
    private String direccion;
    private String telefono;
    private LocalDate fechaIngreso;

    protected Empleado(UUID id, String nombreUsuario, String hashContrasena, String nombre,
            String direccion, String telefono, LocalDate fechaIngreso) {
        super(id, nombreUsuario, hashContrasena, nombre);
        actualizarDatosLaborales(direccion, telefono, fechaIngreso);
    }

    @Override
    public final Optional<Empleado> comoEmpleado() {
        return Optional.of(this);
    }

    public String getDireccion() { return direccion; }
    public String getTelefono() { return telefono; }
    public LocalDate getFechaIngreso() { return fechaIngreso; }

    public final void actualizarDatosLaborales(String direccion, String telefono, LocalDate fechaIngreso) {
        this.direccion = Validaciones.texto(direccion, "direccion", 120);
        this.telefono = Validaciones.formato(telefono, "telefono", "^\\+?[0-9 -]{8,20}$",
                "El teléfono debe tener entre 8 y 20 dígitos (se permiten espacios y guiones).");
        this.fechaIngreso = Validaciones.obligatorio(fechaIngreso, "fechaIngreso");
        if (fechaIngreso.isAfter(LocalDate.now())) {
            throw new grupoctema12.excepciones.DatoInvalidoException("fechaIngreso", "La fecha de ingreso no puede ser futura.");
        }
    }
}
