package grupoctema12.modelo;

import grupoctema12.util.Validaciones;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Hábitat natural que pueden compartir varias especies.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class Habitat implements Identificable {
    private final UUID id;
    private String nombre;
    private String clima;
    private String vegetacionPredominante;
    private final Set<String> continentes = new LinkedHashSet<>();

    public Habitat(String nombre, String clima, String vegetacion, Set<String> continentes) {
        this(UUID.randomUUID(), nombre, clima, vegetacion, continentes);
    }

    public Habitat(UUID id, String nombre, String clima, String vegetacion, Set<String> continentes) {
        this.id = Validaciones.obligatorio(id, "id");
        actualizar(nombre, clima, vegetacion, continentes);
    }

    public void actualizar(String nombre, String clima, String vegetacion, Set<String> continentes) {
        this.nombre = Validaciones.texto(nombre, "nombre", 80);
        this.clima = Validaciones.texto(clima, "clima", 80);
        this.vegetacionPredominante = Validaciones.texto(vegetacion, "vegetacion", 120);
        Validaciones.noVacia(continentes, "continentes");
        this.continentes.clear();
        continentes.forEach(c -> this.continentes.add(Validaciones.texto(c, "continentes", 30)));
    }

    @Override
    public UUID getId() { return id; }
    public String getNombre() { return nombre; }
    public String getClima() { return clima; }
    public String getVegetacionPredominante() { return vegetacionPredominante; }
    public Set<String> getContinentes() { return Collections.unmodifiableSet(continentes); }
}
