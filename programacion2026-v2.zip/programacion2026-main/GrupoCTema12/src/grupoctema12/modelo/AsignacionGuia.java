package grupoctema12.modelo;

import grupoctema12.util.Validaciones;
import java.time.LocalTime;
import java.util.UUID;

/**
 * Relación guía–itinerario con su hora de salida.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class AsignacionGuia implements Identificable {
    private final UUID id;
    private final UUID guiaId;
    private final UUID itinerarioId;
    private LocalTime hora;

    public AsignacionGuia(UUID guiaId, UUID itinerarioId, LocalTime hora) {
        this(UUID.randomUUID(), guiaId, itinerarioId, hora);
    }

    public AsignacionGuia(UUID id, UUID guiaId, UUID itinerarioId, LocalTime hora) {
        this.id = Validaciones.obligatorio(id, "id");
        this.guiaId = Validaciones.obligatorio(guiaId, "guiaId");
        this.itinerarioId = Validaciones.obligatorio(itinerarioId, "itinerarioId");
        cambiarHora(hora);
    }

    public void cambiarHora(LocalTime hora) {
        this.hora = Validaciones.obligatorio(hora, "hora").withSecond(0).withNano(0);
    }

    @Override
    public UUID getId() { return id; }
    public UUID getGuiaId() { return guiaId; }
    public UUID getItinerarioId() { return itinerarioId; }
    public LocalTime getHora() { return hora; }
}
