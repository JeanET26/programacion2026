package grupoctema12.modelo;

import java.util.UUID;

/**
 * Contrato común de todo lo que se guarda en un DAO: tener un identificador.
 * Gracias a esta interfaz se puede escribir un único DAO genérico
 * ({@code DaoJson<T extends Identificable>}) que sirve para todas las entidades.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public interface Identificable {
    UUID getId();
}
