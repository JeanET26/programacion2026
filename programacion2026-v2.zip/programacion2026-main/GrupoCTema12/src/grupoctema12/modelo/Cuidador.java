package grupoctema12.modelo;

import java.time.LocalDate;
import java.util.EnumSet;
import java.util.Set;
import java.util.UUID;

/**
 * Empleado responsable de especies. Solo puede ver su perfil y las especies a su cargo.
 * Ya no guarda listas de asignaciones: esas relaciones viven en su propio DAO
 * (antes había referencias cruzadas que había que mantener sincronizadas a mano).
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class Cuidador extends Empleado {
    private static final Set<Permiso> PERMISOS =
            EnumSet.of(Permiso.VER_PERFIL_PROPIO, Permiso.VER_ESPECIES_PROPIAS);

    public Cuidador(String nombreUsuario, String hashContrasena, String nombre, String direccion,
            String telefono, LocalDate fechaIngreso) {
        this(UUID.randomUUID(), nombreUsuario, hashContrasena, nombre, direccion, telefono, fechaIngreso);
    }

    public Cuidador(UUID id, String nombreUsuario, String hashContrasena, String nombre, String direccion,
            String telefono, LocalDate fechaIngreso) {
        super(id, nombreUsuario, hashContrasena, nombre, direccion, telefono, fechaIngreso);
    }

    @Override
    public Set<Permiso> getPermisos() {
        return Set.copyOf(PERMISOS);
    }

    @Override
    public Rol getRol() {
        return Rol.CUIDADOR;
    }
}
