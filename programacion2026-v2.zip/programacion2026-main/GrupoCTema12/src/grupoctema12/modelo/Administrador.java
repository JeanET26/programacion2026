package grupoctema12.modelo;

import java.util.EnumSet;
import java.util.Set;
import java.util.UUID;

/**
 * Usuario con permisos de administración total.
 *
 * <p><b>¿Por qué es final?</b> Porque sus permisos son los más amplios del
 * sistema. Si se pudiera heredar, alguien podría crear
 * {@code class AdminFalso extends Administrador} y redefinir
 * {@link #getPermisos()} u otros métodos, obteniendo un objeto que "es un"
 * Administrador pero se comporta distinto. Con {@code final} el compilador
 * impide esa extensión: el comportamiento del administrador es exactamente
 * el de esta clase.</p>
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class Administrador extends Usuario {
    private static final Set<Permiso> PERMISOS =
            EnumSet.of(Permiso.ADMINISTRAR_PARQUE, Permiso.VER_PERFIL_PROPIO);

    public Administrador(String nombreUsuario, String hashContrasena, String nombre) {
        this(UUID.randomUUID(), nombreUsuario, hashContrasena, nombre);
    }

    public Administrador(UUID id, String nombreUsuario, String hashContrasena, String nombre) {
        super(id, nombreUsuario, hashContrasena, nombre);
    }

    @Override
    public Set<Permiso> getPermisos() {
        return Set.copyOf(PERMISOS);
    }

    @Override
    public Rol getRol() {
        return Rol.ADMINISTRADOR;
    }
}
