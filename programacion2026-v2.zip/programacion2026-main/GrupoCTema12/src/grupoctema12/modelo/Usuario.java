package grupoctema12.modelo;

import grupoctema12.util.Validaciones;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * Base abstracta de toda persona que inicia sesión.
 *
 * <p><b>Sobre UUID:</b> {@code UUID.randomUUID()} genera un identificador de
 * 128 bits (122 aleatorios). La probabilidad de repetir uno es despreciable,
 * así que cada objeto obtiene un id único sin depender de un contador ni de
 * la base de datos. Hay dos constructores: uno genera un id nuevo (alta) y
 * otro recibe el id existente (cuando el DAO reconstruye el objeto desde el
 * archivo o la base). Antes el id se generaba siempre en la declaración del
 * atributo, y al leer desde una base cada usuario habría cambiado de id.</p>
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public abstract class Usuario implements Identificable, ConPermisos {
    public static final String REGEX_NOMBRE_USUARIO = "^[a-z0-9._]{3,30}$";

    private final UUID id;
    private final String nombreUsuario;
    private String hashContrasena;
    private String nombre;

    protected Usuario(UUID id, String nombreUsuario, String hashContrasena, String nombre) {
        this.id = Objects.requireNonNull(id, "El id es obligatorio.");
        this.nombreUsuario = Validaciones.formato(nombreUsuario, "nombreUsuario", REGEX_NOMBRE_USUARIO,
                "El usuario debe tener entre 3 y 30 caracteres: minúsculas, números, punto o guion bajo.");
        this.hashContrasena = Validaciones.texto(hashContrasena, "contrasena", 200);
        this.nombre = Validaciones.texto(nombre, "nombre", 80);
    }

    public UUID getId() { return id; }
    public String getNombreUsuario() { return nombreUsuario; }
    public String getHashContrasena() { return hashContrasena; }
    public String getNombre() { return nombre; }

    public void setNombre(String nombre) {
        this.nombre = Validaciones.texto(nombre, "nombre", 80);
    }

    /** Recibe la contraseña YA hasheada; nunca se guarda en texto plano. */
    public void setHashContrasena(String hashContrasena) {
        this.hashContrasena = Validaciones.texto(hashContrasena, "contrasena", 200);
    }

    /** Rol para mostrar y para guardar; cada subclase devuelve el suyo. */
    public abstract Rol getRol();

    /**
     * Permite acceder a los datos laborales sin {@code instanceof}: Usuario
     * responde "vacío" y {@link Empleado} se redefine para devolverse a sí mismo.
     */
    public Optional<Empleado> comoEmpleado() {
        return Optional.empty();
    }
}
