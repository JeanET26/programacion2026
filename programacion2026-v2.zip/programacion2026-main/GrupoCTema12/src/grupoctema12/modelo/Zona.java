package grupoctema12.modelo;

import grupoctema12.util.Validaciones;
import java.util.UUID;

/**
 * Zona física del parque.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class Zona implements Identificable {
    private final UUID id;
    private String nombre;
    private double extensionMetrosCuadrados;

    public Zona(String nombre, double extensionMetrosCuadrados) {
        this(UUID.randomUUID(), nombre, extensionMetrosCuadrados);
    }

    public Zona(UUID id, String nombre, double extensionMetrosCuadrados) {
        this.id = Validaciones.obligatorio(id, "id");
        actualizar(nombre, extensionMetrosCuadrados);
    }

    public void actualizar(String nombre, double extensionMetrosCuadrados) {
        this.nombre = Validaciones.texto(nombre, "nombre", 80);
        this.extensionMetrosCuadrados = Validaciones.positivo(extensionMetrosCuadrados, "extension");
    }

    @Override
    public UUID getId() { return id; }
    public String getNombre() { return nombre; }
    public double getExtensionMetrosCuadrados() { return extensionMetrosCuadrados; }
}
