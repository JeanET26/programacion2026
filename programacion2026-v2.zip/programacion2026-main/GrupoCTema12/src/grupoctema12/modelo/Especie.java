package grupoctema12.modelo;

import grupoctema12.util.Validaciones;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * Especie del parque. Se relaciona con su zona y sus hábitats por
 * <b>identificador</b> y no por referencia directa al objeto. Así se puede
 * guardar en un archivo o en una tabla sin ciclos (Especie→Habitat→Especie)
 * y cada DAO se ocupa de una sola entidad.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class Especie implements Identificable {
    private final UUID id;
    private String nombreEspanol;
    private String nombreCientifico;
    private String descripcionGeneral;
    private UUID zonaId;
    private final Set<UUID> habitatIds = new LinkedHashSet<>();

    public Especie(String nombreEspanol, String nombreCientifico, String descripcion) {
        this(UUID.randomUUID(), nombreEspanol, nombreCientifico, descripcion, null, Set.of());
    }

    public Especie(UUID id, String nombreEspanol, String nombreCientifico, String descripcion,
            UUID zonaId, Set<UUID> habitatIds) {
        this.id = Validaciones.obligatorio(id, "id");
        actualizarDatos(nombreEspanol, nombreCientifico, descripcion);
        this.zonaId = zonaId;
        reemplazarHabitats(habitatIds);
    }

    public void actualizarDatos(String nombreEspanol, String nombreCientifico, String descripcion) {
        this.nombreEspanol = Validaciones.texto(nombreEspanol, "nombreEspanol", 80);
        this.nombreCientifico = Validaciones.texto(nombreCientifico, "nombreCientifico", 120);
        this.descripcionGeneral = Validaciones.texto(descripcion, "descripcion", 500);
    }

    /** Ubica la especie en una zona (o la quita con null). */
    public void ubicarEn(UUID zonaId) {
        this.zonaId = zonaId;
    }

    public void reemplazarHabitats(Set<UUID> habitatIds) {
        this.habitatIds.clear();
        if (habitatIds != null) {
            this.habitatIds.addAll(habitatIds);
        }
    }

    @Override
    public UUID getId() { return id; }
    public String getNombreEspanol() { return nombreEspanol; }
    public String getNombreCientifico() { return nombreCientifico; }
    public String getDescripcionGeneral() { return descripcionGeneral; }
    public Optional<UUID> getZonaId() { return Optional.ofNullable(zonaId); }
    public Set<UUID> getHabitatIds() { return Collections.unmodifiableSet(habitatIds); }
}
