package grupoctema12.modelo;

/**
 * Acciones que el sistema protege. Cada tipo de usuario declara cuáles tiene.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public enum Permiso {
    /** Registrar, modificar y eliminar especies, zonas, itinerarios, personal y asignaciones. */
    ADMINISTRAR_PARQUE,
    /** Ver su propio perfil y cambiar su contraseña. */
    VER_PERFIL_PROPIO,
    /** Ver los itinerarios y horarios asignados a uno mismo (guías). */
    VER_RECORRIDOS_PROPIOS,
    /** Ver las especies que uno tiene a cargo (cuidadores). */
    VER_ESPECIES_PROPIAS
}
