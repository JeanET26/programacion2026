package grupoctema12.modelo;

import java.util.Set;

/**
 * Reemplaza el uso de {@code instanceof} para controlar el acceso.
 * Cada clase concreta dice qué permisos tiene; el control de acceso solo
 * pregunta {@code tienePermiso(...)}. Si mañana se agrega un rol nuevo
 * (por ejemplo, Veterinario) se crea su clase y no se modifica el control
 * de acceso: principio Abierto/Cerrado.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public interface ConPermisos {

    Set<Permiso> getPermisos();

    default boolean tienePermiso(Permiso permiso) {
        return getPermisos().contains(permiso);
    }
}
