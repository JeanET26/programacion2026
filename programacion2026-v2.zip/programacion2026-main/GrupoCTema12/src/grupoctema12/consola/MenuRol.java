package grupoctema12.consola;

import grupoctema12.modelo.Usuario;

/**
 * Menú de un tipo de usuario. El menú principal recorre la lista de menús
 * y muestra el que corresponda según los permisos: agregar un rol nuevo es
 * agregar una clase, sin tocar el menú principal.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public interface MenuRol {
    boolean correspondeA(Usuario usuario);

    void mostrar(Usuario usuario);
}
