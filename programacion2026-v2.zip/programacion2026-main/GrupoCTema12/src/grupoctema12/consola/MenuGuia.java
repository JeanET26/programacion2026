package grupoctema12.consola;

import grupoctema12.modelo.Especie;
import grupoctema12.modelo.Permiso;
import grupoctema12.modelo.Usuario;
import grupoctema12.modelo.Zona;
import grupoctema12.servicio.MisRecorridosServicio;
import java.util.stream.Collectors;

/**
 * El guía ve solo sus horarios y recorridos.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class MenuGuia implements MenuRol {
    private final Consola consola;
    private final MisRecorridosServicio recorridos;

    public MenuGuia(Consola consola, MisRecorridosServicio recorridos) {
        this.consola = consola;
        this.recorridos = recorridos;
    }

    @Override
    public boolean correspondeA(Usuario usuario) {
        return usuario.tienePermiso(Permiso.VER_RECORRIDOS_PROPIOS);
    }

    @Override
    public void mostrar(Usuario usuario) {
        consola.mostrar("\n--- MIS RECORRIDOS ---");
        var lista = recorridos.consultar(usuario);
        if (lista.isEmpty()) {
            consola.mostrar("No tenés recorridos asignados.");
        }
        for (var r : lista) {
            consola.mostrar(r.asignacion().getHora() + " a " + r.horaFin() + "  " + r.itinerario().getCodigo()
                    + "  (" + r.itinerario().getDuracion().toMinutes() + " min, "
                    + r.itinerario().getLongitudKilometros() + " km, hasta "
                    + r.itinerario().getMaximoVisitantes() + " personas)");
            consola.mostrar("   Zonas: " + r.zonas().stream().map(Zona::getNombre).collect(Collectors.joining(", ")));
            consola.mostrar("   Especies: " + r.especies().stream().map(Especie::getNombreEspanol)
                    .collect(Collectors.joining(", ")));
        }
        consola.texto("Enter para cerrar sesión...");
    }
}
