package grupoctema12.consola;

import java.io.Console;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;
import java.util.function.Function;

/**
 * Lectura y escritura por teclado. Separada de los menús para que estos
 * solo se ocupen de qué mostrar (responsabilidad única).
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class Consola {
    private final Scanner entrada = new Scanner(System.in);

    public void mostrar(String texto) {
        System.out.println(texto);
    }

    public String texto(String etiqueta) {
        System.out.print(etiqueta);
        return entrada.hasNextLine() ? entrada.nextLine().strip() : "";
    }

    /** Lee la contraseña sin mostrarla si la terminal lo permite (en NetBeans se ve). */
    public String contrasena(String etiqueta) {
        Console c = System.console();
        if (c != null) {
            char[] clave = c.readPassword(etiqueta);
            return clave == null ? "" : new String(clave);
        }
        return texto(etiqueta);
    }

    public int entero(String etiqueta) {
        while (true) {
            try {
                return Integer.parseInt(texto(etiqueta));
            } catch (NumberFormatException ex) {
                mostrar("Ingresá un número entero.");
            }
        }
    }

    public double decimal(String etiqueta) {
        while (true) {
            try {
                return Double.parseDouble(texto(etiqueta).replace(',', '.'));
            } catch (NumberFormatException ex) {
                mostrar("Ingresá un número.");
            }
        }
    }

    public LocalDate fecha(String etiqueta) {
        while (true) {
            try {
                return LocalDate.parse(texto(etiqueta + " (AAAA-MM-DD): "));
            } catch (DateTimeParseException ex) {
                mostrar("Formato inválido.");
            }
        }
    }

    public LocalTime hora(String etiqueta) {
        while (true) {
            try {
                return LocalTime.parse(texto(etiqueta + " (HH:MM): "));
            } catch (DateTimeParseException ex) {
                mostrar("Formato inválido.");
            }
        }
    }

    /** Muestra una lista numerada y devuelve el elemento elegido, o null si se cancela con 0. */
    public <T> T elegir(String titulo, List<T> opciones, Function<T, String> descripcion) {
        if (opciones.isEmpty()) {
            mostrar("No hay " + titulo.toLowerCase() + " cargados.");
            return null;
        }
        mostrar(titulo + ":");
        for (int i = 0; i < opciones.size(); i++) {
            mostrar("  " + (i + 1) + ". " + descripcion.apply(opciones.get(i)));
        }
        while (true) {
            int n = entero("Número (0 cancela): ");
            if (n == 0) {
                return null;
            }
            if (n >= 1 && n <= opciones.size()) {
                return opciones.get(n - 1);
            }
            mostrar("Opción inválida.");
        }
    }
}
