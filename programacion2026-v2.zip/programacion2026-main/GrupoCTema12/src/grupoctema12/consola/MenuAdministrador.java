package grupoctema12.consola;

import grupoctema12.excepciones.MundoMarinoException;
import grupoctema12.modelo.AsignacionCuidado;
import grupoctema12.modelo.AsignacionGuia;
import grupoctema12.modelo.Cuidador;
import grupoctema12.modelo.Especie;
import grupoctema12.modelo.Guia;
import grupoctema12.modelo.Habitat;
import grupoctema12.modelo.Itinerario;
import grupoctema12.modelo.Permiso;
import grupoctema12.modelo.Rol;
import grupoctema12.modelo.Usuario;
import grupoctema12.modelo.Zona;
import grupoctema12.servicio.Datos;
import grupoctema12.servicio.Servicios;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Menú de consola del administrador. Las mismas operaciones están en la web;
 * ambos usan los mismos servicios (la lógica no se repite).
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class MenuAdministrador implements MenuRol {
    private final Consola c;
    private final Servicios s;

    public MenuAdministrador(Consola consola, Servicios servicios) {
        this.c = consola;
        this.s = servicios;
    }

    @Override
    public boolean correspondeA(Usuario usuario) {
        return usuario.tienePermiso(Permiso.ADMINISTRAR_PARQUE);
    }

    @Override
    public void mostrar(Usuario admin) {
        int opcion;
        do {
            c.mostrar("\n--- MENÚ ADMINISTRADOR ---");
            c.mostrar("1. Ver resumen");
            c.mostrar("2. Registrar zona");
            c.mostrar("3. Registrar hábitat");
            c.mostrar("4. Registrar especie");
            c.mostrar("5. Registrar itinerario");
            c.mostrar("6. Registrar guía o cuidador");
            c.mostrar("7. Asignar guía a itinerario (horario)");
            c.mostrar("8. Asignar cuidador a especie");
            c.mostrar("9. Quitar una asignación");
            c.mostrar("0. Cerrar sesión");
            opcion = c.entero("Opción: ");
            try {
                switch (opcion) {
                    case 1 -> resumen(admin);
                    case 2 -> s.zonas().crear(admin, new Datos.Zona(c.texto("Nombre: "), c.decimal("Extensión (m²): ")));
                    case 3 -> s.habitats().crear(admin, new Datos.Habitat(c.texto("Nombre: "), c.texto("Clima: "),
                            c.texto("Vegetación: "), lista(c.texto("Continentes (separados por coma): "))));
                    case 4 -> registrarEspecie(admin);
                    case 5 -> registrarItinerario(admin);
                    case 6 -> registrarEmpleado(admin);
                    case 7 -> asignarGuia(admin);
                    case 8 -> asignarCuidador(admin);
                    case 9 -> quitarAsignacion(admin);
                    case 0 -> { }
                    default -> c.mostrar("Opción inválida.");
                }
                if (opcion >= 2 && opcion <= 9) {
                    c.mostrar("Listo.");
                }
            } catch (MundoMarinoException ex) {
                c.mostrar("No se pudo completar: " + ex.getMessage());
            }
        } while (opcion != 0);
    }

    private void resumen(Usuario admin) {
        Map<UUID, String> zonas = s.zonas().listar(admin).stream().collect(Collectors.toMap(Zona::getId, Zona::getNombre));
        c.mostrar("\nESPECIES");
        s.especies().listar(admin).forEach(e -> c.mostrar("  " + e.getNombreEspanol() + " · zona: "
                + e.getZonaId().map(zonas::get).orElse("sin zona")));
        c.mostrar("ITINERARIOS");
        s.itinerarios().listar(admin).forEach(i -> c.mostrar("  " + i.getCodigo() + " · " + i.getDuracion().toMinutes()
                + " min · zonas: " + s.itinerarios().zonasDe(i).stream().map(Zona::getNombre).collect(Collectors.joining(", "))));
        Map<UUID, String> nombres = s.personal().listar(admin).stream().collect(Collectors.toMap(Usuario::getId, Usuario::getNombre));
        Map<UUID, String> codigos = s.itinerarios().listar(admin).stream().collect(Collectors.toMap(Itinerario::getId, Itinerario::getCodigo));
        Map<UUID, String> especies = s.especies().listar(admin).stream().collect(Collectors.toMap(Especie::getId, Especie::getNombreEspanol));
        c.mostrar("HORARIOS DE GUÍAS");
        s.asignacionesGuia().listar(admin).forEach(a -> c.mostrar("  " + a.getHora() + " · " + nombres.get(a.getGuiaId())
                + " · " + codigos.get(a.getItinerarioId())));
        c.mostrar("CUIDADOS");
        s.asignacionesCuidado().listar(admin).forEach(a -> c.mostrar("  " + nombres.get(a.getCuidadorId()) + " → "
                + especies.get(a.getEspecieId()) + " desde " + a.getFechaAsignacion()));
    }

    private void registrarEspecie(Usuario admin) {
        String nombre = c.texto("Nombre en español: ");
        String cientifico = c.texto("Nombre científico: ");
        String descripcion = c.texto("Descripción: ");
        Zona zona = c.elegir("Zonas", s.zonas().listar(admin), Zona::getNombre);
        Habitat habitat = c.elegir("Hábitats", s.habitats().listar(admin), Habitat::getNombre);
        s.especies().crear(admin, new Datos.Especie(nombre, cientifico, descripcion,
                zona == null ? null : zona.getId(), habitat == null ? Set.of() : Set.of(habitat.getId())));
    }

    private void registrarItinerario(Usuario admin) {
        int numero = c.entero("Número (1-99, genera IT-XX): ");
        int duracion = c.entero("Duración (minutos): ");
        double longitud = c.decimal("Longitud (km): ");
        int maximo = c.entero("Máximo de visitantes: ");
        Set<UUID> especies = new LinkedHashSet<>();
        Especie e;
        while ((e = c.elegir("Especies (0 para terminar)", s.especies().listar(admin), Especie::getNombreEspanol)) != null) {
            especies.add(e.getId());
        }
        s.itinerarios().crear(admin, new Datos.Itinerario(numero, duracion, longitud, maximo, especies));
    }

    private void registrarEmpleado(Usuario admin) {
        Rol rol = c.entero("1 = Guía, 2 = Cuidador: ") == 1 ? Rol.GUIA : Rol.CUIDADOR;
        s.personal().crear(admin, new Datos.Empleado(rol, c.texto("Usuario: ").toLowerCase(),
                c.contrasena("Contraseña inicial: "), c.texto("Nombre completo: "), c.texto("Dirección: "),
                c.texto("Teléfono: "), c.fecha("Fecha de ingreso")));
    }

    private void asignarGuia(Usuario admin) {
        Guia g = c.elegir("Guías", s.personal().listarGuias(admin), Guia::getNombre);
        Itinerario i = g == null ? null : c.elegir("Itinerarios", s.itinerarios().listar(admin), Itinerario::getCodigo);
        if (i != null) {
            s.asignacionesGuia().asignar(admin, g.getId(), i.getId(), c.hora("Hora de salida"));
        }
    }

    private void asignarCuidador(Usuario admin) {
        Cuidador cu = c.elegir("Cuidadores", s.personal().listarCuidadores(admin), Cuidador::getNombre);
        Especie e = cu == null ? null : c.elegir("Especies", s.especies().listar(admin), Especie::getNombreEspanol);
        if (e != null) {
            s.asignacionesCuidado().asignar(admin, cu.getId(), e.getId(), c.fecha("Fecha de inicio"));
        }
    }

    private void quitarAsignacion(Usuario admin) {
        Map<UUID, String> nombres = s.personal().listar(admin).stream().collect(Collectors.toMap(Usuario::getId, Usuario::getNombre));
        if (c.entero("1 = Horario de guía, 2 = Cuidado: ") == 1) {
            Map<UUID, String> codigos = s.itinerarios().listar(admin).stream().collect(Collectors.toMap(Itinerario::getId, Itinerario::getCodigo));
            Function<AsignacionGuia, String> d = a -> a.getHora() + " " + nombres.get(a.getGuiaId()) + " " + codigos.get(a.getItinerarioId());
            AsignacionGuia a = c.elegir("Horarios", s.asignacionesGuia().listar(admin), d);
            if (a != null) {
                s.asignacionesGuia().eliminar(admin, a.getId());
            }
        } else {
            Map<UUID, String> especies = s.especies().listar(admin).stream().collect(Collectors.toMap(Especie::getId, Especie::getNombreEspanol));
            Function<AsignacionCuidado, String> d = a -> nombres.get(a.getCuidadorId()) + " → " + especies.get(a.getEspecieId());
            AsignacionCuidado a = c.elegir("Cuidados", s.asignacionesCuidado().listar(admin), d);
            if (a != null) {
                s.asignacionesCuidado().eliminar(admin, a.getId());
            }
        }
    }

    private static Set<String> lista(String texto) {
        return Arrays.stream(texto.split(",")).map(String::strip).filter(t -> !t.isEmpty())
                .collect(Collectors.toCollection(LinkedHashSet::new));
    }
}
