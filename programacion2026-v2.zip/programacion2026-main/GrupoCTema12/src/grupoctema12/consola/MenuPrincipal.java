package grupoctema12.consola;

import grupoctema12.excepciones.MundoMarinoException;
import grupoctema12.modelo.Usuario;
import grupoctema12.servicio.AutenticacionServicio;
import java.util.List;

/**
 * Inicio de sesión por consola y derivación al menú del rol.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class MenuPrincipal {
    private final Consola consola;
    private final AutenticacionServicio autenticacion;
    private final List<MenuRol> menus;

    public MenuPrincipal(Consola consola, AutenticacionServicio autenticacion, List<MenuRol> menus) {
        this.consola = consola;
        this.autenticacion = autenticacion;
        this.menus = menus;
    }

    public void iniciar() {
        while (true) {
            consola.mostrar("\n=== MUNDO MARINO · Sistema del personal ===");
            String usuario = consola.texto("Usuario (vacío para salir): ");
            if (usuario.isEmpty()) {
                consola.mostrar("Hasta luego.");
                return;
            }
            try {
                Usuario u = autenticacion.autenticar(usuario, consola.contrasena("Contraseña: "));
                consola.mostrar("Hola, " + u.getNombre() + " (" + u.getRol() + ").");
                menus.stream().filter(m -> m.correspondeA(u)).findFirst()
                        .ifPresentOrElse(m -> m.mostrar(u), () -> consola.mostrar("No hay un menú para tu rol."));
            } catch (MundoMarinoException ex) {
                consola.mostrar(ex.getMessage());
            }
        }
    }
}
