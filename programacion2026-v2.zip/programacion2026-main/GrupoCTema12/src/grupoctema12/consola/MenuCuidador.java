package grupoctema12.consola;

import grupoctema12.modelo.Habitat;
import grupoctema12.modelo.Permiso;
import grupoctema12.modelo.Usuario;
import grupoctema12.modelo.Zona;
import grupoctema12.servicio.MisEspeciesServicio;
import java.util.stream.Collectors;

/**
 * El cuidador ve solo las especies que tiene a cargo.
 *
 *
 * @author Jean Pier Graterol
 * @author Mauricio Castellano
 * @version 2.0
 */
public final class MenuCuidador implements MenuRol {
    private final Consola consola;
    private final MisEspeciesServicio especies;

    public MenuCuidador(Consola consola, MisEspeciesServicio especies) {
        this.consola = consola;
        this.especies = especies;
    }

    @Override
    public boolean correspondeA(Usuario usuario) {
        return usuario.tienePermiso(Permiso.VER_ESPECIES_PROPIAS);
    }

    @Override
    public void mostrar(Usuario usuario) {
        consola.mostrar("\n--- ESPECIES A MI CARGO ---");
        var lista = especies.consultar(usuario);
        if (lista.isEmpty()) {
            consola.mostrar("No tenés especies asignadas.");
        }
        for (var e : lista) {
            consola.mostrar(e.especie().getNombreEspanol() + " (" + e.especie().getNombreCientifico() + ") desde "
                    + e.asignacion().getFechaAsignacion());
            consola.mostrar("   Zona: " + e.zona().map(Zona::getNombre).orElse("sin zona"));
            consola.mostrar("   Hábitats: " + e.habitats().stream().map(Habitat::getNombre).collect(Collectors.joining(", ")));
            consola.mostrar("   También la cuidan: " + (e.otrosCuidadores().isEmpty() ? "nadie más"
                    : String.join(", ", e.otrosCuidadores())));
        }
        consola.texto("Enter para cerrar sesión...");
    }
}
