-- =============================================================
-- Mundo Marino v2.0: esquema para MySQL 8
-- Cada tabla corresponde a un DAO del paquete grupoctema12.dao.
-- Los ids son UUID guardados como texto (CHAR(36)), igual que en Java.
-- =============================================================
CREATE DATABASE IF NOT EXISTS mundo_marino CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE mundo_marino;

-- ZonaDao
CREATE TABLE zona (
  id            CHAR(36)      PRIMARY KEY,
  nombre        VARCHAR(80)   NOT NULL UNIQUE,
  extension_m2  DECIMAL(10,2) NOT NULL CHECK (extension_m2 > 0)
);

-- HabitatDao
CREATE TABLE habitat (
  id          CHAR(36)     PRIMARY KEY,
  nombre      VARCHAR(80)  NOT NULL UNIQUE,
  clima       VARCHAR(80)  NOT NULL,
  vegetacion  VARCHAR(120) NOT NULL
);
CREATE TABLE habitat_continente (
  habitat_id  CHAR(36)    NOT NULL,
  continente  VARCHAR(30) NOT NULL,
  PRIMARY KEY (habitat_id, continente),
  FOREIGN KEY (habitat_id) REFERENCES habitat(id) ON DELETE CASCADE
);

-- EspecieDao (ver dao/jdbc/EspecieDaoJdbc.java)
CREATE TABLE especie (
  id                 CHAR(36)     PRIMARY KEY,
  nombre_espanol     VARCHAR(80)  NOT NULL,
  nombre_cientifico  VARCHAR(120) NOT NULL UNIQUE,
  descripcion        VARCHAR(500) NOT NULL,
  zona_id            CHAR(36)     NULL,
  FOREIGN KEY (zona_id) REFERENCES zona(id)
);
CREATE TABLE especie_habitat (
  especie_id  CHAR(36) NOT NULL,
  habitat_id  CHAR(36) NOT NULL,
  PRIMARY KEY (especie_id, habitat_id),
  FOREIGN KEY (especie_id) REFERENCES especie(id) ON DELETE CASCADE,
  FOREIGN KEY (habitat_id) REFERENCES habitat(id)
);

-- ItinerarioDao (las zonas NO se guardan: se calculan desde las especies)
CREATE TABLE itinerario (
  id                 CHAR(36)     PRIMARY KEY,
  codigo             CHAR(5)      NOT NULL UNIQUE,         -- IT-01
  duracion_minutos   INT          NOT NULL CHECK (duracion_minutos BETWEEN 5 AND 480),
  longitud_km        DECIMAL(5,2) NOT NULL CHECK (longitud_km > 0),
  maximo_visitantes  INT          NOT NULL CHECK (maximo_visitantes BETWEEN 1 AND 500)
);
CREATE TABLE itinerario_especie (
  itinerario_id  CHAR(36) NOT NULL,
  especie_id     CHAR(36) NOT NULL,
  orden          INT      NOT NULL,
  PRIMARY KEY (itinerario_id, especie_id),
  FOREIGN KEY (itinerario_id) REFERENCES itinerario(id) ON DELETE CASCADE,
  FOREIGN KEY (especie_id) REFERENCES especie(id)
);

-- UsuarioDao: una sola tabla para Administrador, Guia y Cuidador
-- ("single table inheritance"). La columna rol indica la subclase.
CREATE TABLE usuario (
  id               CHAR(36)     PRIMARY KEY,
  rol              ENUM('ADMINISTRADOR','GUIA','CUIDADOR') NOT NULL,
  nombre_usuario   VARCHAR(30)  NOT NULL UNIQUE,
  hash_contrasena  VARCHAR(200) NOT NULL,                  -- PBKDF2, nunca la clave real
  nombre           VARCHAR(80)  NOT NULL,
  direccion        VARCHAR(120) NULL,                      -- solo empleados
  telefono         VARCHAR(20)  NULL,
  fecha_ingreso    DATE         NULL
);

-- AsignacionGuiaDao
CREATE TABLE asignacion_guia (
  id             CHAR(36) PRIMARY KEY,
  guia_id        CHAR(36) NOT NULL,
  itinerario_id  CHAR(36) NOT NULL,
  hora           TIME     NOT NULL,
  FOREIGN KEY (guia_id)       REFERENCES usuario(id),
  FOREIGN KEY (itinerario_id) REFERENCES itinerario(id),
  INDEX idx_asig_guia (guia_id, hora)
  -- La superposición de horarios (hora + duración) se controla en
  -- VerificadorHorarios, porque depende de la duración del itinerario.
);

-- AsignacionCuidadoDao
CREATE TABLE asignacion_cuidado (
  id                CHAR(36) PRIMARY KEY,
  cuidador_id       CHAR(36) NOT NULL,
  especie_id        CHAR(36) NOT NULL,
  fecha_asignacion  DATE     NOT NULL,
  UNIQUE (cuidador_id, especie_id),
  FOREIGN KEY (cuidador_id) REFERENCES usuario(id),
  FOREIGN KEY (especie_id)  REFERENCES especie(id)
);

-- Usuario de la aplicación con permisos mínimos (no usar root desde Java):
-- CREATE USER 'mm_app'@'localhost' IDENTIFIED BY 'cambiar-esta-clave';
-- GRANT SELECT, INSERT, UPDATE, DELETE ON mundo_marino.* TO 'mm_app'@'localhost';
